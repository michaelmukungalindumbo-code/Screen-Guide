package zm.screenguide

import org.json.JSONArray

// v0.124 stub: tests first
object Status {
    class Item(val id: String, val title: String, val steps: Int, val by: String, val device: String, val gets: Int, val mine: Boolean)
    fun items(a: JSONArray?): List<Item> = emptyList()
    fun steps(n: Int) = ""
    fun gotIt(n: Int) = ""
    fun line(it: Item): String = ""
    fun words(steps: List<Step>): List<String> = emptyList()
    fun canPost(steps: List<Step>): Boolean = true
    fun firstName(name: String): String = name
    fun shownAs(name: String) = name
    fun confirm(words: List<String>, name: String): String = ""
    fun preview(it: Item, says: List<String>): String = ""
    fun stepsJson(steps: List<Step>): JSONArray = JSONArray()
    val REPORT_WHY = emptyList<String>()
}
