package zm.screenguide

// tests first: not built yet
object Quoted {
    const val KEEP = 400
    fun of(m: Msg): String = ""
    fun who(mine: Boolean) = ""
    fun original(msgs: List<Msg>, at: Int, quote: String, mine: Boolean): Int = -2
    fun context(quote: String, mine: Boolean): String = ""
    fun history(base: List<String>, asked: Msg?): List<String> = emptyList()
    fun showable(replyTo: Msg?, said: String, showWords: Set<String>): Msg? = null
    fun about(asked: Msg?): String? = null
}
