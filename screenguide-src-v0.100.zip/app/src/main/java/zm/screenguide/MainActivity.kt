package zm.screenguide

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.app.Dialog
import android.content.res.ColorStateList
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.text.TextUtils
import android.view.Window
import android.os.CancellationSignal
import androidx.credentials.CredentialManager
import androidx.credentials.CredentialManagerCallback
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.GetCredentialResponse
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.GetCredentialException
import androidx.credentials.exceptions.NoCredentialException
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.util.Base64
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.*
import java.io.ByteArrayOutputStream
import java.util.Locale

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

// The chat screen: header at the top, the conversation in the middle, the message box fixed at the bottom.
class MainActivity : Activity() {
    private var typed = ""
    private var note = ""
    private var convs: ArrayList<Conv> = ArrayList()
    private var cur: Conv? = null
    private var incognito = false
    private var waiting = false
    private var attached: List<String> = emptyList()
    private var attachedThumb: Bitmap? = null
    private var input: EditText? = null
    private var thinkingView: TextView? = null
    private var dots = 0
    private var waitStart = 0L
    private var reqId = 0    // a newer request (or Stop) makes older answers arrive to nobody
    private var failed = false
    private val ui = Handler(Looper.getMainLooper())
    private val dotsRun = object : Runnable {
        override fun run() {
            val v = thinkingView ?: return
            dots = (dots + 1) % 4
            val slow = System.currentTimeMillis() - waitStart > 10000
            v.text = (if (slow) "Still thinking. The connection is slow" else "Thinking") + ".".repeat(dots)
            ui.postDelayed(this, 400)
        }
    }

    // Light by default (easier in sunlight); follows the phone's dark mode when it is on.
    private val dark: Boolean get() = when (Profile.str(this, "theme", "auto")) {
        "light" -> false; "dark" -> true
        else -> (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    }
    private val ink: Int get() = if (dark) 0xFFF2F4F5.toInt() else 0xFF1F1A14.toInt()
    private val mute: Int get() = if (dark) 0xFFADB5BA.toInt() else 0xFF534C45.toInt()
    private val green: Int get() = if (dark) 0xFF18C3DA.toInt() else 0xFF145A3D.toInt()       // accent
    private val onAccent: Int get() = if (dark) 0xFF06262C.toInt() else Color.WHITE            // text on the accent colour
    private val paper: Int get() = if (dark) 0xFF0B0D0F.toInt() else 0xFFFAF6EF.toInt()
    private val chatBg: Int get() = ChatBackground.color(Profile.str(this, "chat_bg", "default"), dark)   // Customize: Chat background
    // "Your photo" (6 Nov): a picture from the gallery behind the chat. Kept only on this phone, never sent anywhere.
    private val bgFile: java.io.File get() = java.io.File(filesDir, "chat_bg.jpg")
    private var bgPhoto: Bitmap? = null
    private var bgPhotoAt = 0L
    private fun photoBg(): Bitmap? {
        if (Profile.str(this, "chat_bg", "default") != ChatBackground.PHOTO || !bgFile.exists()) return null
        if (bgPhoto == null || bgPhotoAt != bgFile.lastModified()) {
            bgPhoto = try { BitmapFactory.decodeFile(bgFile.path) } catch (e: Throwable) { null }; bgPhotoAt = bgFile.lastModified()
        }
        return bgPhoto
    }
    // Softer / Normal / Stronger (6 Nov). Kept on this phone, like the photo. Stronger is measured on the photo itself.
    private val bgStrength: String get() = getSharedPreferences("sg", MODE_PRIVATE).getString("bg_strength", "normal") ?: "normal"
    private var bgStrongest = ChatBackground.SCRIM
    private var bgStrongestKey = ""
    private fun strongestFor(b: Bitmap): Double {
        val key = "$bgPhotoAt/$dark"
        if (key != bgStrongestKey) {
            bgStrongest = try {
                val s = Bitmap.createScaledBitmap(b, 32, maxOf(1, 32 * b.height / maxOf(1, b.width)), true)
                val px = IntArray(s.width * s.height); s.getPixels(px, 0, s.width, 0, 0, s.width, s.height)
                ChatBackground.strongest(px, paper, ink, mute, green)
            } catch (e: Throwable) { ChatBackground.SCRIM }
            bgStrongestKey = key
        }
        return bgStrongest
    }
    private val line: Int get() = if (dark) 0xFF2A3034.toInt() else 0xFFE3D8C6.toInt()
    private val card: Int get() = if (dark) 0xFF14181B.toInt() else Color.WHITE
    private val chipBg: Int get() = if (dark) 0xFF1E2428.toInt() else 0xFFF1EADD.toInt()
    private val iconBg: Int get() = if (dark) 0xFF0F2C33.toInt() else 0xFFE3F2EA.toInt()
    private val warmBg: Int get() = if (dark) 0xFF2A2417.toInt() else 0xFFFFF4E0.toInt()
    private val warmLine: Int get() = if (dark) 0xFF5A4A24.toInt() else 0xFFF1D9A8.toInt()
    private val noteColor: Int get() = if (dark) 0xFFF0A935.toInt() else 0xFF8A3B05.toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Crash.install(this); Crash.sendPending(this)
        Server.initTester(this)
        Guides.load(this); Server.installId(this); Server.wake(); convs = ChatStore.load(this)
        Server.pass = getSharedPreferences("sg", MODE_PRIVATE).getString("pass", "") ?: ""
        Account.load(this)
        Server.flush(this)
        build()
        Sync.atStart(this) { runOnUiThread { build() } }
        Thread { fetchVoicePack() }.start()
        // Fetch the latest guides from the server in the background; the screen updates if they changed.
        Thread { Server.guides()?.let { t -> runOnUiThread { if (Guides.applyRemote(this, t)) build() } } }.start()
        handleIntent(intent)
    }
    override fun onNewIntent(i: Intent) { super.onNewIntent(i); setIntent(i); handleIntent(i) }

    // screenguide://g/K7M2QX (the "Open in ScreenGuide" button on a shared guide's page), or back from teaching a task.
    private fun handleIntent(i: Intent?) {
        if (i == null) return
        // v0.94: "Your answer is ready" was tapped: that chat
        val chat = i.getLongExtra(Notify.EXTRA_CHAT, 0L)
        if (chat != 0L) {
            i.removeExtra(Notify.EXTRA_CHAT)
            val c = convs.firstOrNull { it.id == chat }
            ui.post { if (c != null && c !== cur) openChat(c) else build() }
            return
        }
        if (i.getBooleanExtra("teach_review", false)) { i.removeExtra("teach_review"); ui.post { showTeachReview() }; return }
        // "Show me how" on an error card: a built-in task (battery saver) or a Smart guide (free up storage).
        val fixGuide = i.getStringExtra("fix_guide"); val fixGoal = i.getStringExtra("fix_goal")
        if (fixGuide != null || fixGoal != null) {
            i.removeExtra("fix_guide"); i.removeExtra("fix_goal")
            val g = fixGuide?.let { id -> Guides.all.firstOrNull { it.id == id } }
            ui.post { if (g != null) start(g) else fixGoal?.let { startSmart(it, false, emptyList()) } }
            return
        }
        val d = i.data ?: return
        if (d.scheme == "screenguide" && d.host == "g") {
            val code = d.path?.trim('/').orEmpty()
            i.data = null
            if (code.isNotEmpty()) ui.post { openShared(code) }
        }
    }
    // The intro (the "Try it now" card, the tasks, the safety card) shows on the first visit only. After that the home
    // screen stays clean and the tasks live in the menu ("Learn your phone"). Leaving to do a task does not end the
    // first visit, so the person comes back to see their first tick.
    private var showIntro = false
    private var leavingForGuide = false
    override fun onStart() {
        super.onStart()
        val sp = getSharedPreferences("sg", MODE_PRIVATE)
        showIntro = !sp.getBoolean("intro_done", false)
        sp.edit().putInt("visits", sp.getInt("visits", 0) + 1).apply()   // the example questions change on each visit
    }
    override fun onStop() {
        if (showIntro && !leavingForGuide && enabled()) getSharedPreferences("sg", MODE_PRIVATE).edit().putBoolean("intro_done", true).apply()
        leavingForGuide = false
        super.onStop()
    }

    // v0.94: on the screen or not, for "Your answer is ready" (Notify)
    private var onScreen = false
    // v0.94: failed answers in a row ("can't reach", then "isn't available"); something above fits the question
    private var failsInRow = 0
    private var wayOn = false
    override fun onPause() { onScreen = false; super.onPause() }

    override fun onResume() {
        super.onResume(); onScreen = true; Notify.clear(this); build(); Server.wake()
        val sp = getSharedPreferences("sg", MODE_PRIVATE)
        if (enabled() && !sp.getBoolean("setup_on_counted", false)) { sp.edit().putBoolean("setup_on_counted", true).apply(); Server.event(this, "setup", "on") }
        val p = pending
        if (p != null && enabled()) { pending = null; p(); return }
        if (enabled() && !sp.getBoolean("extras_offered", false)) ui.postDelayed({ if (!isFinishing) offerExtras() }, 600)
    }

    // Once, after ScreenGuide is turned on: help that works on any screen. Each needs a clear yes (Google Play rule).
    private fun offerExtras() {
        val sp = getSharedPreferences("sg", MODE_PRIVATE)
        if (sp.getBoolean("extras_offered", false)) return
        sp.edit().putBoolean("extras_offered", true).apply()
        val names = arrayOf("Read button: a round button that reads any screen to you, in your language (sends that screen's words to get the reading)",
            "Explain error messages like \u201CStorage full\u201D in simple words (on your phone only)",
            "Scam guard: warns you if someone gets you to install an app that controls your phone (on your phone only)")
        val keys = arrayOf("read_button", "explain_errors", "scam_guard")
        val pick = booleanArrayOf(true, true, true)
        AlertDialog.Builder(this).setTitle("Extra help on any screen")
            .setMultiChoiceItems(names, pick) { _, i, on -> pick[i] = on }
            .setPositiveButton("Turn on") { _, _ ->
                val e = sp.edit(); keys.forEachIndexed { i, k -> e.putBoolean(k, pick[i]) }; e.apply()
                keys.forEachIndexed { i, k -> if (pick[i]) Server.event(this, "extra", k) }
                if (pick[0] && !sp.getBoolean("smart_ok", false)) askSmart { build() }
            }
            .setNegativeButton("Not now", null).show()
    }
    override fun onDestroy() { ui.removeCallbacks(dotsRun); tts?.shutdown(); super.onDestroy() }

    private fun enabled() =
        (Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: "").contains(packageName)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun bg(color: Int, radius: Int, oval: Boolean = false, stroke: Int = 0) = GradientDrawable().apply {
        setColor(color)
        if (stroke != 0) setStroke(dp(1), stroke)
        if (oval) shape = GradientDrawable.OVAL else cornerRadius = dp(radius).toFloat()
    }
    private fun lp(top: Int = 0, bottom: Int = 0) =
        LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(0, dp(top), 0, dp(bottom)) }

    // A short tick under the finger, so people feel that the tap worked.
    private fun View.onTap(f: () -> Unit) = setOnClickListener { v ->
        if (Profile.buzzOn(this@MainActivity)) v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY); f()
    }

    private fun goHome() =
        startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))

    // What the person asked for before ScreenGuide was turned on. It starts by itself when they come back.
    private var pending: (() -> Unit)? = null

    private fun needOn(then: () -> Unit): Boolean {
        if (enabled()) return false
        pending = then; consent(); return true
    }

    // alone = "Let me try alone": no ring at first (see GuideService.tryAlone).
    private fun start(g: Guide, alone: Boolean = false) {
        // v0.96: a tablet with no flash has no torch: say so, instead of looking for it forever
        if (g.id == "torch" && Guides.noTorch) { AlertDialog.Builder(this).setMessage(Guides.NO_TORCH).setPositiveButton("OK", null).show(); return }
        if (needOn { start(g, alone) }) return
        Guides.practice = alone; Guides.practiceHelped = false; Teach.on = false
        Live.id?.let { lid -> val key = Live.key; val iid = Server.installId(this); Thread { Server.liveEnd(lid, key, iid) }.start(); Live.stop() }
        Stats.inc(this, if (alone) "started_alone" else "started"); Server.event(this, "start", g.id); Guides.active = g; Guides.index = 0
        learnDialog?.dismiss(); leavingForGuide = true
        goHome()
    }

    private fun norm(s: String) = s.lowercase().filter { it.isLetterOrDigit() }
    private fun score(g: Guide, text: String) = Match.score(g.keywords, text)   // tested in MatchTest

    // Questions about a problem ("why is my wifi not working") need the helper, not the "turn it on" guide.
    private fun isProblem(text: String) = Match.isProblem(text)

    // Replies that mean "yes, show me" right after an answer that can be shown on screen.
    private val showWords = setOf("showme", "showmehow", "showmewhere", "yesshowme", "okshowme", "pleaseshowme", "showmeplease",
        "guideme", "yes", "yesplease", "ok", "okay", "doit", "go", "start", "letsgo", "yesshowmeplease")

    private fun ask(text: String) {
        hideKeyboard()
        if (waiting) { Toast.makeText(this, "One moment…", Toast.LENGTH_SHORT).show(); return }
        val t = norm(text)
        if (t.isEmpty() && attached.isEmpty()) return
        editing?.let { e ->   // sending an edited message: drop the old one and the answers after it
            val c = cur
            if (c != null) { val i = c.msgs.indexOf(e); if (i >= 0) while (c.msgs.size > i) c.msgs.removeAt(c.msgs.size - 1) }
            editing = null; persist()
        }
        Stats.inc(this, "questions")
        input = null; typed = ""
        val re = replyTo?.takeIf { r -> cur?.msgs?.contains(r) == true }; replyTo = null   // v0.100: this message replies to that one
        build()   // v0.92 (the owner's test, 7 Nov): the question must not stay in the box behind a "turned off" or "install" box
        if (attached.isNotEmpty()) { askServer(if (text.isBlank()) "What should I do next on this screen?" else text.trim(), re = re); return }
        if (re != null) {
            // "Show me" or "yes" as a reply to an answer that can be shown: that answer's guide, even an older one. Anything
            // else goes to the helper with the message it is about (never to a guide picked from its key words alone).
            Stats.inc(this, "replies")
            val shown = Quoted.showable(re, text, showWords)
            if (shown != null) {
                cur?.msgs?.add(Msg(true, text.trim(), quote = Quoted.of(re), quoteMine = re.mine)); persist()
                val opens = shown.guideId?.let { openOf(it) }
                val builtIn = shown.guideId?.let { id -> Guides.all.firstOrNull { it.id == id } }
                val finds = shown.guideId?.let { findOf(it) }
                if (opens != null) openLocal(opens.first, opens.second, rowOf(shown.guideId))
                else if (finds != null) openByName(finds)
                else if (builtIn != null) start(builtIn) else shown.goal?.let { startSmart(it, shown.needsApps, shown.plan) }
                return
            }
            askServer(text.trim(), re = re); return
        }
        // "Show me" typed: start the latest answer that can be shown on screen, even one or two answers back (seen: after
        // "What is an Excel sheet?", "Show me" was sent to the server twice instead of starting the Drive guide).
        // "ok" or "yes" only ever means the answer just given.
        val last = cur?.msgs?.lastOrNull()
        val strong = t.startsWith("showme") || t in setOf("guideme", "doit", "pointtoit")
        val showable = if (t !in showWords && !strong) null
            else if (strong) cur?.msgs?.takeLast(8)?.lastOrNull { !it.mine && (it.goal != null || it.guideId != null) }
            else last?.takeIf { !it.mine && (it.goal != null || it.guideId != null) }
        if (showable != null) {
            cur?.msgs?.add(Msg(true, text.trim())); persist()
            val opens = showable.guideId?.let { openOf(it) }
            val builtIn = showable.guideId?.let { id -> Guides.all.firstOrNull { it.id == id } }
            val finds = showable.guideId?.let { findOf(it) }
            if (opens != null) openLocal(opens.first, opens.second, rowOf(showable.guideId))
            else if (finds != null) openByName(finds)
            else if (builtIn != null) start(builtIn) else showable.goal?.let { startSmart(it, showable.needsApps, showable.plan) }
            return
        }
        // v0.91 (the owner's test, 7 Nov: "How do I use YouTube music"): an app the message names is turned off. Said at once,
        // on the phone, before the helper (which may not be reachable). "Not now" asks the helper as usual.
        // v0.95: "Open YouTube Music" and "Not now": nothing more to do (the helper cannot open it either); a question goes on
        Guides.offApp(this, text)?.let { (n, p) -> offerTurnOn(n, p, if (Match.openWord(text) != null) null else ({ askServer(text.trim()) })); return }
        // v0.91: "Install TikTok" for an app that is not on this phone: the install guide at once, with no helper first (it
        // also says on the phone when the phone is full, offline or waiting for Wi-Fi)
        Match.installTarget(text)?.let { name -> if (Match.pickApp(name, Guides.installedNames(this).map { it to it }) == null) { offerInstall(name); return } }
        if (quickOpen(text)) { build(); return }
        if (!isProblem(text)) {
            val best = Guides.all.maxByOrNull { score(it, text) }
            if (best != null && score(best, text) > 0) { note = ""; build(); start(best); return }
            val app = findApp(text)
            if (app != null) { note = ""; build(); openLocal(app.first, app.second); return }
            if (Server.tester) Match.openWord(text)?.let { w ->
                val names = Guides.launcherApps(this).map { it.first }
                Toast.makeText(this, "Test phone: no app named \u201C$w\u201D among ${names.size} names. Closest: " +
                    Match.closest(w, names).joinToString(", "), Toast.LENGTH_LONG).show()
            }
        }
        askServer(text.trim(), offer = instantOffer(text))
    }

    // ---- v0.91 (the owner's tests, 7 Nov): getting to an app needs no helper ----
    // "Open XTheme", a key term in any question, or a button: the same opening as Smart guides (Search when the icon is out
    // of sight, two copies, a hidden icon), done when the app opens. Nothing is sent, so it works with no data or credit.
    private fun openLocal(name: String, pkg: String, then: String? = null) {
        if (needOn { openLocal(name, pkg, then) }) return
        Stats.inc(this, "started"); Stats.inc(this, "open_local"); Server.event(this, "start", "open")
        Guides.aiReset("Open $name"); Guides.aiApp = name; Guides.aiAppPkg = pkg; Guides.aiJustOpen = true; Guides.aiThen = then
        Guides.active = Guide("ai", mapOf("en" to "Open $name"), mapOf("en" to "Well done!", "ny" to "Zabwino!", "bem" to "Nawamya!"), emptyList(), emptyList())
        Guides.index = 0
        goHome()
    }

    // The app "Open …", "Find …" or "Where is …" names, by either of its names, as (name under the icon, package)
    private fun findApp(text: String): Pair<String, String>? {
        val apps = Guides.launcherApps(this)
        val said = Match.findTarget(text, apps.map { it.first }) ?: return null
        val pkg = apps.firstOrNull { it.first == said }?.second ?: return null
        return (Guides.shownName(this, pkg) ?: said) to pkg
    }

    // While the helper thinks (or when it cannot be reached): the app the question names, or the app a "feature" lives in,
    // offered at once. It goes when the helper's own answer has a guide.
    private fun instantOffer(text: String): Msg? {
        val apps = Guides.launcherApps(this)
        Match.feature(text)?.let { (f, appName) ->
            val pkg = apps.firstOrNull { it.first.equals(appName, true) }?.second
            val row = Match.featureRow(f)
            return Msg(false, Match.featureLine(f, appName) + (if (pkg != null) " I can take you to $appName now." else ""),
                guideId = pkg?.let { "open:$it|$appName" + (if (row != null) "|$row" else "") })
        }
        Match.keyApp(text, apps)?.let { (said, pkg) ->
            val name = Guides.shownName(this, pkg) ?: said
            return Msg(false, "I can take you to $name now.", guideId = "open:$pkg|$name")
        }
        // v0.94 (the owner's test, 8 Nov): "Open xtheme" named nothing on the phone's app list (on Infinix it is part of the
        // home screen). Look for it by what is written under the icon instead.
        val w = Match.openWord(text)?.takeIf { Match.findableName(it) } ?: return null
        val name = Match.titleCase(w)
        return Msg(false, "I can look for \u201C$name\u201D among your apps.", guideId = "find:$name")
    }
    private fun findOf(id: String): String? = if (id.startsWith("find:")) id.removePrefix("find:").ifEmpty { null } else null

    // v0.94: the same opening, by the name under the icon only (no package): done once they tap it
    private fun openByName(name: String) {
        if (needOn { openByName(name) }) return
        Stats.inc(this, "started"); Stats.inc(this, "open_by_name"); Server.event(this, "start", "open")
        Guides.aiReset("Open $name"); Guides.aiApp = name; Guides.aiAppPkg = ""; Guides.aiJustOpen = true
        Guides.active = Guide("ai", mapOf("en" to "Open $name"), mapOf("en" to "Well done!", "ny" to "Zabwino!", "bem" to "Nawamya!"), emptyList(), emptyList())
        Guides.index = 0
        goHome()
    }
    // "open:pkg|Name" or "open:pkg|Name|Row" (v0.95: the row to ring once it is open) -> (Name, pkg)
    private fun openOf(id: String): Pair<String, String>? =
        if (!id.startsWith("open:")) null else id.removePrefix("open:").split("|").let { p -> if (p.size < 2) null else p[1] to p[0] }
    private fun rowOf(id: String?): String? = id?.takeIf { it.startsWith("open:") }?.split("|")?.getOrNull(2)?.ifEmpty { null }

    private fun isMoney(t: String) = Match.isMoney(t)
    private fun noShowMe(t: String): String {
        val kept = t.trim().split(Regex("(?<=[.!?])\\s+")).filterNot { Regex("show me|point to|point at", RegexOption.IGNORE_CASE).containsMatchIn(it) }
        return kept.joinToString(" ").ifBlank { t }
    }

    // The on-screen helper sees only the goal, never the chat. "I want to use it" means nothing on its own,
    // so add the question before it ("What is YouTube"). The server does this too; this covers older servers.
    private fun standAlone(conv: Conv, goal: String, quoted: String? = null): String {
        if (!Regex("\\b(it|this|that|them|there)\\b", RegexOption.IGNORE_CASE).containsMatchIn(goal)) return goal
        if (goal.contains("(about:")) return goal
        val before = quoted ?: conv.msgs.filter { it.mine }.dropLast(1).lastOrNull()?.text?.removePrefix("\uD83D\uDCCE ")?.trim()
        return if (before.isNullOrEmpty()) goal else "$goal (about: $before)"
    }

    private fun persist() { if (!incognito) ChatStore.save(this, convs) }
    private fun newConv(q: String): Conv { val c = Conv(System.currentTimeMillis(), q.trim().take(40), ArrayList()); if (!incognito) convs.add(c); return c }

    // Stop waiting. The answer, if it still comes, is ignored.
    private fun cancelAsk() {
        if (!waiting) return
        reqId++; waiting = false; failed = false; note = "Stopped. Ask again when you are ready."; build()
    }

    // Ask the last question again, without the saved answer.
    private fun retry() {
        val c = cur ?: return
        if (waiting) return
        while (c.msgs.lastOrNull()?.mine == false) c.msgs.removeAt(c.msgs.size - 1)   // v0.94: the offer and the reply both
        val q = c.msgs.lastOrNull()?.takeIf { it.mine && !it.text.startsWith("📎") }?.text ?: return
        askServer(q, again = true, offer = instantOffer(q))
    }

    private fun askServer(q: String, again: Boolean = false, offer: Msg? = null, re: Msg? = null) {
        if (!Server.configured) { note = "I can’t help with that yet. Try these:"; build(); return }
        askNotifyOnce()
        val imgs = attached; attached = emptyList(); attachedThumb = null
        val conv = cur ?: newConv(q).also { cur = it }
        if (!again) conv.msgs.add(Msg(true, (if (imgs.isNotEmpty()) "📎 " else "") + q, quote = re?.let { Quoted.of(it) }, quoteMine = re?.mine == true))
        val asked = conv.msgs.lastOrNull { it.mine }
        persist()
        val my = ++reqId
        note = ""; failed = false; waiting = true; waitStart = System.currentTimeMillis(); build()
        val id = Server.installId(this)
        val hist = conv.msgs.dropLast(1).filter { it.guideId?.let { g -> g.startsWith("open:") || g.startsWith("find:") } != true }
            .takeLast(8).map { (if (it.mine) "User: " else "Helper: ") + it.text.take(300) }
            .let { Quoted.history(it, asked) }   // v0.100: the message this question replies to, as the last line
        val instant = offer?.takeIf { !isMoney(q) }
        if (instant != null) { conv.msgs.add(instant); persist(); build() }
        // "How do I scan a document?": the helper sees which apps this phone has, so it picks one the person already has
        // or names one to install. Only after they agreed to Smart guide, which already sends app names.
        val withApps = getSharedPreferences("sg", MODE_PRIVATE).getBoolean("smart_ok", false) && Match.wantsApps(q)
        Thread {
            val r = Server.ask(q, Guides.lang, id, imgs, hist, again, if (withApps) Guides.installedNames(this) else emptyList())
            runOnUiThread {
                if (my != reqId) return@runOnUiThread   // stopped, or a newer question was asked
                waiting = false
                if (r.left >= 0) getSharedPreferences("sg", MODE_PRIVATE).edit().putInt("left", r.left).apply()
                if (r.ok) failsInRow = 0
                if (r.ok) {
                    // Money tasks are never guided on screen (money apps are off limits), so never offer Show me for them.
                    val money = isMoney(q) || isMoney(r.goal)
                    val goal = if (r.kind == "guide" && !money) standAlone(conv, r.goal.ifBlank { q }, Quoted.about(asked)) else null
                    if (goal != null && instant?.guideId != null) conv.msgs.remove(instant)   // its own guide does it
                    conv.msgs.add(Msg(false, if (money) noShowMe(r.text) else r.text, goal, r.needsApps, if (money) emptyList() else r.plan))
                } else {
                    // No answer (no internet, the helper not reachable, or today's limit). v0.94 (the owner, 8 Nov): said like
                    // any reply, in true words, with what still works: the Open or Find button above, or a guide.
                    failed = true; failsInRow++
                    val hasOffer = instant?.guideId != null
                    val local = if (hasOffer) null else Guides.all.maxByOrNull { score(it, q) }?.takeIf { score(it, q) > 0 }
                    wayOn = hasOffer || local != null
                    conv.msgs.add(Msg(false, Replies.withWayOn(Replies.fail(r.code, r.text, failsInRow), hasOffer, local != null), guideId = local?.id))
                    note = ""
                    // v0.90: today's free questions are used up: the person may choose to watch a short ad for more
                    if (r.limited) { getSharedPreferences("sg", MODE_PRIVATE).edit().putInt("left", 0).apply(); offerAd(again = true) }
                }
                persist(); build()
                if (!onScreen) Notify.answerReady(this, conv.id, r.ok)   // v0.94: they left while it was thinking
            }
        }.start()
    }

    // v0.94: Android 13 and newer ask once, at the first question, whether ScreenGuide may say "Your answer is ready"
    private fun askNotifyOnce() {
        val sp = getSharedPreferences("sg", MODE_PRIVATE)
        val granted = Build.VERSION.SDK_INT < 33 || checkSelfPermission(Notify.PERMISSION) == android.content.pm.PackageManager.PERMISSION_GRANTED
        if (!Notify.needsAsking(Build.VERSION.SDK_INT, granted, sp.getBoolean("notify_asked", false))) return
        sp.edit().putBoolean("notify_asked", true).apply()
        try { requestPermissions(arrayOf(Notify.PERMISSION), 41) } catch (e: Exception) {}
    }

    // ---- Chats, like Claude's side panel: new chat, search, and every saved chat by day ----
    private fun showChats() {
        val d = Dialog(this)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun action(icon: String, text: String, tint: Int, f: () -> Unit) = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; minimumHeight = dp(52); setPadding(dp(20), dp(4), dp(16), dp(4)); background = press(null, 0); isClickable = true
            addView(IconView(context, icon, tint).apply { layoutParams = ll(dp(22), dp(22)).apply { rightMargin = dp(16) } })
            addView(tv(text, 16.5f, tint, 0, true)); onTap { d.dismiss(); f() }
        }
        fun chatRow(c: Conv) = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(9), dp(16), dp(9)); isClickable = true
            background = press(if (c === cur) bg(chipBg, 14) else null, 14)
            layoutParams = lp(0, 0).apply { leftMargin = dp(8); rightMargin = dp(8) }
            addView(tv((if (c.starred) "\u2605 " else "") + c.title.ifBlank { "Chat" }, 16f, ink, 0, c === cur).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END })
            val preview = c.msgs.firstOrNull { !it.mine }?.text ?: c.msgs.lastOrNull()?.text ?: ""
            if (preview.isNotEmpty()) addView(tv(preview.replace("\n", " "), 13.5f, mute, 0).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END; setPadding(0, dp(2), 0, 0) })
            onTap { d.dismiss(); openChat(c) }
            setOnLongClickListener { d.dismiss(); chatOptions(c); true }
        }
        fun fill(q: String) {
            list.removeAllViews()
            val day = 86400000L
            val today = java.util.Calendar.getInstance().apply { set(java.util.Calendar.HOUR_OF_DAY, 0); set(java.util.Calendar.MINUTE, 0); set(java.util.Calendar.SECOND, 0) }.timeInMillis
            val found = convs.filter { c -> q.isBlank() || c.title.contains(q, true) || c.msgs.any { it.text.contains(q, true) } }.sortedByDescending { it.id }
            if (found.isEmpty()) list.addView(tv(if (convs.isEmpty()) "No chats yet. Your chats will appear here." else "No chats match.", 14.5f, mute, 0).apply { setPadding(dp(20), dp(16), dp(20), dp(16)) })
            val groups = LinkedHashMap<String, ArrayList<Conv>>()
            for (c in found) {
                val g = when { c.starred -> "Starred"; c.id >= today -> "Today"; c.id >= today - day -> "Yesterday"; c.id >= today - 6 * day -> "Previous 7 days"; else -> "Older" }
                groups.getOrPut(g) { ArrayList() }.add(c)
            }
            for (g in listOf("Starred", "Today", "Yesterday", "Previous 7 days", "Older")) {
                val cs = groups[g] ?: continue
                list.addView(tv(g, 13f, mute, 0, true).apply { setPadding(dp(20), dp(14), dp(20), dp(4)) })
                cs.forEach { list.addView(chatRow(it)) }
            }
        }
        val search = EditText(this).apply {
            hint = "Search chats"; setHintTextColor(mute); setTextColor(ink); textSize = 16f; setSingleLine(true)
            background = bg(chipBg, 22); setPadding(dp(16), 0, dp(16), 0)
            layoutParams = ll(MATCH, dp(46)).apply { setMargins(dp(16), dp(8), dp(16), dp(4)) }
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(e: Editable?) { fill(e?.toString() ?: "") }
                override fun beforeTextChanged(x: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(x: CharSequence?, a: Int, b: Int, c: Int) {}
            })
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(0, dp(12), 0, dp(10))
            background = GradientDrawable().apply { setColor(card); val r = dp(24).toFloat(); cornerRadii = floatArrayOf(0f, 0f, r, r, r, r, 0f, 0f) }
            addView(LinearLayout(context).apply {
                gravity = Gravity.CENTER_VERTICAL; setPadding(dp(20), 0, dp(8), dp(4))
                addView(tv("Chats", 21f, ink, 0, true).apply { layoutParams = ll(0, WRAP, 1f) })
                addView(iconBtn("close", "Close", ink, 48, 14) { d.dismiss() })
            })
            addView(action("edit", "New chat", green) { newChat() })
            addView(action(if (incognito) "eye" else "eyeoff", if (incognito) "Leave incognito" else "Incognito chat", ink) { toggleIncognito() })
            addView(action("check", "Learn your phone", ink) { showLearn() })
            addView(search)
            addView(ScrollView(context).apply { addView(list) }, ll(MATCH, 0, 1f))
            addView(View(context).apply { setBackgroundColor(line); layoutParams = ll(MATCH, dp(1)).apply { setMargins(0, dp(6), 0, dp(4)) } })
            addView(action("logo", if (Account.signedIn(this@MainActivity)) Account.name(this@MainActivity).ifEmpty { "Your account" } else "Sign in to keep your settings", ink) { showAccount() })
        }
        fill("")
        d.setContentView(box, ViewGroup.LayoutParams(MATCH, MATCH))
        d.window?.let { w ->
            w.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT)); w.setGravity(Gravity.START or Gravity.TOP)
        }
        d.show()
        d.window?.setLayout((resources.displayMetrics.widthPixels * 0.86).toInt(), MATCH)
    }

    private fun openChat(c: Conv) { incognito = false; Guides.incognito = false; cur = c; note = ""; failed = false; editing = null; replyTo = null; build() }

    // Hold a chat: star it, rename it, or delete it.
    private fun chatOptions(c: Conv) {
        sheet(c.title.ifBlank { "Chat" }, arrayListOf(
            Row("star", if (c.starred) "Remove star" else "Star") { c.starred = !c.starred; persist(); showChats() },
            Row("edit", "Rename") {
                val box = EditText(this).apply { setText(c.title); textSize = 18f; setSingleLine(true); setSelection(text.length) }
                AlertDialog.Builder(this).setTitle("Rename chat").setView(FrameLayout(this).apply { setPadding(dp(20), dp(8), dp(20), 0); addView(box) })
                    .setPositiveButton("Save") { _, _ -> val t = box.text.toString().trim(); if (t.isNotEmpty()) { c.title = t.take(60); persist(); build() } }
                    .setNegativeButton("Cancel", null).show()
            },
            Row("trash", "Delete", tint = noteColor) {
                AlertDialog.Builder(this).setTitle("Delete this chat?").setMessage(c.title)
                    .setPositiveButton("Delete") { _, _ -> convs.remove(c); if (cur === c) cur = null; persist(); build() }
                    .setNegativeButton("Cancel", null).show()
            }))
    }

    private fun toggleIncognito() {
        incognito = !incognito
        Guides.incognito = incognito
        cur = null; note = ""   // a new chat starts, and an incognito chat is gone once you leave it
        if (incognito) Toast.makeText(this, "Incognito: this chat will not be saved", Toast.LENGTH_SHORT).show()
        build()
    }

    // Everything that is not the conversation lives in one menu, so the chat stays clean.
    private fun showMenu() {
        val rows = ArrayList<Row>()
        rows.add(Row("logo", "Your account", if (Account.signedIn(this)) Account.name(this).ifEmpty { "Signed in" } else "Sign in") { showAccount() })
        if (cur != null) rows.add(Row("edit", "New chat") { newChat() })
        rows.add(Row("menu", "Chats", if (convs.isEmpty()) null else convs.size.toString()) { showChats() })
        rows.add(Row("check", "Learn your phone", "${Skills.learned(this)} of ${Skills.tasks().size}") { showLearn() })
        if (Teach.steps.isNotEmpty() && !Teach.on) rows.add(Row("share", "Share what you taught", Teach.title.take(18)) { showTeachReview() })
        rows.add(Row("chat", "Get help from someone", if (Live.id != null) "On" else null) { startLive() })
        rows.add(Row("edit", "Teach a task") { startTeach() })
        rows.add(Row("share", "Open a shared guide") { enterShareCode() })
        rows.add(Row(if (incognito) "eyeoff" else "eye", "Incognito", if (incognito) "On" else "Off") { toggleIncognito() })
        rows.add(Row("star", "Your plan", planValue()) { showPlan() })
        rows.add(Row("sliders", "Customize ScreenGuide") { showCustomize() })
        rows.add(Row("info", "Settings and permissions") { showSettings() })
        rows.add(Row("shield", "Stay safe from scams") { showTips() })
        rows.add(Row("info", "About ScreenGuide", "v" + appVersion()) { showAbout() })
        sheet(null, rows)
    }

    private fun newChat() { cur = null; note = ""; failed = false; editing = null; replyTo = null; input = null; typed = ""; build() }

    private fun copy(text: String) {
        (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("ScreenGuide", text))
        Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
    }

    private fun share(text: String) {
        try { startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text), "Share with")) }
        catch (e: Exception) { copy(text) }
    }

    // Edit a message you sent: it comes back into the box; sending it again replaces it and everything after it.
    private var editing: Msg? = null
    private fun startEdit(m: Msg) {
        editing = m; replyTo = null; input = null; typed = m.text; build()
        ui.post { input?.let { it.requestFocus(); it.setSelection(it.text.length); (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(it, 0) } }
    }

    // v0.100 (the owner, 9 Nov): hold a message, tap Reply, as in WhatsApp. It shows above the box until sent or closed.
    private var replyTo: Msg? = null
    private val msgViews = HashMap<Msg, View>()
    private var chatScroll: ScrollView? = null
    private fun startReply(m: Msg) {
        replyTo = m; editing = null; build()
        ui.post { input?.let { it.requestFocus(); (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(it, 0) } }
    }
    // The quote: a green line, who wrote it, and two lines of it
    private fun quoteView(who: String, words: String, onPaper: Boolean): LinearLayout = LinearLayout(this).apply {
        background = press(bg(if (onPaper) chipBg else line, 12), 12); setPadding(0, 0, dp(12), 0)
        addView(View(context).apply { background = bg(green, 2) }, ll(dp(4), MATCH).apply { setMargins(dp(6), dp(6), dp(8), dp(6)) })
        addView(LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL; setPadding(0, dp(6), 0, dp(7))
            addView(tv(who, 12.5f, green, 0, true))
            addView(tv(words.replace("\n", " "), 13.5f, mute, 0).apply { maxLines = 2; ellipsize = TextUtils.TruncateAt.END })
        }, ll(WRAP, WRAP))
    }
    // Tap a quote: the chat moves to the message it came from, which shows for a moment
    private fun jumpTo(c: Conv, m: Msg) {
        val q = m.quote ?: return
        val i = Quoted.original(c.msgs, c.msgs.indexOf(m).let { if (it < 0) c.msgs.size else it }, q, m.quoteMine)
        val v = c.msgs.getOrNull(i)?.let { msgViews[it] }
        val sv = chatScroll
        if (v == null || sv == null) { Toast.makeText(this, "That message is no longer in this chat.", Toast.LENGTH_SHORT).show(); return }
        sv.smoothScrollTo(0, maxOf(0, v.top - dp(24)))
        v.alpha = 0.35f; v.animate().alpha(1f).setDuration(900).start()
    }

    private fun planValue(): String {
        if (planExpiry() > 0) return "Plus"
        val left = getSharedPreferences("sg", MODE_PRIVATE).getInt("left", -1)
        return if (left >= 0) "Free \u00B7 $left left" else "Free"
    }

    private fun showSettings() {
        val sp = getSharedPreferences("sg", MODE_PRIVATE)
        val smart = sp.getBoolean("smart_ok", false)
        val shot = if (!sp.contains("shot_ok")) "Ask me" else if (sp.getBoolean("shot_ok", false)) "On" else "Off"
        val rows = arrayListOf(
            Row("logo", "Smart guide (AI)", if (smart) "On" else "Off") {
                if (smart) { sp.edit().putBoolean("smart_ok", false).putBoolean("smart_asked", true).apply(); showSettings() }
                else askSmart { showSettings() }
            },
            // Pictures go only after Help, or when a screen's words are not enough; never on bank, money or password screens.
            Row("eye", "Screen pictures when words are not enough", shot) {
                val on = !sp.getBoolean("shot_ok", false)
                sp.edit().putBoolean("shot_ok", on).putBoolean("shot_auto", on).apply(); showSettings()
            })
        rows.add(Row("shield", "Scam guard", if (sp.getBoolean("scam_guard", false)) "On" else "Off") { scamGuard { showSettings() } })
        rows.add(Row("speaker", "Read button: reads any screen to you", if (sp.getBoolean("read_button", false)) "On" else "Off") {
            val on = !sp.getBoolean("read_button", false)
            sp.edit().putBoolean("read_button", on).apply(); Server.event(this, "extra", if (on) "read_on" else "read_off")
            if (on) Toast.makeText(this, "A round green button is now on your screen. Drag it anywhere. Tap it to hear what a screen says.", Toast.LENGTH_LONG).show()
            if (on && !sp.getBoolean("smart_ok", false)) askSmart { showSettings() } else showSettings()
        })
        rows.add(Row("help", "Explain error messages", if (sp.getBoolean("explain_errors", false)) "On" else "Off") {
            val on = !sp.getBoolean("explain_errors", false)
            sp.edit().putBoolean("explain_errors", on).apply(); Server.event(this, "extra", if (on) "errors_on" else "errors_off"); showSettings()
        })
        if (enabled()) rows.add(Row("info", "Keep running in the background", "Battery") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })
        rows.add(Row("sliders", "Accessibility settings") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        sheet("Settings and permissions", rows)
    }

    // ---- Customize: how this person likes ScreenGuide. Kept in their account when signed in. ----
    private fun showCustomize() {
        val names = mapOf("en" to "English", "ny" to "Chinyanja", "bem" to "Icibemba")
        fun cycle(k: String, order: List<String>, def: String) {
            val now = Profile.str(this, k, def); Profile.set(this, k, order[(order.indexOf(now) + 1) % order.size]); build(); showCustomize()
        }
        val name = Profile.str(this, "name", "")
        val rows = arrayListOf(
            Row("edit", "Your name", name.ifEmpty { "Add" }) { askName() },
            Row("globe", "Language", names[Guides.lang]) { langDialog() },
            Row("speaker", "Speak the steps", if (Profile.voiceOn(this)) "On" else "Off") { Profile.set(this, "voice", !Profile.voiceOn(this)); showCustomize() },
            Row("mic", "Record a real voice for the steps", Voices.clips.count { Voices.mine(this, Guides.lang, it.key).length() > 200 }.let { if (it == 0) "Try it" else "$it of ${Voices.clips.size}" }) { showVoices() },
            Row("clock", "Speaking speed", if (Profile.str(this, "rate", "normal") == "slow") "Slow" else "Normal") { cycle("rate", listOf("normal", "slow"), "normal") },
            Row("info", "Size of the step card", if (Profile.str(this, "text", "large") == "xl") "Extra large" else "Large") { cycle("text", listOf("large", "xl"), "large") },
            Row("chat", "How I explain", mapOf("auto" to "Learns from you", "simple" to "Very simple", "normal" to "Normal", "short" to "Short")[Profile.str(this, "words", "auto")]) {
                cycle("words", listOf("auto", "simple", "normal", "short"), "auto")
            },
            Row("eye", "Colours", mapOf("auto" to "Like my phone", "light" to "Light", "dark" to "Dark")[Profile.str(this, "theme", "auto")]) {
                cycle("theme", listOf("auto", "light", "dark"), "auto")
            },
            Row("chat", "Chat background", ChatBackground.name(Profile.str(this, "chat_bg", "default"))) { chatBgDialog() },
            Row("check", "Vibrate on each step", if (Profile.buzzOn(this)) "On" else "Off") { Profile.set(this, "buzz", !Profile.buzzOn(this)); showCustomize() })
        sheet("Customize ScreenGuide", rows, if (Account.signedIn(this)) "Saved to your account, so it comes back on a new phone." else "Sign in to keep these if you change phones.")
    }

    // Like WhatsApp's chat themes: the chat's background colour. Each one shows as a round sample; the chat behind the list
    // changes at once, so the person sees it before closing.
    private fun chatBgDialog() {
        val now = Profile.str(this, "chat_bg", "default")
        val rows = ArrayList<Row>()
        ChatBackground.choices.forEach { c ->
            rows.add(Row(null, c.name, if (c.key == now) "Chosen" else null, swatch = if (dark) c.dark else c.light) {
                Profile.set(this, "chat_bg", c.key); bgFile.delete(); bgPhoto = null; build(); chatBgDialog()
            })
        }
        rows.add(Row("plus", "Your photo", if (now == ChatBackground.PHOTO && bgFile.exists()) "Chosen" else "From your gallery") { pickBgPhoto() })
        if (now == ChatBackground.PHOTO && bgFile.exists()) {
            val order = ChatBackground.strengths.map { it.first }
            rows.add(Row("sliders", "How much of the photo shows", ChatBackground.strengths.firstOrNull { it.first == bgStrength }?.second ?: "Normal") {
                getSharedPreferences("sg", MODE_PRIVATE).edit().putString("bg_strength", order[(order.indexOf(bgStrength) + 1) % order.size]).apply()
                build(); chatBgDialog()
            })
        }
        sheet("Chat background", rows, "Only you see it. The words stay easy to read on every colour and photo: Stronger shows as much of " +
            "your photo as it can while they do. Your photo stays on this phone.")
    }

    private fun pickBgPhoto() {
        val i = if (Build.VERSION.SDK_INT >= 33) Intent(MediaStore.ACTION_PICK_IMAGES)
            else Intent(Intent.ACTION_GET_CONTENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE)
        try { startActivityForResult(i, 4) }
        catch (e: ActivityNotFoundException) { Toast.makeText(this, "No gallery found on this phone", Toast.LENGTH_LONG).show() }
    }

    // The chosen photo: turned the right way up, cut from the middle to the screen's shape, made small, and kept in this
    // app's own folder (not shared, not sent). Reading it again is not needed later.
    private fun saveBgPhoto(uri: Uri) {
        val d = resources.displayMetrics
        Thread {
            val ok = try {
                val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: throw IllegalStateException("empty")
                val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
                val turn = try {
                    when (android.media.ExifInterface(java.io.ByteArrayInputStream(bytes)).getAttributeInt(
                            android.media.ExifInterface.TAG_ORIENTATION, android.media.ExifInterface.ORIENTATION_NORMAL)) {
                        android.media.ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                        android.media.ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                        android.media.ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                        else -> 0f
                    }
                } catch (e: Exception) { 0f }
                val want = minOf(d.widthPixels, 1080)
                var b = BitmapFactory.decodeByteArray(bytes, 0, bytes.size,
                    BitmapFactory.Options().apply { inSampleSize = ChatBackground.sample(o.outWidth, o.outHeight, want) }) ?: throw IllegalStateException("not a picture")
                if (turn != 0f) b = Bitmap.createBitmap(b, 0, 0, b.width, b.height, android.graphics.Matrix().apply { postRotate(turn) }, true)
                val c = ChatBackground.crop(b.width, b.height, d.widthPixels, d.heightPixels)
                b = Bitmap.createBitmap(b, c[0], c[1], c[2], c[3])
                if (b.width > want) b = Bitmap.createScaledBitmap(b, want, maxOf(1, b.height * want / b.width), true)
                java.io.FileOutputStream(bgFile).use { b.compress(Bitmap.CompressFormat.JPEG, 85, it) }
                true
            } catch (e: Throwable) { false }
            runOnUiThread {
                if (ok) { Profile.set(this, "chat_bg", ChatBackground.PHOTO); bgPhoto = null; build()
                    Toast.makeText(this, "Your photo is now the chat background.", Toast.LENGTH_SHORT).show() }
                else Toast.makeText(this, "That picture could not be used. Try another one.", Toast.LENGTH_LONG).show()
            }
        }.start()
    }

    private fun askName() {
        val box = EditText(this).apply {
            setText(Profile.str(this@MainActivity, "name", "")); hint = "Your first name"; textSize = 18f; setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS
        }
        val wrap = FrameLayout(this).apply { setPadding(dp(20), dp(8), dp(20), 0); addView(box) }
        AlertDialog.Builder(this).setTitle("What should I call you?").setView(wrap)
            .setPositiveButton("Save") { _, _ -> Profile.set(this, "name", box.text.toString().trim().take(30)); build(); showCustomize() }
            .setNegativeButton("Cancel", null).show()
    }

    // ---- Your account: sign in with Google (optional) ----
    private fun showAccount() {
        if (!Account.signedIn(this)) {
            sheet("Your account", arrayListOf(Row("logo", "Sign in with Google") { signIn() }),
                "Keep your settings, the tasks your phone learned, and your Plus plan if you change phones. Your chats stay on this phone.")
            return
        }
        val rows = arrayListOf(
            Row("check", Account.name(this).ifEmpty { "Signed in" }, Account.email(this)) {},
            Row("refresh", "Update now") {
                Sync.atStart(this) { runOnUiThread { build(); Toast.makeText(this, "Up to date", Toast.LENGTH_SHORT).show() } }
            },
            Row("close", "Sign out") {
                Account.signOut(this); build(); Toast.makeText(this, "Signed out. Your settings stay on this phone.", Toast.LENGTH_LONG).show()
            },
            Row("trash", "Delete my account", tint = noteColor) { confirmDelete() })
        sheet("Your account", rows, "Your chats are never stored in your account. They stay on this phone.")
    }

    private fun signIn() {
        Toast.makeText(this, "Opening Google sign-in\u2026", Toast.LENGTH_SHORT).show()
        Thread {
            val clientId = Server.googleClientId()
            runOnUiThread {
                if (clientId.isEmpty()) {
                    AlertDialog.Builder(this).setTitle("Sign-in is not ready yet")
                        .setMessage("ScreenGuide accounts are not switched on yet. Everything else works without an account.")
                        .setPositiveButton("OK", null).show()
                    return@runOnUiThread
                }
                // 4 Nov (#26): on an Infinix phone, starting Google's sign-in closed the app (a missing part inside Android's
                // sign-in library). Whatever goes wrong there, the app stays open, says so, and the report still reaches us.
                try {
                val request = GetCredentialRequest.Builder().addCredentialOption(GetSignInWithGoogleOption.Builder(clientId).build()).build()
                CredentialManager.create(this).getCredentialAsync(this, request, CancellationSignal(), java.util.concurrent.Executor { ui.post(it) },
                    object : CredentialManagerCallback<GetCredentialResponse, GetCredentialException> {
                        override fun onResult(result: GetCredentialResponse) {
                            val cred = result.credential
                            val token = if (cred is CustomCredential && cred.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL)
                                try { GoogleIdTokenCredential.createFrom(cred.data).idToken } catch (e: Exception) { null } else null
                            if (token == null) Toast.makeText(this@MainActivity, "Sign-in did not work. Please try again.", Toast.LENGTH_LONG).show()
                            else finishSignIn(token)
                        }
                        override fun onError(e: GetCredentialException) {
                            when (e) {
                                is GetCredentialCancellationException -> {}
                                is NoCredentialException -> AlertDialog.Builder(this@MainActivity).setTitle("No Google account on this phone")
                                    .setMessage("Add one in the phone's Settings, under Accounts, then try again.").setPositiveButton("OK", null).show()
                                else -> Toast.makeText(this@MainActivity, "Sign-in did not work. Please try again.", Toast.LENGTH_LONG).show()
                            }
                        }
                    })
                } catch (e: Throwable) {
                    Crash.keep(this, e, "sign-in (caught)")
                    AlertDialog.Builder(this).setTitle("Sign-in is not working on this phone yet")
                        .setMessage("We have been told and are fixing it. Everything else works without an account.")
                        .setPositiveButton("OK", null).show()
                }
            }
        }.start()
    }

    private fun finishSignIn(idToken: String) {
        val id = Server.installId(this)
        Thread {
            val r = Server.signIn(idToken, id)
            val j = r.json
            if (r.ok && j != null) {
                Account.apply(this, j, j.optString("session"))
                // Bring this phone's settings and learned tasks into the account too.
                Server.saveMe(id, Profile.toJson(this), Recipes.export(this))
            }
            runOnUiThread {
                build()
                if (r.ok) Toast.makeText(this, "Signed in" + (Account.name(this).let { if (it.isEmpty()) "" else " as $it" }), Toast.LENGTH_LONG).show()
                else AlertDialog.Builder(this).setTitle("Sign-in did not work").setMessage(r.message).setPositiveButton("OK", null).show()
            }
        }.start()
    }

    private fun confirmDelete() {
        AlertDialog.Builder(this).setTitle("Delete your account?")
            .setMessage("This deletes your name, email, saved settings, learned tasks and any Plus plan from your account. It cannot be undone. Your chats on this phone are not touched.")
            .setPositiveButton("Delete") { _, _ ->
                val id = Server.installId(this)
                Thread {
                    val ok = Server.deleteMe(id)
                    runOnUiThread {
                        if (ok) { Account.signOut(this); build(); Toast.makeText(this, "Your account is deleted.", Toast.LENGTH_LONG).show() }
                        else Toast.makeText(this, "Could not delete it now. Check your internet and try again.", Toast.LENGTH_LONG).show()
                    }
                }.start()
            }
            .setNegativeButton("Keep it", null).show()
    }

    // Turning on the AI always shows what it sends first (Google Play asks for this, and it is fair).
    private fun askSmart(then: () -> Unit) {
        val prefs = getSharedPreferences("sg", MODE_PRIVATE)
        AlertDialog.Builder(this).setTitle("Let AI help you tap?")
            .setMessage("\u2022 Sends the words on your screen to an AI service while you follow a guide, or when you tap the Read button. For \"how do I\u2026\" questions it also sends the names of your apps (never banking or money apps)\n\u2022 When a guide finishes, the names of the buttons you tapped are kept, so the next phone like yours gets it at once\n\u2022 Never sends passwords\n\u2022 Never works inside banking or mobile money apps")
            .setPositiveButton("Agree") { _, _ -> prefs.edit().putBoolean("smart_ok", true).putBoolean("smart_asked", true).apply(); then() }
            .setNegativeButton("Not now", null).show()
    }

    // The version from the app itself (About said "v0.55" long after: it was typed in by hand)
    private fun appVersion(): String = try { packageManager.getPackageInfo(packageName, 0).versionName ?: "" } catch (e: Exception) { "" }

    private fun showAbout() {
        val rows = arrayListOf(
            Row("lock", "Privacy policy") { openLink(Server.privacyUrl) },
            Row("chat", "Pilot numbers (copy)") {
                val s = Stats.dump(this)
                (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("sg-stats", s))
                AlertDialog.Builder(this).setTitle("Pilot numbers (copied)").setMessage(s).setPositiveButton("Close", null).show()
            })
        val sp = getSharedPreferences("sg", MODE_PRIVATE)
        val testBuild = (applicationInfo.flags and android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE) != 0
        val tester = sp.getBoolean("tester", testBuild)
        rows.add(Row("eye", "Show what ScreenGuide sees (for testing)", if (tester) "On" else "Off") {
            sp.edit().putBoolean("tester", !tester).apply(); Server.initTester(this); showAbout()
        })
        if (tester) rows.add(Row("edit", "Test an app (for developers)", "Start") { startActivity(Intent(this, TestActivity::class.java)) })
        if (Guides.seen.isNotEmpty()) rows.add(Row("edit", "Copy debug info") {
            (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("sg",
                "ScreenGuide v" + (try { packageManager.getPackageInfo(packageName, 0).versionName } catch (e: Exception) { "" }) + " on " + Server.device +
                (if (Server.lastProblem.isNotEmpty()) "\nLast server problem: " + Server.lastProblem else "") + "\n\n" + Guides.seen.values.joinToString("\n\n")))
            Toast.makeText(this, "Copied. Paste it to me.", Toast.LENGTH_SHORT).show()
        })
        sheet("ScreenGuide v" + appVersion(), rows, "Shows you where to tap, one step at a time. It never taps for you.")
    }

    private fun openLink(url: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
        catch (e: ActivityNotFoundException) { Toast.makeText(this, url, Toast.LENGTH_LONG).show() }
    }

    // ---- Plans: free help every day, more with a code from an organisation ----
    private fun planExpiry(): Long {
        val exp = getSharedPreferences("sg", MODE_PRIVATE).getLong("pass_exp", 0L)
        return if (Server.pass.isNotEmpty() && exp * 1000 > System.currentTimeMillis()) exp else 0L
    }
    private fun day(exp: Long): String = java.text.DateFormat.getDateInstance(java.text.DateFormat.MEDIUM).format(java.util.Date(exp * 1000))

    private fun showPlan() {
        val exp = planExpiry()
        val ads = AdsGate.offer(exp > 0, adsLeft())   // v0.90: free, and an ad left today (or not known yet)
        val sp0 = getSharedPreferences("sg", MODE_PRIVATE)
        val msg = if (exp > 0)
            "You have ScreenGuide Plus until ${day(exp)}: more questions and more step-by-step help every day."
        else
            "Free every day: a set number of questions and step-by-step help. Quick tasks and safety tips are always free.\n\nGot a ScreenGuide code from a school, church, shop or organisation? Enter it to get Plus." +
                (if (ads) "\n\n" + AdsGate.planText(sp0.getInt("ads_ask", 5), sp0.getInt("ads_steps", 20)) else "")
        val b = AlertDialog.Builder(this).setTitle(if (exp > 0) "ScreenGuide Plus" else "Your plan: Free").setMessage(msg)
            .setPositiveButton("Enter a code") { _, _ -> enterCode() }
            .setNegativeButton("Close", null)
        if (ads) b.setNeutralButton("Watch an ad") { _, _ -> watchAd(again = false) }   // v0.92: this box already says it all
        b.show()
    }

    // ---- v0.90 rewarded ads: AdsGate has the rules, Ads shows Google's ad, the server counts ----
    private fun adsLeft(): Int {
        val sp = getSharedPreferences("sg", MODE_PRIVATE)
        return AdsGate.known(sp.getInt("ads_left", -1), sp.getLong("ads_at", 0L), System.currentTimeMillis())
    }
    private fun keepAds(s: Server.AdState) {
        if (!s.ok) return
        val e = getSharedPreferences("sg", MODE_PRIVATE).edit()
        if (s.left >= 0) e.putInt("left", s.left)
        e.putInt("ads_left", if (s.adsOn) s.adsLeft else 0).putLong("ads_at", System.currentTimeMillis())
            .putInt("ads_ask", s.ask).putInt("ads_steps", s.steps).apply()
    }
    private var adBusy = false
    // again: ask the question that hit the limit once more after the ad
    private fun offerAd(again: Boolean) {
        if (adBusy || isFinishing || !AdsGate.offer(planExpiry() > 0, adsLeft())) return
        val sp = getSharedPreferences("sg", MODE_PRIVATE)
        val today = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())
        // v0.92: after "Not now", not offered again by itself that day (only from Your plan): no nagging
        if (again && !AdsGate.autoOffer(sp.getString("ads_no_day", "") ?: "", today)) return
        AlertDialog.Builder(this).setTitle("More help today")
            .setMessage(AdsGate.offerText(sp.getInt("ads_ask", 5), sp.getInt("ads_steps", 20)))
            .setPositiveButton("Watch ad") { _, _ -> watchAd(again) }
            .setNegativeButton("Not now") { _, _ -> if (!again) return@setNegativeButton; sp.edit().putString("ads_no_day", today).apply() }.show()
    }
    private fun watchAd(again: Boolean) {
        if (adBusy) return
        adBusy = true
        Stats.inc(this, "ad_yes")
        Toast.makeText(this, AdsGate.LOADING, Toast.LENGTH_LONG).show()
        val id = Server.installId(this)
        Ads.watch(this, id) { r, nonce ->
            if (r != AdsGate.Result.WATCHED) { adBusy = false; adSaid(AdsGate.after(r, false, -1, -1)); return@watch }
            Stats.inc(this, "ad_watched")
            Thread {
                var s = Server.adClaim(nonce, id)
                // Real ads: Google tells our server itself, a few seconds after the ad
                if (s.ok && s.left == 0 && s.adsLeft != 0) { Thread.sleep(4000); s = Server.plan(id).takeIf { it.ok } ?: s }
                runOnUiThread {
                    adBusy = false; keepAds(s)
                    if (isFinishing) return@runOnUiThread
                    adSaid(AdsGate.after(r, s.ok, s.left, s.adsLeft))
                    if (again && s.ok && s.left > 0) retry() else build()
                }
            }.start()
        }
    }
    private fun adSaid(text: String) { if (!isFinishing) AlertDialog.Builder(this).setMessage(text).setPositiveButton("OK", null).show() }

    private fun enterCode() {
        val box = EditText(this).apply {
            hint = "For example ABCDE-1234-WXYZ"; textSize = 18f; setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
        }
        val wrap = FrameLayout(this).apply { setPadding(dp(20), dp(8), dp(20), 0); addView(box) }
        AlertDialog.Builder(this).setTitle("Enter your code").setView(wrap)
            .setPositiveButton("Use code") { _, _ ->
                val code = box.text.toString().trim()
                if (code.isEmpty()) return@setPositiveButton
                Toast.makeText(this, "Checking\u2026", Toast.LENGTH_SHORT).show()
                Thread {
                    val r = Server.redeem(code, Server.installId(this))
                    runOnUiThread {
                        if (r.ok) {
                            getSharedPreferences("sg", MODE_PRIVATE).edit().putString("pass", r.pass).putLong("pass_exp", r.expires).apply()
                            Server.pass = r.pass
                            AlertDialog.Builder(this).setTitle("Welcome to Plus!")
                                .setMessage("You have ScreenGuide Plus for ${r.weeks} weeks, until ${day(r.expires)}.")
                                .setPositiveButton("OK", null).show()
                        } else {
                            AlertDialog.Builder(this).setTitle("Code not accepted").setMessage(r.message)
                                .setPositiveButton("Try again") { _, _ -> enterCode() }.setNegativeButton("Close", null).show()
                        }
                        build()
                    }
                }.start()
            }
            .setNegativeButton("Cancel", null).show()
    }

    // Smart guide: needs the person's agreement. Tapping Show me while it is off simply asks again.
    private fun startSmart(goal: String, needsApps: Boolean = false, plan: List<String> = emptyList()) {
        if (getSharedPreferences("sg", MODE_PRIVATE).getBoolean("smart_ok", false)) { beginSmart(goal, needsApps, plan); return }
        askSmart { beginSmart(goal, needsApps, plan) }
    }

    private fun startSelf(goal: String, path: List<String>) {
        val steps = path.map { row ->
            Step(listOf(row), mapOf("en" to if (row == "Menu") "Tap the menu button, the three dots." else "Tap \u201C$row\u201D."), null)
        }
        val g = Guide("self", mapOf("en" to goal), mapOf("en" to (Match.selfDone(path.last()) ?: "Well done!")), steps, emptyList(), "last_tap")
        Guides.practice = false; Guides.practiceHelped = false; Guides.ownTap = null   // an old tap must not finish it at once
        Stats.inc(this, "started"); Server.event(this, "start", "self"); Guides.active = g; Guides.index = 0
        build()   // no going home: the guide starts on this screen
    }

    private fun offerInstall(name: String) {
        Stats.inc(this, "app_missing")
        AlertDialog.Builder(this).setTitle("$name is not on this phone")
            .setMessage("Do you want to install it from the Play Store? I will show you where to tap.")
            .setPositiveButton("Install it") { _, _ -> beginSmart("Install $name from the Play Store", false, emptyList()) }
            .setNegativeButton("Not now", null).show()
    }

    // v0.86 (the owner's list): an app that is turned off. Its own page in Settings has the button that turns it on: open
    // that page, and ring the button. English only: there are no checked Nyanja or Bemba words for this yet.
    private fun offerTurnOn(name: String, pkg: String, notNow: (() -> Unit)? = null) {
        Stats.inc(this, "app_off")
        AlertDialog.Builder(this).setTitle("$name is turned off")
            .setMessage("$name is on this phone, but it is turned off. Do you want to turn it on? I will show you where to tap.")
            .setPositiveButton("Turn it on") { _, _ -> startTurnOn(name, pkg) }
            .setNegativeButton("Not now") { _, _ -> notNow?.invoke() }.show()
    }

    private fun startTurnOn(name: String, pkg: String) {
        val step = Step(KnownApps.enableWords, mapOf("en" to "Tap the glowing row."), null)   // named by the button on this phone
        val g = Guide("turn_on", mapOf("en" to "Turn on $name"), mapOf("en" to "Well done! $name is on. Ask me again, and I will show you the rest."),
            listOf(step), emptyList(), "last_tap")
        Guides.practice = false; Guides.practiceHelped = false
        Stats.inc(this, "started"); Server.event(this, "start", "turn_on"); Guides.active = g; Guides.index = 0
        try { startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.fromParts("package", pkg, null))) }
        catch (e: Exception) { goHome() }
    }

    private fun beginSmart(goal: String, needsApps: Boolean, plan: List<String>) {
        if (needOn { beginSmart(goal, needsApps, plan) }) return
        // ScreenGuide's own settings (6 Nov, the owner's choice): guided right here, a ring on each menu row. Its menus are
        // known, so no AI is asked and nothing from the chat leaves the phone.
        Match.selfPath(goal)?.let { startSelf(goal, it); return }
        // 5 Nov: a guide for WhatsApp Business, on a phone without it, rang plain WhatsApp and then went round in circles.
        // Now it says the app is not on this phone and offers to install it (the owner's choice). Checked on the phone only.
        // v0.86: on this phone but turned off: say so, and show where to turn it on (not "not on this phone", not a search)
        Guides.offApp(this, goal)?.let { (name, pkg) -> offerTurnOn(name, pkg); return }
        Match.missingApp(goal, Guides.installedNames(this))?.let { offerInstall(it); return }
        // Done this task on this phone before? Then it runs like a built-in guide: instant, numbered, a ring on every step.
        Recipes.find(this, goal)?.let { learned -> Stats.inc(this, "learned_used"); start(learned); return }
        // Two or more phones of this kind already finished this task the same way: follow their path, no AI needed.
        // A quick question to the server; on any problem the Smart guide starts as usual.
        if (Server.configured && !Guides.incognito) {
            val id = Server.installId(this); val my = ++reqId
            Thread {
                val j = Server.learnedFor(goal, id)
                runOnUiThread {
                    if (my != reqId) return@runOnUiThread
                    val g = j?.let { Recipes.fromServer(it, "learned") }
                    if (g != null) { Stats.inc(this, "crowd_used"); start(Guide("learned", mapOf("en" to goal.substringBefore(" (about:")), g.done, g.steps,
                        emptyList(), g.doneWhen, null, null, null, g.shade)) }
                    else smartNow(goal, needsApps, plan)
                }
            }.start()
            return
        }
        smartNow(goal, needsApps, plan)
    }

    private fun smartNow(goal: String, needsApps: Boolean, plan: List<String>) {
        Stats.inc(this, "started"); Server.event(this, "start", "ai")
        Guides.aiReset(goal); Guides.aiNeedsApps = needsApps; Guides.aiPlan = plan
        // The app the task happens in: getting into it needs no AI (ring on the icon, swipe arrow, done when it opens).
        Guides.appFor(this, goal)?.let { (name, pkg, just) -> Guides.aiApp = name; Guides.aiAppPkg = pkg; Guides.aiJustOpen = just }
        Guides.active = Guide("ai", mapOf("en" to goal), mapOf("en" to "Well done!", "ny" to "Zabwino!", "bem" to "Nawamya!"), emptyList(), emptyList())
        Guides.index = 0
        goHome()
    }

    private fun listen(code: Int) {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        try { startActivityForResult(i, code) }
        catch (e: ActivityNotFoundException) { Toast.makeText(this, "Voice input is not available on this phone", Toast.LENGTH_LONG).show() }
    }

    override fun onActivityResult(rc: Int, res: Int, data: Intent?) {
        super.onActivityResult(rc, res, data)
        if (rc == 3) { if (res == RESULT_OK) data?.data?.let { loadMedia(it) }; return }
        if (rc == 4) { if (res == RESULT_OK) data?.data?.let { saveBgPhoto(it) }; return }
        if (res != RESULT_OK) return
        val said = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull() ?: return
        if (rc == 2) ask(said) else { input = null; typed = said; build() }
    }

    private fun langDialog() {
        val opts = listOf("en" to "English", "ny" to "Chinyanja", "bem" to "Icibemba")
        sheet("Language", opts.map { (k, n) -> Row(if (k == Guides.lang) "check" else "", n) { Guides.setLang(this, k); Sync.pushProfile(this); build() } },
            "Instructions are spoken and shown in this language.")
    }

    // Straight to ScreenGuide's own switch where the phone allows it (Android 13 and newer), else the Accessibility list,
    // with this phone maker's way through it. Each stage is counted (shown, agreed, opened, on), to see where people stop.
    private fun openA11ySettings() {
        getSharedPreferences("sg", MODE_PRIVATE).edit().putBoolean("tried_a11y", true).apply()
        Server.event(this, "setup", "opened"); Stats.inc(this, "setup_opened")
        var direct = false
        if (Build.VERSION.SDK_INT >= 33) try {
            startActivity(Intent("android.settings.ACCESSIBILITY_DETAILS_SETTINGS")
                .putExtra(Intent.EXTRA_COMPONENT_NAME, ComponentName(this, GuideService::class.java).flattenToString()))
            direct = true
        } catch (e: Exception) {}
        if (!direct) try { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } catch (e: Exception) {}
        Toast.makeText(this, if (direct) "Turn on the switch for ScreenGuide, then tap Allow." else a11yPath(), Toast.LENGTH_LONG).show()
    }

    // The way to ScreenGuide's switch on this phone's own Accessibility page.
    private fun a11yPath(): String {
        val m = Build.MANUFACTURER.lowercase()
        val brand = Build.MANUFACTURER.trim().lowercase().replaceFirstChar { it.uppercase() }
        val list = when {
            m.contains("samsung") -> "Installed apps"
            m.contains("huawei") || m.contains("honor") -> "Downloaded services"
            else -> "Downloaded apps"   // Infinix, Tecno, itel, Xiaomi, Nokia, Motorola, Pixel
        }
        return "On your $brand: tap $list, then ScreenGuide. Turn on the switch, then tap Allow."
    }

    // Google Play needs the accessibility disclosure on its own, with a clear yes. The AI choice comes after, separately.
    private fun consent() {
        val prefs = getSharedPreferences("sg", MODE_PRIVATE)
        Server.event(this, "setup", "shown")
        AlertDialog.Builder(this).setTitle("ScreenGuide uses Accessibility")
            .setMessage("To show you where to tap, ScreenGuide uses Android\u2019s Accessibility service to read the words on your screen while a guide is running.\n\n" +
                "\u2022 It draws a ring around the button to tap. It never taps or types for you.\n" +
                "\u2022 It skips password boxes and does not work inside banking or mobile money apps.\n" +
                "\u2022 These words stay on your phone, unless you turn on Smart guide on the next screen.")
            .setPositiveButton("I agree") { _, _ ->
                prefs.edit().putBoolean("a11y_ok", true).apply(); Server.event(this, "setup", "agreed")
                if (prefs.getBoolean("smart_asked", false)) {
                    openA11ySettings()
                } else smartChoice()
            }
            .setNeutralButton("Privacy policy") { _, _ -> openLink(Server.privacyUrl) }
            .setNegativeButton("No thanks") { _, _ -> pending = null; Server.event(this, "setup", "declined") }.show()
    }

    private fun smartChoice() {
        val prefs = getSharedPreferences("sg", MODE_PRIVATE)
        fun go(smart: Boolean) {
            prefs.edit().putBoolean("smart_ok", smart).putBoolean("smart_asked", true).apply()
            openA11ySettings()
        }
        AlertDialog.Builder(this).setTitle("Turn on Smart guide?")
            .setMessage("Smart guide can help with any app. While you follow a guide, it sends the words on your screen to our AI service so it can choose the next button. For \"how do I\u2026\" questions it also sends the names of your apps. " +
                "When a guide finishes, the names of the buttons you tapped are kept, so the next phone like yours gets that guide at once.\n\n" +
                "Never passwords. Never banking or mobile money apps. You can change this later in the menu, under Settings.")
            .setPositiveButton("Turn on") { _, _ -> go(true) }
            .setNegativeButton("Not now") { _, _ -> go(false) }
            .setCancelable(false).show()
    }

    // "open chrome", "where is whatsapp" -> a one-step guide that points at that app, only if that app is on the phone.
    private var tts: TextToSpeech? = null
    private val tips = listOf(
        "Never tell anyone your PIN. Not even someone who says they work for your mobile money company.",
        "Real mobile money companies never ask for your PIN, by call or by message.",
        "If someone says you won a prize but must send money first, it is a scam.",
        "If someone says they sent you money by mistake and asks you to send it back, check your balance yourself first.",
        "Before you send money, read the name and number on the screen carefully.",
        "If you are not sure, stop and ask someone you trust.")
    private fun showTips() {
        val on = getSharedPreferences("sg", MODE_PRIVATE).getBoolean("scam_guard", false)
        AlertDialog.Builder(this).setTitle("Stay safe from scams")
            .setMessage(tips.joinToString("\n\n") { "• $it" })
            .setPositiveButton("Close", null).setNeutralButton("Listen") { _, _ -> speak(tips.joinToString(" "), "en") }
            .setNegativeButton(if (on) "Scam guard is on" else "Turn on Scam guard") { _, _ -> if (!on) scamGuard {} }.show()
    }

    // Scam guard: Google Play wants its own clear explanation before it uses the Accessibility permission for this.
    private fun scamGuard(then: () -> Unit) {
        val sp = getSharedPreferences("sg", MODE_PRIVATE)
        if (sp.getBoolean("scam_guard", false)) { sp.edit().putBoolean("scam_guard", false).apply(); then(); return }
        AlertDialog.Builder(this).setTitle("Turn on Scam guard?")
            .setMessage("Scammers phone people and ask them to install an app that lets a stranger control the phone, such as AnyDesk or TeamViewer. " +
                "Then they take the money.\n\nScam guard uses ScreenGuide\u2019s Accessibility permission to notice when such an app opens, or when its " +
                "Play Store page is showing, and warns you, more strongly if you are on a call.\n\nIt works on your phone only. Nothing is sent.")
            .setPositiveButton("Turn on") { _, _ ->
                sp.edit().putBoolean("scam_guard", true).apply(); Stats.inc(this, "scam_guard_on")
                if (!enabled()) needOn { then() } else then()
            }
            .setNegativeButton("Not now") { _, _ -> then() }.show()
    }

    // ---- Real voices: record the fixed instructions in a person's own voice (this phone), or share them (owner) ----
    private val names3 = mapOf("en" to "English", "ny" to "Chinyanja", "bem" to "Icibemba")
    private fun showVoices() {
        val l = Guides.lang
        val rows = ArrayList<Row>()
        Voices.clips.forEach { cl ->
            val t = cl.text[l] ?: return@forEach
            val mine = Voices.mine(this, l, cl.key).length() > 200
            val shared = Voices.pack(this, l, cl.key).length() > 200
            rows.add(Row(if (mine) "check" else "mic", if (cl.prefix) "$t \u2026" else t, if (mine) "Yours" else if (shared) "Shared" else "Record") { recordClip(cl) })
        }
        rows.add(Row("share", "Share my recordings with everyone (owner only)") { publishVoices() })
        sheet("A real voice (${names3[l]})", rows, "Tap a line and read it in a clear voice. ScreenGuide then plays it instead of the robot voice. " +
            "For a line ending in \u2026, say only those words: the phone adds the button's name after it.")
    }

    private var recClip: Voices.Clip? = null
    @Suppress("DEPRECATION")   // MediaRecorder() without a context, for Android 11 and older
    private fun recordClip(cl: Voices.Clip) {
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            recClip = cl; requestPermissions(arrayOf(android.Manifest.permission.RECORD_AUDIO), 7); return
        }
        val l = Guides.lang
        val text = (cl.text[l] ?: return) + if (cl.prefix) " \u2026" else ""
        val tmp = java.io.File(cacheDir, "rec.m4a"); tmp.delete()
        var rec: android.media.MediaRecorder? = null
        var player: android.media.MediaPlayer? = null
        val status = tv("Tap Record, say the words, then tap Stop.", 15f, mute, 0)
        var auto: Runnable? = null
        lateinit var recBtn: TextView
        fun stopRec() {
            try { rec?.stop() } catch (e: Exception) { tmp.delete() }
            rec?.release(); rec = null
            auto?.let { ui.removeCallbacks(it) }
            status.text = if (tmp.length() > 200) "Recorded. Tap Play to listen, then Save." else "Nothing was recorded. Try again."
            recBtn.text = "\u25CF  Record again"
        }
        auto = Runnable { if (rec != null) stopRec() }
        recBtn = pill("\u25CF  Record", green, onAccent) {
            if (rec != null) { stopRec(); return@pill }
            player?.release(); player = null; tmp.delete()
            try {
                rec = (if (Build.VERSION.SDK_INT >= 31) android.media.MediaRecorder(this) else android.media.MediaRecorder()).apply {
                    setAudioSource(android.media.MediaRecorder.AudioSource.MIC)
                    setOutputFormat(android.media.MediaRecorder.OutputFormat.MPEG_4)
                    setAudioEncoder(android.media.MediaRecorder.AudioEncoder.AAC)
                    setAudioEncodingBitRate(48000); setAudioSamplingRate(22050)
                    setOutputFile(tmp.absolutePath); prepare(); start()
                }
                status.text = "Recording\u2026 say: $text"
                recBtn.text = "\u25A0  Stop"
                auto?.let { ui.postDelayed(it, 8000) }
            } catch (e: Exception) { rec?.release(); rec = null; status.text = "The microphone could not start. Try again." }
        }
        val play = pill("\u25B6  Play", card, ink, line) {
            val f = if (tmp.length() > 200) tmp else Voices.mine(this, l, cl.key).takeIf { it.length() > 200 } ?: Voices.pack(this, l, cl.key).takeIf { it.length() > 200 }
            if (f == null) { status.text = "Nothing recorded yet."; return@pill }
            try { player?.release(); player = android.media.MediaPlayer().apply { setDataSource(f.absolutePath); prepare(); start() } } catch (e: Exception) {}
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(8), dp(22), 0)
            addView(tv(text, 22f, ink, 10, true)); addView(status)
            addView(recBtn.apply { layoutParams = lp(14, 0) }); addView(play.apply { layoutParams = lp(8, 0) })
        }
        fun done() { if (rec != null) stopRec(); player?.release(); player = null; auto?.let { ui.removeCallbacks(it) } }
        AlertDialog.Builder(this).setTitle("Say this").setView(box)
            .setPositiveButton("Save") { _, _ ->
                done()
                if (tmp.length() > 200) {
                    val f = Voices.mine(this, l, cl.key); f.parentFile?.mkdirs(); tmp.copyTo(f, overwrite = true); tmp.delete()
                    Stats.inc(this, "voice_recorded"); Toast.makeText(this, "Saved. Your voice will say this.", Toast.LENGTH_SHORT).show()
                }
                showVoices()
            }
            .setNeutralButton("Delete mine") { _, _ -> done(); Voices.mine(this, l, cl.key).delete(); showVoices() }
            .setNegativeButton("Cancel") { _, _ -> done(); tmp.delete() }
            .setOnCancelListener { done(); tmp.delete() }.show()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (code == 7) {
            val cl = recClip; recClip = null
            if (cl != null && res.firstOrNull() == android.content.pm.PackageManager.PERMISSION_GRANTED) recordClip(cl)
            else Toast.makeText(this, "ScreenGuide needs the microphone to record your voice.", Toast.LENGTH_LONG).show()
        }
    }

    // The owner shares their recordings with every phone. The owner key is typed each time and never kept.
    private fun publishVoices() {
        val mine = listOf("en", "ny", "bem").flatMap { l -> Voices.clips.mapNotNull { cl -> Voices.mine(this, l, cl.key).takeIf { it.length() > 200 }?.let { Triple(l, cl.key, it) } } }
        if (mine.isEmpty()) { Toast.makeText(this, "Record some lines first.", Toast.LENGTH_SHORT).show(); return }
        val box = EditText(this).apply { hint = "Owner key (from Render)"; textSize = 18f; setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD }
        val wrap = FrameLayout(this).apply { setPadding(dp(20), dp(8), dp(20), 0); addView(box) }
        AlertDialog.Builder(this).setTitle("Share ${mine.size} recordings with everyone?")
            .setMessage("Every ScreenGuide phone will play these instead of the robot voice. Only the owner can do this.").setView(wrap)
            .setPositiveButton("Share") { _, _ ->
                val key = box.text.toString().trim()
                if (key.isEmpty()) return@setPositiveButton
                Toast.makeText(this, "Sharing\u2026", Toast.LENGTH_SHORT).show()
                Thread {
                    var ok = 0; var why = ""
                    for ((l, k, f) in mine) { val r = Server.uploadVoice(key, l, k, f.readBytes()); if (r.first) ok++ else { why = r.second; if (why.contains("key")) break } }
                    runOnUiThread {
                        AlertDialog.Builder(this).setTitle(if (ok == mine.size) "Shared" else "Not all shared")
                            .setMessage(if (ok == mine.size) "All ${mine.size} recordings are shared. Phones get them the next time they open ScreenGuide." else "$ok of ${mine.size} shared. $why")
                            .setPositiveButton("OK", null).show()
                    }
                }.start()
            }.setNegativeButton("Cancel", null).show()
    }

    // Shared recordings: fetch only the ones that are new since last time. Small (a few KB each).
    private fun fetchVoicePack() {
        if (!Server.configured) return
        val list = Server.voices() ?: return
        val sp = getSharedPreferences("voices", MODE_PRIVATE)
        for (name in list.keys().asSequence().toList().take(60)) {
            val at = list.optLong(name)
            if (sp.getLong(name, 0L) >= at) continue
            val lang = name.substringBefore('_'); val key = name.substringAfter('_')
            if (Voices.clips.none { it.key == key } || lang !in setOf("en", "ny", "bem")) continue
            val bytes = Server.voice(name) ?: continue
            try { val f = Voices.pack(this, lang, key); f.parentFile?.mkdirs(); f.writeBytes(bytes); sp.edit().putLong(name, at).apply() } catch (e: Exception) {}
        }
    }

    // ---- Live help: someone the person trusts opens a link and points at this screen. They can never tap. ----
    private fun startLive() {
        if (Live.id != null) {
            AlertDialog.Builder(this).setTitle("Live help is on")
                .setMessage(if (Live.helper) "Your helper can see the words on your screen." else "Waiting for your helper to open the link.")
                .setPositiveButton("Send the link again") { _, _ -> shareLive() }
                .setNegativeButton("Stop live help") { _, _ ->
                    val lid = Live.id; val key = Live.key; val iid = Server.installId(this)
                    if (lid != null) Thread { Server.liveEnd(lid, key, iid) }.start()
                    Live.stop(); build()
                }.setNeutralButton("Close", null).show()
            return
        }
        if (needOn { startLive() }) return
        if (!Server.configured) return
        AlertDialog.Builder(this).setTitle("Get help from someone you trust")
            .setMessage("Send a link to someone you trust, on WhatsApp or by SMS. When they open it, they see the words on your screen " +
                "and can point where you should tap. A ring shows you, and you hear it.\n\n\u2022 They can never tap or type for you\n" +
                "\u2022 They never see passwords, bank or mobile money screens, or long numbers\n\u2022 Tap Stop on the blue bar any time")
            .setPositiveButton("Make the link") { _, _ ->
                Toast.makeText(this, "Making the link\u2026", Toast.LENGTH_SHORT).show()
                Thread {
                    val r = Server.liveStart(Server.installId(this))
                    runOnUiThread {
                        if (!r.ok) { AlertDialog.Builder(this).setTitle("Could not start live help").setMessage(r.message).setPositiveButton("OK", null).show(); return@runOnUiThread }
                        Guides.active = null; Teach.on = false
                        Live.key = r.key; Live.url = r.url; Live.lastPoint = 0; Live.helper = false; Live.started = System.currentTimeMillis(); Live.id = r.id
                        Stats.inc(this, "live_started"); leavingForGuide = true
                        shareLive()
                    }
                }.start()
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun shareLive() {
        share("Please help me with my phone. Open this link to see my screen and show me where to tap (you cannot tap for me):\n${Live.url}")
    }

    // ---- Teach a task: do it once, check the steps, share the link on WhatsApp ----
    private fun startTeach() {
        if (needOn { startTeach() }) return
        val box = EditText(this).apply {
            hint = "For example: Check ECZ results"; textSize = 18f; setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        }
        val wrap = FrameLayout(this).apply { setPadding(dp(20), dp(8), dp(20), 0); addView(box) }
        AlertDialog.Builder(this).setTitle("Teach a task")
            .setMessage("Do the task once on your phone. ScreenGuide writes down each button you tap. Then you can share it, and others " +
                "follow it on their own screen.\n\nPasswords, money apps and private numbers are never recorded.\n\nWhat will you teach?")
            .setView(wrap)
            .setPositiveButton("Start") { _, _ ->
                val t = box.text.toString().trim().replace(Regex("\\s+"), " ")
                if (t.length < 3) { Toast.makeText(this, "Please give the task a name", Toast.LENGTH_SHORT).show(); return@setPositiveButton }
                Guides.active = null; Teach.reset(t.take(60)); Teach.on = true; Stats.inc(this, "teach_started")
                leavingForGuide = true
                Toast.makeText(this, "Do the task now. Tap Done on the red bar when you finish.", Toast.LENGTH_LONG).show()
                goHome()
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun showTeachReview() {
        if (Teach.steps.isEmpty()) {
            AlertDialog.Builder(this).setTitle("Nothing was recorded")
                .setMessage("Tap Teach a task again, then tap the buttons of the task on your phone. Tap Done when you finish.")
                .setPositiveButton("OK", null).show()
            return
        }
        val rows = arrayListOf(
            Row("share", "Share it (WhatsApp and more)") { shareTaught() },
            Row("play", "Try it yourself first") { Teach.guide()?.let { start(it) } },
            Row("check", "Keep it on this phone only") { keepTaught(); Toast.makeText(this, "Kept. Find it in Learn your phone.", Toast.LENGTH_SHORT).show() },
            Row("trash", "Throw it away") { Teach.reset(""); build() })
        Teach.steps.forEachIndexed { i, st ->
            rows.add(Row("", "${i + 1}. " + (st.say["en"] ?: ""), "Remove") {
                AlertDialog.Builder(this).setTitle("Remove this step?").setMessage(st.say["en"])
                    .setPositiveButton("Remove") { _, _ -> Teach.remove(i); showTeachReview() }
                    .setNegativeButton("Keep") { _, _ -> showTeachReview() }.show()
            })
        }
        val left = if (Teach.skipped > 0) "${Teach.skipped} tap" + (if (Teach.skipped == 1) " was" else "s were") + " left out: they showed numbers or an email address, or were in a money app. " else ""
        sheet("Check the steps: " + Teach.title, rows, left + "Before you share, remove any step that shows a name or something private.")
    }

    private fun keepTaught() {
        val g = Teach.guide() ?: return
        Recipes.save(this, Teach.title, g.steps, g.steps.last().toggle)
    }

    private fun shareTaught() {
        val g = Teach.guide() ?: return
        if (!Server.configured) return
        keepTaught()
        Toast.makeText(this, "Making the link\u2026", Toast.LENGTH_SHORT).show()
        val title = Teach.title
        Thread {
            val r = Server.share(title, Recipes.stepsJson(g.steps), g.steps.last().toggle, g.shade, Guides.lang, Server.installId(this))
            runOnUiThread {
                if (!r.ok) {
                    AlertDialog.Builder(this).setTitle("Could not share yet").setMessage(r.message)
                        .setPositiveButton("Back to the steps") { _, _ -> showTeachReview() }.setNegativeButton("Close", null).show()
                    return@runOnUiThread
                }
                Stats.inc(this, "guides_shared")
                share("Learn this on your phone: \u201C$title\u201D. Open the link and ScreenGuide shows you each step on your own screen:\n${r.url}\n\n" +
                    "Or open ScreenGuide, tap the menu, Open a shared guide, and type the code ${r.code}")
            }
        }.start()
    }

    private fun enterShareCode() {
        val box = EditText(this).apply {
            hint = "For example K7M2QX"; textSize = 20f; setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
        }
        val wrap = FrameLayout(this).apply { setPadding(dp(20), dp(8), dp(20), 0); addView(box) }
        AlertDialog.Builder(this).setTitle("Open a shared guide").setMessage("Type the 6-letter code from the message you got.").setView(wrap)
            .setPositiveButton("Open") { _, _ -> box.text.toString().trim().takeIf { it.length >= 4 }?.let { openShared(it) } }
            .setNegativeButton("Cancel", null).show()
    }

    private fun openShared(code: String) {
        if (!Server.configured) return
        Toast.makeText(this, "Opening the guide\u2026", Toast.LENGTH_SHORT).show()
        Thread {
            val (j, why) = Server.shared(code, Server.installId(this))
            runOnUiThread {
                val g = j?.let { Recipes.fromServer(it, "shared") }
                if (j == null || g == null) {
                    AlertDialog.Builder(this).setTitle("Could not open the guide").setMessage(why.ifEmpty { "Please try again." })
                        .setPositiveButton("Type the code") { _, _ -> enterShareCode() }.setNegativeButton("Close", null).show()
                    return@runOnUiThread
                }
                val title = g.title["en"] ?: ""
                val from = g.by?.let { "\u2714 Official guide from $it\n\n" } ?: "Made by another ScreenGuide user.\n\n"
                AlertDialog.Builder(this).setTitle(title)
                    .setMessage(from + "${g.steps.size} steps. I will point at each one on your screen. You do the tapping. " +
                        "ScreenGuide never points at payments or passwords.")
                    .setPositiveButton("Start") { _, _ -> Recipes.save(this, title, g.steps, j.optBoolean("sw")); Stats.inc(this, "shared_started"); start(g) }
                    .setNegativeButton("Not now", null).show()
            }
        }.start()
    }

    // Uses a voice for the language if the phone has one, otherwise English.
    private fun speak(text: String, lang: String) {
        fun go(t: TextToSpeech) {
            val loc = Locale.forLanguageTag(lang)
            t.language = if (t.isLanguageAvailable(loc) >= TextToSpeech.LANG_AVAILABLE) loc else Locale.ENGLISH
            t.setSpeechRate(Profile.speechRate(this))
            t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "sg")
        }
        val t = tts
        if (t == null) { tts = TextToSpeech(this) { st -> if (st == TextToSpeech.SUCCESS) tts?.let { go(it) } } } else go(t)
    }

    // Simple everyday requests open the right app straight away (no AI, no data). Never banking or money apps.
    private fun quickOpen(text: String): Boolean {
        val pm = packageManager
        val labels = try { pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0).map { it.loadLabel(pm).toString().trim() } } catch (e: Exception) { return false }
        val want = Match.quickTarget(text, labels) ?: return false   // tested in MatchTest
        val ri = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0).firstOrNull { r ->
            val label = r.loadLabel(pm).toString().lowercase()
            want.any { label.contains(it) }
        } ?: return false
        val launch = pm.getLaunchIntentForPackage(ri.activityInfo.packageName) ?: return false
        Toast.makeText(this, "Opening " + ri.loadLabel(pm), Toast.LENGTH_SHORT).show()
        startActivity(launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return true
    }

    // ---- Attach a screenshot or video, then ask what you need ----
    private fun pickMedia() {
        val prefs = getSharedPreferences("sg", MODE_PRIVATE)
        fun open() {
            val i = Intent(Intent.ACTION_GET_CONTENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE)
                .putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/*", "video/*"))
            try { startActivityForResult(Intent.createChooser(i, "Choose a screenshot or video"), 3) }
            catch (e: ActivityNotFoundException) { Toast.makeText(this, "No gallery found on this phone", Toast.LENGTH_LONG).show() }
        }
        if (prefs.getBoolean("attach_ok", false)) { open(); return }
        AlertDialog.Builder(this).setTitle("Attach a picture or video?")
            .setMessage("It is sent to an AI service so it can help you. Do not attach anything that shows PINs, passwords or bank details.")
            .setPositiveButton("OK") { _, _ -> prefs.edit().putBoolean("attach_ok", true).apply(); open() }
            .setNegativeButton("Cancel", null).show()
    }

    private fun shrink(b: Bitmap): Bitmap {
        val m = maxOf(b.width, b.height)
        if (m <= 800) return b
        val f = 800f / m
        return Bitmap.createScaledBitmap(b, (b.width * f).toInt(), (b.height * f).toInt(), true)
    }
    private fun encode(b: Bitmap): String {
        val o = ByteArrayOutputStream(); b.compress(Bitmap.CompressFormat.JPEG, 60, o)
        return Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP)
    }

    private fun loadMedia(uri: Uri) {
        Toast.makeText(this, "Getting it ready…", Toast.LENGTH_SHORT).show()
        Thread {
            val frames = ArrayList<String>()
            var thumb: Bitmap? = null
            try {
                val type = contentResolver.getType(uri) ?: ""
                if (type.startsWith("video")) {
                    val r = MediaMetadataRetriever(); r.setDataSource(this, uri)
                    val dur = (r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L) * 1000
                    for (f in listOf(0.05, 0.5, 0.95)) {
                        r.getFrameAtTime((dur * f).toLong(), MediaMetadataRetriever.OPTION_CLOSEST_SYNC)?.let { b ->
                            val s = shrink(b); if (thumb == null) thumb = s; frames.add(encode(s))
                        }
                    }
                    r.release()
                } else {
                    contentResolver.openInputStream(uri)?.use { ins ->
                        val bytes = ins.readBytes()
                        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
                        var sample = 1
                        while (o.outWidth / sample > 1600) sample *= 2
                        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })?.let { b ->
                            val s = shrink(b); thumb = s; frames.add(encode(s))
                        }
                    }
                }
            } catch (e: Exception) {}
            val shown = thumb
            runOnUiThread {
                if (frames.isEmpty()) Toast.makeText(this, "I could not open that file.", Toast.LENGTH_LONG).show()
                else { attached = frames; attachedThumb = shown; build() }
            }
        }.start()
    }

    private fun hideKeyboard() {
        val im = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        currentFocus?.let { im.hideSoftInputFromWindow(it.windowToken, 0) }
    }

    // ---- Small building blocks ----
    private val ripple: Int get() = if (dark) 0x33FFFFFF else 0x1F000000
    // Every tap shows a soft ripple, so people can see that it landed.
    private fun press(base: Drawable?, radius: Int, oval: Boolean = false): Drawable =
        RippleDrawable(ColorStateList.valueOf(ripple), base, bg(Color.BLACK, radius, oval))
    private fun ll(w: Int, h: Int, weight: Float = 0f) = LinearLayout.LayoutParams(w, h, weight)

    private fun tv(t: String, sz: Float, c: Int, pb: Int = 12, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = sz; setTextColor(c); setPadding(0, 0, 0, dp(pb)); if (bold) typeface = Typeface.DEFAULT_BOLD
    }
    private fun pill(t: String, fill: Int, fg: Int, stroke: Int = 0, f: () -> Unit) = TextView(this).apply {
        text = t; textSize = 16f; setTextColor(fg); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
        background = press(bg(fill, 26, false, stroke), 26); setPadding(dp(20), dp(14), dp(20), dp(14)); minHeight = dp(52)
        onTap { f() }; layoutParams = lp(0, 10)
    }
    // A round icon button: 48dp to touch, the picture smaller inside.
    private fun iconBtn(kind: String, desc: String, tint: Int, size: Int = 48, pad: Int = 12, fill: Int = 0, f: () -> Unit) =
        IconView(this, kind, tint).apply {
            contentDescription = desc; setPadding(dp(pad), dp(pad), dp(pad), dp(pad)); layoutParams = ll(dp(size), dp(size))
            background = press(if (fill != 0) bg(fill, 0, true) else null, 0, true); isClickable = true; onTap { Guides.ownTap = desc; f() }
        }
    // The big green button that starts a guide on the real screen. The most important button, so it is the biggest.
    private fun primary(label: String, f: () -> Unit) = LinearLayout(this).apply {
        gravity = Gravity.CENTER; background = press(bg(green, 28), 28); minimumHeight = dp(54)
        setPadding(dp(18), dp(12), dp(18), dp(12)); contentDescription = label; isClickable = true; onTap { f() }
        layoutParams = lp(12, 0)
        addView(IconView(context, "play", onAccent).apply { layoutParams = ll(dp(16), dp(16)).apply { rightMargin = dp(10) } })
        addView(TextView(context).apply { text = label; textSize = 17f; setTextColor(onAccent); typeface = Typeface.DEFAULT_BOLD; maxLines = 2 })
    }
    private fun section(t: String) = tv(t, 14f, mute, 0, true).apply { setPadding(0, dp(20), 0, dp(10)) }
    private fun iconPad(kind: String) = if (kind in listOf("wifi", "bluetooth", "airplane", "hotspot", "torch", "battery_saver", "data_saver", "text_size", "screenshot")) 3 else 11

    // A full-width card with a picture, a name and an arrow.
    private fun iconCard(kind: String, title: String, tint: Int, tintBg: Int, sub: String? = null, subColor: Int = green, f: () -> Unit): LinearLayout {
        val icon = IconView(this, kind, tint).apply {
            val pd = dp(iconPad(kind)); setPadding(pd, pd, pd, pd); background = bg(tintBg, 0, true); layoutParams = ll(dp(46), dp(46))
        }
        val name = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; layoutParams = ll(0, WRAP, 1f).apply { leftMargin = dp(14) }
            addView(TextView(context).apply { text = title; textSize = 16.5f; setTextColor(ink); typeface = Typeface.DEFAULT_BOLD })
            if (sub != null) addView(TextView(context).apply { text = sub; textSize = 13.5f; setTextColor(subColor); setPadding(0, dp(2), 0, 0) })
        }
        val go = TextView(this).apply { text = "\u203A"; textSize = 26f; setTextColor(mute); setPadding(dp(8), 0, 0, dp(2)) }
        return LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; background = press(bg(card, 20, false, line), 20); setPadding(dp(14), dp(12), dp(16), dp(12))
            layoutParams = lp(0, 10); minimumHeight = dp(68); isClickable = true; contentDescription = title; onTap { f() }
            addView(icon); addView(name); addView(go)
        }
    }
    // A tile for the quick tasks: picture on top, name below. Two per row, so they all fit on one screen.
    private fun tile(kind: String, title: String, tint: Int, tintBg: Int, sub: String?, subColor: Int = green, f: () -> Unit) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; background = press(bg(card, 22, false, line), 22)
        setPadding(dp(14), dp(14), dp(14), dp(14)); minimumHeight = dp(112); isClickable = true; contentDescription = title; onTap { f() }
        addView(IconView(context, kind, tint).apply {
            val pd = dp(iconPad(kind)); setPadding(pd, pd, pd, pd); background = bg(tintBg, 0, true); layoutParams = ll(dp(46), dp(46))
        })
        addView(TextView(context).apply { text = title; textSize = 16f; setTextColor(ink); typeface = Typeface.DEFAULT_BOLD; maxLines = 2; setPadding(0, dp(12), 0, 0) })
        if (sub != null) addView(TextView(context).apply { text = sub; textSize = 13f; setTextColor(subColor); maxLines = 2; ellipsize = TextUtils.TruncateAt.END; setPadding(0, dp(3), 0, 0) })
    }
    private fun grid(col: LinearLayout, items: List<View>) {
        items.chunked(2).forEach { pair ->
            col.addView(LinearLayout(this).apply {
                layoutParams = lp(0, 10)
                pair.forEachIndexed { i, v -> addView(v, ll(0, MATCH, 1f).apply { if (i == 0) rightMargin = dp(10) }) }
                if (pair.size == 1) addView(Space(context), ll(0, 1, 1f))
            })
        }
    }
    // Each task has its own colour (picture, circle behind it), so the grid is easy to tell apart at a glance.
    private fun taskColors(id: String): Pair<Int, Int> = when (id) {
        "torch" -> if (dark) 0xFFF6C453.toInt() to 0xFF3A2F12.toInt() else 0xFFA86A0C.toInt() to 0xFFFFF0CC.toInt()
        "battery_saver" -> if (dark) 0xFF5EDB9B.toInt() to 0xFF123325.toInt() else 0xFF17784A.toInt() to 0xFFDDF3E6.toInt()
        "data_saver" -> if (dark) 0xFF6FB3F2.toInt() to 0xFF132B42.toInt() else 0xFF1D64A8.toInt() to 0xFFDCEAF9.toInt()
        "text_size" -> if (dark) 0xFFB49CF5.toInt() to 0xFF2A2142.toInt() else 0xFF6142B0.toInt() to 0xFFECE5FB.toInt()
        "hotspot" -> if (dark) 0xFFF59E73.toInt() to 0xFF3A2216.toInt() else 0xFFB8461A.toInt() to 0xFFFDE6DA.toInt()
        "airplane" -> if (dark) 0xFFA9B6C6.toInt() to 0xFF22272E.toInt() else 0xFF475569.toInt() to 0xFFE6EAF0.toInt()
        "bluetooth" -> if (dark) 0xFF7EA8F5.toInt() to 0xFF18233F.toInt() else 0xFF2752A8.toInt() to 0xFFE0E8FA.toInt()
        "screenshot" -> if (dark) 0xFFF37EB0.toInt() to 0xFF3A1A28.toInt() else 0xFFB0306A.toInt() to 0xFFFBE3EE.toInt()
        else -> green to iconBg
    }
    // A task tile: what it is for until it is learned, then a tick, then a star once done alone.
    private fun taskTile(g: Guide): View {
        val l = Guides.lang
        val done = Skills.done(this, g.id) > 0
        val star = Skills.alone(this, g.id)
        val (fg, circle) = taskColors(g.id)
        val sub = when {
            star -> "\u2B50 You can do this alone"
            done -> "\u2714 Learned \u00B7 try alone"
            else -> g.about?.let { it[l] ?: it["en"] } ?: g.by?.let { "\u2714 Verified by $it" }
        }
        return tile(g.id, g.title[l] ?: g.title["en"] ?: g.id, fg, circle, sub, if (done) green else mute) { if (done) chooseHow(g) else start(g) }
    }
    // Done before: watch again, or try alone ("I do, we do, you do"). Trying alone is how it sticks.
    private fun chooseHow(g: Guide) {
        sheet(g.title[Guides.lang] ?: g.title["en"] ?: "", listOf(
            Row("logo", "Let me try alone", "No ring at first") { start(g, alone = true) },
            Row("play", "Show me again") { start(g) }),
            "Trying alone helps you remember. If you get stuck, tap Help and the ring comes back.")
    }
    // The first thing a new person does: one quick task that ends with something they can see (the light comes on).
    private fun firstTry(g: Guide): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; layoutParams = lp(6, 4); setPadding(dp(18), dp(18), dp(18), dp(16))
        background = bg(card, 24, false, line)
        val (fg, circle) = taskColors(g.id)
        addView(LinearLayout(context).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(IconView(context, g.id, fg).apply { val pd = dp(5); setPadding(pd, pd, pd, pd); background = bg(circle, 0, true); layoutParams = ll(dp(58), dp(58)).apply { rightMargin = dp(14) } })
            addView(LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL; layoutParams = ll(0, WRAP, 1f)
                addView(tv("Try it now", 13.5f, green, 2, true))
                addView(tv(g.title[Guides.lang] ?: g.title["en"] ?: "", 21f, ink, 0, true))
            })
        })
        addView(tv((g.about?.let { (it[Guides.lang] ?: it["en"] ?: "") + ". " } ?: "") +
            "I\u2019ll show you on your real screen, one tap at a time, all the way through Settings. It takes about 30 seconds and needs no internet.", 15.5f, mute, 2)
            .apply { setPadding(0, dp(12), 0, dp(2)); setLineSpacing(0f, 1.2f) })
        addView(primary("Show me") { start(g) })
    }
    // "Learn your phone": how many tasks are learned, with a bar.
    private fun learnHeader(inPanel: Boolean = false): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; layoutParams = lp(0, 0)
        val n = Skills.learned(this@MainActivity); val m = Skills.tasks().size; val st = Skills.stars(this@MainActivity)
        addView(LinearLayout(context).apply {
            gravity = Gravity.BOTTOM; setPadding(0, dp(if (inPanel) 14 else 20), 0, dp(8))
            addView(tv(if (inPanel) "Your progress" else "Learn your phone", 14f, mute, 0, true).apply { layoutParams = ll(0, WRAP, 1f) })
            addView(tv(if (n == 0) "No internet needed" else "$n of $m learned" + (if (st > 0) "  \u00B7  \u2B50 $st" else ""),
                13.5f, if (n == 0) mute else green, 0, n > 0))
        })
        if (n > 0) addView(LinearLayout(context).apply {
            background = bg(chipBg, 3); layoutParams = lp(0, 12).apply { height = dp(6) }
            addView(View(context).apply { background = bg(green, 3) }, ll(0, MATCH, n.toFloat()))
            if (m > n) addView(Space(context), ll(0, MATCH, (m - n).toFloat()))
        })
        else addView(Space(context), ll(1, dp(2)))
    }
    private fun safeCard() = iconCard("shield", "Stay safe from scams", noteColor, if (dark) 0xFF2A2417.toInt() else 0xFFFFF0D9.toInt(),
        "Six rules that protect your money", mute) { showTips() }

    private fun setupCard(): LinearLayout {
        val tried = getSharedPreferences("sg", MODE_PRIVATE).getBoolean("tried_a11y", false)
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = bg(warmBg, 22, false, warmLine); setPadding(dp(18), dp(18), dp(18), dp(8)); layoutParams = lp(0, 6)
            addView(LinearLayout(context).apply {
                gravity = Gravity.CENTER_VERTICAL
                addView(IconView(context, "logo", green).apply { setPadding(dp(8), dp(8), dp(8), dp(8)); background = bg(card, 0, true); layoutParams = ll(dp(42), dp(42)).apply { rightMargin = dp(12) } })
                addView(tv("One step before you start", 18f, ink, 0, true).apply { layoutParams = ll(0, WRAP, 1f) })
            })
            listOf("Shows you where to tap", "Never taps for you", "Never works in bank or money apps").forEach { t ->
                addView(LinearLayout(context).apply {
                    gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(10), 0, 0)
                    addView(IconView(context, "check", green).apply { layoutParams = ll(dp(18), dp(18)).apply { rightMargin = dp(10) } })
                    addView(tv(t, 15f, ink, 0))
                })
            }
            if (tried) addView(tv(a11yPath(), 14.5f, ink, 0).apply { setPadding(0, dp(14), 0, 0) })
            if (tried) addView(tv("Switch looks grey? Open App info, tap the three dots, then tap Allow restricted settings.", 14f, mute, 0).apply { setPadding(0, dp(8), 0, 0) })
            addView(pill("Turn on ScreenGuide", green, onAccent) { consent() }.apply { layoutParams = lp(16, 10) })
            if (tried) addView(pill("Open App info", card, ink, line) {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            })
        }
    }

    private fun guideBanner(): LinearLayout = LinearLayout(this).apply {
        gravity = Gravity.CENTER_VERTICAL; background = bg(warmBg, 18, false, warmLine); setPadding(dp(14), dp(4), dp(4), dp(4)); layoutParams = lp(8, 8)
        addView(IconView(context, "logo", noteColor).apply { layoutParams = ll(dp(20), dp(20)).apply { rightMargin = dp(10) } })
        addView(tv("A guide is running on your screen.", 15f, ink, 0).apply { layoutParams = ll(0, WRAP, 1f) })
        addView(TextView(context).apply {
            text = "Stop"; textSize = 15f; setTextColor(green); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            setPadding(dp(16), 0, dp(16), 0); minHeight = dp(48); background = press(null, 24)
            onTap {
                Server.event(this@MainActivity, "stop", Guides.active?.id ?: "unknown")
                Guides.active = null; Guides.aiStep = null; Stats.inc(this@MainActivity, "stopped"); build()
            }
        })
    }

    // A panel that slides up from the bottom, in the app's own colours, instead of the phone's plain pop-up list.
    private class Row(val icon: String?, val text: String, val value: String? = null, val tint: Int = 0, val swatch: Int = 0, val f: () -> Unit)

    private fun sheet(title: String?, rows: List<Row>, foot: String? = null) {
        val d = Dialog(this)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        rows.forEach { r ->
            val fg = if (r.tint != 0) r.tint else ink
            list.addView(LinearLayout(this).apply {
                gravity = Gravity.CENTER_VERTICAL; minimumHeight = dp(56); setPadding(dp(22), dp(6), dp(20), dp(6))
                background = press(null, 0); isClickable = true; contentDescription = r.text + (r.value?.let { ", $it" } ?: "")
                when {
                    r.swatch != 0 -> addView(View(context).apply {   // a colour to choose: a round sample of it
                        background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(r.swatch); setStroke(maxOf(1, dp(1)), mute) }
                        layoutParams = ll(dp(26), dp(26)).apply { rightMargin = dp(16) }; importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
                    })
                    r.icon == "" -> addView(Space(context), ll(dp(22), dp(22)).apply { rightMargin = dp(18) })
                    r.icon != null -> addView(IconView(context, r.icon, if (r.icon == "check") green else fg).apply { layoutParams = ll(dp(22), dp(22)).apply { rightMargin = dp(18) } })
                }
                addView(TextView(context).apply { text = r.text; textSize = 16.5f; setTextColor(fg); maxLines = 2; layoutParams = ll(0, WRAP, 1f) })
                if (r.value != null) addView(TextView(context).apply { text = r.value; textSize = 14.5f; setTextColor(mute); maxLines = 1; setPadding(dp(12), 0, 0, 0) })
                onTap { Guides.ownTap = r.text; d.dismiss(); r.f() }
            })
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(0, dp(10), 0, dp(18))
            background = GradientDrawable().apply { setColor(card); val r = dp(24).toFloat(); cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f) }
            addView(View(context).apply { background = bg(line, 3); layoutParams = ll(dp(40), dp(5)).apply { gravity = Gravity.CENTER_HORIZONTAL; bottomMargin = dp(6) } })
            if (title != null) addView(tv(title, 14f, mute, 0, true).apply { setPadding(dp(22), dp(10), dp(22), dp(6)) })
            addView(ScrollView(context).apply { addView(list) }, ll(MATCH, WRAP))
            if (foot != null) addView(tv(foot, 13.5f, mute, 0).apply { setPadding(dp(22), dp(12), dp(22), 0) })
        }
        d.setContentView(box)
        d.window?.let { w ->
            w.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT)); w.setGravity(Gravity.BOTTOM)
            w.attributes = w.attributes.apply { windowAnimations = android.R.style.Animation_InputMethod }
        }
        d.show()
        d.window?.setLayout(MATCH, WRAP)
    }

    // ---- The screen ----
    private fun header(): LinearLayout = LinearLayout(this).apply {
        gravity = Gravity.CENTER_VERTICAL; setPadding(dp(4), dp(8), dp(4), dp(4))
        addView(iconBtn("menu", "Chats", ink, 48, 13) { showChats() })
        addView(IconView(context, if (incognito) "eyeoff" else "logo", if (incognito) noteColor else green).apply {
            layoutParams = ll(dp(24), dp(24)).apply { leftMargin = dp(2); rightMargin = dp(8) }
            if (incognito) { contentDescription = "Incognito is on. Tap to turn it off"; isClickable = true; onTap { toggleIncognito() } }
        })
        addView(LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL; layoutParams = ll(0, WRAP, 1f)
            addView(tv(if (incognito) "Incognito" else "ScreenGuide", 19f, if (incognito) noteColor else ink, 0, true).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END })
            if (incognito) addView(tv("Nothing is saved", 12f, mute, 0))
        })
        addView(iconBtn("edit", "New chat", ink, 48, 13) { newChat() })
        addView(iconBtn("dots", "Menu", ink, 48, 13) { showMenu() })
    }

    // The language, where a first-time user starts (it moved out of the header to make room for Chats).
    private fun langChip(): View = LinearLayout(this).apply {
        gravity = Gravity.CENTER_VERTICAL; background = press(bg(chipBg, 22), 22); setPadding(dp(12), 0, dp(14), 0)
        layoutParams = ll(WRAP, dp(44)).apply { topMargin = dp(2); bottomMargin = dp(4) }; isClickable = true; contentDescription = "Language"
        onTap { Guides.ownTap = "Language"; langDialog() }
        addView(IconView(context, "globe", ink).apply { layoutParams = ll(dp(16), dp(16)).apply { rightMargin = dp(8) } })
        addView(tv(mapOf("en" to "English", "ny" to "Chinyanja", "bem" to "Icibemba")[Guides.lang] ?: "English", 14.5f, ink, 0))
        addView(tv("  \u25BE", 13f, mute, 0))
    }

    private fun greeting(): String {
        val h = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        val hello = if (h < 12) "Good morning" else if (h < 17) "Good afternoon" else "Good evening"
        val name = Profile.str(this, "name", "").trim()
        return if (name.isEmpty()) hello else "$hello, $name"
    }

    // Ideas for a question: the big things ScreenGuide helps with. Four at a time, different on every visit.
    private val examplePool = listOf("How do I scan my certificates into one PDF?", "How do I apply for a job online?",
        "How do I send my CV by email?", "How do I back up my photos?", "How do I set up WhatsApp on a new phone?",
        "How do I join a Zoom class from a link?", "Which app is using up my data?", "How do I free up space on my phone?",
        "How do I create a Google account?", "How do I make a WhatsApp group for parents?", "How do I share my internet with a laptop?",
        "How do I check my ECZ results online?", "How do I sell something on Facebook Marketplace?", "How do I make a quiz with Google Forms?",
        "How do I find my lost phone?", "Is this SMS a scam?")
    private val examples: List<String> get() {
        val start = (getSharedPreferences("sg", MODE_PRIVATE).getInt("visits", 0) * 4) % examplePool.size
        return (0 until 4).map { examplePool[(start + it) % examplePool.size] }
    }

    // Ideas for a first question, for people who do not know what to ask yet.
    private fun suggestions(): View = HorizontalScrollView(this).apply {
        isHorizontalScrollBarEnabled = false; layoutParams = lp(2, 0)
        addView(LinearLayout(context).apply {
            examples.forEach { q ->
                addView(TextView(context).apply {
                    text = q; textSize = 14.5f; setTextColor(ink); gravity = Gravity.CENTER
                    background = press(bg(card, 22, false, line), 22); setPadding(dp(16), 0, dp(16), 0)
                    layoutParams = ll(WRAP, dp(44)).apply { rightMargin = dp(8) }; onTap { ask(q) }
                })
            }
        })
    }

    private fun welcome(col: LinearLayout) {
        col.addView(tv(greeting(), 15f, green, 2, true).apply { setPadding(0, dp(16), 0, dp(4)) })
        col.addView(tv("What do you need help with?", 26f, ink, 6, true))
        col.addView(tv("Ask in your own words. I\u2019ll show you where to tap, one step at a time.", 16f, mute, 12).apply { setLineSpacing(0f, 1.2f) })
        col.addView(langChip())
        if (note.isNotEmpty()) col.addView(tv(note, 15f, noteColor, 12))
        if (!enabled()) col.addView(setupCard())
        val tasks = Skills.tasks()
        // The first try: hotspot. Four screens deep in Settings, so the person sees the ring follow them, and it matters
        // (sharing a bundle). The torch was too simple to show what ScreenGuide does.
        val first = tasks.firstOrNull { it.id == "hotspot" } ?: tasks.firstOrNull()
        if (showIntro && enabled() && first != null && Skills.learned(this) == 0) col.addView(firstTry(first))   // the 10-second first win
        col.addView(section("Try asking"))
        col.addView(suggestions())
        if (!showIntro) return   // after the first visit: a clean home; the tasks are in the menu
        col.addView(learnHeader())
        grid(col, tasks.map { taskTile(it) })
        learnedTasks(col)
        col.addView(safeCard())
    }

    // Tasks this phone learned from Smart guides (instant next time). Hold one to forget it.
    private fun learnedTasks(col: LinearLayout) {
        val learned = Recipes.recent(this, 4)
        if (learned.isEmpty()) return
        col.addView(section("Learned on this phone"))
        grid(col, learned.map { g ->
            val name = g.title["en"] ?: ""
            tile("logo", name, green, iconBg, "${g.steps.size} steps \u00B7 no waiting") { start(g) }.apply {
                setOnLongClickListener {
                    AlertDialog.Builder(this@MainActivity).setTitle("Forget this task?").setMessage(name)
                        .setPositiveButton("Forget") { _, _ -> Recipes.forget(this@MainActivity, name); learnDialog?.dismiss(); build() }
                        .setNegativeButton("Keep", null).show()
                    true
                }
            }
        })
    }

    // "Learn your phone": the tasks that need no internet, kept here after the first visit (menu and Chats panel).
    private var learnDialog: Dialog? = null
    private fun showLearn() {
        val d = Dialog(this)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), 0, dp(16), dp(12)) }
        col.addView(tv("I can show you these without internet. Do one with me, then try it alone.", 15f, mute, 0).apply { setLineSpacing(0f, 1.2f) })
        col.addView(learnHeader(inPanel = true))
        grid(col, Skills.tasks().map { taskTile(it) })
        learnedTasks(col)
        col.addView(safeCard())
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(0, dp(10), 0, 0)
            background = GradientDrawable().apply { setColor(paper); val r = dp(24).toFloat(); cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f) }
            addView(View(context).apply { background = bg(line, 3); layoutParams = ll(dp(40), dp(5)).apply { gravity = Gravity.CENTER_HORIZONTAL; bottomMargin = dp(2) } })
            addView(LinearLayout(context).apply {
                gravity = Gravity.CENTER_VERTICAL; setPadding(dp(16), 0, dp(6), dp(4))
                addView(tv("Learn your phone", 21f, ink, 0, true).apply { layoutParams = ll(0, WRAP, 1f) })
                addView(iconBtn("close", "Close", ink, 48, 14) { d.dismiss() })
            })
            addView(ScrollView(context).apply { addView(col) }, ll(MATCH, 0, 1f))
        }
        d.setContentView(box)
        d.window?.let { w ->
            w.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT)); w.setGravity(Gravity.BOTTOM)
            w.attributes = w.attributes.apply { windowAnimations = android.R.style.Animation_InputMethod }
        }
        d.setOnDismissListener { learnDialog = null }
        learnDialog = d
        d.show()
        d.window?.setLayout(MATCH, (resources.displayMetrics.heightPixels * 0.9).toInt())
    }

    private fun userBubble(m: Msg): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.END; layoutParams = lp(18, 2)
        m.quote?.let { q ->   // v0.100: what this message replies to; tap it to go there
            addView(quoteView(Quoted.who(m.quoteMine), q, false).apply { onTap { cur?.let { c -> jumpTo(c, m) } } },
                ll(WRAP, WRAP).apply { bottomMargin = dp(4); leftMargin = (resources.displayMetrics.widthPixels * 0.14).toInt() })
        }
        addView(TextView(context).apply {
            text = m.text; textSize = 16f; setTextColor(ink); background = press(bg(if (m === editing) line else chipBg, 20), 20); setLineSpacing(0f, 1.15f)
            setPadding(dp(16), dp(10), dp(16), dp(11)); maxWidth = (resources.displayMetrics.widthPixels * 0.8).toInt()
            // Hold your message to edit or copy it.
            setOnLongClickListener {
                val rows = arrayListOf(Row("reply", "Reply") { startReply(m) }, Row("copy", "Copy") { copy(m.text) })
                if (!m.text.startsWith("\uD83D\uDCCE") && !waiting) rows.add(1, Row("edit", "Edit") { startEdit(m) })
                sheet(null, rows); true
            }
        })
        if (m === editing) addView(tv("Editing", 12f, mute, 0).apply { setPadding(0, dp(4), dp(6), 0) })
    }

    private val rated = HashMap<Msg, String>()   // this session's thumbs, so the choice stays visible

    private fun helperBlock(m: Msg, asked: Msg?, last: Boolean = false): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; layoutParams = lp(18, 2)
        addView(TextView(context).apply {
            text = m.text; textSize = 16.5f; setTextColor(ink); setLineSpacing(0f, 1.3f)
            // Hold an answer to copy, share or hear it.
            setOnLongClickListener {
                sheet(null, arrayListOf(Row("reply", "Reply") { startReply(m) }, Row("copy", "Copy") { copy(m.text) }, Row("share", "Share") { share(m.text) },
                    Row("speaker", "Listen") { speak(m.text, Guides.lang) })); true
            }
        })
        val g = m.goal
        val builtIn = m.guideId?.let { id -> Guides.all.firstOrNull { it.id == id } }
        if (g != null && m.plan.isNotEmpty()) addView(steps(m.plan))
        val opens = m.guideId?.let { openOf(it) }
        val finds = m.guideId?.let { findOf(it) }
        if (opens != null) addView(primary("Open " + opens.first) { openLocal(opens.first, opens.second, rowOf(m.guideId)) })
        else if (finds != null) addView(primary("Find $finds") { openByName(finds) })
        else if (builtIn != null) addView(primary("Show me: " + (builtIn.title[Guides.lang] ?: builtIn.title["en"] ?: "")) { start(builtIn) })
        else if (g != null) addView(primary("Show me on my screen") { startSmart(g, m.needsApps, m.plan) })
        else if (asked?.mine == true && isMoney(asked.text)) addView(safeCard().apply { layoutParams = lp(12, 0) })
        val row = LinearLayout(context).apply { gravity = Gravity.CENTER_VERTICAL; layoutParams = ll(WRAP, WRAP).apply { leftMargin = -dp(11); topMargin = dp(4) } }
        row.addView(iconBtn("speaker", "Listen", mute, 44, 12) { speak(m.text, Guides.lang) })
        row.addView(iconBtn("copy", "Copy", mute, 44, 12) { copy(m.text) })
        if (last && m.guideId == null && asked?.mine == true && !asked.text.startsWith("\uD83D\uDCCE") && !failed)   // v0.95: one Try again
            row.addView(iconBtn("refresh", "Try again", mute, 44, 12) { retry() })
        val up = iconBtn("up", "Good answer", mute, 44, 12) {}
        val down = iconBtn("down", "Bad answer", mute, 44, 12) {}
        fun showRating(r: String?) {
            up.tint(if (r == "up") green else mute); down.tint(if (r == "down") noteColor else mute)
            up.visibility = if (r == "down") View.GONE else View.VISIBLE
            down.visibility = if (r == "up") View.GONE else View.VISIBLE
        }
        up.onTap {
            if (rated[m] == null) {
                rated[m] = "up"; showRating("up")
                Stats.inc(this@MainActivity, "thumbs_up"); Server.feedback(this@MainActivity, "up", asked?.text ?: "", m.text)
                Toast.makeText(this@MainActivity, "Thanks!", Toast.LENGTH_SHORT).show()
            }
        }
        down.onTap {
            if (rated[m] == null) {
                rated[m] = "down"; showRating("down")
                Stats.inc(this@MainActivity, "thumbs_down"); Server.feedback(this@MainActivity, "down", asked?.text ?: "", m.text)
                if (asked != null) Stats.remember(this@MainActivity, "bad", asked.text)
                Toast.makeText(this@MainActivity, "Thanks. This helps me improve.", Toast.LENGTH_SHORT).show()
            }
        }
        showRating(rated[m]); row.addView(up); row.addView(down)
        addView(row)
    }

    // The plan, so people know what is coming before they start.
    private fun steps(plan: List<String>) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; background = bg(chipBg, 18); setPadding(dp(14), dp(12), dp(14), dp(4)); layoutParams = lp(12, 0)
        plan.take(6).forEachIndexed { i, t ->
            addView(LinearLayout(context).apply {
                setPadding(0, 0, 0, dp(8))
                addView(TextView(context).apply {
                    text = "${i + 1}"; textSize = 12.5f; setTextColor(green); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
                    background = bg(card, 0, true, line); layoutParams = ll(dp(22), dp(22)).apply { rightMargin = dp(10) }
                })
                addView(TextView(context).apply { text = t; textSize = 15f; setTextColor(ink); setPadding(0, dp(1), 0, 0); layoutParams = ll(0, WRAP, 1f) })
            })
        }
    }

    private fun conversation(col: LinearLayout) {
        val c = cur
        msgViews.clear()
        if (c != null) c.msgs.forEachIndexed { i, m ->
            val v = if (m.mine) userBubble(m) else helperBlock(m, c.msgs.getOrNull(i - 1), i == c.msgs.size - 1 && !waiting)
            msgViews[m] = v; col.addView(v)
        }
        if (waiting) {
            val t = tv("Thinking", 16f, mute, 0)
            thinkingView = t
            col.addView(LinearLayout(this).apply {
                gravity = Gravity.CENTER_VERTICAL; layoutParams = lp(20, 8)
                addView(IconView(context, "logo", green).apply { layoutParams = ll(dp(22), dp(22)).apply { rightMargin = dp(10) } })
                addView(t)
            })
        }
        if (note.isNotEmpty()) col.addView(tv(note, 15f, noteColor, 0).apply { setPadding(0, dp(14), 0, dp(6)) })
        if (failed && !waiting) {
            val lastQ = c?.msgs?.lastOrNull { it.mine }
            if (lastQ != null && !lastQ.text.startsWith("\uD83D\uDCCE"))
                col.addView(pill("Try again", card, ink, line) { retry() }.apply { contentDescription = "Ask again"; layoutParams = lp(12, 0) })
            if (!wayOn) {   // v0.94: only when nothing above fits what they asked
                col.addView(section("These work without internet"))
                grid(col, Skills.tasks().take(4).map { taskTile(it) })
            }
        }
    }

    private fun attachRow(): LinearLayout = LinearLayout(this).apply {
        gravity = Gravity.CENTER_VERTICAL; setPadding(dp(2), dp(6), 0, dp(2))
        addView(ImageView(context).apply {
            attachedThumb?.let { setImageBitmap(it) }; scaleType = ImageView.ScaleType.CENTER_CROP
            layoutParams = LinearLayout.LayoutParams(dp(48), dp(48))
        })
        addView(TextView(context).apply {
            text = if (attached.size > 1) "Video attached. Now ask your question." else "Picture attached. Now ask your question."
            textSize = 14f; setTextColor(ink)
            layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(12) }
        })
        addView(iconBtn("close", "Remove", mute, 48, 14) { attached = emptyList(); attachedThumb = null; build() })
    }

    // The message box, fixed at the bottom like Claude's: + on the left; one green button on the right that is
    // Speak when the box is empty, Send when there is text, and Stop while waiting. One voice button, not two.
    private fun composer(): LinearLayout {
        val et = EditText(this).apply {
            hint = if (incognito) "Incognito: nothing is saved" else if (cur?.msgs?.isNotEmpty() == true) "Reply to ScreenGuide" else "Type or say what you want to do"
            setHintTextColor(mute); setTextColor(ink); textSize = 17f; background = null
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            setHorizontallyScrolling(false); maxLines = 4; minHeight = dp(48)
            imeOptions = EditorInfo.IME_ACTION_SEND
            setPadding(dp(6), dp(8), dp(6), dp(4))
            setText(typed); setSelection(typed.length)
            setOnEditorActionListener { v, _, _ -> ask(v.text.toString()); true }
        }
        input = et
        val actIcon = IconView(this, "mic", onAccent).apply { layoutParams = ll(dp(20), dp(20)) }
        val actText = TextView(this).apply {
            textSize = 16f; setTextColor(onAccent); typeface = Typeface.DEFAULT_BOLD; layoutParams = ll(WRAP, WRAP).apply { leftMargin = dp(8) }
        }
        val action = LinearLayout(this).apply {
            gravity = Gravity.CENTER; background = press(bg(green, 24), 24); layoutParams = ll(WRAP, dp(48)); minimumWidth = dp(48); isClickable = true
            addView(actIcon); addView(actText)
        }
        fun setAction(send: Boolean) {
            val (kind, label) = when { waiting -> "stop" to "Stop"; send -> "send" to ""; else -> "mic" to "Speak" }
            actIcon.kind = kind; actText.text = label
            actText.visibility = if (label.isEmpty()) View.GONE else View.VISIBLE
            val side = if (label.isEmpty()) 14 else 18
            action.setPadding(dp(side - 2), 0, dp(side), 0)
            action.contentDescription = when { waiting -> "Stop waiting"; send -> "Send"; else -> "Speak your question" }
            action.onTap { when { waiting -> cancelAsk(); send -> ask(et.text.toString()); else -> listen(2) } }
        }
        setAction(typed.isNotBlank() || attached.isNotEmpty())
        et.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { setAction(!s.isNullOrBlank() || attached.isNotEmpty()) }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = bg(card, 26, false, line); setPadding(dp(12), dp(6), dp(8), dp(8))
            if (attached.isNotEmpty()) addView(attachRow())
            if (editing != null) addView(LinearLayout(context).apply {
                gravity = Gravity.CENTER_VERTICAL; setPadding(dp(6), dp(2), 0, 0)
                addView(IconView(context, "edit", green).apply { layoutParams = ll(dp(16), dp(16)).apply { rightMargin = dp(8) } })
                addView(tv("Editing your message", 13.5f, green, 0, true).apply { layoutParams = ll(0, WRAP, 1f) })
                addView(iconBtn("close", "Stop editing", mute, 40, 12) { editing = null; input = null; typed = ""; build() })
            })
            replyTo?.let { r ->   // v0.100: the message being replied to, with an X to stop
                addView(LinearLayout(context).apply {
                    gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(2), 0, dp(2))
                    addView(quoteView("Replying to " + Quoted.who(r.mine), Quoted.of(r), true), ll(0, WRAP, 1f))
                    addView(iconBtn("close", "Stop replying", mute, 40, 12) { replyTo = null; build() })
                })
            }
            addView(et, ll(MATCH, WRAP))
            addView(LinearLayout(context).apply {
                gravity = Gravity.CENTER_VERTICAL
                addView(iconBtn("plus", "Attach a screenshot or video", ink, 48, 13, chipBg) { pickMedia() })
                addView(Space(context), ll(0, 1, 1f))
                addView(action)
            })
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(6), dp(12), dp(8)); setBackgroundColor(paper)
            addView(box, ll(MATCH, WRAP))
            addView(LinearLayout(context).apply {
                gravity = Gravity.CENTER; setPadding(0, dp(6), 0, 0)
                addView(IconView(context, "lock", mute).apply { layoutParams = ll(dp(12), dp(12)).apply { rightMargin = dp(6) } })
                addView(tv("Never type your PIN or passwords here.", 12f, mute, 0))
            })
        }
    }

    // Android 15 and later draw every app under the status bar and the navigation bar (Google Play requires targeting
    // them). The page does the same on every phone, so it looks and behaves alike everywhere: its colour runs to the
    // edges, and the content is padded clear of the bars, the camera hole and the keyboard.
    @Suppress("DEPRECATION")   // the older calls are only used on the Android versions that need them
    private fun fitSystemBars(root: View) {
        try {
            if (android.os.Build.VERSION.SDK_INT >= 30) {
                window.setDecorFitsSystemWindows(false)
                val both = android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or android.view.WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
                window.insetsController?.setSystemBarsAppearance(if (dark) 0 else both, both)   // dark icons on the light page
            } else {
                window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or (if (dark) 0 else View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or
                    (if (android.os.Build.VERSION.SDK_INT >= 26) View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR else 0))
            }
            if (android.os.Build.VERSION.SDK_INT < 35) {
                window.statusBarColor = Color.TRANSPARENT
                window.navigationBarColor = Color.TRANSPARENT
            }
        } catch (e: Exception) {}
        root.setOnApplyWindowInsetsListener { v, ins ->
            if (android.os.Build.VERSION.SDK_INT >= 30) {
                val t = android.view.WindowInsets.Type.systemBars() or android.view.WindowInsets.Type.ime() or android.view.WindowInsets.Type.displayCutout()
                val i = ins.getInsets(t)
                v.setPadding(i.left, i.top, i.right, i.bottom)
            } else {
                v.setPadding(ins.systemWindowInsetLeft, ins.systemWindowInsetTop, ins.systemWindowInsetRight, ins.systemWindowInsetBottom)
            }
            ins
        }
        root.requestApplyInsets()
    }

    private fun build() {
        typed = input?.text?.toString() ?: typed
        ui.removeCallbacks(dotsRun); thinkingView = null
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(paper) }
        root.addView(header())
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(4), dp(18), dp(16)) }
        val chatting = cur?.msgs?.isNotEmpty() == true || waiting
        if (Guides.active != null) col.addView(guideBanner())
        if (chatting) conversation(col) else welcome(col)
        val sv = ScrollView(this).apply { setBackgroundColor(chatBg); isFillViewport = true; addView(col) }
        chatScroll = sv
        val photo = photoBg()
        if (photo == null) root.addView(sv, LinearLayout.LayoutParams(MATCH, 0, 1f))
        else {
            // The photo, then a layer of the usual colour over it so the words stay easy to read (ChatBackground.veil)
            sv.setBackgroundColor(Color.TRANSPARENT)
            val a = (ChatBackground.scrim(bgStrength, strongestFor(photo)) * 255).toInt()
            root.addView(FrameLayout(this).apply {
                addView(ImageView(context).apply { setImageBitmap(photo); scaleType = ImageView.ScaleType.CENTER_CROP
                    importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO }, FrameLayout.LayoutParams(MATCH, MATCH))
                addView(View(context).apply { setBackgroundColor(Color.argb(a, Color.red(paper), Color.green(paper), Color.blue(paper))) },
                    FrameLayout.LayoutParams(MATCH, MATCH))
                addView(sv, FrameLayout.LayoutParams(MATCH, MATCH))
            }, LinearLayout.LayoutParams(MATCH, 0, 1f))
        }
        root.addView(composer())
        setContentView(root)
        fitSystemBars(root)
        if (chatting) sv.post { sv.scrollTo(0, col.height) }
        if (thinkingView != null) ui.postDelayed(dotsRun, 400)
    }
}

// Simple line icons drawn in code, so the app needs no image files. One style everywhere: 2px lines on a
// 24-unit grid (like common icon sets), drawn inside the view's padding.
class IconView(c: Context, kind: String, fg: Int) : View(c) {
    var kind: String = kind
        set(v) { field = v; invalidate() }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND; color = fg }
    fun tint(c: Int) { p.color = c; invalidate() }
    override fun onDraw(cv: Canvas) {
        cv.save(); cv.translate(paddingLeft.toFloat(), paddingTop.toFloat())
        val w = (width - paddingLeft - paddingRight).toFloat(); val h = (height - paddingTop - paddingBottom).toFloat()
        if (w > 0 && h > 0) draw(cv, w, h)
        cv.restore()
    }

    private fun draw(cv: Canvas, w: Float, h: Float) {
        fun x(f: Float) = w * f
        fun y(f: Float) = h * f
        val s = minOf(w, h) / 24f
        val ox = (w - 24 * s) / 2; val oy = (h - 24 * s) / 2
        fun X(v: Float) = ox + v * s
        fun Y(v: Float) = oy + v * s
        fun line(a: Float, b: Float, c: Float, d: Float) = cv.drawLine(X(a), Y(b), X(c), Y(d), p)
        fun circle(cx: Float, cy: Float, r: Float, fill: Boolean = false) {
            p.style = if (fill) Paint.Style.FILL else Paint.Style.STROKE; cv.drawCircle(X(cx), Y(cy), r * s, p); p.style = Paint.Style.STROKE
        }
        fun arc(cx: Float, cy: Float, r: Float, start: Float, sweep: Float) =
            cv.drawArc(RectF(X(cx - r), Y(cy - r), X(cx + r), Y(cy + r)), start, sweep, false, p)
        fun path(fill: Boolean = false, b: Path.() -> Unit) {
            p.style = if (fill) Paint.Style.FILL else Paint.Style.STROKE; cv.drawPath(Path().apply(b), p); p.style = Paint.Style.STROKE
        }
        fun Path.m(a: Float, b: Float) = moveTo(X(a), Y(b))
        fun Path.l(a: Float, b: Float) = lineTo(X(a), Y(b))
        fun Path.q(a: Float, b: Float, c: Float, d: Float) = quadTo(X(a), Y(b), X(c), Y(d))
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2f * s
        when (kind) {
            // ---- quick task pictures (drawn large inside a coloured circle) ----
            "wifi" -> {
                p.strokeWidth = w * 0.075f
                val cx = w / 2; val cy = h * 0.72f
                for (i in 1..3) { val r = w * 0.15f * i; cv.drawArc(RectF(cx - r, cy - r, cx + r, cy + r), 225f, 90f, false, p) }
                p.style = Paint.Style.FILL; cv.drawCircle(cx, cy, w * 0.05f, p)
            }
            "bluetooth" -> {
                p.strokeWidth = w * 0.075f
                cv.drawPath(Path().apply {
                    moveTo(x(0.34f), y(0.34f)); lineTo(x(0.64f), y(0.64f)); lineTo(x(0.5f), y(0.78f)); lineTo(x(0.5f), y(0.22f))
                    lineTo(x(0.64f), y(0.36f)); lineTo(x(0.34f), y(0.66f))
                }, p)
            }
            "airplane" -> {
                p.strokeWidth = w * 0.075f
                cv.drawLine(x(0.5f), y(0.2f), x(0.5f), y(0.78f), p)
                cv.drawPath(Path().apply { moveTo(x(0.2f), y(0.56f)); lineTo(x(0.5f), y(0.4f)); lineTo(x(0.8f), y(0.56f)) }, p)
                cv.drawPath(Path().apply { moveTo(x(0.38f), y(0.8f)); lineTo(x(0.5f), y(0.73f)); lineTo(x(0.62f), y(0.8f)) }, p)
            }
            "hotspot" -> {
                p.strokeWidth = w * 0.075f
                val cx = w / 2; val cy = h / 2
                for (i in 1..2) {
                    val r = w * 0.15f * i; val o = RectF(cx - r, cy - r, cx + r, cy + r)
                    cv.drawArc(o, 140f, 80f, false, p); cv.drawArc(o, -40f, 80f, false, p)
                }
                p.style = Paint.Style.FILL; cv.drawCircle(cx, cy, w * 0.06f, p)
            }
            "torch" -> {
                p.strokeWidth = w * 0.07f
                cv.drawPath(Path().apply { moveTo(x(0.27f), y(0.32f)); lineTo(x(0.73f), y(0.32f)); lineTo(x(0.62f), y(0.50f)); lineTo(x(0.38f), y(0.50f)); close() }, p)
                cv.drawRoundRect(RectF(x(0.38f), y(0.50f), x(0.62f), y(0.88f)), w * 0.04f, w * 0.04f, p)
                p.style = Paint.Style.FILL; cv.drawCircle(x(0.5f), y(0.64f), w * 0.04f, p); p.style = Paint.Style.STROKE
                cv.drawLine(x(0.5f), y(0.11f), x(0.5f), y(0.23f), p)   // light
                cv.drawLine(x(0.26f), y(0.16f), x(0.33f), y(0.26f), p)
                cv.drawLine(x(0.74f), y(0.16f), x(0.67f), y(0.26f), p)
            }
            "screenshot" -> {   // a phone with crop corners on its screen
                p.strokeWidth = w * 0.065f
                cv.drawRoundRect(RectF(x(0.28f), y(0.10f), x(0.72f), y(0.90f)), w * 0.07f, w * 0.07f, p)
                val a = 0.39f; val b = 0.61f; val t = 0.37f; val u = 0.63f; val k = 0.08f
                cv.drawLine(x(a), y(t), x(a + k), y(t), p); cv.drawLine(x(a), y(t), x(a), y(t + k), p)
                cv.drawLine(x(b), y(t), x(b - k), y(t), p); cv.drawLine(x(b), y(t), x(b), y(t + k), p)
                cv.drawLine(x(a), y(u), x(a + k), y(u), p); cv.drawLine(x(a), y(u), x(a), y(u - k), p)
                cv.drawLine(x(b), y(u), x(b - k), y(u), p); cv.drawLine(x(b), y(u), x(b), y(u - k), p)
            }
            "battery_saver" -> {
                p.strokeWidth = w * 0.07f
                cv.drawRoundRect(RectF(x(0.32f), y(0.22f), x(0.68f), y(0.86f)), w * 0.06f, w * 0.06f, p)
                p.style = Paint.Style.FILL; cv.drawRoundRect(RectF(x(0.42f), y(0.12f), x(0.58f), y(0.2f)), w * 0.02f, w * 0.02f, p); p.style = Paint.Style.STROKE
                cv.drawLine(x(0.5f), y(0.42f), x(0.5f), y(0.66f), p); cv.drawLine(x(0.38f), y(0.54f), x(0.62f), y(0.54f), p)
            }
            "data_saver" -> {
                p.strokeWidth = w * 0.07f
                cv.drawArc(RectF(x(0.2f), y(0.2f), x(0.8f), y(0.8f)), -60f, 300f, false, p)   // a ring with a gap at the top
                cv.drawLine(x(0.5f), y(0.38f), x(0.5f), y(0.62f), p); cv.drawLine(x(0.38f), y(0.5f), x(0.62f), y(0.5f), p)
            }
            "text_size" -> {   // a small A and a big A
                p.strokeWidth = w * 0.065f
                cv.drawPath(Path().apply { moveTo(x(0.10f), y(0.80f)); lineTo(x(0.25f), y(0.44f)); lineTo(x(0.40f), y(0.80f)) }, p)
                cv.drawLine(x(0.155f), y(0.67f), x(0.345f), y(0.67f), p)
                cv.drawPath(Path().apply { moveTo(x(0.42f), y(0.82f)); lineTo(x(0.65f), y(0.18f)); lineTo(x(0.88f), y(0.82f)) }, p)
                cv.drawLine(x(0.505f), y(0.60f), x(0.795f), y(0.60f), p)
            }
            "shield" -> path { m(12f, 3f); l(19f, 6f); l(19f, 11f); q(19f, 18f, 12f, 21f); q(5f, 18f, 5f, 11f); l(5f, 6f); close() }
                .also { line(12f, 8.5f, 12f, 12.5f); circle(12f, 16f, 1.1f, true) }
            // ---- ScreenGuide's mark: a ring around a tap point ----
            "logo" -> {
                circle(12f, 12f, 9.5f)
                p.alpha = 60; circle(12f, 12f, 6.5f, true); p.alpha = 255
                circle(12f, 12f, 3.4f, true)
            }
            // ---- interface icons ----
            "mic" -> {
                path { addRoundRect(RectF(X(9f), Y(2.5f), X(15f), Y(14f)), 3f * s, 3f * s, Path.Direction.CW) }
                arc(12f, 11f, 6.5f, 0f, 180f); line(12f, 17.5f, 12f, 21.5f); line(8.5f, 21.5f, 15.5f, 21.5f)
            }
            "send" -> { line(12f, 19f, 12f, 5f); path { m(5.5f, 11.5f); l(12f, 5f); l(18.5f, 11.5f) } }
            "plus" -> { line(12f, 5f, 12f, 19f); line(5f, 12f, 19f, 12f) }
            "close" -> { line(6f, 6f, 18f, 18f); line(18f, 6f, 6f, 18f) }
            "stop" -> path(true) { addRoundRect(RectF(X(6.5f), Y(6.5f), X(17.5f), Y(17.5f)), 2.5f * s, 2.5f * s, Path.Direction.CW) }
            "play" -> path(true) { m(8f, 5f); l(19f, 12f); l(8f, 19f); close() }
            "speaker" -> {
                path { m(11f, 5f); l(6f, 9f); l(2.5f, 9f); l(2.5f, 15f); l(6f, 15f); l(11f, 19f); close() }
                arc(12f, 12f, 4.5f, -45f, 90f); arc(12f, 12f, 8.5f, -45f, 90f)
            }
            "refresh" -> { arc(12f, 12f, 8f, 20f, 290f); path { m(13.1f, 5.9f); l(17.1f, 5.9f); l(16.5f, 1.9f) } }
            "up", "down" -> {
                if (kind == "down") { cv.save(); cv.scale(1f, -1f, w / 2, h / 2) }
                path {
                    m(7f, 10.5f); l(10.8f, 3f); q(13.8f, 3f, 13.8f, 6f); l(13.8f, 9f); l(18.6f, 9f)
                    q(20.8f, 9f, 20.4f, 11.2f); l(19.2f, 18.6f); q(18.8f, 21f, 16.6f, 21f); l(7f, 21f); close()
                }
                path { addRoundRect(RectF(X(3f), Y(10.5f), X(7f), Y(21f)), 1.2f * s, 1.2f * s, Path.Direction.CW) }
                if (kind == "down") cv.restore()
            }
            "check" -> path { m(4.5f, 12.5f); l(9.5f, 17.5f); l(19.5f, 6.5f) }
            "back" -> path { m(15f, 5f); l(8f, 12f); l(15f, 19f) }
            "next" -> path { m(9f, 5f); l(16f, 12f); l(9f, 19f) }
            "help" -> {
                circle(12f, 12f, 9.5f)
                path { m(9.2f, 9.3f); q(9.6f, 6.6f, 12.2f, 6.8f); q(15f, 7.1f, 14.9f, 9.6f); q(14.8f, 11.4f, 12f, 12.6f); l(12f, 13.8f) }
                circle(12f, 17.2f, 1.15f, true)
            }
            "chat" -> path { m(4f, 5.5f); q(4f, 4f, 5.5f, 4f); l(18.5f, 4f); q(20f, 4f, 20f, 5.5f); l(20f, 15f); q(20f, 16.5f, 18.5f, 16.5f)
                l(9f, 16.5f); l(4f, 20.5f); close() }
            "edit" -> { path { m(15.5f, 4.5f); l(19.5f, 8.5f); l(8.5f, 19.5f); l(4f, 20f); l(4.5f, 15.5f); close() }; line(13f, 20f, 20f, 20f) }
            "dots" -> { circle(12f, 5f, 1.7f, true); circle(12f, 12f, 1.7f, true); circle(12f, 19f, 1.7f, true) }
            "menu" -> { line(4f, 7f, 20f, 7f); line(4f, 12f, 20f, 12f); line(4f, 17f, 14f, 17f) }
            "copy" -> {
                path { addRoundRect(RectF(X(8.5f), Y(8.5f), X(20f), Y(20f)), 2f * s, 2f * s, Path.Direction.CW) }
                path { m(15.5f, 8.5f); l(15.5f, 5.5f); q(15.5f, 4f, 14f, 4f); l(5.5f, 4f); q(4f, 4f, 4f, 5.5f); l(4f, 14f); q(4f, 15.5f, 5.5f, 15.5f); l(8.5f, 15.5f) }
            }
            "reply" -> { path { m(10f, 6f); l(4f, 12f); l(10f, 18f) }; path { m(4f, 12f); l(14f, 12f); q(20f, 12f, 20f, 18.5f) } }
            "share" -> {
                circle(18f, 5.5f, 2.6f); circle(6f, 12f, 2.6f); circle(18f, 18.5f, 2.6f)
                line(8.4f, 10.7f, 15.6f, 6.8f); line(8.4f, 13.3f, 15.6f, 17.2f)
            }
            "clock" -> { circle(12f, 12f, 9.5f); path { m(12f, 7f); l(12f, 12f); l(15.5f, 14f) } }
            "eye", "eyeoff" -> {
                path { m(2f, 12f); q(12f, 2.5f, 22f, 12f); q(12f, 21.5f, 2f, 12f); close() }
                circle(12f, 12f, 3f)
                if (kind == "eyeoff") line(4f, 4f, 20f, 20f)
            }
            "star" -> path {
                for (i in 0 until 10) {
                    val r = if (i % 2 == 0) 9.5f else 4.2f
                    val a = Math.toRadians((-90 + i * 36).toDouble())
                    val px = 12f + (r * Math.cos(a)).toFloat(); val py = 12.6f + (r * Math.sin(a)).toFloat()
                    if (i == 0) m(px, py) else l(px, py)
                }
                close()
            }
            "sliders" -> {
                line(4f, 7f, 20f, 7f); line(4f, 12f, 20f, 12f); line(4f, 17f, 20f, 17f)
                circle(9f, 7f, 2.3f, true); circle(15.5f, 12f, 2.3f, true); circle(7f, 17f, 2.3f, true)
            }
            "lock" -> {
                path { addRoundRect(RectF(X(5f), Y(11f), X(19f), Y(21f)), 2f * s, 2f * s, Path.Direction.CW) }
                path { m(8f, 11f); l(8f, 8f); q(8f, 4f, 12f, 4f); q(16f, 4f, 16f, 8f); l(16f, 11f) }
            }
            "info" -> { circle(12f, 12f, 9.5f); line(12f, 11f, 12f, 16.5f); circle(12f, 7.8f, 1.15f, true) }
            "globe" -> { circle(12f, 12f, 9.5f); line(2.5f, 12f, 21.5f, 12f); path { m(12f, 2.5f); q(5.5f, 12f, 12f, 21.5f); m(12f, 2.5f); q(18.5f, 12f, 12f, 21.5f) } }
            "trash" -> { line(4f, 6.5f, 20f, 6.5f); path { m(6f, 6.5f); l(7f, 20.5f); l(17f, 20.5f); l(18f, 6.5f) }; path { m(9f, 6.5f); l(9.5f, 3.5f); l(14.5f, 3.5f); l(15f, 6.5f) } }
            else -> { circle(12f, 12f, 8f); circle(12f, 12f, 2.5f, true) }
        }
    }
}
