package zm.screenguide

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class Msg(val mine: Boolean, val text: String, val goal: String? = null, val needsApps: Boolean = false, val plan: List<String> = emptyList(), val guideId: String? = null,
          val quote: String? = null, val quoteMine: Boolean = false)
class Conv(val id: Long, var title: String, val msgs: ArrayList<Msg>, var starred: Boolean = false)

// Chats are saved only on this phone. Incognito chats are never saved.
object ChatStore {
    private fun prefs(c: Context) = c.getSharedPreferences("chats", Context.MODE_PRIVATE)

    fun load(c: Context): ArrayList<Conv> {
        val raw = try { prefs(c).getString("all", "[]") ?: "[]" } catch (e: Exception) { "[]" }
        return parse(if (raw.startsWith("v1:")) Vault.open(raw) ?: "[]" else raw)
    }

    // Plain function (no Android needed) so a unit test can check it. A chat that cannot be read is skipped; the others still load.
    internal fun parse(text: String): ArrayList<Conv> {
        val out = ArrayList<Conv>()
        val arr = try { JSONArray(text) } catch (e: Exception) { return out }
        for (i in 0 until arr.length()) {
            try {
                val o = arr.getJSONObject(i)
                val a = o.getJSONArray("m")
                val ms = ArrayList<Msg>()
                for (j in 0 until a.length()) {
                    val x = a.getJSONObject(j)
                    val pj = x.optJSONArray("p")
                    val plan = if (pj == null) emptyList() else (0 until pj.length()).map { pj.getString(it) }
                    ms.add(Msg(x.getBoolean("me"), x.getString("t"), x.optString("g").ifEmpty { null }, x.optBoolean("a"), plan, x.optString("b").ifEmpty { null }))
                }
                out.add(Conv(o.getLong("id"), o.getString("title"), ms, o.optBoolean("s", false)))
            } catch (e: Exception) {}
        }
        return out
    }

    fun save(c: Context, all: List<Conv>) {
        val arr = JSONArray()
        all.takeLast(30).forEach { cv ->
            val a = JSONArray()
            cv.msgs.forEach { m -> a.put(JSONObject().put("me", m.mine).put("t", m.text).put("g", m.goal ?: "").put("a", m.needsApps).put("p", JSONArray(m.plan)).put("b", m.guideId ?: "")) }
            arr.put(JSONObject().put("id", cv.id).put("title", cv.title).put("m", a).put("s", cv.starred))
        }
        val text = arr.toString()
        prefs(c).edit().putString("all", Vault.seal(text) ?: text).apply()
    }

    internal fun write(all: List<Conv>): String = "[]"   // tests first: not built yet
    fun clear(c: Context) { prefs(c).edit().clear().apply() }
}

// Chats are encrypted on the phone with a key that stays inside Android's secure key store.
private object Vault {
    private const val ALIAS = "screenguide_chats"

    private fun key(): javax.crypto.SecretKey {
        val ks = java.security.KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? javax.crypto.SecretKey)?.let { return it }
        val gen = javax.crypto.KeyGenerator.getInstance(android.security.keystore.KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(android.security.keystore.KeyGenParameterSpec.Builder(ALIAS,
            android.security.keystore.KeyProperties.PURPOSE_ENCRYPT or android.security.keystore.KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(android.security.keystore.KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(android.security.keystore.KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256).build())
        return gen.generateKey()
    }

    fun seal(plain: String): String? = try {
        val cipher = javax.crypto.Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(javax.crypto.Cipher.ENCRYPT_MODE, key())
        val body = cipher.iv + cipher.doFinal(plain.toByteArray(Charsets.UTF_8))
        "v1:" + android.util.Base64.encodeToString(body, android.util.Base64.NO_WRAP)
    } catch (e: Exception) { null }

    fun open(sealed: String): String? = try {
        val all = android.util.Base64.decode(sealed.removePrefix("v1:"), android.util.Base64.NO_WRAP)
        val cipher = javax.crypto.Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(javax.crypto.Cipher.DECRYPT_MODE, key(), javax.crypto.spec.GCMParameterSpec(128, all, 0, 12))
        String(cipher.doFinal(all, 12, all.size - 12), Charsets.UTF_8)
    } catch (e: Exception) { null }
}
