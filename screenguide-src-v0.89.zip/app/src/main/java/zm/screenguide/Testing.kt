package zm.screenguide

// Developer phones: "Test an app". ScreenGuide watches one app's screens (with a guide for a goal, or without) and spots
// problems by itself. No code is added to the app under test. The rules here are plain functions, so TestingTest can
// check them on every build.
object Testing {
    @Volatile var active = false
    @Volatile var pkg = ""
    @Volatile var app = ""
    @Volatile var repo = ""
    @Volatile var goal = ""

    // One thing on the screen, as ScreenGuide reads it. labelled: it, or something inside it, has words.
    class Part(val text: String, val clickable: Boolean, val editable: Boolean, val progress: Boolean,
               val wDp: Int, val hDp: Int, val labelled: Boolean)
    class Found(val kind: String, val detail: String)

    // Short messages that say something went wrong. Long text is an article or a message about errors, not an error.
    private val errorWords = Regex("(?i)(something went wrong|an error (has )?occurred|\\berror\\b|\\bfailed\\b|failure|try again|" +
        "no internet|no connection|you are offline|unable to|could not|couldn.t|not found|exception|\\bnull\\b|\\bundefined\\b|" +
        "\\bnan\\b|timed out|timeout|server error|bad request|\\b(400|401|403|404|500|502|503)\\b)")

    fun errorText(texts: List<String>): String? =
        texts.map { it.trim() }.firstOrNull { it.length in 4..140 && errorWords.containsMatchIn(it) }

    // What is wrong with this screen, from its parts alone: an error message, buttons with no name, buttons too small.
    fun look(parts: List<Part>): List<Found> {
        val out = ArrayList<Found>()
        // Only text that is not a button: a "Try again" button is not an error message (seen 2 Nov on ScreenGuide's own
        // answer), but "Could not load. Try again." written on the screen is.
        errorText(parts.filter { !it.clickable }.map { it.text })?.let { out.add(Found("error_text", it.take(90))) }
        val taps = parts.filter { it.clickable && !it.editable && it.wDp >= 8 && it.hDp >= 8 }
        val unnamed = taps.count { !it.labelled }
        if (unnamed > 0) out.add(Found("unlabeled", "$unnamed"))
        val small = taps.count { it.wDp < 32 || it.hDp < 32 }
        if (small > 0) out.add(Found("small_target", "$small"))
        return out
    }

    // Android's own message about the app under test: "Zexam keeps stopping", "Zexam isn't responding".
    fun systemMessage(texts: List<String>, app: String): Found? {
        if (app.isBlank()) return null
        val t = texts.joinToString(" | ")
        val a = Regex.escape(app)
        if (Regex("(?i)$a (keeps stopping|has stopped)").containsMatchIn(t)) return Found("crash", "$app keeps stopping")
        if (Regex("(?i)$a (isn.t responding|is not responding)").containsMatchIn(t)) return Found("freeze", "$app isn't responding")
        return null
    }

    // Taps that change nothing: the same thing tapped 3 times within 4 seconds while the screen stays the same.
    class TapWatch {
        private val taps = ArrayList<Pair<String, Long>>()
        private var screen = ""
        fun tap(key: String, onScreen: String, now: Long): Boolean {
            if (onScreen != screen) { screen = onScreen; taps.clear() }
            taps.add(key to now)
            taps.removeAll { now - it.second > 4000 }
            if (taps.count { it.first == key } >= 3) { taps.clear(); return true }
            return false
        }
        fun screenChanged(onScreen: String) { if (onScreen != screen) { screen = onScreen; taps.clear() } }
    }

    // A loading sign that stays: reported once it has been there for 8 seconds, then again only if it stays 8 more.
    class Loading {
        private var since = -1L
        fun seen(showing: Boolean, now: Long): Int? {
            if (!showing) { since = -1L; return null }
            if (since < 0L) { since = now; return null }
            val secs = ((now - since) / 1000).toInt()
            if (secs >= 8) { since = now; return secs }
            return null
        }
    }
}

// Developer phones: the screen changed under a step that stayed. Seen 2 Nov: the photo was taken, and the guide kept
// saying "tap the big round button" for 15 seconds, its ring on another button. The watcher never saw it, because the
// guide had not asked again. GuideService takes the pictures; the deciding is here, so it can be tested.
class StaleWatch(private val limit: Int = 28, private val hold: Long = 6000) {
    private var step: Any? = null
    private var shownAt = 0L
    private var eventAt = 0L
    private var changedAt = 0L
    private var done = false
    var print: IntArray? = null
        private set

    // A new step (a new object, even with the same words) starts again
    fun step(key: Any?, now: Long) {
        if (key !== step) { step = key; shownAt = now; eventAt = 0L; changedAt = 0L; done = false; print = null }
    }
    // The step's own picture, taken just after it was shown
    fun print(key: Any?, p: IntArray) { if (key != null && key === step && print == null) print = p }
    // ScreenGuide asked the AI again while this step was showing. 4 Nov: "Screen changed, step 9 stayed" was reported
    // while the question about the new screen was on its way: looking again is not staying (a slow answer has its own
    // report). If the AI keeps the same step, its picture is taken again after the answer, and changes count from there.
    fun asked(key: Any?) { if (key != null && key === step) { print = null; eventAt = 0L; changedAt = 0L } }
    // The app under the guide changed something on the screen
    fun event(now: Long) { eventAt = now }
    // A change was seen and is waiting to be confirmed a few seconds later
    val waiting: Boolean get() = changedAt != 0L && !done
    // Time to take a picture and compare? After the app changed something and went quiet; and once a change was seen,
    // again a few seconds later, to be sure the guide really stayed.
    fun due(key: Any?, now: Long): Boolean = key != null && key === step && !done && print != null && now - shownAt >= 3000 &&
        (if (changedAt == 0L) eventAt > shownAt + 500 && now - eventAt >= 1500 else now - changedAt >= hold)
    // A new picture compared with the step's own. True when it is time to report it.
    fun compared(key: Any?, p: IntArray, now: Long): Boolean {
        val old = print
        if (key == null || key !== step || done || old == null) return false
        if (diff(old, p) < limit) { changedAt = 0L; return false }
        if (changedAt == 0L) { changedAt = now; return false }
        if (now - changedAt < hold) return false
        done = true
        return true
    }
    // How long the step stayed after the change, in seconds
    fun secs(now: Long): Int = if (changedAt == 0L) 0 else ((now - changedAt) / 1000).toInt()

    companion object {
        // Colours (ARGB) to greys, 0-255
        fun grey(px: IntArray): IntArray = IntArray(px.size) { i ->
            val c = px[i]; ((c shr 16 and 0xFF) * 299 + (c shr 8 and 0xFF) * 587 + (c and 0xFF) * 114) / 1000
        }
        // How different two small grey pictures are: 0 (same) to 255
        fun diff(a: IntArray, b: IntArray): Int = if (a.size != b.size || a.isEmpty()) 0 else a.indices.sumOf { kotlin.math.abs(a[it] - b[it]) } / a.size
    }
}

// What the watcher counts as slow on the phone (the server keeps the same line: over 10 s)
object Watch {
    const val SLOW_MS = 10_000L
    // The pop-up's Allow waits this long before it can be tapped (a stray tap must not send anything to the fixer)
    const val ARM_MS = 2_000L

    // The test strip's note on the last answer: how long the phone waited, and whether the stronger AI (after Help) or a
    // screen picture was used. 4 Nov: the owner was told the strip would show the stronger AI; now it does.
    fun answerNote(ms: Long, strong: Boolean, picture: Boolean): String =
        "Last AI answer: ${ms / 100 / 10.0} s" + (if (strong) ", stronger AI" else "") + (if (picture) ", with a screen picture" else "")

    // What a test phone says after a guide when there is no pop-up to show. Never nothing: 4 Nov, a guide ended, no
    // review came, and the developer could not tell whether the watcher had worked at all.
    fun afterText(error: String, lost: Boolean, stopped: Boolean, fromTest: Boolean): String = when {
        error.isNotEmpty() -> "The watcher's review did not come through ($error). Run the guide again to check it."
        lost -> "The watcher lost this guide: the server restarted while it ran. Run it again to check it."
        stopped -> "Stopped. The watcher saw no problems up to here."
        fromTest -> "Test finished. ScreenGuide noticed no problems."
        else -> "Guide finished. The watcher saw no problems."
    }
    fun slow(ms: Long): Boolean = ms > SLOW_MS
}
