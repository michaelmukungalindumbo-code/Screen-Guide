package zm.screenguide

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

// How this person likes ScreenGuide. Kept on the phone, and in their account when they sign in.
object Profile {
    private fun prefs(c: Context) = c.getSharedPreferences("profile", Context.MODE_PRIVATE)

    fun str(c: Context, k: String, def: String): String = prefs(c).getString(k, def) ?: def
    fun bool(c: Context, k: String, def: Boolean): Boolean = prefs(c).getBoolean(k, def)

    fun set(c: Context, k: String, v: Any) {
        val e = prefs(c).edit()
        when (v) { is Boolean -> e.putBoolean(k, v); else -> e.putString(k, v.toString()) }
        e.putBoolean("dirty", true).apply()
        Sync.pushProfile(c)
    }

    // Everything worth keeping in the account. Consent (Smart guide, screen pictures) stays on each phone on purpose.
    fun toJson(c: Context): JSONObject = JSONObject()
        .put("name", str(c, "name", "")).put("lang", Guides.lang)
        .put("voice", bool(c, "voice", true)).put("rate", str(c, "rate", "normal")).put("text", str(c, "text", "large"))
        .put("words", str(c, "words", "auto")).put("theme", str(c, "theme", "auto")).put("chat_bg", str(c, "chat_bg", "default")).put("buzz", bool(c, "buzz", true))

    fun fromJson(c: Context, j: JSONObject) {
        val e = prefs(c).edit()
        for (k in listOf("name", "rate", "text", "words", "theme", "chat_bg")) if (j.has(k)) e.putString(k, j.optString(k))
        for (k in listOf("voice", "buzz")) if (j.has(k)) e.putBoolean(k, j.optBoolean(k))
        e.putBoolean("dirty", false).apply()
        val l = j.optString("lang", "")
        if (l in listOf("en", "ny", "bem")) Guides.setLang(c, l)
    }

    fun dirty(c: Context) = prefs(c).getBoolean("dirty", false)
    fun clean(c: Context) = prefs(c).edit().putBoolean("dirty", false).apply()

    // What the settings mean, used by the chat and by the on-screen guide.
    fun speechRate(c: Context): Float = if (str(c, "rate", "normal") == "slow") 0.8f else 1.0f
    fun voiceOn(c: Context) = bool(c, "voice", true)
    fun buzzOn(c: Context) = bool(c, "buzz", true)
    fun cardSize(c: Context): Float = if (str(c, "text", "large") == "xl") 24f else 20f
}

// The ScreenGuide account (optional): sign in with Google, and settings, learned tasks and the Plus plan come back
// on a new phone. Chats are never sent to the account.
object Account {
    private fun prefs(c: Context) = c.getSharedPreferences("account", Context.MODE_PRIVATE)
    fun signedIn(c: Context) = prefs(c).getString("session", "").isNullOrEmpty().not()
    fun name(c: Context) = prefs(c).getString("name", "") ?: ""
    fun email(c: Context) = prefs(c).getString("email", "") ?: ""

    // Called once at start: the session goes into every request to our server.
    fun load(c: Context) { Server.session = prefs(c).getString("session", "") ?: "" }

    // A reply from sign-in or /me: remember who, bring settings, learned tasks and the plan to this phone.
    fun apply(c: Context, j: JSONObject, session: String? = null) {
        val e = prefs(c).edit()
        if (session != null) { e.putString("session", session); Server.session = session }
        e.putString("name", j.optString("name")).putString("email", j.optString("email")).apply()
        j.optJSONObject("profile")?.let { p ->
            if (p.length() > 0 && !(session == null && Profile.dirty(c))) Profile.fromJson(c, p)
            if (p.optString("name").isEmpty() && Profile.str(c, "name", "").isEmpty()) {
                // First sign-in: greet them by their first name until they choose another.
                val first = j.optString("name").trim().substringBefore(" ")
                if (first.isNotEmpty()) c.getSharedPreferences("profile", Context.MODE_PRIVATE).edit().putString("name", first).apply()
            }
        }
        j.optJSONArray("learned")?.let { Recipes.merge(c, it) }
        j.optJSONObject("plan")?.let { pl ->
            val pass = pl.optString("pass")
            if (pl.optString("tier") == "plus" && pass.isNotEmpty()) {
                c.getSharedPreferences("sg", Context.MODE_PRIVATE).edit().putString("pass", pass).putLong("pass_exp", pl.optLong("expires")).apply()
                Server.pass = pass
            }
        }
    }

    fun signOut(c: Context) {
        prefs(c).edit().clear().apply()
        Server.session = ""
    }
}

// Keeps the account up to date in the background. Never blocks the screen; if offline, it tries again next time.
object Sync {
    fun pushProfile(c: Context) {
        if (!Account.signedIn(c) || Guides.incognito) return
        val app = c.applicationContext; val p = Profile.toJson(app); val id = Server.installId(app)
        Thread { if (Server.saveMe(id, p, null)) Profile.clean(app) }.start()
    }

    fun pushLearned(c: Context) {
        if (!Account.signedIn(c) || Guides.incognito) return
        val app = c.applicationContext; val l = Recipes.export(app); val id = Server.installId(app)
        Thread { Server.saveMe(id, null, l) }.start()
    }

    // At start: send what changed here while offline, otherwise bring in what changed on another phone.
    fun atStart(c: Context, done: () -> Unit) {
        if (!Account.signedIn(c)) return
        val app = c.applicationContext; val id = Server.installId(app)
        Thread {
            if (Profile.dirty(app)) { if (Server.saveMe(id, Profile.toJson(app), Recipes.export(app))) Profile.clean(app) }
            val r = Server.me(id)
            if (r.ok && r.json != null) { Account.apply(app, r.json); done() }
            else if (r.message.endsWith("|401")) { Account.signOut(app); done() }   // the account was deleted, or the sign-in expired
        }.start()
    }
}
