package zm.screenguide

// Drag the Read button down to the round X at the bottom of the screen to close it, like a chat head (the owner asked,
// 6 Nov). GuideService draws the X; where it is and when a drop closes are here, so they can be tested.
object CloseTarget {
    // The X's centre on a screen of w x h pixels (dp: pixels in one dp)
    fun centre(w: Int, h: Int, dp: Float): Pair<Int, Int> = w / 2 to (h - 110 * dp).toInt()

    // Is the button (its top-left corner at x, y; size pixels wide) close enough to the X to close when let go?
    fun over(x: Int, y: Int, size: Int, w: Int, h: Int, dp: Float): Boolean {
        val (cx, cy) = centre(w, h, dp)
        return Math.hypot((x + size / 2 - cx).toDouble(), (y + size / 2 - cy).toDouble()) <= 70 * dp
    }
}
