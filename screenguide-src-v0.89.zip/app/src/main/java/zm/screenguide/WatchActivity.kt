package zm.screenguide

import android.app.Activity
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject

private const val FILL = ViewGroup.LayoutParams.MATCH_PARENT
private const val FIT = ViewGroup.LayoutParams.WRAP_CONTENT

// Developer phones: the step pictures of the guide in progress, kept in memory on the phone until the next guide.
object WatchShots {
    private val list = ArrayList<Pair<Int, String>>()
    @Synchronized fun clear() { list.clear() }
    @Synchronized fun add(n: Int, jpg: String) { if (list.size < 30 && list.none { it.first == n }) list.add(n to jpg) }
    @Synchronized fun all(): List<Pair<Int, String>> = ArrayList(list)
}

// Developer phones only. After a guide or a test, the problems the watcher saw: what went wrong and how to fix it.
// "Allow" sends them to the AI fixer (one GitHub issue each, fixed and waiting for the developer's merge).
// "Don't allow" sends nothing. Either way the list stays in Past results, where it opens again (result_id) and can still
// be sent later.
class WatchActivity : Activity() {
    private val dark: Boolean get() = when (Profile.str(this, "theme", "auto")) {
        "light" -> false; "dark" -> true
        else -> (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    }
    private val bgc: Int get() = if (dark) 0xFF14181B.toInt() else Color.WHITE
    private val ink: Int get() = if (dark) 0xFFF2F4F5.toInt() else 0xFF1F1A14.toInt()
    private val muted: Int get() = if (dark) 0xFFADB5BA.toInt() else 0xFF534C45.toInt()
    private val red: Int get() = if (dark) 0xFFFF6B6B.toInt() else 0xFFC62828.toInt()
    private val accent: Int get() = if (dark) 0xFF18C3DA.toInt() else 0xFF145A3D.toInt()
    private val onAccent: Int get() = if (dark) 0xFF06262C.toInt() else Color.WHITE
    private val soft: Int get() = if (dark) 0xFF1E2428.toInt() else 0xFFF1EADD.toInt()
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun box(c: Int, r: Int) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat() }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Server.initTester(this)
        val rid = intent.getLongExtra("result_id", 0L)
        val fresh = intent.getBooleanExtra("fresh", false)
        val kept = if (rid != 0L) Results.load(this, rid) else null
        val arr = kept?.problems ?: try { JSONArray(intent.getStringExtra("problems") ?: "[]") } catch (e: Exception) { JSONArray() }
        val ps: List<JSONObject> = (0 until arr.length()).mapNotNull { arr.optJSONObject(it) }
        if (ps.isEmpty()) { finish(); return }
        val saved = kept?.saved ?: (intent.getStringExtra("saved") ?: "")
        // The step pictures: kept with the result, or this guide's, taken now so a new guide cannot change them
        val shots = if (kept != null) Results.shots(this, rid) else WatchShots.all()
        val sentBefore = kept?.sent == true
        val doneIds = HashSet(kept?.sentIds ?: emptySet())   // already with the AI fixer
        val isTest = kept?.title?.startsWith("Test") == true
        val stoppedAt = intent.getIntExtra("stopped_at", 0)   // a Stop halfway: what the watcher saw up to there
        window.setGravity(Gravity.BOTTOM)
        window.setLayout(FILL, FIT)
        window.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
        setFinishOnTouchOutside(!fresh)   // just after a guide a choice is needed: Allow or Don't allow

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(16), dp(18), dp(16))
            background = GradientDrawable().apply { setColor(bgc); val r = dp(24).toFloat(); cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f) }
        }
        // Everything above the buttons scrolls, and is never taller than the screen leaves room for: the buttons always
        // show (2 Nov: with tick boxes and a longer note, Allow fell off the bottom of a 720 x 1600 phone).
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun kind(p: JSONObject) = p.optString("kind", "problem").let { if (it == "change" || it == "idea") it else "problem" }
        fun count(n: Int, one: String) = if (n == 1) "1 $one" else "$n ${one}s"
        val np = ps.count { kind(it) == "problem" }; val nc = ps.count { kind(it) == "change" }; val ni = ps.count { kind(it) == "idea" }
        body.addView(TextView(this).apply {
            text = if (np > 0) "ScreenGuide noticed ${count(np, "problem")}" else "Ready for the AI fixer"
            textSize = 20f; typeface = Typeface.DEFAULT_BOLD; setTextColor(if (np > 0) red else accent)
        })
        if (nc + ni > 0) body.addView(TextView(this).apply {
            text = listOf(if (np > 0) count(np, "problem") else "", if (nc > 0) count(nc, "change") + " you asked for" else "",
                if (ni > 0) count(ni, "idea") + " from the AI" else "").filter { it.isNotEmpty() }.joinToString(" \u00B7 ")
            textSize = 14.5f; typeface = Typeface.DEFAULT_BOLD; setTextColor(ink); setPadding(0, dp(2), 0, 0)
        })
        val pics = if (shots.isNotEmpty()) " ${shots.size} screen pictures go too (private, never published)." else ""
        body.addView(TextView(this).apply {
            text = when {
                fresh -> (if (stoppedAt > 0) "What the watcher saw before you stopped, at step $stoppedAt. " else "From the ${if (isTest) "test" else "guide"} you just finished. ") +
                    "Send the ticked ones to the AI fixer? It makes " +
                    "the fixes and asks you to merge.$pics" + (if (!kept?.note.isNullOrEmpty()) " " + kept?.note else "")
                sentBefore -> "${kept?.title ?: ""}, ${java.text.DateFormat.getDateTimeInstance(java.text.DateFormat.MEDIUM, java.text.DateFormat.SHORT).format(java.util.Date(rid))}. Already sent to the AI fixer."
                else -> "${kept?.title ?: ""}, ${java.text.DateFormat.getDateTimeInstance(java.text.DateFormat.MEDIUM, java.text.DateFormat.SHORT).format(java.util.Date(rid))}. " +
                    (if (doneIds.isEmpty()) "Not sent yet. " else "Some were sent already. ") + "Tick the ones to send to the AI fixer.$pics"
            }
            textSize = 14.5f; setTextColor(muted); setPadding(0, dp(4), 0, dp(10))
        })

        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        // Tick boxes: send only the ones that are right (2 Nov: one was a false alarm, and only 3 problems go each day)
        val chosen = LinkedHashSet<String>()
        val ticks = HashMap<String, android.widget.CheckBox>()
        val sentTags = HashMap<String, TextView>()
        var refresh: () -> Unit = {}
        val heads = mapOf("problem" to "Problems the watcher found", "change" to "Changes you asked for", "idea" to "Ideas from the AI")
        val shown = listOf("problem", "change", "idea").flatMap { k -> ps.filter { kind(it) == k } }
        var lastKind = ""
        shown.forEachIndexed { i, p ->
            val k = kind(p)
            if (k != lastKind && (nc + ni > 0)) {
                lastKind = k
                list.addView(TextView(this).apply {
                    text = heads[k]; textSize = 13f; typeface = Typeface.DEFAULT_BOLD; letterSpacing = 0.04f
                    setTextColor(if (k == "problem") red else accent); setPadding(dp(2), dp(6), 0, dp(6))
                })
            }
            list.addView(LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; background = box(soft, 16); setPadding(dp(14), dp(12), dp(14), dp(12))
                layoutParams = LinearLayout.LayoutParams(FILL, FIT).apply { bottomMargin = dp(8) }
                val pid = p.optString("id")
                val done = pid in doneIds
                if (!done && pid.isNotEmpty()) chosen.add(pid)
                addView(android.widget.CheckBox(context).apply {
                    text = "${i + 1}. ${p.optString("title")}"; textSize = 16f; typeface = Typeface.DEFAULT_BOLD; setTextColor(ink)
                    buttonTintList = android.content.res.ColorStateList.valueOf(accent)
                    isChecked = !done; isEnabled = !done && pid.isNotEmpty(); minHeight = dp(44)
                    setOnCheckedChangeListener { _, on -> if (on) chosen.add(pid) else chosen.remove(pid); refresh() }
                    ticks[pid] = this
                })
                addView(TextView(context).apply {
                    text = "Sent to the AI fixer"; textSize = 13f; typeface = Typeface.DEFAULT_BOLD; setTextColor(accent)
                    visibility = if (done) View.VISIBLE else View.GONE
                    sentTags[pid] = this
                })
                val (w1, w2) = when (k) { "change" -> "" to "Next: "; "idea" -> "Why: " to "Suggestion: "; else -> "What happened: " to "How to fix it: " }
                addView(TextView(context).apply {
                    text = w1 + p.optString("what"); textSize = 14.5f; setTextColor(ink); setPadding(0, dp(6), 0, 0)
                })
                addView(TextView(context).apply {
                    text = w2 + p.optString("fix"); textSize = 14.5f; setTextColor(muted); setPadding(0, dp(4), 0, 0)
                })
            })
        }
        body.addView(list)

        val status = TextView(this).apply { textSize = 14.5f; setTextColor(ink); setPadding(0, dp(8), 0, 0); visibility = View.GONE }
        body.addView(status)
        val no = TextView(this).apply {
            text = if (fresh) "Don’t allow" else "Close"; textSize = 16f; setTextColor(ink); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            background = box(soft, 24); minHeight = dp(48); setPadding(dp(12), dp(12), dp(12), dp(12))
            layoutParams = LinearLayout.LayoutParams(0, FIT, 1f).apply { rightMargin = dp(8) }
            setOnClickListener { finish() }
        }
        val yes = TextView(this).apply {
            text = "Allow"; textSize = 16f; setTextColor(onAccent); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            background = box(accent, 24); minHeight = dp(48); setPadding(dp(12), dp(12), dp(12), dp(12))
            layoutParams = LinearLayout.LayoutParams(0, FIT, 1f)
        }
        // Allow answers only after the pop-up has been on screen a moment. It arrives several seconds after Stop, often
        // under a finger still tapping the screen behind it: 3 Nov, a tap meant for "Test an app" sent 3 items.
        var armed = false
        refresh = {
            yes.isEnabled = armed && chosen.isNotEmpty(); yes.alpha = if (armed && chosen.isNotEmpty()) 1f else 0.45f
            yes.text = if (chosen.size == ps.count { it.optString("id") !in doneIds }) "Allow" else "Send ${chosen.size}"
        }
        refresh()
        yes.postDelayed({ armed = true; if (yes.text != "Close" && yes.text != "Sending\u2026") refresh() }, if (fresh) Watch.ARM_MS else 800L)
        yes.setOnClickListener {
            if (chosen.isEmpty()) return@setOnClickListener
            yes.isEnabled = false; no.isEnabled = false; yes.text = "Sending…"
            ticks.values.forEach { it.isEnabled = false }
            val id = Server.installId(this)
            val ids = chosen.toList()
            Thread {
                val (msg, done) = Server.watchSend(id, ids, shots, saved)
                if (rid != 0L) Results.markSent(this, rid, done)
                runOnUiThread {
                    status.text = msg; status.visibility = View.VISIBLE
                    done.forEach { d -> doneIds.add(d); chosen.remove(d); sentTags[d]?.visibility = View.VISIBLE; ticks[d]?.isChecked = false }
                    ticks.forEach { (k, t) -> t.isEnabled = k !in doneIds }
                    no.visibility = View.GONE
                    yes.text = "Close"; yes.isEnabled = true; yes.alpha = 1f; yes.setOnClickListener { finish() }
                }
            }.start()
        }
        if (sentBefore) { yes.visibility = View.GONE; (no.layoutParams as LinearLayout.LayoutParams).rightMargin = 0 }
        val room = (resources.displayMetrics.heightPixels * 0.88).toInt() - dp(48 + 12 + 32 + 40)   // screen minus buttons, padding, status bar
        root.addView(MaxScroll(this, maxOf(dp(200), room)).apply { addView(body); isVerticalScrollBarEnabled = true })
        root.addView(LinearLayout(this).apply { setPadding(0, dp(12), 0, 0); addView(no); addView(yes) })
        setContentView(root)
    }
}
