package zm.screenguide

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.speech.RecognizerIntent
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

private const val ALL = ViewGroup.LayoutParams.MATCH_PARENT
private const val SOME = ViewGroup.LayoutParams.WRAP_CONTENT

// Developer phones: what the developer pointed at, waiting for their words. Set by the guide, read here.
object ChangeDraft {
    @Volatile var shot: Bitmap? = null
    @Volatile var x = -1f
    @Volatile var y = -1f
    @Volatile var words: List<String> = emptyList()
    fun set(b: Bitmap?, px: Float, py: Float, w: List<String>) { shot = b; x = px; y = py; words = w }
}

// Developer phones only. "What should change?": the developer says or types a change to the screen they pointed at.
// It joins the list after the guide, next to the problems; nothing goes to the AI fixer until they tap Allow there.
class ChangeActivity : Activity() {
    private lateinit var input: EditText
    private val dark: Boolean get() = when (Profile.str(this, "theme", "auto")) {
        "light" -> false; "dark" -> true
        else -> (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    }
    private val bgc: Int get() = if (dark) 0xFF14181B.toInt() else Color.WHITE
    private val ink: Int get() = if (dark) 0xFFF2F4F5.toInt() else 0xFF1F1A14.toInt()
    private val muted: Int get() = if (dark) 0xFFADB5BA.toInt() else 0xFF534C45.toInt()
    private val accent: Int get() = if (dark) 0xFF18C3DA.toInt() else 0xFF145A3D.toInt()
    private val onAccent: Int get() = if (dark) 0xFF06262C.toInt() else Color.WHITE
    private val soft: Int get() = if (dark) 0xFF1E2428.toInt() else 0xFFF1EADD.toInt()
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun box(c: Int, r: Int) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat() }

    // The picture with a red circle where they pointed, small enough to send.
    private fun marked(b: Bitmap, x: Float, y: Float): Bitmap {
        val w = 480
        val s = if (b.width > w) Bitmap.createScaledBitmap(b, w, maxOf(1, b.height * w / b.width), true) else b.copy(Bitmap.Config.ARGB_8888, true)
        val m = if (s.isMutable) s else s.copy(Bitmap.Config.ARGB_8888, true)
        if (x in 0f..1f && y in 0f..1f) {
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = m.width / 70f; color = 0xFFFF1744.toInt() }
            Canvas(m).drawCircle(x * m.width, y * m.height, m.width / 11f, p)
        }
        return m
    }

    private fun jpg(b: Bitmap): String {
        val o = java.io.ByteArrayOutputStream()
        b.compress(Bitmap.CompressFormat.JPEG, 60, o)
        return android.util.Base64.encodeToString(o.toByteArray(), android.util.Base64.NO_WRAP)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Server.initTester(this)
        if (!Server.tester) { finish(); return }
        val shot = ChangeDraft.shot; val x = ChangeDraft.x; val y = ChangeDraft.y; val words = ChangeDraft.words
        val preview = shot?.let { marked(it, x, y) }
        window.setGravity(Gravity.BOTTOM)
        window.setLayout(ALL, SOME)
        window.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
        setFinishOnTouchOutside(true)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(16), dp(18), dp(16))
            background = GradientDrawable().apply { setColor(bgc); val r = dp(24).toFloat(); cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f) }
        }
        root.addView(TextView(this).apply {
            text = "What should change?"; textSize = 20f; typeface = Typeface.DEFAULT_BOLD; setTextColor(ink)
        })
        root.addView(TextView(this).apply {
            text = "For example: “Make this button bigger”, “Remove this step”, “Add a Share button here”. " +
                "Your words go to GitHub as you write them, so leave out anything private."
            textSize = 14.5f; setTextColor(muted); setPadding(0, dp(4), 0, dp(10))
        })
        if (preview != null) root.addView(ImageView(this).apply {
            setImageBitmap(preview); adjustViewBounds = true; scaleType = ImageView.ScaleType.FIT_CENTER
            background = box(soft, 12); contentDescription = "The screen, with a red circle where you pointed"
            layoutParams = LinearLayout.LayoutParams(ALL, dp(170)).apply { bottomMargin = dp(10) }
        })
        input = EditText(this).apply {
            hint = "Say or type the change"; textSize = 16f; minLines = 2; maxLines = 5
            setTextColor(ink); setHintTextColor(muted); background = box(soft, 18); setPadding(dp(14), dp(12), dp(14), dp(12))
            layoutParams = LinearLayout.LayoutParams(0, SOME, 1f)
        }
        val mic = IconView(this, "mic", ink).apply {
            setPadding(dp(13), dp(13), dp(13), dp(13)); background = GradientDrawable().apply { setColor(soft); shape = GradientDrawable.OVAL }
            layoutParams = LinearLayout.LayoutParams(dp(48), dp(48)).apply { leftMargin = dp(6) }
            contentDescription = "Speak"; isClickable = true; setOnClickListener { listen() }
        }
        root.addView(LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; addView(input); addView(mic) })
        val cancel = TextView(this).apply {
            text = "Cancel"; textSize = 16f; setTextColor(ink); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            background = box(soft, 24); minHeight = dp(48); setPadding(dp(12), dp(12), dp(12), dp(12))
            layoutParams = LinearLayout.LayoutParams(0, SOME, 1f).apply { rightMargin = dp(8) }
            setOnClickListener { finish() }
        }
        val add = TextView(this).apply {
            text = "Add to the list"; textSize = 16f; setTextColor(onAccent); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            background = box(accent, 24); minHeight = dp(48); setPadding(dp(12), dp(12), dp(12), dp(12))
            layoutParams = LinearLayout.LayoutParams(0, SOME, 1f)
        }
        add.setOnClickListener {
            val text = input.text.toString().trim()
            if (text.length < 3) { input.error = "Say what should change"; return@setOnClickListener }
            add.isEnabled = false; cancel.isEnabled = false; add.text = "Adding…"
            val id = Server.installId(this)
            Thread {
                val pic = Server.watchChange(id, text, x, y, words)
                if (pic > 0 && preview != null) WatchShots.add(pic, jpg(preview))
                runOnUiThread {
                    if (pic > 0) {
                        Toast.makeText(this, "Added. You will see it in the list after the guide.", Toast.LENGTH_LONG).show()
                        ChangeDraft.set(null, -1f, -1f, emptyList()); finish()
                    } else {
                        add.isEnabled = true; cancel.isEnabled = true; add.text = "Add to the list"
                        Toast.makeText(this, "Could not add it. Check the internet and try again.", Toast.LENGTH_LONG).show()
                    }
                }
            }.start()
        }
        root.addView(LinearLayout(this).apply { setPadding(0, dp(12), 0, 0); addView(cancel); addView(add) })
        setContentView(root)
    }

    // While this panel is open the on-screen guide hides its ring, cards and buttons, so nothing covers it.
    override fun onResume() { super.onResume(); Guides.chatOpen = true }
    override fun onPause() { Guides.chatOpen = false; super.onPause() }

    private fun listen() {
        try {
            startActivityForResult(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM), 12)
        } catch (e: ActivityNotFoundException) { Toast.makeText(this, "Voice input is not available on this phone", Toast.LENGTH_LONG).show() }
    }

    override fun onActivityResult(rc: Int, res: Int, data: Intent?) {
        super.onActivityResult(rc, res, data)
        if (rc == 12 && res == RESULT_OK) data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let {
            val now = input.text.toString().trim()
            input.setText(if (now.isEmpty()) it else "$now $it"); input.setSelection(input.text.length)
        }
    }
}
