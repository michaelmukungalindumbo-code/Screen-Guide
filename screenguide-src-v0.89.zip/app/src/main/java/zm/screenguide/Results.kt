package zm.screenguide

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

// Developer phones: "Past results". Every pop-up after a guide or a test is kept on this phone: the problems and how to
// fix them, the screen pictures, and the server's signed copy, so it can be read again and still sent with Allow later
// (up to 30 days). Only on this phone, in the app's private storage, never in a backup. The newest 10 are kept.
class SavedResult(val id: Long, val title: String, val problems: JSONArray, val saved: String, val sentIds: Set<String> = emptySet(),
                  val note: String = "") {
    val ids: List<String> get() = (0 until problems.length()).mapNotNull { problems.optJSONObject(it)?.optString("id")?.ifEmpty { null } }
    // Everything in it has gone to the AI fixer
    val sent: Boolean get() = ids.isNotEmpty() && sentIds.containsAll(ids)
}

object Results {
    const val KEEP = 10
    private fun dir(c: Context) = File(c.noBackupFilesDir, "results").apply { mkdirs() }

    // Plain functions (no Android needed), so unit tests can check them.
    internal fun encode(r: SavedResult): String = JSONObject().put("id", r.id).put("title", r.title).put("problems", r.problems)
        .put("saved", r.saved).put("sentIds", JSONArray(r.sentIds.toList().sorted())).put("note", r.note).toString()

    internal fun decode(text: String): SavedResult? = try {
        val o = JSONObject(text)
        val ps = o.getJSONArray("problems")
        val a = o.optJSONArray("sentIds")
        val sent = if (a != null) (0 until a.length()).map { a.optString(it) }.toSet()
            // v0.62 kept only "sent": true for the whole list
            else if (o.optBoolean("sent")) (0 until ps.length()).mapNotNull { ps.optJSONObject(it)?.optString("id") }.toSet() else emptySet()
        SavedResult(o.getLong("id"), o.optString("title"), ps, o.optString("saved"), sent, o.optString("note"))
    } catch (e: Exception) { null }

    internal fun encodeShots(shots: List<Pair<Int, String>>): String {
        val a = JSONArray(); shots.forEach { (n, jpg) -> a.put(JSONObject().put("n", n).put("jpg", jpg)) }
        return a.toString()
    }

    internal fun decodeShots(text: String): List<Pair<Int, String>> = try {
        val a = JSONArray(text)
        (0 until a.length()).mapNotNull { i -> a.optJSONObject(i)?.let { o -> o.optInt("n", 0) to o.optString("jpg") } }
            .filter { (n, jpg) -> n > 0 && jpg.isNotEmpty() }
    } catch (e: Exception) { emptyList() }

    // Which results to delete so that only the newest [keep] stay.
    internal fun toDrop(ids: List<Long>, keep: Int = KEEP): List<Long> = ids.sortedDescending().drop(keep)

    // "3 problems · 1 change", for the list.
    internal fun summary(problems: JSONArray): String {
        val kinds = (0 until problems.length()).map { problems.optJSONObject(it)?.optString("kind", "problem") ?: "problem" }
        fun n(k: String, one: String) = kinds.count { it == k }.let { if (it == 0) "" else if (it == 1) "1 $one" else "$it ${one}s" }
        return listOf(n("problem", "problem"), n("change", "change"), n("idea", "idea")).filter { it.isNotEmpty() }.joinToString(" · ")
    }

    private fun ids(d: File): List<Long> =
        d.listFiles()?.mapNotNull { f -> if (f.name.endsWith(".json")) f.name.removeSuffix(".json").toLongOrNull() else null } ?: emptyList()

    fun add(c: Context, title: String, problems: JSONArray, saved: String, shots: List<Pair<Int, String>>, note: String = ""): Long {
        val d = dir(c)
        var id = System.currentTimeMillis()
        while (File(d, "$id.json").exists()) id++
        if (shots.isNotEmpty()) File(d, "$id.shots").writeText(encodeShots(shots))
        File(d, "$id.json").writeText(encode(SavedResult(id, title, problems, saved, emptySet(), note)))
        toDrop(ids(d)).forEach { File(d, "$it.json").delete(); File(d, "$it.shots").delete() }
        return id
    }

    fun list(c: Context): List<SavedResult> = try { ids(dir(c)).sortedDescending().mapNotNull { load(c, it) } } catch (e: Exception) { emptyList() }

    fun load(c: Context, id: Long): SavedResult? = try { decode(File(dir(c), "$id.json").readText()) } catch (e: Exception) { null }

    fun shots(c: Context, id: Long): List<Pair<Int, String>> = try { decodeShots(File(dir(c), "$id.shots").readText()) } catch (e: Exception) { emptyList() }

    fun markSent(c: Context, id: Long, done: Collection<String>) {
        if (done.isEmpty()) return
        val r = load(c, id) ?: return
        try { File(dir(c), "$id.json").writeText(encode(SavedResult(r.id, r.title, r.problems, r.saved, r.sentIds + done, r.note))) } catch (e: Exception) {}
    }

    fun delete(c: Context, id: Long) { File(dir(c), "$id.json").delete(); File(dir(c), "$id.shots").delete() }
}
