package zm.screenguide

// When the button a Smart guide step points at disappears, the guide asks the AI again. Once per step, so an AI that
// keeps naming a button that is not there cannot ask again and again; and once more after each new screen.
// 4 Nov (#24): the one re-ask for "Tap Done" was used while the person scrolled the photo picker. After the picker
// closed, YouTube's gallery showed the old "Tap Done" for 8 seconds, with nothing to point at, until the words changed.
object Recheck {
    fun goneMayAsk(askedFor: Any?, step: Any, askedAt: Long, screenAt: Long): Boolean = askedFor !== step || screenAt > askedAt
}
