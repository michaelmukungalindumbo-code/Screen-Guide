package zm.screenguide

// The same button several times on one screen: an "Install" for every app in the Play Store's results, "Follow" or
// "Add friend" in a list. 6 Nov: "Tap Install to install Facebook" put the ring on the first Install, which was
// Instagram's. Which one is meant: the one next to a name from the step ("Facebook"). GuideService gives the places on
// the screen; the deciding is here, so it can be tested.
object Duplicates {
    class Box(val text: String, val left: Int, val top: Int, val right: Int, val bottom: Int)

    // Words with a capital that are not names: the start of an instruction, the store, the button's own word
    private val notNames = setOf("tap", "press", "open", "choose", "select", "scroll", "swipe", "find", "look", "type", "now", "then",
        "next", "done", "ok", "the", "a", "an", "to", "and", "or", "from", "on", "in", "for", "with", "your", "this", "that", "it", "you",
        "if", "play", "store", "google", "search", "app", "apps", "games", "install", "update", "uninstall", "get", "download")
    private val capitals = Regex("[A-Z][\\p{L}\\p{N}'&+.,!?-]*(?:\\s+[A-Z][\\p{L}\\p{N}'&+.,!?-]*)*")

    // Names in the step and the goal that could be on the screen next to the button: "Facebook" in
    // "Tap Install to install Facebook.", never the button's own word or words like "Tap" and "Play Store".
    fun names(say: String, goal: String, button: String): List<String> {
        val own = Match.words(button).trim().split(" ").toSet()
        val out = LinkedHashSet<String>()
        for (m in capitals.findAll("$say $goal")) {
            val run = ArrayList<String>()
            fun flush() { val n = run.joinToString(" "); if (n.length >= 3) out.add(n); run.clear() }
            for (w in m.value.split(Regex("\\s+"))) {
                val clean = w.trim('.', ',', '!', '?', ':', ';')
                val low = clean.lowercase()
                if (clean.isEmpty() || low in notNames || low in own) { flush(); continue }
                run.add(clean)
                if (w.last() in ".,!?") flush()   // a sentence ends: "Facebook. Messenger" is two names
            }
            flush()
        }
        return out.toList()
    }

    // Which of the buttons (index), or -1 when no name from the step is on the screen. The same line as the name comes
    // first; then the button just below it (its own card); a button above it more likely belongs to the card before.
    fun pick(buttons: List<Box>, others: List<Box>, names: List<String>): Int {
        if (buttons.size < 2 || names.isEmpty()) return -1
        val keys = names.map { Match.words(it) }
        val exact = others.filter { o -> Match.words(o.text) in keys }
        val anchors = exact.ifEmpty { others.filter { o -> keys.any { k -> Match.words(o.text).startsWith(k) } } }
        if (anchors.isEmpty()) return -1
        var best = -1
        var score = Double.MAX_VALUE
        for ((i, b) in buttons.withIndex()) for (a in anchors) {
            val s = when {
                b.top < a.bottom && a.top < b.bottom -> maxOf(0, maxOf(b.left - a.right, a.left - b.right)) / 10.0
                b.top >= a.bottom -> (b.top - a.bottom).toDouble()
                else -> (a.top - b.bottom) * 3.0 + 200
            }
            if (s < score) { score = s; best = i }
        }
        return best
    }
}
