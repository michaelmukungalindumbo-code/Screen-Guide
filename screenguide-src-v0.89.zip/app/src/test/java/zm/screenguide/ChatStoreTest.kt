package zm.screenguide

import org.junit.Assert.assertEquals
import org.junit.Test

class ChatStoreTest {
    private fun chat(id: Int) = """{"id":$id,"title":"Chat $id","s":false,"m":[{"me":true,"t":"hello","g":"","a":false,"p":[],"b":""}]}"""

    @Test fun goodChatsAllLoad() {
        val out = ChatStore.parse("[${chat(1)},${chat(2)},${chat(3)}]")
        assertEquals(listOf(1L, 2L, 3L), out.map { it.id })
        assertEquals("hello", out[0].msgs[0].text)
    }

    // The bug: one damaged chat (here: no "m" list) used to hide every chat after it.
    @Test fun damagedChatInTheMiddleIsSkippedOthersLoad() {
        val bad = """{"id":2,"title":"Old chat"}"""
        val out = ChatStore.parse("[${chat(1)},$bad,${chat(3)},${chat(4)}]")
        assertEquals(listOf(1L, 3L, 4L), out.map { it.id })
    }

    @Test fun damagedMessageSkipsOnlyThatChat() {
        val bad = """{"id":2,"title":"x","m":[{"me":true}]}"""
        val out = ChatStore.parse("[$bad,${chat(3)}]")
        assertEquals(listOf(3L), out.map { it.id })
    }

    @Test fun unreadableTextGivesEmptyList() {
        assertEquals(0, ChatStore.parse("not json at all").size)
        assertEquals(0, ChatStore.parse("[]").size)
    }
}
