package zm.screenguide

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class RecheckTest {
    private val done = Any()   // the "Tap Done" step

    @Test fun aGoneButtonIsAskedAboutOnce() {
        assertTrue(Recheck.goneMayAsk(null, done, 0L, 1_000L))              // first time: ask
        assertFalse(Recheck.goneMayAsk(done, done, 5_000L, 1_000L))         // asked, same screen since: do not ask again
    }

    @Test fun aNewScreenAllowsOneMoreAsk() {
        // #24, 4 Nov: asked at 5 s while scrolling the picker; the picker closed at 9 s and YouTube's gallery came back
        assertTrue(Recheck.goneMayAsk(done, done, 5_000L, 9_000L))
    }

    @Test fun aNewStepIsAlwaysAllowed() {
        assertTrue(Recheck.goneMayAsk(done, Any(), 5_000L, 1_000L))
    }
}
