package zm.screenguide

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

// v0.85, 7 Nov: an app name written or heard another way. Split by the AI or voice typing ("Cap Cut", "you tube", "Whats
// App"), a letter slipped ("Watsap", "Youtub"), or heard as other words ("what's up"). Before, the app was not opened,
// or was called "not on this phone" and offered for install; "open watsap" in the chat needed the AI.
class NearNamesTest {
    private val apps = (MatchCases.apps.map { it.first } + "CapCut").map { it to "pkg." + it.lowercase().replace(" ", "") }
    private val names = apps.map { it.first }
    private fun pick(goal: String) = Match.pickApp(goal, apps)?.first

    @Test fun aSplitNameIsTheApp() {
        assertEquals("CapCut", pick("Open the Cap Cut app"))
        assertEquals("YouTube", pick("Upload a video on you tube"))
        assertEquals("WhatsApp", pick("Send a message on Whats App"))
        assertEquals("TikTok", pick("Open Tick Tock"))
    }

    @Test fun aSlippedLetterIsTheApp() {
        assertEquals("WhatsApp", pick("Send a message on watsap"))
        assertEquals("YouTube", pick("Watch videos on Youtub"))
        assertEquals("Facebook", pick("Post on facbook"))
        assertEquals("Chrome", pick("Open Chrom"))
        assertEquals("Instagram", pick("Open Instagramm"))
        assertEquals("Messenger", pick("Open Messanger"))
    }

    @Test fun aNameHeardAsOtherWords() {
        assertEquals("WhatsApp", pick("Open what's up"))
        assertEquals("Instagram", pick("open insta"))
    }

    // The name as written still wins; a slip never turns an ordinary word into an app
    @Test fun ordinaryWordsStayOrdinary() {
        assertEquals("WhatsApp", pick("Send a photo on watsap"))      // not Photos
        assertNull(pick("Make my phone faster"))                        // "phone faster" is not Phone Master
        assertNull(pick("Write a note")); assertNull(pick("Take a photo")); assertNull(pick("Read the news"))
        assertNull(pick("Send a photo to my friend")); assertNull(pick("Find my phone"))
        assertNull(pick("Join a class on Zoon"))                        // short names are matched only as written
        assertNull(pick("Open Whats App Business"))                     // another app, as before
    }

    // The Go and Lite versions count, as before
    @Test fun aLighterVersionCounts() {
        val lite = listOf("Facebook Lite" to "pkg.fblite", "Settings" to "pkg.settings")
        assertEquals("Facebook Lite", Match.pickApp("Post on facbook", lite)?.first)
    }

    // Not offered for install when it is on the phone under its real name
    @Test fun notCalledMissing() {
        assertNull(Match.missingApp("Open the Cap Cut app", names))
        assertNull(Match.missingApp("Open the Watsap app", names))
        assertEquals("Cap Cut", Match.missingApp("Open the Cap Cut app", names - "CapCut"))   // really not there: offered
    }

    // "open watsap" typed in the chat: opened on the phone, without the AI
    @Test fun openingFromTheChat() {
        assertEquals("WhatsApp", Match.findTarget("open watsap", names))
        assertEquals("Instagram", Match.findTarget("open insta", names))
        assertEquals("YouTube", Match.findTarget("where is you tube", names))
        assertNull(Match.findTarget("start a call", names))
        assertNull(Match.findTarget("find my phone", names))
    }
}
