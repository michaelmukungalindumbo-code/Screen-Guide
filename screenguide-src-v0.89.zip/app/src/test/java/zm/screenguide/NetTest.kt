package zm.screenguide

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

// v0.66: a weak network is tried once more, but only when nothing can have reached the server (3 Nov: "No connection"
// in the middle of a guide from one failed name lookup).
class NetTest {
    @Test fun failuresBeforeTheServerAreTriedAgain() {
        assertTrue(Net.retryable(java.net.UnknownHostException("screen-guide-server.onrender.com")))
        assertTrue(Net.retryable(java.net.ConnectException("refused")))
        assertTrue(Net.retryable(javax.net.ssl.SSLHandshakeException("reset")))
    }

    @Test fun failuresAfterTheServerMayHaveActedAreNot() {
        assertFalse(Net.retryable(java.net.SocketTimeoutException("read timed out")))   // the server may be working on it
        assertFalse(Net.retryable(java.io.EOFException("unexpected end of stream")))   // an Allow may already have been sent
        assertFalse(Net.retryable(RuntimeException("other")))
    }
}
