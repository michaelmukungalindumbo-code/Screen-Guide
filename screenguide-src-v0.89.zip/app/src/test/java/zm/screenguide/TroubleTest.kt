package zm.screenguide

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

// v0.86, 7 Nov (the owner's list): an install stopped because the phone is full, offline or waiting for Wi-Fi; an app
// that is turned off.
class TroubleTest {
    private fun src(name: String) = listOf("src/main/$name", "app/src/main/$name").map { File(it) }.first { it.exists() }.readText()

    @Test fun anInstallStoppedSaysWhy() {
        assertEquals("storage", Trouble.installProblem("Install CapCut from the Play Store", listOf("CapCut", "Not enough storage", "Free up space")))
        assertEquals("storage", Trouble.installProblem("Update WhatsApp", listOf("Insufficient storage")))
        assertEquals("internet", Trouble.installProblem("Install TikTok from the Play Store", listOf("You're offline", "Try again")))
        assertEquals("wifi", Trouble.installProblem("Download Boomplay", listOf("Boomplay", "Waiting for Wi-Fi")))
    }

    @Test fun onlyWhileInstallingAndOnlyShortLines() {
        assertNull(Trouble.installProblem("Upload a video to YouTube", listOf("Not enough storage")))          // not installing
        assertNull(Trouble.installProblem("Install CapCut from the Play Store", listOf("Install", "CapCut", "4.5", "Editors' Choice")))
        val about = "Phone Master cleans your phone. Is your storage full? Free up space in one tap and keep your phone fast, with the " +
            "junk cleaner, the app manager and the battery saver, all in one small app."
        assertNull(Trouble.installProblem("Install Phone Master", listOf(about)))                          // an app's description
    }

    @Test fun theStoresOwnButtonGetsTheRing() {
        assertTrue(Trouble.isFix("storage", "Free up space")); assertTrue(Trouble.isFix("internet", "Try again"))
        assertTrue(Trouble.isFix("internet", "Retry")); assertFalse(Trouble.isFix("internet", "Install"))
    }

    // The words are the ones "Error messages explained" already has, with their checked Nyanja and Bemba
    @Test fun theSameCheckedWords() {
        val g = src("java/zm/screenguide/GuideService.kt")
        assertTrue(g.contains("tip(\"storage\", Trouble.STORAGE") && g.contains("tip(\"internet\", Trouble.INTERNET"))
        assertTrue(g.contains("errorTips.first { it.id == \"storage\" }.say") && g.contains("if (installTrouble(nodes, pkg)) return"))
    }

    @Test fun aTurnedOffAppIsKnownByItsName() {
        assertEquals("com.google.android.apps.docs", KnownApps.named("Scan a document with the Drive app")?.second)
        assertEquals("com.google.android.youtube", KnownApps.named("Watch videos on Youtub")?.second)
        assertEquals("com.android.chrome", KnownApps.named("Open Google Chrome")?.second)
        assertNull(KnownApps.named("Send a message on WhatsApp"))
        assertNull(KnownApps.named("Take a screenshot"))
    }

    // The phone shows ScreenGuide these apps even when turned off only if the manifest lists them; and turned off is
    // checked before "not on this phone"
    @Test fun theWiringIsThere() {
        val m = src("AndroidManifest.xml")
        for ((_, pkg) in KnownApps.list) assertTrue(pkg, m.contains("<package android:name=\"$pkg\"/>"))
        val a = src("java/zm/screenguide/MainActivity.kt")
        assertTrue(a.indexOf("Guides.offApp(this, goal)") in 1 until a.indexOf("Match.missingApp(goal, Guides.installedNames(this))"))
        assertTrue(a.contains("ACTION_APPLICATION_DETAILS_SETTINGS") && a.contains("Step(KnownApps.enableWords"))
    }
}
