package zm.screenguide

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DuplicatesTest {
    private fun box(t: String, top: Int, h: Int = 40, left: Int = 40, right: Int = 680) = Duplicates.Box(t, left, top, right, top + h)

    // v0.77, 6 Nov: the Play Store's results for Facebook, with Instagram's card first
    private val installs = listOf(box("Install", 380), box("Install", 680), box("Install", 980))
    private val words = listOf(box("Instagram", 300), box("Meta Platforms, Inc.", 340), box("Facebook", 600),
        box("Meta Platforms, Inc.", 640), box("Messenger", 900))

    @Test fun theNamesInAStep() {
        val n = Duplicates.names("Tap Install to install Facebook.", "Install Facebook from the Play Store", "Install")
        assertTrue(n.toString(), "Facebook" in n)
        assertTrue(n.toString(), n.none { it.equals("Install", true) || it.equals("Tap", true) || it.contains("Store") })
        assertTrue(Duplicates.names("Tap Install.", "", "Install").isEmpty())
    }

    @Test fun theButtonNextToTheNameIsRinged() {
        val names = Duplicates.names("Tap Install to install Facebook.", "Install Facebook from the Play Store", "Install")
        assertEquals(1, Duplicates.pick(installs, words, names))                         // Facebook's, not Instagram's
        assertEquals(2, Duplicates.pick(installs, words, listOf("Messenger")))
        assertEquals(-1, Duplicates.pick(installs, words, listOf("TikTok")))              // no name on screen: as before
    }

    // Rows with the name on the left and the button on the right, on the same line
    @Test fun sameLineWins() {
        val follow = listOf(box("Follow", 200, left = 520), box("Follow", 300, left = 520), box("Follow", 400, left = 520))
        val people = listOf(box("Ministry of Health", 205, right = 400), box("Zambia Daily Mail", 305, right = 400), box("ZNBC", 405, right = 400))
        assertEquals(2, Duplicates.pick(follow, people, listOf("ZNBC")))
        // Facebook Lite just above Facebook: the exact name wins
        val rows = listOf(box("Facebook Lite", 200, right = 400), box("Facebook", 300, right = 400))
        assertEquals(1, Duplicates.pick(follow.take(2), rows, listOf("Facebook")))
    }

    // A button above the name usually belongs to the card before it
    @Test fun theCardsOwnButtonComesFirst() {
        val buttons = listOf(box("Install", 560), box("Install", 700))
        val names = listOf(box("Facebook", 600))
        assertEquals(1, Duplicates.pick(buttons, names, listOf("Facebook")))
    }
}
