package zm.screenguide

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class SelfGuideTest {
    private val customize = listOf("Menu", "Customize ScreenGuide")

    // v0.79, 6 Nov: "change my ScreenGuide chat background" went home, rang ScreenGuide's icon, and round again. The owner
    // chose: Show me works inside ScreenGuide too. Its menus are known, so the way there needs no AI.
    @Test fun theWayToScreenGuidesOwnSettings() {
        assertEquals(customize + "Chat background", Match.selfPath("Change the chat background in ScreenGuide"))
        assertEquals(customize + "Chat background", Match.selfPath("change my Screen Guide chat background"))
        assertEquals(customize + "Chat background", Match.selfPath("Make ScreenGuide's chat background dark"))
        assertEquals(customize + "Language", Match.selfPath("Change the language of ScreenGuide"))
        assertEquals(customize + "Speak the steps", Match.selfPath("Turn off ScreenGuide's voice"))
        assertEquals(customize + "Record a real voice for the steps", Match.selfPath("Record my own voice for ScreenGuide"))
        assertEquals(customize + "Colours", Match.selfPath("Use dark mode in ScreenGuide"))
        assertEquals(listOf("Menu", "Settings and permissions", "Read button: reads any screen to you"),
            Match.selfPath("Turn on the Read button in ScreenGuide"))
        assertEquals(listOf("Menu", "Your account"), Match.selfPath("Sign in to ScreenGuide"))
        assertEquals(listOf("Menu"), Match.selfPath("Change something in ScreenGuide"))      // not sure what: open the menu
    }

    @Test fun otherAppsAreNotScreenGuide() {
        assertNull(Match.selfPath("Change my WhatsApp chat background"))
        assertNull(Match.selfPath("Turn on dark mode"))
        assertNull(Match.selfPath("Change the language of my phone"))
    }

    @Test fun whatToDoAtTheEnd() {
        assertEquals("Now tap a colour, or Your photo for a picture from your gallery.", Match.selfDone("Chat background"))   // v0.80
        assertEquals("Now tap your language.", Match.selfDone("Language"))
        assertNull(Match.selfDone("Incognito"))
        assertEquals("Now tap Sign out, or Sign in with Google.", Match.selfDone("Your account"))   // v0.80: "How do I log out"
        assertEquals(listOf("Menu", "Your account"), Match.selfPath("Log out of ScreenGuide"))
    }

    // v0.80, 6 Nov: on the colour list, whose title is also "Chat background", the guide kept saying "Tap Chat background".
    // ScreenGuide's own lists close as they are tapped, and Android drops the tap with them. Now the menus tell the guide.
    @Test fun theLastTapIsHeardFromTheMenus() {
        assertTrue(Match.selfFinished("Chat background", "Chat background"))
        assertTrue(Match.selfFinished("Language", "Language"))          // the language button on the chat screen works too
        assertFalse(Match.selfFinished("Chat background", "Customize ScreenGuide"))
        assertFalse(Match.selfFinished("Chat background", null))
    }

    // Every name on the way is really in ScreenGuide's menus: a renamed row would leave the ring with nothing to find
    @Test fun everyNameIsInTheMenus() {
        val src = listOf("src/main/java/zm/screenguide/MainActivity.kt", "app/src/main/java/zm/screenguide/MainActivity.kt")
            .map { File(it) }.first { it.exists() }.readText()
        for (row in Match.selfRows()) assertTrue("\"$row\" is not in MainActivity", src.contains("\"$row\""))
        assertTrue(Match.selfRows().size >= 20)
    }
}
