package zm.screenguide

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TestingTest {
    private fun part(text: String, click: Boolean = true, w: Int = 48, h: Int = 48, labelled: Boolean = text.isNotBlank(),
                     edit: Boolean = false, progress: Boolean = false) = Testing.Part(text, click, edit, progress, w, h, labelled)

    @Test fun errorMessagesAreFoundButNotArticles() {
        assertEquals("Something went wrong. Try again.", Testing.errorText(listOf("Home", "Something went wrong. Try again.")))
        assertEquals("Error 404", Testing.errorText(listOf("Error 404")))
        assertNull(Testing.errorText(listOf("Download", "Past papers", "Terror")))          // "Terror" is not "error"
        assertNull(Testing.errorText(listOf("How to fix a failed download: " + "x".repeat(150))))   // long text is an article
    }

    @Test fun aTryAgainButtonIsNotAnErrorMessage() {
        // 2 Nov: the ↻ button under ScreenGuide's answer is named "Try again"; it was reported as an error message
        assertTrue(Testing.look(listOf(part("Try again"), part("Copy"), part("Speak"))).none { it.kind == "error_text" })
        val found = Testing.look(listOf(part("Could not load the papers.", click = false), part("Try again")))
        assertEquals("Could not load the papers.", found.first { it.kind == "error_text" }.detail)
    }

    @Test fun buttonsWithNoNameAndSmallButtons() {
        val found = Testing.look(listOf(part("Download"), part("", labelled = false), part("", labelled = false, w = 24, h = 24),
            part("Row with words inside", labelled = true), part("Search", edit = true, labelled = false), part("Title", click = false)))
        val kinds = found.associate { it.kind to it.detail }
        assertEquals("2", kinds["unlabeled"])          // the two icon buttons; the row has words inside, the search box is a box
        assertEquals("1", kinds["small_target"])       // the 24 dp one
        assertTrue(Testing.look(listOf(part("Download"), part("Share"))).isEmpty())
    }

    @Test fun androidsCrashAndFreezeMessages() {
        assertEquals("crash", Testing.systemMessage(listOf("Zexam keeps stopping", "App info", "Close app"), "Zexam")?.kind)
        assertEquals("freeze", Testing.systemMessage(listOf("Zexam isn't responding", "Wait"), "Zexam")?.kind)
        assertNull(Testing.systemMessage(listOf("WhatsApp keeps stopping"), "Zexam"))   // another app
    }

    @Test fun threeTapsThatChangeNothing() {
        val t = Testing.TapWatch()
        assertTrue(!t.tap("Download", "s1", 0) && !t.tap("Download", "s1", 1000))
        assertTrue(t.tap("Download", "s1", 2000))
        assertTrue(!t.tap("Share", "s1", 2100) && !t.tap("Share", "s2", 2200) && !t.tap("Share", "s2", 2300))   // the screen changed
        assertTrue(!t.tap("Next", "s2", 10000) && !t.tap("Next", "s2", 15000) && !t.tap("Next", "s2", 20000))   // too slow to count
    }

    @Test fun loadingThatStays() {
        val l = Testing.Loading()
        assertNull(l.seen(true, 0)); assertNull(l.seen(true, 5000))
        assertEquals(9, l.seen(true, 9000))
        assertNull(l.seen(false, 9500)); assertNull(l.seen(true, 10000)); assertNull(l.seen(true, 12000))
    }

    // v0.65: the screen changed under a step that stayed (2 Nov: the photo was taken, the guide kept saying to take it)
    private fun flat(v: Int) = IntArray(120) { v }

    @Test fun aChangedScreenUnderTheSameStepIsReported() {
        val w = StaleWatch(); val step = Any()
        w.step(step, 0); w.print(step, flat(20))                  // the camera screen, just after the step was shown
        w.event(5000)
        assertTrue(!w.due(step, 6000))                            // the app is still busy
        assertTrue(w.due(step, 6600))                             // quiet for 1.5 s: look
        assertTrue(!w.compared(step, flat(80), 6600))             // changed (the photo review screen): wait to be sure
        assertTrue(w.waiting && !w.due(step, 9000) && w.due(step, 12600))
        assertTrue(w.compared(step, flat(80), 12600))             // 6 s later the guide still shows the same step: report
        assertEquals(6, w.secs(12600))
        assertTrue(!w.due(step, 20000) && !w.compared(step, flat(80), 20000))   // only once per step
    }

    @Test fun nothingIsReportedWhenTheGuideMovesOnOrNothingChanged() {
        val w = StaleWatch(); val a = Any(); val b = Any()
        w.step(a, 0); w.print(a, flat(20)); w.event(4000)
        assertTrue(!w.compared(a, flat(30), 6000))                // a small change (the ring pulsing, a toast): not a change
        assertTrue(!w.waiting)
        assertTrue(!w.compared(a, flat(90), 6000))
        w.step(b, 7000)                                           // the guide asked again: a new step, start over
        assertTrue(!w.waiting && !w.due(b, 20000) && w.print == null)
        assertTrue(!w.compared(a, flat(90), 20000))               // the old step does not count any more
        val c = StaleWatch(); val s = Any()
        c.step(s, 0); c.print(s, flat(20)); c.event(200)          // only the step's own drawing: not an app change
        assertTrue(!c.due(s, 5000))
    }

    // v0.74, 4 Nov: "Screen changed, step 9 stayed" while ScreenGuide was already asking the AI about the new screen
    @Test fun askingAgainIsNotStaying() {
        val w = StaleWatch(); val step = Any()
        w.step(step, 0); w.print(step, flat(20)); w.event(5000)  // the person tapped: a new screen
        w.asked(step)                                             // ScreenGuide asks the AI about it
        assertTrue(!w.due(step, 6600) && !w.compared(step, flat(80), 6600) && !w.waiting)
        assertTrue(!w.compared(step, flat(80), 12600))            // the answer is still coming 6 s later: not reported
        w.print(step, flat(80))                                   // the AI kept the same step: its picture is now this screen
        w.event(14000)
        assertTrue(w.due(step, 15600) && !w.compared(step, flat(80), 15600) && !w.waiting)   // nothing changed since
        w.event(16000)                                            // a change after that, with no new question
        assertTrue(w.due(step, 17600) && !w.compared(step, flat(20), 17600) && w.compared(step, flat(20), 23600))
        val o = StaleWatch(); val s = Any()
        o.step(s, 0); o.print(s, flat(20)); o.event(4000)
        o.asked(Any())                                            // a question for another step changes nothing here
        assertTrue(o.due(s, 5600))
    }

    @Test fun greysAndDifferences() {
        assertEquals(listOf(0, 255, 76), StaleWatch.grey(intArrayOf(0xFF000000.toInt(), 0xFFFFFFFF.toInt(), 0xFFFF0000.toInt())).toList())
        assertEquals(50, StaleWatch.diff(flat(20), flat(70)))
        assertEquals(0, StaleWatch.diff(flat(20), IntArray(3)))
    }

    // v0.67: a slow answer as the phone saw it (3 Nov: 20 s) is reported; 10 s or less is not
    @Test fun slowAnswersAreOverTenSeconds() {
        assertTrue(Watch.slow(20_200)); assertTrue(!Watch.slow(10_000)); assertTrue(!Watch.slow(4_500))
    }

    // v0.69: Allow waits long enough to stop a stray tap, but not so long that it gets in the way
    @Test fun allowWaitsAMoment() { assertTrue(Watch.ARM_MS in 1_500L..3_000L) }

    // v0.73: the strip says when the stronger AI answered (after Help)
    @Test fun stripSaysWhichAi() {
        assertEquals("Last AI answer: 2.3 s", Watch.answerNote(2345, false, false))
        assertEquals("Last AI answer: 4.1 s, stronger AI, with a screen picture", Watch.answerNote(4100, true, true))
    }

    // v0.72: after a guide on a test phone the watcher always says something (4 Nov: a guide ended in silence)
    @Test fun watcherIsNeverSilent() {
        for (err in listOf("", "no connection")) for (lost in listOf(false, true)) for (st in listOf(false, true)) for (t in listOf(false, true))
            assertTrue(Watch.afterText(err, lost, st, t).isNotBlank())
        assertEquals("Guide finished. The watcher saw no problems.", Watch.afterText("", false, false, false))
        assertTrue(Watch.afterText("the server answered 500", false, true, false).contains("did not come through"))
        assertTrue(Watch.afterText("", true, false, false).contains("server restarted"))
    }
}
