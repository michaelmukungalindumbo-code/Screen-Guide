package zm.screenguide

import org.junit.Assert.assertTrue
import org.junit.Test

class MatchTest {
    @Test fun everyRealQuestionPicksTheRightAction() {
        val bad = MatchCases.failures(MatchCases.guidesFile().readText())
        assertTrue("Words picked the wrong action:\n" + bad.joinToString("\n"), bad.isEmpty())
    }
}
