package zm.screenguide

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

// v0.86, 7 Nov (the owner's list): two copies of an app (App twin, Dual apps), and an app whose icon is hidden.
class TwinHiddenTest {
    @Test fun aSecondCopyIsMarkedAsOne() {
        for (w in listOf("WhatsApp (2)", "Dual WhatsApp", "WhatsApp Twin", "WhatsApp clone", "Twin WhatsApp")) {
            assertTrue(w, FindApp.isCopyOf(w, "WhatsApp")); assertTrue(w, FindApp.isTwin(w, "WhatsApp"))
        }
        assertTrue(FindApp.isCopyOf("WhatsApp", "WhatsApp")); assertFalse(FindApp.isTwin("WhatsApp", "WhatsApp"))
        assertFalse(FindApp.isCopyOf("WhatsApp Business", "WhatsApp"))                 // another app
        assertFalse(FindApp.isCopyOf("Facebook Lite", "Facebook"))
        assertEquals("You have two WhatsApp. Tap the one you want.", FindApp.twoCopies("WhatsApp"))
    }

    // An icon and its name overlap: one place. Two copies side by side: two places.
    @Test fun copiesAreCountedByPlace() {
        val icon = intArrayOf(40, 400, 160, 520); val name = intArrayOf(30, 525, 170, 560)
        val iconAndName = intArrayOf(30, 400, 170, 560)
        assertEquals(1, FindApp.places(listOf(iconAndName, icon, name)))
        assertEquals(2, FindApp.places(listOf(iconAndName, intArrayOf(210, 400, 350, 560))))
        assertEquals(0, FindApp.places(emptyList()))
    }

    // The owner's list of all apps (7 Nov recording, Infinix): A to Z, after a row of recent apps
    private val installed = listOf("AI Gallery", "AI Studio", "Base44", "Calculator", "Calendar", "Camera", "Chrome", "Clock", "Contacts",
        "Docs", "Drive", "English", "FairMoney", "Files", "Gemini", "Gmail", "Google", "Messages", "Past Papers ZM", "Phone", "Photos",
        "WhatsApp", "YouTube")
    private val recent = listOf("WhatsApp", "Phone", "Chrome")

    @Test fun anIconMissingFromItsPlaceIsHidden() {
        val list = recent + listOf("Calculator", "Calendar", "Camera", "Chrome", "Clock", "Contacts", "Docs", "English", "Files", "Gemini")
        assertTrue(FindApp.hiddenHere("Drive", list, installed))                          // Docs, then English: no Drive
        assertFalse(FindApp.hiddenHere("Drive", list.take(9) + "Drive" + list.drop(9), installed))   // there
        assertFalse(FindApp.hiddenHere("YouTube", list, installed))                       // further down: not seen yet
        assertFalse(FindApp.hiddenHere("Drive", recent + listOf("Docs", "English"), installed))   // too few to be sure
    }

    @Test fun theRecentRowIsNotTheList() {
        // "WhatsApp, Phone, Chrome" is not in A-Z order: no app is "missing" between them
        assertFalse(FindApp.hiddenHere("Messages", recent + listOf("AI Gallery", "AI Studio", "Base44"), installed))
    }

    @Test fun aNameCutShortIsNotHidden() {
        assertTrue(FindApp.isCut("Past Papers …", "Past Papers ZM")); assertTrue(FindApp.isCut("Past Papers ...", "Past Papers ZM"))
        assertFalse(FindApp.isCut("Past Papers ZM", "Past Papers ZM")); assertFalse(FindApp.isCut("Pa…", "Past Papers ZM"))
        val list = listOf("Gemini", "Gmail", "Google", "Messages", "Past Papers …", "Phone", "Photos")
        assertFalse(FindApp.hiddenHere("Past Papers ZM", list, installed))
    }

    @Test fun searchingTheWholeName() {
        assertTrue(FindApp.typedName("Drive", "Drive")); assertTrue(FindApp.typedName("drive ", "Drive"))
        assertFalse(FindApp.typedName("Dri", "Drive")); assertFalse(FindApp.typedName("", "Drive"))
    }

    // The opening step uses them; the person taps "Open" (ScreenGuide never opens it by itself)
    @Test fun theOpeningStepUsesThem() {
        val src = listOf("src/main/java/zm/screenguide/GuideService.kt", "app/src/main/java/zm/screenguide/GuideService.kt")
            .map { File(it) }.first { it.exists() }.readText()
        assertTrue(src.contains("FindApp.isTwin(it, app)") && src.contains("FindApp.twoCopies(app)"))
        assertTrue(src.contains("FindApp.hiddenHere(app, shown, launcherNames())") && src.contains("FindApp.isCut(txt(it), app)"))
        val offer = src.substringAfter("private fun offerOpen(").substringBefore("\n    }\n")
        assertTrue(offer.contains("listOf(\"Open \$app\" to {") && offer.indexOf("startActivity") > offer.indexOf("\"Open \$app\" to {"))
    }
}
