package zm.screenguide

// Which recorded line plays for an instruction, and which button name the phone reads after it.
object VoiceCases {
    fun failures(): List<String> {
        val bad = ArrayList<String>()
        val all: (String) -> Boolean = { true }
        fun check(lang: String, text: String, want: Pair<String, String?>?, has: (String) -> Boolean = all) {
            val got = Voices.matchText(lang, text, has)
            if (got != want) bad.add("$lang \"$text\": got $got, want $want")
        }
        check("bem", "Kandeni “Create new”.", "tap" to "Create new")
        check("ny", "Dinani “Settings”.", "tap" to "Settings")
        check("en", "Tap Settings.", "tap" to "Settings")                      // built-in guides have no quotes
        check("bem", "Kandeni Network & internet.", "tap" to "Network & internet")
        check("bem", "Kandeni ukupyunga Wi-Fi.", null)                          // a Bemba sentence, not a button name
        check("en", "Tap the glowing row.", null)
        check("en", "Tap here.", "tap_here" to null)
        check("bem", "Kandeni apa.", "tap_here" to null)
        check("en", "Tap the switch for “Use Data Saver”.", "switch" to "Use Data Saver")
        check("bem", "Ikeni pansi pa kusanga “Storage”.", "scroll" to "Storage")
        check("ny", "Zabwino!", "well_done" to null)
        check("bem", "nawamya", "well_done" to null)                           // spacing and marks do not matter
        check("en", "Swipe down from the top right corner of the screen.", "pull_right" to null)
        check("bem", "Kandeni “Create new”.", null) { it != "tap" }   // not recorded yet: the phone reads it all
        check("en", "Tapping is fun.", null)
        check("en", "Well done! Drive is open.", null)                         // more than the recording says
        return bad
    }
}

// What a crash report keeps: the kind of error and where in the code, never numbers or emails from the message.
object CrashCases {
    fun failures(): List<String> {
        val bad = ArrayList<String>()
        val e = IllegalStateException("No guide for 0977123456 (michael@example.com)", NumberFormatException("card 4242424242424242"))
        val t = Crash.text(e)
        val lines = t.lines()
        if (!lines[0].startsWith("java.lang.IllegalStateException: No guide for #")) bad.add("first line: ${lines[0]}")
        if (t.contains("0977") || t.contains("michael@") || t.contains("4242")) bad.add("numbers or email kept: $t")
        if (lines.none { it.startsWith("    at zm.screenguide.CrashCases.failures(VoiceCases.kt:") }) bad.add("no code place for this file: $t")
        if (lines.none { it.startsWith("Caused by: java.lang.NumberFormatException: card #") }) bad.add("no cause line: $t")
        // The server keeps only lines shaped like this, so the shape must not change.
        val frame = Regex("^\\s*at [\\w.$<>\\-]+\\([\\w.\\-? ]*(:-?\\d+)?\\)\\s*$")
        if (lines.filter { it.startsWith("    at ") }.any { !frame.matches(it) }) bad.add("a code line the server would drop: $t")
        return bad
    }
}
