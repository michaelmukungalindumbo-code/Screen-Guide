package zm.screenguide

import org.junit.Assert.assertEquals
import org.junit.Test

class ScreenWordsTest {
    private fun tag(switch: Boolean = false, selected: Boolean = false, short: Boolean = true, tappable: Boolean = true,
                    editable: Boolean = false, focused: Boolean = false) = ScreenWords.tag(switch, selected, short, tappable, editable, focused)

    // v0.76, 5 Nov: the Play Store's search box looked the same before and after it was tapped
    @Test fun anOpenTextBoxSaysTyping() {
        assertEquals("[tap]", tag(editable = true))                       // a box not open yet: tap it
        assertEquals("[typing]", tag(editable = true, focused = true))    // open, the keyboard is up: type
        assertEquals("[typing]", tag(editable = true, focused = true, tappable = false))
        assertEquals("[tap]", tag(focused = true))                        // a focused button is still a button
    }

    @Test fun theOtherTagsStayTheSame() {
        assertEquals("[switch]", tag(switch = true))
        assertEquals("[selected]", tag(selected = true))
        assertEquals("[tap]", tag(selected = true, short = false))       // long titles can be "selected" just to scroll
        assertEquals("[tap]", tag())
        assertEquals("[text]", tag(tappable = false))
    }
}
