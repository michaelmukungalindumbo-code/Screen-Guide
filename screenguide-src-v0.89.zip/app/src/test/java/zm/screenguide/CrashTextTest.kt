package zm.screenguide

import org.junit.Assert.assertTrue
import org.junit.Test

class CrashTextTest {
    // 4 Nov (#26): the report stopped 3 causes deep, before the class that was really missing
    @Test fun everyCauseIsKept() {
        var e: Throwable = NoClassDefFoundError("Failed resolution of: Landroidx/lifecycle/LifecycleOwner;")
        for (i in 1..4) e = RuntimeException("level $i", e)
        val t = Crash.text(e)
        assertTrue(t, t.contains("Landroidx/lifecycle/LifecycleOwner;"))
        assertTrue(t.length <= 6000)
    }
}
