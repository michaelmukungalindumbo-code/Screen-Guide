package zm.screenguide

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class CloseTargetTest {
    // A 720 x 1600 phone at 2 pixels per dp; the Read button is 52 dp (104 pixels) wide
    private val w = 720; private val h = 1600; private val dp = 2f; private val size = 104

    // v0.79, 6 Nov: drag the Read button down to the round X at the bottom to close it, like a chat head
    @Test fun theXIsAtTheBottomInTheMiddle() {
        val (cx, cy) = CloseTarget.centre(w, h, dp)
        assertEquals(360, cx)
        assertTrue(cy > h * 0.8 && cy < h - size)                           // low, but the button can still get there
    }

    @Test fun droppedOnTheXCloses() {
        val (cx, cy) = CloseTarget.centre(w, h, dp)
        assertTrue(CloseTarget.over(cx - size / 2, cy - size / 2, size, w, h, dp))          // right on it
        assertTrue(CloseTarget.over(cx - size / 2 + 100, cy - size / 2, size, w, h, dp))    // a little to the side
        assertFalse(CloseTarget.over(w - size - 24, h / 2, size, w, h, dp))                 // where it usually sits
        assertFalse(CloseTarget.over(cx - size / 2, cy - size / 2 - 300, size, w, h, dp))   // above it
        assertFalse(CloseTarget.over(0, cy - size / 2, size, w, h, dp))                     // at the bottom, far to the side
    }
}
