package zm.screenguide

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class WaitingTest {
    private val guide = Any()

    // v0.74, 4 Nov: Help, then Stop while the answer was coming. "Still looking at your screen…" kept coming back over the
    // "Why did you stop?" card, so its buttons were hard to see.
    @Test fun lookingStopsWithTheGuide() {
        assertTrue(Waiting.keepShowing(true, guide, guide))      // the guide that asked: keep saying it is looking
        assertFalse(Waiting.keepShowing(true, guide, null))      // stopped
        assertFalse(Waiting.keepShowing(true, guide, Any()))     // another guide started
        assertFalse(Waiting.keepShowing(false, guide, guide))    // the answer came
    }
}
