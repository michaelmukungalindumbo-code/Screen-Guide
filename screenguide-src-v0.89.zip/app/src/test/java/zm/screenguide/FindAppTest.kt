package zm.screenguide

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import zm.screenguide.FindApp.Way

class FindAppTest {
    // The apps on the test phone that the issue names (ScreenGuide and money apps are never in this list)
    private val installed = listOf("Calculator", "Camera", "Chrome", "Clock", "Drive", "Gmail", "Messages", "Phone", "Photos",
        "Play Store", "Settings", "Sheets", "Weather", "WhatsApp", "YouTube")

    // Issues 39 and 40 (6 Nov, Infinix): the list of all apps, scrolled down to M, Drive out of sight above, a Search box.
    // The words as the issue gives them, top to bottom ("…" stands for words that were removed).
    private val issueList = listOf("Messages", "…", "…", "…", "…", "Phone", "…", "Photos", "…", "Play Store", "…", "…",
        "ScreenGuide", "Settings", "Sheets", "…", "…", "Weather", "WhatsApp", "…", "YouTube", "Search")

    @Test fun theIssuesListIsTheListOfAllApps() {
        assertTrue(FindApp.isAppList(issueList, installed))
    }

    @Test fun inTheListWithSearchItSaysTapSearchAndTypeTheName() {
        val way = FindApp.way(home = true, appList = true, search = true, typing = false, searched = false)
        assertEquals(Way.SEARCH, way)
        assertEquals("Tap “Search”, then type Drive.", FindApp.say(way, "Drive"))
        assertEquals("Tap “Search apps”, then type Drive.", FindApp.say(way, "Drive", "Search apps"))
    }

    @Test fun onceTheSearchIsOpenItSaysWhatToType() {
        // The box is open (the keyboard is up); the list itself may be gone
        val way = FindApp.way(home = true, appList = false, search = false, typing = true, searched = true)
        assertEquals(Way.TYPE, way)
        assertEquals("Type Drive.", FindApp.say(way, "Drive"))
        // Some phones open the search in another app: still the same search
        assertEquals(Way.TYPE, FindApp.way(home = false, appList = false, search = false, typing = true, searched = true))
    }

    @Test fun anOpenBoxWeDidNotAskForIsNotTheSearch() {
        assertEquals(Way.SEARCH, FindApp.way(home = true, appList = true, search = true, typing = true, searched = false))
    }

    @Test fun onTheHomeScreenItStillSaysSwipeUp() {
        // Icons in the person's own order, and maybe a Google search bar: that is not the app list, so no typing there
        val home = listOf("Phone", "Messages", "Chrome", "Camera", "WhatsApp", "Photos", "Play Store", "Search")
        assertFalse(FindApp.isAppList(home, installed))
        val way = FindApp.way(home = true, appList = false, search = true, typing = false, searched = false)
        assertEquals(Way.SWIPE, way)
        assertEquals("Swipe up to see all your apps.", FindApp.say(way, "Drive"))
    }

    @Test fun aListWithoutSearchSaysScroll() {
        val way = FindApp.way(home = true, appList = true, search = false, typing = false, searched = false)
        assertEquals("Scroll down to find “Drive”.", FindApp.say(way, "Drive"))
    }

    @Test fun inAnotherAppItSaysPressHome() {
        val way = FindApp.way(home = false, appList = false, search = true, typing = false, searched = false)
        assertEquals("Press Home, then swipe up to see all your apps.", FindApp.say(way, "Drive"))
    }

    @Test fun otherSignsOfTheList() {
        assertTrue(FindApp.isAppList(listOf("All apps", "Camera"), installed))
        assertTrue(FindApp.isAppList(listOf("Search apps"), installed))
        assertTrue(FindApp.isAppList(listOf("A", "B", "C", "D", "E", "F", "G", "H", "Camera"), installed))
        assertFalse(FindApp.isAppList(listOf("Camera", "Chrome", "Clock"), installed))   // too few names to tell
    }

    @Test fun onlyThePhonesOwnSearchBox() {
        for (w in listOf("Search", "Search apps", "Search your apps", "Search phone", "search apps & more")) assertTrue(w, FindApp.isSearchBox(w))
        for (w in listOf("Search in Drive", "Search YouTube", "Searches", "Research", "")) assertFalse(w, FindApp.isSearchBox(w))
    }

    // The opening step uses these rules, and never rings the search box itself when the name is typed in it
    @Test fun theOpeningStepUsesThem() {
        val src = listOf("src/main/java/zm/screenguide/GuideService.kt", "app/src/main/java/zm/screenguide/GuideService.kt")
            .map { File(it) }.first { it.exists() }.readText()
        assertTrue(src.contains("FindApp.way(") && src.contains("FindApp.isAppList(") && src.contains("FindApp.isSearchBox("))
        assertTrue(src.contains("!it.isEditable && norm((it.text ?: it.contentDescription)?.toString()) == norm(app)"))
    }
}
