package zm.screenguide

// Recording a taught task (Teach): what the person taps becomes steps another phone can follow.
// Pure Kotlin, so it runs on every build with MatchTest.
object TeachCases {
    fun failures(): List<String> {
        val bad = ArrayList<String>()
        fun check(what: String, ok: Boolean) { if (!ok) bad.add(what) }
        fun says() = Teach.steps.map { it.say["en"] }

        Teach.reset("Check ECZ results")
        Teach.tap("Chrome", false)
        Teach.tap("Search or type web address", false, isBox = true)
        Teach.typedIn("ecz results")
        Teach.tap("ECZ Results Portal", false)
        check("box gets what was typed: ${says()}", says() == listOf("Tap “Chrome”.", "Tap the box and type “ecz results”.", "Tap “ECZ Results Portal”."))
        check("Nyanja and Bemba too", Teach.steps[1].say["ny"]!!.startsWith("Dinani bokosi") && Teach.steps[2].say["bem"] == "Kandeni “ECZ Results Portal”.")

        check("a phone number is never a step", !Teach.tap("0977 123456", false) && !Teach.tap("Call 0977123456", false) && Teach.skipped == 2)
        check("an email is never a step", !Teach.tap("michael@example.com", false))
        check("the same tap twice is one step", !Teach.tap("ECZ Results Portal", false) && Teach.steps.size == 3)
        val g = Teach.guide()!!
        check("ends on a tap: done when it is tapped", g.doneWhen == "last_tap" && !g.steps.last().toggle && g.title["en"] == "Check ECZ results")

        Teach.reset("Turn on data saver")
        Teach.tap("Settings", false); Teach.tap("Search", false); Teach.typedIn("data"); Teach.tap("Data saver", false); Teach.tap("Use Data Saver", true)
        check("no box: typing goes before the next tap: ${says()}", says()[2] == "Type “data”, then tap “Data saver”.")
        check("a switch at the end: done when it turns on", Teach.guide()!!.steps.last().toggle && Teach.guide()!!.doneWhen == null &&
            says().last() == "Tap the switch for “Use Data Saver”.")

        Teach.reset("Search the Play Store")
        Teach.tap("Play Store", false); Teach.tap("Search apps & games", false, isBox = true); Teach.typedIn("0977123456"); Teach.tap("", false)
        check("a typed phone number is never kept: ${says()}", says() == listOf("Tap “Play Store”.", "Tap “Search apps & games”."))
        Teach.typedIn("whatsapp"); Teach.tap("", false)
        check("Done keeps the last typing: ${says()}", says()[1] == "Tap the box and type “whatsapp”.")
        Teach.remove(0)
        check("a step can be removed", Teach.steps.size == 1)

        Teach.reset("Long task")
        for (i in 1..40) Teach.tap("Button $i", false)
        check("at most 25 steps", Teach.steps.size == 25)
        Teach.reset("")
        check("nothing recorded: no guide", Teach.guide() == null)
        return bad
    }
}
