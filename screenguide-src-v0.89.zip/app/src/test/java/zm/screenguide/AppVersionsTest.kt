package zm.screenguide

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class AppVersionsTest {
    private fun apps(vararg n: String) = n.map { it to "pkg." + it.lowercase().replace(" ", "") }
    private val mine = apps("Messages", "Phone", "Photos", "Play Store", "Palm Store", "Settings", "WhatsApp", "YouTube", "Gmail", "Chrome")
    private val names = mine.map { it.first }

    // v0.75, 5 Nov: "Open the WhatsApp Business app" rang plain WhatsApp, on a phone without WhatsApp Business
    @Test fun anAppWithALongerNameIsAnotherApp() {
        assertNull(Match.pickApp("Open the WhatsApp Business app", mine))
        assertNull(Match.pickApp("Watch cartoons on YouTube Kids", mine))
        assertEquals("WA Business", Match.pickApp("Open the WhatsApp Business app", mine + apps("WA Business"))?.first)   // its name under the icon
        assertEquals("WhatsApp Business", Match.pickApp("Open WhatsApp Business", mine + apps("WhatsApp Business"))?.first)
        assertEquals("WhatsApp", Match.pickApp("Send a photo on WhatsApp", mine + apps("WA Business"))?.first)
    }

    // Cheaper phones (itel, Tecno, Infinix) often have the Go and Lite versions: they do the same job
    @Test fun goAndLiteVersionsCount() {
        val go = apps("Gmail Go", "Maps Go", "Facebook Lite", "Settings")
        assertEquals("Gmail Go", Match.pickApp("Send an email with Gmail", go)?.first)
        assertEquals("Maps Go", Match.pickApp("Open Google Maps", go)?.first)
        assertEquals("Facebook Lite", Match.pickApp("Post a photo on Facebook", go)?.first)
        assertEquals("Facebook", Match.pickApp("Post a photo on Facebook", go + apps("Facebook"))?.first)   // both: the one named
        assertEquals("Facebook Lite", Match.pickApp("Open Facebook Lite", go + apps("Facebook"))?.first)
        assertEquals("Facebook", Match.pickApp("Open Facebook Lite", apps("Facebook"))?.first)             // the full one does the job
    }

    // The owner's choice (5 Nov): say that the app is not on this phone, and offer to install it
    @Test fun aMissingAppIsNamed() {
        assertEquals("WhatsApp Business", Match.missingApp("Open the WhatsApp Business app", names))
        assertEquals("WhatsApp Business", Match.missingApp("Open WhatsApp Business", names))
        assertEquals("TikTok", Match.missingApp("Open the TikTok app", names))
        assertNull(Match.missingApp("Open the WhatsApp Business app", names + "WA Business"))          // there, under another name
        assertNull(Match.missingApp("Send an email with the Gmail app", listOf("Gmail Go")))            // the Go version is there
        assertNull(Match.missingApp("Open the Gallery app", names))                                       // a plain word: Photos does it
        assertNull(Match.missingApp("Install WhatsApp Business from the Play Store", names))              // already installing
        assertNull(Match.missingApp("Open the Zanaco app", names))                                        // never banking or money apps
        assertNull(Match.missingApp("Open the Airtel Money app", names))
        assertNull(Match.missingApp("Open the ScreenGuide app", names))
        assertNull(Match.missingApp("Open the Play Store app", listOf("Palm Store")))                      // a store is not offered
        assertNull(Match.missingApp("Turn on dark mode", names))
        assertNull(Match.missingApp("Upload a video in the YouTube app", names))
        assertNull(Match.missingApp("Send a message on WhatsApp", names))
    }
}
