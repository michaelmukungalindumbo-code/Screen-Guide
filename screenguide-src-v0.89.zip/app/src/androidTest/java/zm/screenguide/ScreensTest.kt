package zm.screenguide

import android.content.Intent
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.uiautomator.By
import androidx.test.uiautomator.BySelector
import androidx.test.uiautomator.UiDevice
import androidx.test.uiautomator.Until
import org.json.JSONArray
import org.json.JSONObject
import org.junit.After
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

// Opens ScreenGuide's own screens on a small phone (720 x 1600, like many Tecno, Infinix and itel phones) and checks that
// the buttons people need are really on the screen. Seen 2 Nov: the pop-up's Allow button was below the bottom of the
// screen. Pictures of each screen are kept (GitHub: the "screens" download of this check).
@RunWith(AndroidJUnit4::class)
class ScreensTest {
    private val ins = InstrumentationRegistry.getInstrumentation()
    private val dev = UiDevice.getInstance(ins)
    private val ctx = ins.targetContext

    private fun shot(name: String) {
        dev.waitForIdle()
        dev.executeShellCommand("mkdir -p /data/local/tmp/screens")
        dev.executeShellCommand("screencap -p /data/local/tmp/screens/$name.png")
    }

    // The button is on the screen, whole: not cut off at the bottom or hidden under the navigation bar.
    private fun whole(sel: BySelector, what: String) {
        val o = dev.wait(Until.findObject(sel), 10000)
        assertTrue("$what is not on the screen", o != null)
        val b = o!!.visibleBounds
        val minH = (40 * ctx.resources.displayMetrics.density).toInt()
        assertTrue("$what is cut off: $b on a screen ${dev.displayWidth} x ${dev.displayHeight}", b.height() >= minH && b.bottom <= dev.displayHeight)
    }

    private fun problems(n: Int): JSONArray = JSONArray().apply {
        for (i in 0 until n) put(JSONObject().put("id", "p$i").put("kind", if (i == n - 1) "idea" else if (i == n - 2) "change" else "problem")
            .put("title", "Could not point on step ${i + 3}")
            .put("what", "ScreenGuide told them to tap something on step ${i + 3} but could not show where. On the upload screen, the guide " +
                "only gave words and did not point at a button, so the person was left unsure what to press next.")
            .put("fix", "Make the guide point at the Upload button on the upload screen, or give a clear next action instead of only telling the person to wait."))
    }

    private fun popup(n: Int) {
        ctx.startActivity(Intent(ctx, WatchActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            .putExtra("fresh", true).putExtra("problems", problems(n).toString()).putExtra("saved", ""))
    }

    @After fun normalText() { dev.executeShellCommand("settings put system font_scale 1.0") }

    @Test fun popupButtonsShowWithAShortList() {
        popup(2)
        whole(By.text("Allow"), "Allow"); whole(By.textStartsWith("Don"), "Don't allow")
        shot("popup-2-items")
        // 3 Nov: a stray tap sent 3 items. Allow waits a moment, and then works (it must not stay off)
        Thread.sleep(Watch.ARM_MS + 1500)
        assertTrue("Allow never became usable", dev.findObject(By.text("Allow"))?.isEnabled == true)
    }

    @Test fun popupButtonsShowWithALongList() {
        popup(9)
        whole(By.text("Allow"), "Allow"); whole(By.textStartsWith("Don"), "Don't allow")
        shot("popup-9-items")
    }

    @Test fun popupButtonsShowWithBigText() {
        dev.executeShellCommand("settings put system font_scale 1.3")
        popup(9)
        whole(By.text("Allow"), "Allow (big text)"); whole(By.textStartsWith("Don"), "Don't allow (big text)")
        shot("popup-9-items-big-text")
    }

    @Test fun testAnAppScreen() {
        ctx.startActivity(Intent(ctx, TestActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
        whole(By.text("ScreenGuide (this app)"), "The first app in the list")
        shot("test-an-app")
    }

    @Test fun homeScreen() {
        ctx.startActivity(Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
        dev.wait(Until.hasObject(By.pkg("zm.screenguide").depth(0)), 10000)
        shot("home")
    }
}
