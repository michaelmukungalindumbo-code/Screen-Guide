package zm.screenguide

// v0.90 tests first: not built yet
object AdsGate {
    const val TEST_APP_ID = ""
    const val TEST_UNIT = ""
    enum class Result { WATCHED, CLOSED, NONE }
    fun limited(code: Int, body: String): Boolean = false
    fun known(adsLeft: Int, at: Long, now: Long): Int = adsLeft
    fun offer(plus: Boolean, adsLeft: Int): Boolean = false
    fun offerText(ask: Int, steps: Int): String = ""
    fun after(r: Result, claimOk: Boolean, left: Int, adsLeft: Int): String = ""
}
