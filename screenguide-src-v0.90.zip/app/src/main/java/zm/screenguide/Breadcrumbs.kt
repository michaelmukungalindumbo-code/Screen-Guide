package zm.screenguide

// v0.90 tests first: not built yet
object Breadcrumbs {
    const val MAX = 8
    fun add(path: MutableList<String>, name: String?) {}
}
