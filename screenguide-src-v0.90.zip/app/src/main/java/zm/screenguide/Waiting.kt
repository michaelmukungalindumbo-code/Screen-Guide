package zm.screenguide

// "Looking at your screen…" after Help belongs to the guide that asked. 4 Nov: Help, then Stop while the answer was still
// coming. The words came back every half second over the "Why did you stop?" card, until the answer came.
object Waiting {
    fun keepShowing(thinking: Boolean, askedBy: Any?, active: Any?): Boolean = thinking && active != null && active === askedBy

    // v0.90 tests first: not built yet
    const val EXTRA_AFTER_MS = 2500L
    const val EXTRA_EVERY_MS = 5000L
    val TIPS = listOf("")
    fun comingUp(plan: List<String>, done: Int): String? = null
    fun extra(lang: String, plan: List<String>, done: Int, waited: Long): String? = null
    fun withExtra(text: String, extra: String?): String = text
}
