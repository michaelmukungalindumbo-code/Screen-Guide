package zm.screenguide

import android.accessibilityservice.AccessibilityService
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.media.MediaPlayer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.Locale

class RingView(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 8f; color = 0xFFF0A935.toInt() }
    private var t = 0f
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1200; repeatCount = ValueAnimator.INFINITE
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }
    override fun onDraw(c: Canvas) {
        p.alpha = 255
        c.drawRoundRect(RectF(26f, 26f, width - 26f, height - 26f), 30f, 30f, p)
        val g = 26f - 22f * t
        p.alpha = (255 * (1 - t)).toInt()
        c.drawRoundRect(RectF(g, g, width - g, height - g), 34f, 34f, p)
    }
}

class GuideService : AccessibilityService(), TextToSpeech.OnInitListener {
    private var wm: WindowManager? = null
    private var ring: RingView? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var spokenFor = -1
    private var mp: MediaPlayer? = null

    override fun onServiceConnected() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        tts = TextToSpeech(this, this)
        Guides.load(this)
    }
    override fun onInit(s: Int) { ttsReady = s == TextToSpeech.SUCCESS }
    override fun onInterrupt() {}
    override fun onDestroy() { hide(); tts?.shutdown(); mp?.release(); super.onDestroy() }

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        val guide = Guides.active ?: run { hide(); return }
        val step = Guides.step() ?: run { hide(); return }
        // The person tapped the highlighted thing: move on.
        if (e.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED) {
            val src = e.source
            if (src != null && (matches(src, step.match) || matches(src.parent, step.match))) { advance(guide); return }
        }
        val root = rootInActiveWindow ?: return
        // Find this step's target, or any later step's (phones label things differently).
        for (i in Guides.index until guide.steps.size) {
            val node = find(root, guide.steps[i].match) ?: continue
            if (i != Guides.index) Guides.index = i
            val r = Rect(); node.getBoundsInScreen(r)
            show(r)
            if (spokenFor != Guides.index) { spokenFor = Guides.index; speak(guide.steps[Guides.index]) }
            return
        }
        hide()
    }

    private fun advance(g: Guide) {
        Guides.index++; spokenFor = -1; hide()
        if (Guides.step() == null) { Guides.active = null; say(g.done) }
    }

    private fun find(root: AccessibilityNodeInfo, keys: List<String>): AccessibilityNodeInfo? {
        for (k in keys) {
            val n = root.findAccessibilityNodeInfosByText(k).firstOrNull { it.isVisibleToUser } ?: continue
            var c: AccessibilityNodeInfo? = n
            repeat(4) { if (c?.isClickable == true) return c; c = c?.parent }
            return n
        }
        return null
    }

    private fun blob(n: AccessibilityNodeInfo?, d: Int = 0): String {
        if (n == null || d > 3) return ""
        var s = "${n.text} ${n.contentDescription} "
        for (i in 0 until n.childCount) s += blob(n.getChild(i), d + 1)
        return s
    }
    private fun matches(n: AccessibilityNodeInfo?, keys: List<String>): Boolean {
        val t = blob(n).lowercase()
        return keys.any { t.contains(it.lowercase()) }
    }

    private fun show(r: Rect) {
        val w = wm ?: return
        val lp = WindowManager.LayoutParams(r.width() + 52, r.height() + 52,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = r.left - 26; lp.y = r.top - 26
        val v = ring
        if (v == null) { ring = RingView(this).also { w.addView(it, lp) } } else w.updateViewLayout(v, lp)
    }
    private fun hide() { ring?.let { try { wm?.removeView(it) } catch (_: Exception) {} }; ring = null }

    private fun speak(s: Step) {
        val l = Guides.lang
        val res = s.audio?.let { resources.getIdentifier("${it}_$l", "raw", packageName) } ?: 0
        if (res != 0) { mp?.release(); mp = MediaPlayer.create(this, res); mp?.start(); return }
        say(s.say)
    }
    // Uses a voice for the chosen language if the phone has one; otherwise falls back to English.
    private fun say(texts: Map<String, String>) {
        if (!ttsReady) return
        val l = Guides.lang
        val loc = Locale(l)
        val ok = (tts?.isLanguageAvailable(loc) ?: TextToSpeech.LANG_NOT_SUPPORTED) >= TextToSpeech.LANG_AVAILABLE
        val msg = if (ok) texts[l] else texts["en"]
        tts?.language = if (ok) loc else Locale.ENGLISH
        if (msg != null) tts?.speak(msg, TextToSpeech.QUEUE_FLUSH, null, "sg")
    }
}
