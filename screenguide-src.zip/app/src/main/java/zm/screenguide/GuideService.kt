package zm.screenguide

import android.accessibilityservice.AccessibilityService
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.media.MediaPlayer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.Locale

class RingView(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 8f; color = 0xFFF0A935.toInt() }
    private var t = 0f
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1200; repeatCount = ValueAnimator.INFINITE
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }
    override fun onDraw(c: Canvas) {
        p.alpha = 255
        c.drawRoundRect(RectF(26f, 26f, width - 26f, height - 26f), 30f, 30f, p)
        val g = 26f - 22f * t
        p.alpha = (255 * (1 - t)).toInt()
        c.drawRoundRect(RectF(g, g, width - g, height - g), 34f, 34f, p)
    }
}

class GuideService : AccessibilityService(), TextToSpeech.OnInitListener {
    private var wm: WindowManager? = null
    private var ring: RingView? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var spokenFor = -1
    private var mp: MediaPlayer? = null

    override fun onServiceConnected() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        tts = TextToSpeech(this, this)
        Guides.load(this)
    }
    override fun onInit(s: Int) { ttsReady = s == TextToSpeech.SUCCESS }
    override fun onInterrupt() {}
    override fun onDestroy() { hide(); tts?.shutdown(); mp?.release(); super.onDestroy() }

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        val guide = Guides.active ?: run { hide(); return }
        // Final step: the person tapped the switch, so we are done.
        val last = guide.steps.last()
        if (e.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED && last.toggle) {
            val src = e.source
            if (src != null && (src.isCheckable || src.parent?.isCheckable == true || (0 until src.childCount).any { src.getChild(it)?.isCheckable == true }) &&
                (matches(src, last.match) || matches(src.parent, last.match))) { finish(guide); return }
        }
        val root = rootInActiveWindow ?: return
        // Show the LATEST step whose target is on screen. This skips steps a phone brand doesn't have.
        for (i in guide.steps.size - 1 downTo 0) {
            val node = find(root, guide.steps[i]) ?: continue
            Guides.index = i
            val r = Rect(); node.getBoundsInScreen(r)
            show(r)
            if (spokenFor != i) { spokenFor = i; speak(guide.steps[i]) }
            return
        }
        hide()
    }

    private fun finish(g: Guide) { hide(); Guides.active = null; spokenFor = -1; say(g.done) }

    private fun exact(n: AccessibilityNodeInfo, k: String) =
        n.text?.toString()?.trim().equals(k, true) || n.contentDescription?.toString()?.trim().equals(k, true)

    private fun find(root: AccessibilityNodeInfo, s: Step): AccessibilityNodeInfo? {
        if (s.toggle) {
            val q = ArrayDeque<AccessibilityNodeInfo>(); q.add(root)
            while (q.isNotEmpty()) {
                val n = q.removeFirst()
                val row = n.parent
                if (n.isCheckable && n.isVisibleToUser && row != null && blob(row).length < 120 && matches(row, s.match)) return n
                for (i in 0 until n.childCount) n.getChild(i)?.let { q.add(it) }
            }
            return null
        }
        for (k in s.match) {
            val n = root.findAccessibilityNodeInfosByText(k).firstOrNull { it.isVisibleToUser && exact(it, k) } ?: continue
            return target(n)
        }
        return null
    }

    // The tappable thing around the label, but never a huge container like a whole screen.
    private fun target(n: AccessibilityNodeInfo): AccessibilityNodeInfo {
        val nr = Rect(); n.getBoundsInScreen(nr)
        val limit = maxOf(1, nr.width() * nr.height()) * 30L
        var c: AccessibilityNodeInfo = n
        repeat(3) {
            val p = c.parent ?: return n
            val pr = Rect(); p.getBoundsInScreen(pr)
            if (pr.width().toLong() * pr.height() > limit) return n
            if (p.isClickable) return p
            c = p
        }
        return n
    }

    private fun blob(n: AccessibilityNodeInfo?, d: Int = 0): String {
        if (n == null || d > 3) return ""
        var s = "${n.text} ${n.contentDescription} "
        for (i in 0 until n.childCount) s += blob(n.getChild(i), d + 1)
        return s
    }
    private fun matches(n: AccessibilityNodeInfo?, keys: List<String>): Boolean {
        val t = blob(n).lowercase()
        return keys.any { t.contains(it.lowercase()) }
    }

    private fun show(r: Rect) {
        val w = wm ?: return
        val lp = WindowManager.LayoutParams(r.width() + 52, r.height() + 52,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = r.left - 26; lp.y = r.top - 26
        val v = ring
        if (v == null) { ring = RingView(this).also { w.addView(it, lp) } } else w.updateViewLayout(v, lp)
    }
    private fun hide() { ring?.let { try { wm?.removeView(it) } catch (_: Exception) {} }; ring = null }

    private fun speak(s: Step) {
        val l = Guides.lang
        val res = s.audio?.let { resources.getIdentifier("${it}_$l", "raw", packageName) } ?: 0
        if (res != 0) { mp?.release(); mp = MediaPlayer.create(this, res); mp?.start(); return }
        say(s.say)
    }
    // Uses a voice for the chosen language if the phone has one; otherwise falls back to English.
    private fun say(texts: Map<String, String>) {
        if (!ttsReady) return
        val l = Guides.lang
        val loc = Locale(l)
        val ok = (tts?.isLanguageAvailable(loc) ?: TextToSpeech.LANG_NOT_SUPPORTED) >= TextToSpeech.LANG_AVAILABLE
        val msg = if (ok) texts[l] else texts["en"]
        tts?.language = if (ok) loc else Locale.ENGLISH
        if (msg != null) tts?.speak(msg, TextToSpeech.QUEUE_FLUSH, null, "sg")
    }
}
