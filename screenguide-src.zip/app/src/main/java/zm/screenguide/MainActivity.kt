package zm.screenguide

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) { super.onCreate(b); Guides.load(this); build() }
    override fun onResume() { super.onResume(); build() }

    private fun enabled(): Boolean =
        (Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: "").contains(packageName)

    private fun build() {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 90, 40, 40); setBackgroundColor(0xFF120F0A.toInt()) }
        fun tv(t: String, sz: Float, c: Int) = TextView(this).apply { text = t; textSize = sz; setTextColor(c); setPadding(0, 0, 0, 24) }
        fun btn(t: String, f: () -> Unit) = Button(this).apply {
            text = t; textSize = 18f; isAllCaps = false; setOnClickListener { f() }
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = 16 }
        }
        col.addView(tv("ScreenGuide", 30f, 0xFFF7F0E4.toInt()))
        col.addView(tv("I\u2019ll point. You tap.", 16f, 0xFFA99E8D.toInt()))
        if (!enabled()) col.addView(btn("Step 1: Turn on ScreenGuide") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        val langs = LinearLayout(this)
        listOf("en" to "English", "ny" to "Chinyanja", "bem" to "Icibemba").forEach { (k, n) ->
            langs.addView(Button(this).apply { text = if (Guides.lang == k) "\u2714 $n" else n; isAllCaps = false; setOnClickListener { Guides.lang = k; build() } })
        }
        col.addView(langs)
        col.addView(tv("\nWhat do you want to do?", 18f, 0xFFF7F0E4.toInt()))
        Guides.all.forEach { g ->
            col.addView(btn(g.title[Guides.lang] ?: g.title["en"] ?: g.id) {
                if (!enabled()) { Toast.makeText(this, "Turn on ScreenGuide first", Toast.LENGTH_LONG).show(); startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
                else {
                    Guides.active = g; Guides.index = 0
                    startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
            })
        }
        if (Guides.active != null) col.addView(btn("Stop guide") { Guides.active = null; build() })
        setContentView(ScrollView(this).apply { addView(col) })
    }
}
