package zm.screenguide

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.*
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.view.View
import android.speech.tts.TextToSpeech
import java.util.Locale

class MainActivity : Activity() {
    private var typed = ""
    private var note = ""
    private var input: EditText? = null
    private val ink = 0xFF1F1A14.toInt()
    private val mute = 0xFF6B6257.toInt()
    private val green = 0xFF1B6B4A.toInt()
    private val paper = 0xFFFAF6EF.toInt()
    private val line = 0xFFE3D8C6.toInt()

    override fun onCreate(b: Bundle?) { super.onCreate(b); Guides.load(this); build() }
    override fun onResume() { super.onResume(); build() }

    private fun enabled() =
        (Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: "").contains(packageName)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun bg(color: Int, radius: Int, oval: Boolean = false, stroke: Int = 0) = GradientDrawable().apply {
        setColor(color)
        if (stroke != 0) setStroke(dp(1), stroke)
        if (oval) shape = GradientDrawable.OVAL else cornerRadius = dp(radius).toFloat()
    }
    private fun lp(top: Int = 0, bottom: Int = 0) =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(0, dp(top), 0, dp(bottom)) }

    private fun start(g: Guide) {
        if (!enabled()) {
            Toast.makeText(this, "Turn on ScreenGuide first", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); return
        }
        Guides.active = g; Guides.index = 0
        startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun norm(s: String) = s.lowercase().filter { it.isLetterOrDigit() }
    private fun score(g: Guide, t: String) = g.keywords.count { norm(it).isNotEmpty() && t.contains(norm(it)) }

    private fun ask(text: String) {
        val t = norm(text)
        if (t.isEmpty()) return
        val best = Guides.all.maxByOrNull { score(it, t) }
        input = null; typed = text
        val app = findName(text)
        if (best != null && score(best, t) > 0) { typed = ""; note = ""; start(best) }
        else if (app != null) { typed = ""; note = ""; start(findGuide(app)) }
        else { note = "I don\u2019t have a guide for that yet. Try one of these:"; build() }
    }

    private fun listen(code: Int) {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        try { startActivityForResult(i, code) }
        catch (e: ActivityNotFoundException) { Toast.makeText(this, "Voice input is not available on this phone", Toast.LENGTH_LONG).show() }
    }

    override fun onActivityResult(rc: Int, res: Int, data: Intent?) {
        super.onActivityResult(rc, res, data)
        if (res != RESULT_OK) return
        val said = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull() ?: return
        if (rc == 2) ask(said) else { input = null; typed = said; build() }
    }

    private fun langDialog() {
        val keys = listOf("en", "ny", "bem")
        AlertDialog.Builder(this).setTitle("Language")
            .setItems(arrayOf("English", "Chinyanja", "Icibemba")) { _, w -> Guides.lang = keys[w]; build() }.show()
    }

    // Clear explanation and a real choice before the system Accessibility screen.
    private fun consent() {
        AlertDialog.Builder(this).setTitle("Allow ScreenGuide to see your screen?")
            .setMessage("ScreenGuide uses Android\u2019s Accessibility feature to read the words on your screen, so it can show you where to tap.\n\nIt never taps or types for you, and it does not send anything off your phone. You can switch it off any time in Settings.")
            .setPositiveButton("Agree") { _, _ -> startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
            .setNegativeButton("Not now", null).show()
    }

    // "open chrome", "where is whatsapp" -> a one-step guide that points at that app.
    private fun findName(text: String): String? {
        val t = text.trim().lowercase()
        for (p in listOf("open ", "find ", "where is ", "where's ", "show me ", "launch ", "start ", "go to ")) {
            if (t.startsWith(p)) {
                val n = t.removePrefix(p).removePrefix("the ").removePrefix("my ").trim()
                return if (n.isNotEmpty()) n else null
            }
        }
        return null
    }
    private fun findGuide(name: String): Guide {
        val cap = name.split(" ").joinToString(" ") { w -> w.replaceFirstChar { it.uppercase() } }
        return Guide("find", mapOf("en" to cap), mapOf("en" to "Well done!", "ny" to "Zabwino!", "bem" to "Nawamya!"),
            listOf(Step(listOf(name), mapOf("en" to "Tap $cap.", "ny" to "Dinani $cap.", "bem" to "Kandeni $cap."), null)),
            emptyList(), null, mapOf("en" to "Looking for $cap. Swipe up or sideways to see all apps."))
    }

    private var tts: TextToSpeech? = null
    private val tips = listOf(
        "Never tell anyone your PIN. Not even someone who says they work for your mobile money company.",
        "Real mobile money companies never ask for your PIN, by call or by message.",
        "If someone says you won a prize but must send money first, it is a scam.",
        "If someone says they sent you money by mistake and asks you to send it back, check your balance yourself first.",
        "Before you send money, read the name and number on the screen carefully.",
        "If you are not sure, stop and ask someone you trust.")
    private fun showTips() {
        AlertDialog.Builder(this).setTitle("Stay safe from scams")
            .setMessage(tips.joinToString("\n\n") { "\u2022 $it" })
            .setPositiveButton("Close", null).setNeutralButton("Listen") { _, _ -> speakTips() }.show()
    }
    private fun speakTips() {
        val text = tips.joinToString(" ")
        val t = tts
        if (t == null) { tts = TextToSpeech(this) { st -> if (st == TextToSpeech.SUCCESS) { tts?.language = Locale.ENGLISH; tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "tips") } } }
        else t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "tips")
    }
    override fun onDestroy() { tts?.shutdown(); super.onDestroy() }

    private fun safeCard(): LinearLayout {
        val icon = IconView(this, "logo", 0xFFB45309.toInt()).apply { background = bg(0xFFFFF0D9.toInt(), 0, true); layoutParams = LinearLayout.LayoutParams(dp(56), dp(56)) }
        val name = TextView(this).apply {
            text = "Stay safe from scams"; textSize = 18f; setTextColor(ink); typeface = Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(16) }
        }
        val go = TextView(this).apply { text = "\u203A"; textSize = 30f; setTextColor(mute) }
        return LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; background = bg(Color.WHITE, 22, false, line); setPadding(dp(16), dp(14), dp(18), dp(14))
            layoutParams = lp(0, 12); setOnClickListener { showTips() }
            addView(icon); addView(name); addView(go)
        }
    }

    private fun tv(t: String, sz: Float, c: Int, pb: Int = 12, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = sz; setTextColor(c); setPadding(0, 0, 0, dp(pb)); if (bold) typeface = Typeface.DEFAULT_BOLD
    }
    private fun pill(t: String, fill: Int, fg: Int, stroke: Int = 0, f: () -> Unit) = TextView(this).apply {
        text = t; textSize = 16f; setTextColor(fg); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
        background = bg(fill, 26, false, stroke); setPadding(dp(20), dp(15), dp(20), dp(15)); setOnClickListener { f() }; layoutParams = lp(0, 10)
    }
    private fun taskCard(g: Guide): LinearLayout {
        val icon = IconView(this, g.id, green).apply { background = bg(0xFFE3F2EA.toInt(), 0, true); layoutParams = LinearLayout.LayoutParams(dp(56), dp(56)) }
        val name = TextView(this).apply {
            text = g.title[Guides.lang] ?: g.title["en"] ?: g.id; textSize = 18f; setTextColor(ink); typeface = Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(16) }
        }
        val go = TextView(this).apply { text = "\u203A"; textSize = 30f; setTextColor(mute) }
        return LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; background = bg(Color.WHITE, 22, false, line); setPadding(dp(16), dp(14), dp(18), dp(14))
            layoutParams = lp(0, 12); setOnClickListener { start(g) }
            addView(icon); addView(name); addView(go)
        }
    }

    private fun build() {
        typed = input?.text?.toString() ?: typed
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(52), dp(20), dp(28)); setBackgroundColor(paper) }

        val brand = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; layoutParams = lp(0, 28)
            addView(IconView(context, "logo", green).apply { layoutParams = LinearLayout.LayoutParams(dp(34), dp(34)).apply { rightMargin = dp(10) } })
            addView(tv("ScreenGuide", 20f, ink, 0, true))
        }
        col.addView(brand)
        col.addView(tv("What do you need help with?", 28f, ink, 8, true))
        col.addView(tv("Type it or say it. I\u2019ll show you where to tap.", 15f, mute, 20))

        val et = EditText(this).apply {
            hint = "Ask anything"; setHintTextColor(0xFF9A8F80.toInt()); setTextColor(ink); textSize = 19f; background = null
            setText(typed); setSingleLine(true); minHeight = dp(56); gravity = Gravity.CENTER_VERTICAL
            inputType = InputType.TYPE_CLASS_TEXT; imeOptions = EditorInfo.IME_ACTION_SEND
            setOnEditorActionListener { v, _, _ -> ask(v.text.toString()); true }
        }
        input = et
        val names = mapOf("en" to "English", "ny" to "Chinyanja", "bem" to "Icibemba")
        val lang = TextView(this).apply {
            text = "${names[Guides.lang]}  \u25BE"; textSize = 15f; setTextColor(ink); gravity = Gravity.CENTER
            background = bg(0xFFF1EADD.toInt(), 22); setPadding(dp(16), 0, dp(16), 0)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(44)); setOnClickListener { langDialog() }
        }
        val mic = ImageButton(this).apply {
            setImageResource(android.R.drawable.ic_btn_speak_now); setColorFilter(ink); background = bg(0xFFF1EADD.toInt(), 0, true)
            layoutParams = LinearLayout.LayoutParams(dp(48), dp(48)).apply { rightMargin = dp(10) }; setOnClickListener { listen(1) }
        }
        val speak = TextView(this).apply {
            text = "Speak"; textSize = 16f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            background = bg(green, 24); setPadding(dp(24), 0, dp(24), 0)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(48)); setOnClickListener { listen(2) }
        }
        val row = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(lang); addView(Space(context), LinearLayout.LayoutParams(0, 1, 1f)); addView(mic); addView(speak)
        }
        col.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = bg(Color.WHITE, 28, false, line); setPadding(dp(20), dp(8), dp(14), dp(14)); layoutParams = lp(0, 20)
            addView(et); addView(row)
        })
        if (note.isNotEmpty()) col.addView(tv(note, 15f, 0xFFB45309.toInt(), 12))

        if (!enabled()) {
            col.addView(LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; background = bg(0xFFFFF4E0.toInt(), 22, false, 0xFFF1D9A8.toInt()); setPadding(dp(18), dp(16), dp(18), dp(8)); layoutParams = lp(0, 20)
                addView(tv("Before we start", 18f, ink, 6, true))
                addView(tv("ScreenGuide needs permission to see which button to point at. It never taps for you and sends nothing anywhere.", 14f, mute, 14))
                addView(pill("1   Allow restricted settings", green, Color.WHITE) { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) })
                addView(pill("2   Turn on ScreenGuide", green, Color.WHITE) { consent() })
            })
        }
        col.addView(tv("Tasks", 15f, mute, 10, true))
        Guides.all.forEach { col.addView(taskCard(it)) }
        col.addView(safeCard())
        if (Guides.active != null) col.addView(pill("Stop guide", Color.WHITE, ink, line) { Guides.active = null; build() })
        if (enabled()) col.addView(tv("Keep ScreenGuide running (battery settings)", 14f, green, 6).apply {
            paintFlags = paintFlags or Paint.UNDERLINE_TEXT_FLAG; setPadding(0, dp(10), 0, dp(6)); setOnClickListener { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
        })
        if (Guides.lastSeen.isNotEmpty()) col.addView(tv("Copy debug info", 14f, green, 6).apply {
            paintFlags = paintFlags or Paint.UNDERLINE_TEXT_FLAG; setPadding(0, dp(6), 0, dp(6))
            setOnClickListener {
                (getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager).setPrimaryClip(android.content.ClipData.newPlainText("sg", Guides.lastSeen))
                Toast.makeText(this@MainActivity, "Copied. Paste it to me.", Toast.LENGTH_SHORT).show()
            }
        })
        col.addView(tv("v0.10", 12f, 0xFFA89D8C.toInt(), 0).apply { setPadding(0, dp(16), 0, 0) })
        setContentView(ScrollView(this).apply { setBackgroundColor(paper); addView(col) })
    }
}

class IconView(c: Context, private val kind: String, private val fg: Int) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; color = fg }
    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        p.strokeWidth = w * 0.085f
        if (kind == "wifi") {
            val cx = w / 2; val cy = h * 0.72f
            for (i in 1..3) { val r = w * 0.15f * i; cv.drawArc(RectF(cx - r, cy - r, cx + r, cy + r), 225f, 90f, false, p) }
            p.style = Paint.Style.FILL; cv.drawCircle(cx, cy, w * 0.05f, p); p.style = Paint.Style.STROKE
        } else {
            cv.drawCircle(w / 2, h / 2, w * 0.3f, p)
            p.style = Paint.Style.FILL; cv.drawCircle(w / 2, h / 2, w * 0.1f, p); p.style = Paint.Style.STROKE
        }
    }
}
