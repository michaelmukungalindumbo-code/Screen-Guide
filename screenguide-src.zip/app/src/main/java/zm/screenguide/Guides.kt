package zm.screenguide

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class Step(val match: List<String>, val say: Map<String, String>, val audio: String?, val toggle: Boolean = false)
class Guide(val id: String, val title: Map<String, String>, val done: Map<String, String>, val steps: List<Step>, val keywords: List<String>)

object Guides {
    var all: List<Guide> = emptyList()
    var active: Guide? = null
    var index = 0
    var lang = "en"

    fun step(): Step? = active?.steps?.getOrNull(index)

    private fun map(o: JSONObject) = o.keys().asSequence().associateWith { o.getString(it) }
    private fun strings(a: JSONArray?) = if (a == null) emptyList() else (0 until a.length()).map { a.getString(it) }

    fun load(c: Context) {
        if (all.isNotEmpty()) return
        val arr = JSONArray(c.assets.open("guides.json").bufferedReader().readText())
        all = (0 until arr.length()).map { i ->
            val g = arr.getJSONObject(i)
            val st = g.getJSONArray("steps")
            val steps = (0 until st.length()).map { j ->
                val o = st.getJSONObject(j)
                Step(strings(o.getJSONArray("match")), map(o.getJSONObject("say")), o.optString("audio").ifEmpty { null }, o.optBoolean("toggle"))
            }
            Guide(g.getString("id"), map(g.getJSONObject("title")), map(g.getJSONObject("done")), steps, strings(g.optJSONArray("keywords")))
        }
    }
}
