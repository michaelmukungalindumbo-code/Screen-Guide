package zm.screenguide

// The same button several times on one screen: an "Install" for every app in the Play Store's results, "Follow" or
// "Add friend" in a list. 6 Nov: "Tap Install to install Facebook" put the ring on the first Install, which was
// Instagram's. Which one is meant: the one next to a name from the step ("Facebook"). GuideService gives the places on
// the screen; the deciding is here, so it can be tested.
object Duplicates {
    class Box(val text: String, val left: Int, val top: Int, val right: Int, val bottom: Int)

    // Names in the step and the goal that could be on the screen next to the button: "Facebook" in
    // "Tap Install to install Facebook.", never the button's own word or words like "Tap" and "Play Store".
    fun names(say: String, goal: String, button: String): List<String> = emptyList()

    // Which of the buttons (index), or -1 when no name from the step is on the screen.
    fun pick(buttons: List<Box>, others: List<Box>, names: List<String>): Int = -1
}
