package zm.screenguide

// ◀ and ▶ on the instruction card (6 Nov, the owner's idea; he chose arrows on the card). ScreenGuide never taps for
// the person: ◀ shows the earlier instruction again (with its ring, when its button is on this screen), and ▶ moves on:
// the next step of a numbered guide, or, in a Smart guide, the AI is told they skipped this one and gives the next step
// or another way. A step shown by an arrow stays until the screen changes or PEEK_MS pass; then the guide goes on as usual.
object StepNav {
    const val PEEK_MS = 8000L

    // v0.130 (the owner's Infinix, 25 Nov): his Status post "How to use the past papers app" (taught before steps knew their
    // app) said "Step 2 of 4: Tap Search" on the home screen, with the ring on the phone's own Search bar, never "Tap Past
    // Papers ZM". A step that does not know its app could be looked for one step ahead. Now it waits while the step now is
    // still on the same screen and was not tapped. It goes ahead as before once that step is gone (the app opened), was
    // tapped, or the screen changed (a tap the app did not report). Built-in guides and steps that know their app: as before.
    fun holdNow(i: Int, now: Int, stepApp: String?, builtIn: Boolean, nowShown: Boolean, nowTapped: Boolean, sameScreen: Boolean): Boolean =
        !builtIn && stepApp == null && i > now && nowShown && !nowTapped && sameScreen

    // v0.130, #97: Android's names for common icons, in plain words for a first-time user (the ring shows where). English only.
    private val plainNames = mapOf("navigate up" to "the back arrow", "more options" to "the three dots",
        "open navigation drawer" to "the three lines", "show navigation drawer" to "the three lines")
    fun plainSay(say: String): String {
        val m = Regex("^Tap \u201C(.+)\u201D\\.$").find(say.trim()) ?: return say
        return plainNames[m.groupValues[1].trim().lowercase()]?.let { "Tap $it." } ?: say
    }

    // The same screen as before: most of its words are still there (a clock or one changed line does not count)
    fun sameScreen(a: Set<String>, b: Set<String>): Boolean {
        if (a.isEmpty() || b.isEmpty()) return false
        return a.count { it in b } * 10 >= maxOf(a.size, b.size) * 7
    }

    // v0.130: Help in a taught, shared or built-in guide hands it to the helper. It was told only the task's name ("How to use
    // the past papers app") and went round in circles; now it also gets the guide's own steps as its plan (the server takes 6).
    // A step that only says "Tap the glowing row." is named by its button. Questions not yet answered are left out.
    fun helpPlan(steps: List<Step>, now: Int, lang: String): List<String> {
        val lines = steps.filter { it.match != listOf(Teach.ASK) }.map { st ->
            val say = (st.say[lang] ?: st.say["en"] ?: "").trim()
            val word = st.match.firstOrNull { !it.startsWith("@") }
            (if (word != null && !say.contains(word, true)) "Tap \u201C$word\u201D" else say).take(80)
        }.filter { it.isNotEmpty() }
        if (lines.size <= 6) return lines
        val from = now.coerceIn(0, lines.size - 6)
        return lines.subList(from, from + 6)
    }

    // v0.126 (the owner's Infinix, 25 Nov): Settings opened part-way down its list, and "Scroll down to find Sound &
    // vibration" was said even at the very bottom: the row was above. Down first; once the list cannot go further down but
    // can go up, up, and it stays up until the row shows (or the top is reached without it: down again).
    fun scrollUp(canDown: Boolean, canUp: Boolean, wasUp: Boolean): Boolean = canUp && (wasUp || !canDown)
    // English only: no new Nyanja or Bemba words
    fun scrollUpTo(w: String, l: String) = "Scroll up to find \u201C$w\u201D."

    // Numbered guides: the step each arrow shows, or null when there is none that way.
    fun back(index: Int, size: Int): Int? {
        if (size <= 0) return null
        val i = index.coerceIn(0, size - 1)
        return if (i > 0) i - 1 else null
    }
    fun skip(index: Int, size: Int): Int? = if (size > 0 && index + 1 < size) maxOf(index + 1, 0) else null

    // Smart guides: at is the place, in the instructions shown so far, of the one on the card now (the count, when it is
    // not among them, such as an error). The one before it, or null.
    fun before(at: Int): Int? = if (at > 0) at - 1 else null

    // Smart guides: the instructions worth going back to, oldest first. The same words twice in a row are kept once
    // (the newest copy, so the one on the card is found in the list).
    fun remember(shown: MutableList<Step>, s: Step, max: Int = 12) {
        val last = shown.lastOrNull()
        if (last != null && last.say == s.say && last.match == s.match) { shown[shown.size - 1] = s; return }   // the newest copy
        shown.add(s)
        while (shown.size > max) shown.removeAt(0)
    }

    // A numbered step that says "Tap the glowing row" is named by its row's words on this phone. For a step shown by ◀ ▶:
    // its row on this screen if it is here, else its row as it was when that step was shown, else the guide's own name
    // for it. Never another step's row (7 Nov: ◀ on "Tap Data Usage" showed "Step 2 of 4" with the words "Tap Data Usage").
    // null: the step's own words stay.
    fun rowName(say: String, onScreen: String?, seen: String?, match: List<String>): String? {
        if (!say.contains("glowing row")) return null
        return listOf(onScreen, seen, match.firstOrNull { !it.startsWith("@") })
            .firstNotNullOfOrNull { w -> w?.trim()?.takeIf { it.isNotEmpty() && it.length <= 40 } }
    }

    // v0.89: Help in a built-in guide could not reach the helper (no data, no credit, the server). English only: there
    // are no checked Nyanja or Bemba words for this yet.
    const val NO_HELPER = "I can't reach the helper right now. Follow the ring."
    const val NO_HELPER_MS = 6000L

    // What the AI is told when the person skips its step
    fun skipNote(say: String): String =
        "They tapped Skip on “${say.trim().take(80)}”: it did not work for them, or they did it already. " +
            "Give the next step, or another way."

    // v0.98 (the owner's phone, 8 Nov: "Make words bigger" on Infinix): on the page a step leads to (its name is the page's
    // title), that step is done. There the brightness slider is called "Display brightness", step 2's own words ("Display
    // & brightness"), and the guide said "Tap Display brightness" with the ring on the slider, not "Scroll down to find
    // Font size".
    // v0.105 (the owner's tablet, Samsung): "Device care" is one of the Battery step's names AND the title of the page that
    // holds the "Battery" row. There the step is not done: another of its names is still a row to tap. (rows: the words
    // on the page that are not its title.)
    fun onPageOf(titles: List<String>, names: List<String>, rows: List<String> = emptyList()): Boolean {
        fun k(s: String) = s.lowercase().filter { it.isLetterOrDigit() }
        val t = titles.map { k(it) }.filter { it.isNotEmpty() }.toSet()
        val hit = names.map { k(it) }.filter { it in t }.toSet()
        if (hit.isEmpty()) return false
        val r = rows.map { k(it) }.toSet()
        return names.none { k(it) !in hit && k(it) in r }
    }

    // v0.118: may this step of the guide be looked for on this screen? A step that knows where it was taught: only there.
    // A taught, shared or learned step that does not know (older recordings, guides from other phones): the one now and
    // the next only, never further ahead (that is how the past papers guide jumped to an "English" icon on the app list).
    // Built-in guides: as before (they skip steps a phone maker does not have).
    fun mayLook(i: Int, now: Int, stepApp: String?, pkg: String, home: Boolean, builtIn: Boolean): Boolean = when {
        stepApp == Teach.HOME -> home
        Teach.homeLike(stepApp ?: "", false) -> home   // v0.121: kept in a search screen by 0.118 to 0.120: a home step
        stepApp != null -> stepApp == pkg && (builtIn || i <= now + 1)   // v0.120: in its own app too, never further than the next
        builtIn -> true
        else -> i <= now + 1
    }
    // v0.121 (the same test): on the home screen, at a step taught inside an app (Drive's "Scan Document"), the card said
    // "Not on this screen? Swipe up to find it. Tap “Scan Document”." First that app must be opened. The app to open: the
    // step's own, or, for a part of another app with no icon (Google's scanner, opened by Drive), the last app before it
    // that has one. null: a home step, a built-in step, or a recording that does not know its apps (as before).
    fun appToOpen(apps: List<String?>, now: Int, hasIcon: (String) -> Boolean): String? {
        for (i in minOf(now, apps.size - 1) downTo 0) {
            val a = apps[i] ?: return null
            if (a == Teach.HOME || Teach.homeLike(a, false)) return null
            if (hasIcon(a)) return a
        }
        return null
    }
    fun openIt(name: String) = "Tap “$name” to open it."
    fun openFirst(name: String) = "First open “$name”."
    // v0.120: of the things on the screen with the step's words, the ones to ring. An icon step: only things whose name is
    // all they have (the call button), when there are any; others: as before.
    fun <T> iconFirst(icon: Boolean, same: List<T>, nameOnly: (T) -> Boolean): List<T> =
        if (!icon) same else same.filter(nameOnly).ifEmpty { same }
    // v0.120: a row's words, for a tap the phone reports on a whole row (a chat in WhatsApp): its words before the picture's
    // name ("Sis", not "Sis's status. 0 new updates")
    fun rowWord(texts: List<String?>, names: List<String?>): String? =
        texts.firstOrNull { !it.isNullOrBlank() && it.trim().length <= 50 }?.trim() ?: names.firstOrNull { !it.isNullOrBlank() && it.trim().length <= 50 }?.trim()

    // v0.115: a taught or shared task ends with a tap on its last button. Many phones never report that tap (the owner's
    // Teach test, 11 Nov), so the task never said "Well done". It is done when that button was rung and then the screen
    // moved on to another page (not the home screen: they left). Not for switches or the pull-down panel: as before.
    fun lastTapDone(doneWhen: String?, shade: Boolean, lastIsSwitch: Boolean, lastWasRung: Boolean, pageOpenedSince: Boolean, nowHome: Boolean): Boolean =
        doneWhen == "last_tap" && !shade && !lastIsSwitch && lastWasRung && pageOpenedSince && !nowHome

    // v0.110: a built-in task whose last step opens a page (not a switch, not in the pull-down panel) is done on that page
    fun arrived(doneWhen: String?, shade: Boolean, lastIsSwitch: Boolean, builtIn: Boolean, titles: List<String>, lastNames: List<String>, rows: List<String>): Boolean =
        doneWhen == "last_tap" && !shade && !lastIsSwitch && builtIn && onPageOf(titles, lastNames, rows)

    // v0.99 (the owner's phone, 8 Nov, Infinix): its Font size page has no standard slider to ring, but a "Make larger"
    // button (the big A). One tap makes the words bigger: easier than dragging, for someone new to phones.
    private val larger = setOf("makelarger", "larger", "makebigger", "bigger", "increase", "increasefontsize", "increasetextsize",
        "largerfont", "largertext", "zoomin")
    fun largerButton(label: String): Boolean = label.lowercase().filter { it.isLetterOrDigit() } in larger
    fun tapLarger(label: String) = "Tap \u201C$label\u201D to make the words bigger."   // English only: no new Nyanja or Bemba words
}
