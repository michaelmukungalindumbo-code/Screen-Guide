package zm.screenguide

import java.io.File
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

// v0.110: more tasks that need no internet and no credit (weak networks, costly data), and spoken answers for spoken
// questions (many of the people ScreenGuide is for read slowly or not at all).
class OfflineGuidesTest {
    private fun file(p: String) = listOf("src/main/$p", "app/src/main/$p").map { File(it) }.first { it.exists() }.readText()
    private val all: List<JSONObject> by lazy { JSONArray(file("assets/guides.json")).let { a -> (0 until a.length()).map { a.getJSONObject(it) } } }
    private val new = listOf("storage", "sound", "mobile_data", "location")
    private fun g(id: String) = all.first { it.getString("id") == id }
    private fun names(id: String, step: Int) = g(id).getJSONArray("steps").getJSONObject(step).getJSONArray("match").let { a -> (0 until a.length()).map { a.getString(it) } }
    private val tasks: Map<String, List<String>> by lazy { MatchCases.tasks(file("assets/guides.json")) }
    private fun pick(q: String): String? {
        if (Match.isProblem(q) || Match.isMoney(q)) return null
        val best = tasks.maxByOrNull { Match.score(it.value, q) } ?: return null
        return if (Match.score(best.value, q) > 0) best.key else null
    }

    @Test fun fourNewTasksWithNoInternet() {
        assertEquals(13, all.size)
        for (id in new) {
            val x = g(id)
            assertTrue(id, x.getJSONObject("title").getString("en").isNotEmpty() && x.getJSONObject("done").getString("en").startsWith("Well done!"))
            assertTrue(id, names(id, 0).contains("Settings") && x.getJSONArray("steps").getJSONObject(0).getString("skipIn") == "settings")
            // English only for new words: no Nyanja or Bemba was made up (the first step's old, checked words are kept)
            assertFalse(id, x.getJSONObject("title").has("ny") || x.getJSONObject("title").has("bem") || x.getJSONObject("done").has("ny"))
        }
        // Each maker's names: stock Android, Infinix and Tecno, Samsung
        assertTrue(names("storage", 1).containsAll(listOf("Device care", "Battery and device care")) && names("storage", 2).contains("Storage"))
        assertTrue(names("sound", 1).containsAll(listOf("Sound & vibration", "Sounds and vibration", "Sound")))
        assertTrue(names("mobile_data", 1).containsAll(listOf("Network & internet", "Connections", "SIM & Network Settings")) && names("mobile_data", 3).contains("Mobile data"))
        assertTrue(names("location", 1).contains("Location") && g("location").getJSONArray("steps").getJSONObject(2).getBoolean("toggle"))
        val svc = file("java/zm/screenguide/GuideService.kt")
        for (k in listOf("location_on", "mobile_data_on")) assertTrue(k, svc.contains("\"$k\" ->"))   // the phone itself says it is done
    }

    @Test fun theRightTaskForTheWords() {
        assertEquals("storage", pick("How much storage is left")); assertEquals("storage", pick("check my phone storage"))
        assertEquals("sound", pick("make my phone ring louder")); assertEquals("sound", pick("increase the volume"))
        assertEquals("mobile_data", pick("turn on mobile data")); assertEquals("mobile_data", pick("switch on data"))
        assertEquals("location", pick("turn on location")); assertEquals("location", pick("GPS"))
        // The older tasks keep their words
        assertEquals("data_saver", pick("save my data")); assertEquals("hotspot", pick("share data")); assertEquals("wifi", pick("turn on wifi"))
        assertEquals("battery_saver", pick("battery saver")); assertEquals("text_size", pick("make the words bigger"))
        // A problem is still the helper's work; money is never a task
        assertNull(pick("share my location on WhatsApp")); assertNull(pick("Turn on dark mode"))   // not tasks (MatchCases): the helper's
        assertNull(pick("why is my storage full")); assertNull(pick("my mobile data is not working")); assertNull(pick("send money with mobile money"))
    }

    // A task that ends by opening a page is done on that page, whether or not the phone reported the tap
    @Test fun doneWhenThePageOpens() {
        val storage = names("storage", 2)
        assertTrue(StepNav.arrived("last_tap", false, false, true, listOf("Storage"), storage, listOf("Apps", "Images", "Free up space")))
        assertFalse(StepNav.arrived("last_tap", false, false, true, listOf("Settings"), storage, listOf("Storage", "Battery")))       // still on Settings
        assertFalse(StepNav.arrived("last_tap", false, false, true, listOf("Device care"), storage, listOf("Battery", "Storage")))   // Samsung: one more tap
        assertFalse(StepNav.arrived("last_tap", true, false, true, listOf("Storage"), storage, emptyList()))                         // the pull-down panel: as before
        assertFalse(StepNav.arrived("last_tap", false, true, true, listOf("Storage"), storage, emptyList()))                         // a switch: as before
        assertFalse(StepNav.arrived("last_tap", false, false, false, listOf("Storage"), storage, emptyList()))                       // a taught task: as before
        assertFalse(StepNav.arrived("wifi_on", false, false, true, listOf("Storage"), storage, emptyList()))
    }

    @Test fun aSpokenQuestionIsAnsweredAloud() {
        assertEquals("Open Drive. Tap the plus. Tap Scan.", Voice1st.spoken("Open Drive.  Tap the plus.\nTap Scan."))
        val long = (1..30).joinToString(" ") { "This is sentence number $it of a very long answer." }
        assertTrue(Voice1st.spoken(long).length <= 450 && Voice1st.spoken(long).endsWith("."))              // not a whole page, and whole sentences
        assertEquals("", Voice1st.spoken("  "))
        val m = file("java/zm/screenguide/MainActivity.kt")
        assertTrue(m.contains("if (rc == 2) { spokenAsk = true; ask(said) }"))
        assertTrue(m.contains("val aloud = spokenAsk && Profile.voiceOn(this); spokenAsk = false"))            // their own setting counts
        assertTrue(m.contains("if (aloud && r.ok && onScreen && !isMoney(q)) speak(Voice1st.spoken(r.text), Guides.lang)"))   // never money answers aloud
    }
}
