package zm.screenguide

import org.junit.Assert.assertEquals
import org.junit.Test

class CardWordsTest {
    // #75: the Play Store's search box was open; the card showed only the remark, never what to type.
    @Test fun remarkWithOpenDoesNotHideTheInstruction() {
        assertEquals("Type the word … here, you are doing well.",
            CardWords.tighten("The box is open now. Type the word … here, you are doing well.", true))
        assertEquals("Type the word ….",
            CardWords.tighten("The box is open, so you can type now. Type the word ….", true))
    }

    @Test fun usualCardsStayTheSame() {
        assertEquals("Tap “Search”.", CardWords.tighten("Tap “Search”.", true))
        assertEquals("Now tap Settings.", CardWords.tighten("Good. Now tap Settings.", true))
        assertEquals("Good, you can tap Settings now.", CardWords.tighten("Well done. Good, you can tap Settings now.", true))
        assertEquals("Well done.", CardWords.tighten("Well done.", true))
        assertEquals("One. Two. Three.", CardWords.tighten("One. Two. Three. Four.", false))
    }
}
