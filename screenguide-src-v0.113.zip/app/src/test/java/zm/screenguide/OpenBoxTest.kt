package zm.screenguide

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

// #73, 11 Nov (the Play Store's search page, keyboard up): the phone sent no [typing] word, so the guide said "Tap the
// search bar" twice more. Then the card showed only "The box is open now." of "The box is open now. Type the word …
// here", because "open" counted as something to do, and the person asked "so what if the box is open".
class OpenBoxTest {
    // The screen of step 3, as the phone read it: the box's words came without [typing]
    private val play = listOf("Navigate up [tap]", "Search apps & games [tap]", "Voice search [tap]", "More options [tap]", "Sponsored [text]")

    @Test fun keyboardUpMarksTheBoxThatHasTheFocus() {
        assertEquals(1, ScreenWords.openBox(play, listOf(false, true, false, false, false), keyboardUp = true))
    }

    @Test fun keyboardUpWithNoFocusedBoxMarksTheSearchBox() {
        assertEquals(1, ScreenWords.openBox(play, List(play.size) { false }, keyboardUp = true))
        assertEquals(0, ScreenWords.openBox(listOf("Search [text]", "Apps [tap]"), listOf(false, false), keyboardUp = true))
    }

    @Test fun nothingChangesWithoutTheKeyboardOrWhenABoxIsAlreadyMarked() {
        assertNull(ScreenWords.openBox(play, List(play.size) { false }, keyboardUp = false))
        assertNull(ScreenWords.openBox(play, listOf(false, true, false, false, false), keyboardUp = false))
        val marked = listOf("Navigate up [tap]", "Search apps & games [typing]")
        assertNull(ScreenWords.openBox(marked, listOf(false, true), keyboardUp = true))
        // keyboard up but no box and no search word: guess nothing
        assertNull(ScreenWords.openBox(listOf("Send [tap]", "Searching… [text]"), listOf(false, false), keyboardUp = true))
    }

    @Test fun markingKeepsTheWordsAndChangesOnlyTheTag() {
        assertEquals(listOf("Navigate up [tap]", "Search apps & games [typing]", "Voice search [tap]", "More options [tap]", "Sponsored [text]"),
            ScreenWords.markOpen(play, 1))
        assertEquals(play, ScreenWords.markOpen(play, null))
    }

    @Test fun theCardKeepsTheSentenceThatSaysWhatToDo() {
        assertEquals("Type the word Capcut here, you are doing well.",
            ScreenWords.tighten("The box is open now. Type the word Capcut here, you are doing well.", pointing = true))
        assertEquals("Type the word Capcut.",
            ScreenWords.tighten("The box is open, so you can type now. Type the word Capcut.", pointing = true))
        // as before
        assertEquals("Tap “Search”.", ScreenWords.tighten("Tap “Search”.", pointing = true))
        assertEquals("Now tap Wi-Fi.", ScreenWords.tighten("Good. Now tap Wi-Fi.", pointing = true))
        assertEquals("Open Settings.", ScreenWords.tighten("Open Settings. It has a grey wheel.", pointing = true))
        assertEquals("Well done.", ScreenWords.tighten("Well done.", pointing = true))
        assertEquals("One. Two. Three.", ScreenWords.tighten("One. Two. Three. Four.", pointing = false))
    }
}
