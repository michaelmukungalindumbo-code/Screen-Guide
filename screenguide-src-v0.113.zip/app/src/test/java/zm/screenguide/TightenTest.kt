package zm.screenguide

import org.junit.Assert.assertEquals
import org.junit.Test

class TightenTest {
    // #74 (11 Nov, the Play Store on an Infinix): the search box was open with the keyboard up, and ScreenGuide said
    // "The box is open now. Type the word … here." With the ring on the box the card keeps one sentence, and it kept
    // "The box is open now." because "open" counts as an action. The words to type never showed, Help was pressed, the
    // next answer was cut the same way, and the guide gave up. The sentence that starts with an action is the instruction.
    @Test fun keepsTheInstructionNotTheRemarkAboutAnOpenBox() {
        assertEquals("Type the word WhatsApp here, you are doing well.",
            Tighten.say("The box is open now. Type the word WhatsApp here, you are doing well.", true))
        assertEquals("Type the word WhatsApp.", Tighten.say("The box is open, so you can type now. Type the word WhatsApp.", true))
        assertEquals("Now type the word WhatsApp.", Tighten.say("The app is open. Now type the word WhatsApp.", true))
        assertEquals("Dinani “Search”.", Tighten.say("Zatheka. Dinani “Search”.", true))
    }

    @Test fun keepsWhatWorkedBefore() {
        assertEquals("Tap the search bar that says Search apps & games.", Tighten.say("Tap the search bar that says Search apps & games.", true))
        // no sentence starts with an action: the first one that has one, as before
        assertEquals("You can open it with this button.", Tighten.say("Good. You can open it with this button.", true))
        assertEquals("Well done.", Tighten.say("Well done.", true))
        // one action with a ring, at most 12 words
        assertEquals("Tap “Settings”.", Tighten.say("Tap “Settings”. Then tap “Apps”.", true))
        assertEquals(12, Tighten.say("Tap the long button that has a lot of words written on it today please.", true).split(" ").size)
        // with nothing to point at, up to three sentences
        assertEquals("One. Two. Three.", Tighten.say("One. Two. Three. Four.", false))
    }
}
