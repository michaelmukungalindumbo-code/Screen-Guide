package zm.screenguide

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

// v0.112, the owner (11 Nov): "With one button, how can I activate and deactivate this floating widget" (the Read button).
class ReadTileTest {
    private fun file(p: String) = listOf("src/main/$p", "app/src/main/$p").map { File(it) }.first { it.exists() }.readText()

    @Test fun oneTapOnOneTapOff() {
        assertEquals("off", ReadTile.tap(on = true, serviceOn = true, agreed = true))
        assertEquals("on", ReadTile.tap(on = false, serviceOn = true, agreed = true))
        // On needs ScreenGuide switched on, and their yes to sending a screen's words: a tile cannot ask, so ScreenGuide opens
        assertEquals("open", ReadTile.tap(on = false, serviceOn = false, agreed = true))
        assertEquals("open", ReadTile.tap(on = false, serviceOn = true, agreed = false))
        assertEquals("off", ReadTile.tap(on = true, serviceOn = true, agreed = false))        // off is always allowed
        assertTrue(ReadTile.lit(true, true)); assertFalse(ReadTile.lit(true, false)); assertFalse(ReadTile.lit(false, true))
    }

    @Test fun theWiringIsThere() {
        val man = file("AndroidManifest.xml")
        val svc = man.substringAfter("<service android:name=\".ReadTile\"").substringBefore("</service>")
        assertTrue(svc.contains("android:permission=\"android.permission.BIND_QUICK_SETTINGS_TILE\""))   // only the phone itself may use it
        assertTrue(svc.contains("android.service.quicksettings.action.QS_TILE") && svc.contains("android:label=\"Read button\""))
        val t = file("java/zm/screenguide/ReadTile.kt")
        assertTrue(t.contains("\"off\" -> sp.edit().putBoolean(\"read_button\", false).apply()"))
        assertTrue(t.contains("\"on\" -> sp.edit().putBoolean(\"read_button\", true).apply()"))
        assertTrue(file("java/zm/screenguide/GuideService.kt").contains("if (key == \"read_button\") handler.post { applyReadBubble() }"))   // the button follows the switch
        val m = file("java/zm/screenguide/MainActivity.kt")
        assertTrue(m.contains("Row(\"speaker\", \"Read button in the pull-down panel\", \"Add\") { addReadTile() }"))
        assertTrue(m.contains("if (i.getBooleanExtra(ReadTile.EXTRA, false))"))
    }
}
