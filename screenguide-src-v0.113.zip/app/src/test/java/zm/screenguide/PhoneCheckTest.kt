package zm.screenguide

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

// v0.109: "Check this phone". The owner's tablet showed it (the battery guide broke there in 0.98 and nobody knew until
// every guide was read against Samsung's names): each phone needs its own proof that every built-in task works.
class PhoneCheckTest {
    private val titles = linkedMapOf("wifi" to "Turn on Wi-Fi", "battery_saver" to "Make your battery last", "text_size" to "Make words bigger")

    @Test fun theReportSaysWhatWorkedAndWhatDidNot() {
        PhoneCheck.runs.clear()
        // Wi-Fi: steps 1, 2 and 4 found (this phone has no step 3: skipped by design), finished: OK
        PhoneCheck.start("wifi", 4); listOf(0, 1, 3).forEach { PhoneCheck.found("wifi", it) }; PhoneCheck.end("wifi", "finished")
        // Battery: the tablet of 0.98. "Battery Saver" never found on Device care, Help pressed, stopped
        PhoneCheck.start("battery_saver", 4); PhoneCheck.found("battery_saver", 0); PhoneCheck.found("battery_saver", 1)
        PhoneCheck.lost("battery_saver", 2, "Battery Saver"); PhoneCheck.help("battery_saver"); PhoneCheck.end("battery_saver", "stopped")
        assertTrue(PhoneCheck.ok(PhoneCheck.runs["wifi"]!!)); assertFalse(PhoneCheck.ok(PhoneCheck.runs["battery_saver"]!!))
        val r = PhoneCheck.report(titles, "Samsung tablet, Android 11", "0.109")
        assertEquals(listOf("ScreenGuide 0.109 on Samsung tablet, Android 11", "Tasks tried: 2 of 3. OK: 1. Problems: 1.", "",
            "OK      Turn on Wi-Fi: finished, steps found: 1, 2, 4 of 4.",
            "PROBLEM Make your battery last: stopped before the end, steps found: 1, 2 of 4. Not found: step 3 “Battery Saver”. Help pressed: 1.",
            "", "Not tried yet: Make words bigger."), r.split("\n"))
        assertEquals("2 of 3 tried", PhoneCheck.summary(3))
    }

    @Test fun aButtonFoundLaterIsNotAProblem() {
        PhoneCheck.runs.clear()
        PhoneCheck.start("text_size", 4); PhoneCheck.lost("text_size", 2, "Font size")       // not on the screen yet: "scroll down"
        PhoneCheck.found("text_size", 2); PhoneCheck.lost("text_size", 2, "Font size")       // found after scrolling: no longer missed
        PhoneCheck.found("text_size", 3); PhoneCheck.end("text_size", "finished")
        assertTrue(PhoneCheck.ok(PhoneCheck.runs["text_size"]!!))
        PhoneCheck.start("text_size", 4)                                                     // tried again: the latest try counts
        assertFalse(PhoneCheck.ok(PhoneCheck.runs["text_size"]!!))
        assertTrue(PhoneCheck.line(PhoneCheck.runs["text_size"]!!, "Make words bigger").startsWith("PROBLEM Make words bigger: not finished, no step found."))
        PhoneCheck.found("nothing", 1); PhoneCheck.end("nothing", "finished")                // a task never started: ignored
        assertEquals(1, PhoneCheck.runs.size)
    }

    @Test fun keptOnThePhoneAndNothingPrivate() {
        PhoneCheck.runs.clear()
        PhoneCheck.start("wifi", 4); PhoneCheck.found("wifi", 0); PhoneCheck.lost("wifi", 1, "Network & internet"); PhoneCheck.help("wifi"); PhoneCheck.end("wifi", "stopped")
        val saved = PhoneCheck.save(); val before = PhoneCheck.report(titles, "d", "v")
        PhoneCheck.runs.clear(); PhoneCheck.load(saved)
        assertEquals(before, PhoneCheck.report(titles, "d", "v"))
        PhoneCheck.load("not json"); assertTrue(PhoneCheck.runs.isEmpty()); PhoneCheck.load(null); assertTrue(PhoneCheck.runs.isEmpty())
        fun src(n: String) = listOf("src/main/java/zm/screenguide/$n", "app/src/main/java/zm/screenguide/$n").map { File(it) }.first { it.exists() }.readText()
        val g = src("GuideService.kt")
        assertTrue(g.contains("private fun checked(g: Guide) = g.id != \"ai\" && g.id != \"find\" && g.id != \"taught\" && Guides.all.any { it.id == g.id }"))   // never Smart guides: their words come from the person's screen
        assertEquals(0, Regex("PhoneCheck\\.(found|lost|help|end|start)\\(").findAll(g).count { m -> !g.substring(maxOf(0, m.range.first - 60), m.range.first).contains("checked(") })
        assertFalse(src("PhoneCheck.kt").contains("Server.")); assertFalse(src("PhoneCheck.kt").contains("java.net"))   // only copied by the person, never sent
        assertTrue(src("MainActivity.kt").contains("if (tester) rows.add(Row(\"check\", \"Check this phone\", PhoneCheck.summary(Skills.tasks().size)) { showPhoneCheck() })"))
    }
}
