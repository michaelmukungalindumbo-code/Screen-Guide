package zm.screenguide

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

// v0.107, the owner's phone (11 Nov, Infinix, 0.106, "Scan a document with Drive"): on Drive's scan page, with Enhance,
// Filters, Crop, Discard scan and Next on it, the guide said "I cannot read the words in this app".
class OtherWindowsTest {
    private val money = Match.moneyApps

    @Test fun otherWindowsOnlyWhenThereAreNoWords() {
        assertTrue(ScreenWords.readOtherWindows(0))
        assertFalse(ScreenWords.readOtherWindows(1)); assertFalse(ScreenWords.readOtherWindows(40))   // an ordinary screen: as before
    }

    // Never ScreenGuide's own windows, the keyboard, the phone's bars, or a money app
    @Test fun whichWindowsMayBeRead() {
        val own = "zm.screenguide"
        assertTrue(ScreenWords.otherWindowOk("com.google.android.apps.docs", own, money))
        assertTrue(ScreenWords.otherWindowOk("com.google.android.gms", own, money))
        assertFalse(ScreenWords.otherWindowOk(own, own, money))
        assertFalse(ScreenWords.otherWindowOk("com.android.systemui", own, money))
        assertFalse(ScreenWords.otherWindowOk("com.google.android.inputmethod.latin", own, money))
        assertFalse(ScreenWords.otherWindowOk("com.mtn.momo", own, money)); assertFalse(ScreenWords.otherWindowOk("zm.co.zanaco.bank", own, money))
        assertFalse(ScreenWords.otherWindowOk(null, own, money)); assertFalse(ScreenWords.otherWindowOk("", own, money))
    }

    @Test fun theNoteForTestPhones() {
        assertEquals("No words found: 12 things with no name, in 3 windows.", ScreenWords.noWordsNote(12, 3))
        assertEquals("No words found: 1 thing with no name, in 1 window.", ScreenWords.noWordsNote(1, 1))
    }

    @Test fun theWiringIsThere() {
        val g = listOf("src/main/java/zm/screenguide/GuideService.kt", "app/src/main/java/zm/screenguide/GuideService.kt").map { File(it) }.first { it.exists() }.readText()
        assertTrue(g.contains("val nodes = withOtherWindows(popupNodes() + candidates(root))"))
        val w = g.substringAfter("    private fun withOtherWindows(first: List<AccessibilityNodeInfo>): List<AccessibilityNodeInfo> {").substringBefore("    private fun popupNodes()")
        assertTrue(w.contains("ScreenWords.otherWindowOk(r.packageName?.toString(), packageName, blockedApps)"))
        assertTrue(w.contains("if (more.any { it.isPassword }) continue"))                           // a window with a password box: never
        assertTrue(g.contains("ScreenWords.noWordsNote(nodes.size, windowsSeen)"))
    }
}
