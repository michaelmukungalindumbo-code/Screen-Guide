package zm.screenguide

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

// v0.111: the Google Play version. The hardest two minutes for a new user are before ScreenGuide helps anyone: an app
// installed from a file is locked behind "restricted settings". From the Play Store there is no lock, and updates come
// by themselves. Play does not allow an app to update itself, so that version carries no self-updater.
class PlayBuildTest {
    private fun file(vararg p: String) = p.flatMap { listOf(it, "app/$it") }.map { File(it) }.first { it.exists() }.readText()

    @Test fun noSelfUpdaterInThePlayVersion() {
        val man = file("src/play/AndroidManifest.xml")
        assertTrue(man.contains("<uses-permission android:name=\"android.permission.REQUEST_INSTALL_PACKAGES\" tools:node=\"remove\"/>"))
        assertTrue(man.contains("<uses-permission android:name=\"android.permission.UPDATE_PACKAGES_WITHOUT_USER_ACTION\" tools:node=\"remove\"/>"))
        assertTrue(man.contains("<receiver android:name=\".UpdateReceiver\" tools:node=\"remove\"/>"))
        val m = file("src/main/java/zm/screenguide/MainActivity.kt")
        assertTrue(m.contains("if (BuildConfig.SELF_UPDATE) updateOnResume()"))
        assertTrue(m.contains("if (BuildConfig.SELF_UPDATE) knownUpdate()?.let"))
        assertTrue(m.contains("if (BuildConfig.SELF_UPDATE) rows.add(0, Row(\"refresh\", \"Check for updates\") { checkUpdate(true) })"))
        // every way into the updater is behind that switch
        assertEquals(3, Regex("BuildConfig\\.SELF_UPDATE").findAll(m).count())
        assertEquals(1, Regex("(?<!fun )updateOnResume\\(\\)").findAll(m).count())
        assertEquals(1, Regex("checkUpdate\\(true\\)").findAll(m).count())
    }

    @Test fun thePlayBuildAndItsKey() {
        val g = file("build.gradle.kts")
        val play = g.substringAfter("buildTypes {").substringBefore("compileOptions")
        assertTrue(play.contains("create(\"play\")") && play.contains("buildConfigField(\"boolean\", \"SELF_UPDATE\", \"false\")"))
        assertTrue(g.substringBefore("buildFeatures").contains("buildConfigField(\"boolean\", \"SELF_UPDATE\", \"true\")"))   // test builds: as before
        // The upload key is never in the repository: only handed over by GitHub Secrets while the build runs
        val key = g.substringAfter("create(\"play\") {").substringBefore("buildTypes")
        for (k in listOf("PLAY_KEYSTORE_FILE", "PLAY_KEYSTORE_PASSWORD", "PLAY_KEY_ALIAS", "PLAY_KEY_PASSWORD")) assertTrue(k, key.contains("System.getenv(\"$k\")"))
        assertFalse(Regex("(storePassword|keyPassword) = \"").containsMatchIn(key))
    }
}
