package zm.screenguide

import org.json.JSONArray
import org.json.JSONObject

// v0.109 ("be right every time on the phones people have"): a guide proven on one phone can miss a button on another
// maker's. "Check this phone" keeps, for each built-in task done on this phone, which steps ScreenGuide found, which
// button it looked for and did not find, and whether Help was needed. One report to copy and send shows every task
// that needs fixing on that phone. It holds only ScreenGuide's own task and button names, the app version and the kind
// of phone: nothing the person typed, no app names, nothing from their screen. Kept on the phone until they copy it.
object PhoneCheck {
    class Run(val id: String, val steps: Int) {
        val found = sortedSetOf<Int>(); val lost = LinkedHashMap<Int, String>(); var help = 0; var end = ""
    }
    val runs = LinkedHashMap<String, Run>()   // the latest try of each task

    fun start(id: String, steps: Int) { runs.remove(id); runs[id] = Run(id, steps) }
    fun found(id: String, step: Int) { runs[id]?.let { it.found.add(step); it.lost.remove(step) } }
    fun lost(id: String, step: Int, word: String) { runs[id]?.let { if (step !in it.found) it.lost[step] = word.take(40) } }
    fun help(id: String) { runs[id]?.let { it.help++ } }
    fun end(id: String, how: String) { runs[id]?.let { it.end = how } }

    // OK: finished, no button missed, no Help. A step a phone does not have is skipped by design: that is not a problem.
    fun ok(r: Run) = r.end == "finished" && r.lost.isEmpty() && r.help == 0
    fun line(r: Run, title: String): String {
        val how = when (r.end) { "finished" -> "finished"; "stopped" -> "stopped before the end"; else -> "not finished" }
        val found = if (r.found.isEmpty()) "no step found" else "steps found: " + r.found.joinToString(", ") { (it + 1).toString() } + " of ${r.steps}"
        val lost = r.lost.entries.joinToString("") { (i, w) -> " Not found: step ${i + 1} “$w”." }
        val help = if (r.help > 0) " Help pressed: ${r.help}." else ""
        return (if (ok(r)) "OK      " else "PROBLEM ") + "$title: $how, $found.$lost$help"
    }
    // titles: every built-in task, id -> name, in the menu's order
    fun report(titles: Map<String, String>, device: String, version: String): String {
        val tried = titles.filterKeys { it in runs }
        val good = tried.keys.count { ok(runs[it]!!) }
        return (listOf("ScreenGuide $version on $device", "Tasks tried: ${tried.size} of ${titles.size}. OK: $good. Problems: ${tried.size - good}.", "") +
            tried.map { (id, t) -> line(runs[id]!!, t) } +
            (if (tried.size < titles.size) listOf("", "Not tried yet: " + titles.filterKeys { it !in runs }.values.joinToString(", ") + ".") else emptyList()))
            .joinToString("\n")
    }
    fun summary(total: Int): String = "${runs.keys.size} of $total tried"

    fun save(): String = JSONArray().apply {
        runs.values.forEach { r -> put(JSONObject().put("id", r.id).put("n", r.steps).put("f", JSONArray(r.found.toList())).put("e", r.end).put("h", r.help)
            .put("l", JSONObject().apply { r.lost.forEach { (i, w) -> put(i.toString(), w) } })) }
    }.toString()
    fun load(json: String?) {
        runs.clear()
        try {
            val a = JSONArray(json ?: return)
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i); val r = Run(o.getString("id"), o.getInt("n"))
                o.getJSONArray("f").let { f -> for (j in 0 until f.length()) r.found.add(f.getInt(j)) }
                o.optJSONObject("l")?.let { l -> l.keys().forEach { k -> r.lost[k.toInt()] = l.getString(k) } }
                r.end = o.optString("e"); r.help = o.optInt("h"); runs[r.id] = r
            }
        } catch (e: Exception) { runs.clear() }
    }
}
