package zm.screenguide

// v0.110, voice first: many people ScreenGuide is for read slowly or not at all. A question asked with the Speak button
// is answered aloud as well as in writing (when "Speak the steps" is on). Typed questions stay silent, as before.
object Voice1st {
    // What is read aloud: the answer without the line about a button the ear cannot see, and not a whole page
    fun spoken(answer: String): String {
        val s = answer.replace(Regex("\\s+"), " ").trim()
        val parts = Speech.sentences(s)
        val out = ArrayList<String>(); var n = 0
        for (p in parts) { if (n + p.length > 400 && out.isNotEmpty()) break; out.add(p); n += p.length }
        return out.joinToString(" ")
    }
}
