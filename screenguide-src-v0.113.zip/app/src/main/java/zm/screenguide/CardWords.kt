package zm.screenguide

// Keep each instruction on the card short. With a ring, one action is enough (the ring shows where). With nothing to
// point at, the words must carry everything, so keep up to three sentences (for example the safety message).
object CardWords {
    private val actionWords = Regex("\\b(tap|press|swipe|scroll|choose|select|type|drag|open|turn|pick|hold|slide|dinani|kandeni|kokani|sankhani|lembani)\\b", RegexOption.IGNORE_CASE)
    // An instruction starts with its action word ("Type the word …"). #75 (11 Nov): "The box is open now. Type the word
    // … here." showed only "The box is open now.", because "open" there says how the box is, not what to do.
    private val startsWithAction = Regex("^\\W*(?:now\\s+|then\\s+|next,?\\s+)?" + actionWords.pattern, RegexOption.IGNORE_CASE)
    private val sentenceEnd = Regex("(?<=[.!?])\\s+")

    fun tighten(say: String, pointing: Boolean): String {
        val t = say.trim()
        if (pointing) {
            val parts = t.split(sentenceEnd)
            val act = parts.firstOrNull { startsWithAction.containsMatchIn(it) }
                ?: parts.firstOrNull { actionWords.containsMatchIn(it) } ?: parts.first()
            return act.trim().split(" ").take(12).joinToString(" ")
        }
        return t.split(sentenceEnd).take(3).joinToString(" ").split(" ").take(40).joinToString(" ")
    }
}
