package zm.screenguide

// Keep each instruction short. With a ring, one action is enough (the ring shows where). With nothing to
// point at, the words must carry everything, so keep up to three sentences (for example the safety message).
object Tighten {
    private val actionWords = Regex("\\b(tap|press|swipe|scroll|choose|select|type|drag|open|turn|pick|hold|slide|dinani|kandeni|kokani|sankhani|lembani)\\b", RegexOption.IGNORE_CASE)
    private val startsWithAction = Regex("^\\W*(?:(?:now|then|next|please|ok|okay),?\\s+)?" + actionWords.pattern, RegexOption.IGNORE_CASE)

    fun say(say: String, pointing: Boolean): String {
        val t = say.trim()
        if (pointing) {
            val parts = t.split(Regex("(?<=[.!?])\\s+"))
            // #74: "The box is open now. Type the word …" kept the remark ("open" is an action word too). A sentence that
            // starts with the action is the instruction; else the first one with an action anywhere, as before.
            val act = parts.firstOrNull { startsWithAction.containsMatchIn(it) }
                ?: parts.firstOrNull { actionWords.containsMatchIn(it) } ?: parts.first()
            return act.trim().split(" ").take(12).joinToString(" ")
        }
        return t.split(Regex("(?<=[.!?])\\s+")).take(3).joinToString(" ").split(" ").take(40).joinToString(" ")
    }
}
