package zm.screenguide

// ◀ and ▶ on the instruction card (6 Nov, the owner's idea; he chose arrows on the card). ScreenGuide never taps for
// the person: ◀ shows the earlier instruction again (with its ring, when its button is on this screen), and ▶ moves on:
// the next step of a numbered guide, or, in a Smart guide, the AI is told they skipped this one and gives the next step
// or another way. A step shown by an arrow stays until the screen changes or PEEK_MS pass; then the guide goes on as usual.
object StepNav {
    const val PEEK_MS = 8000L

    // Numbered guides: the step each arrow shows, or null when there is none that way.
    fun back(index: Int, size: Int): Int? {
        if (size <= 0) return null
        val i = index.coerceIn(0, size - 1)
        return if (i > 0) i - 1 else null
    }
    fun skip(index: Int, size: Int): Int? = if (size > 0 && index + 1 < size) maxOf(index + 1, 0) else null

    // Smart guides: at is the place, in the instructions shown so far, of the one on the card now (the count, when it is
    // not among them, such as an error). The one before it, or null.
    fun before(at: Int): Int? = if (at > 0) at - 1 else null

    // Smart guides: the instructions worth going back to, oldest first. The same words twice in a row are kept once
    // (the newest copy, so the one on the card is found in the list).
    fun remember(shown: MutableList<Step>, s: Step, max: Int = 12) {
        val last = shown.lastOrNull()
        if (last != null && last.say == s.say && last.match == s.match) { shown[shown.size - 1] = s; return }   // the newest copy
        shown.add(s)
        while (shown.size > max) shown.removeAt(0)
    }

    // A numbered step that says "Tap the glowing row" is named by its row's words on this phone. For a step shown by ◀ ▶:
    // its row on this screen if it is here, else its row as it was when that step was shown, else the guide's own name
    // for it. Never another step's row (7 Nov: ◀ on "Tap Data Usage" showed "Step 2 of 4" with the words "Tap Data Usage").
    // null: the step's own words stay.
    fun rowName(say: String, onScreen: String?, seen: String?, match: List<String>): String? {
        if (!say.contains("glowing row")) return null
        return listOf(onScreen, seen, match.firstOrNull { !it.startsWith("@") })
            .firstNotNullOfOrNull { w -> w?.trim()?.takeIf { it.isNotEmpty() && it.length <= 40 } }
    }

    // v0.89: Help in a built-in guide could not reach the helper (no data, no credit, the server). English only: there
    // are no checked Nyanja or Bemba words for this yet.
    const val NO_HELPER = "I can't reach the helper right now. Follow the ring."
    const val NO_HELPER_MS = 6000L

    // What the AI is told when the person skips its step
    fun skipNote(say: String): String =
        "They tapped Skip on “${say.trim().take(80)}”: it did not work for them, or they did it already. " +
            "Give the next step, or another way."

    // v0.98 (the owner's phone, 8 Nov: "Make words bigger" on Infinix): on the page a step leads to (its name is the page's
    // title), that step is done. There the brightness slider is called "Display brightness", step 2's own words ("Display
    // & brightness"), and the guide said "Tap Display brightness" with the ring on the slider, not "Scroll down to find
    // Font size".
    // v0.105 (the owner's tablet, Samsung): "Device care" is one of the Battery step's names AND the title of the page that
    // holds the "Battery" row. There the step is not done: another of its names is still a row to tap. (rows: the words
    // on the page that are not its title.)
    fun onPageOf(titles: List<String>, names: List<String>, rows: List<String> = emptyList()): Boolean {
        fun k(s: String) = s.lowercase().filter { it.isLetterOrDigit() }
        val t = titles.map { k(it) }.filter { it.isNotEmpty() }.toSet()
        val hit = names.map { k(it) }.filter { it in t }.toSet()
        if (hit.isEmpty()) return false
        val r = rows.map { k(it) }.toSet()
        return names.none { k(it) !in hit && k(it) in r }
    }

    // v0.110: a built-in task whose last step opens a page (not a switch, not in the pull-down panel) is done on that page
    fun arrived(doneWhen: String?, shade: Boolean, lastIsSwitch: Boolean, builtIn: Boolean, titles: List<String>, lastNames: List<String>, rows: List<String>): Boolean =
        doneWhen == "last_tap" && !shade && !lastIsSwitch && builtIn && onPageOf(titles, lastNames, rows)

    // v0.99 (the owner's phone, 8 Nov, Infinix): its Font size page has no standard slider to ring, but a "Make larger"
    // button (the big A). One tap makes the words bigger: easier than dragging, for someone new to phones.
    private val larger = setOf("makelarger", "larger", "makebigger", "bigger", "increase", "increasefontsize", "increasetextsize",
        "largerfont", "largertext", "zoomin")
    fun largerButton(label: String): Boolean = label.lowercase().filter { it.isLetterOrDigit() } in larger
    fun tapLarger(label: String) = "Tap \u201C$label\u201D to make the words bigger."   // English only: no new Nyanja or Bemba words
}
