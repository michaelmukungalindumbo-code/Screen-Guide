package zm.screenguide

// The tag after each screen word that goes to the server, so the AI knows what the word is. The phone reads the screen;
// the deciding is here, so it can be tested.
// [switch] its row has an on/off switch; [selected] a tab already chosen; [tap] can be tapped; [text] plain text;
// [typing] a text box that is open, with the keyboard up. 5 Nov: in the Play Store the search box read the same before
// and after it was tapped ("Search apps & games [tap]"), so the guide said "tap the search box" again and again.
object ScreenWords {
    // tests first: not built yet
    fun blindKey(pkg: String, pageOpenedAt: Long) = ""
    fun askBlind(key: String, lastKey: String, sinceMs: Long) = false

    // v0.107 (the owner's phone, 11 Nov, Drive's scan page): "I cannot read the words in this app" on a page with Enhance,
    // Filters, Crop, Discard scan and Next on it. The window Android calls "active" had no words; the page's buttons
    // were in another of the app's windows, which was only read when it lay on top. With no words at all in the usual
    // place, every other window of an ordinary app is read too (never ScreenGuide's own, the keyboard, the phone's bars,
    // or a money app).
    fun readOtherWindows(words: Int) = words == 0
    fun otherWindowOk(pkg: String?, own: String, blocked: List<String>): Boolean =
        !pkg.isNullOrEmpty() && pkg != own && !pkg.contains("systemui", true) && !pkg.contains("inputmethod", true) && blocked.none { pkg.contains(it, true) }
    // Test phones: what was there when no words were found, so the next recording shows the cause
    fun noWordsNote(things: Int, windows: Int) = "No words found: $things thing" + (if (things == 1) "" else "s") + " with no name, in $windows window" + (if (windows == 1) "" else "s") + "."

    fun tag(switch: Boolean, selected: Boolean, short: Boolean, tappable: Boolean, editable: Boolean, focused: Boolean): String = when {
        switch -> "[switch]"
        editable && focused -> "[typing]"
        selected && short && tappable -> "[selected]"
        tappable -> "[tap]"
        else -> "[text]"
    }
}
