package zm.screenguide

// The tag after each screen word that goes to the server, so the AI knows what the word is. The phone reads the screen;
// the deciding is here, so it can be tested.
// [switch] its row has an on/off switch; [selected] a tab already chosen; [tap] can be tapped; [text] plain text;
// [typing] a text box that is open, with the keyboard up. 5 Nov: in the Play Store the search box read the same before
// and after it was tapped ("Search apps & games [tap]"), so the guide said "tap the search box" again and again.
object ScreenWords {
    // v0.107 (the owner's phone, 11 Nov, Drive's scan page): "I cannot read the words in this app" on a page with Enhance,
    // Filters, Crop, Discard scan and Next on it. The window Android calls "active" had no words; the page's buttons
    // were in another of the app's windows, which was only read when it lay on top. With no words at all in the usual
    // place, every other window of an ordinary app is read too (never ScreenGuide's own, the keyboard, the phone's bars,
    // or a money app).
    fun readOtherWindows(words: Int) = words == 0
    fun otherWindowOk(pkg: String?, own: String, blocked: List<String>): Boolean =
        !pkg.isNullOrEmpty() && pkg != own && !pkg.contains("systemui", true) && !pkg.contains("inputmethod", true) && blocked.none { pkg.contains(it, true) }
    // Test phones: what was there when no words were found, so the next recording shows the cause
    fun noWordsNote(things: Int, windows: Int) = "No words found: $things thing" + (if (things == 1) "" else "s") + " with no name, in $windows window" + (if (windows == 1) "" else "s") + "."

    // v0.113 (#73, 11 Nov, the Play Store's search page): the keyboard was up, but no word came as [typing] (the box's
    // words were on a part Android did not call focused), so the guide said "Tap the search bar" again and again. With
    // the keyboard up and no word marked, the word inside the box that has the typing focus is the open box; else a
    // "Search …" word. Returns its place in the list, or null to change nothing.
    private val searchWord = Regex("^search(\\s.*)?$", RegexOption.IGNORE_CASE)
    private val tagEnd = Regex("\\s*\\[(tap|text|switch|selected|typing)\\]\\s*$")
    fun openBox(words: List<String>, inFocusedBox: List<Boolean>, keyboardUp: Boolean): Int? {
        if (!keyboardUp || words.any { it.trimEnd().endsWith("[typing]") }) return null
        words.indices.firstOrNull { inFocusedBox.getOrElse(it) { false } && !words[it].trimEnd().endsWith("[switch]") }?.let { return it }
        return words.indexOfFirst { searchWord.matches(it.replace(tagEnd, "").trim()) }.takeIf { it >= 0 }
    }
    fun markOpen(words: List<String>, i: Int?): List<String> =
        if (i == null || i !in words.indices) words else words.toMutableList().also { it[i] = it[i].replace(tagEnd, "") + " [typing]" }

    // Keep each instruction short. With a ring, one action is enough (the ring shows where). With nothing to
    // point at, the words must carry everything, so keep up to three sentences (for example the safety message).
    // #73: "is open" says how a box is, not what to do, so "The box is open now. Type the word …" keeps the second
    // sentence (the card had shown only "The box is open now."). Likewise "you can type now" says it is possible; the
    // sentence after it says what to type.
    private val actionWords = Regex("\\b(tap|press|swipe|scroll|choose|select|type|drag|open|turn|pick|hold|slide|dinani|kandeni|kokani|sankhani|lembani)\\b", RegexOption.IGNORE_CASE)
    private val openState = Regex("\\b(is|are|was|already|still|now)\\s+open\\b|\\bcan\\s+(now\\s+)?\\w+", RegexOption.IGNORE_CASE)
    private fun saysWhatToDo(s: String) = actionWords.containsMatchIn(s.replace(openState, " "))
    fun tighten(say: String, pointing: Boolean): String {
        val t = say.trim()
        if (pointing) {
            val parts = t.split(Regex("(?<=[.!?])\\s+"))
            val act = parts.firstOrNull { saysWhatToDo(it) } ?: parts.first()
            return act.trim().split(" ").take(12).joinToString(" ")
        }
        return t.split(Regex("(?<=[.!?])\\s+")).take(3).joinToString(" ").split(" ").take(40).joinToString(" ")
    }

    fun tag(switch: Boolean, selected: Boolean, short: Boolean, tappable: Boolean, editable: Boolean, focused: Boolean): String = when {
        switch -> "[switch]"
        editable && focused -> "[typing]"
        selected && short && tappable -> "[selected]"
        tappable -> "[tap]"
        else -> "[text]"
    }
}
