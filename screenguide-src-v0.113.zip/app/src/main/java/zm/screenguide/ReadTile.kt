package zm.screenguide

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

// v0.112 (the owner, 11 Nov: "With one button, how can I activate and deactivate this floating widget"): the Read button
// (the round green button that reads a screen aloud) gets a switch in the phone's pull-down panel, next to Wi-Fi and
// Torch. One tap there turns it on or off, from any screen. Turning it ON the first time still goes through ScreenGuide
// when the person has not yet agreed to it (it sends a screen's words to be read): a tile cannot ask for that.
class ReadTile : TileService() {
    companion object {
        const val LABEL = "Read button"
        const val EXTRA = "read_tile"
        // What one tap does. on: the button is showing. serviceOn: ScreenGuide is switched on. agreed: they said yes to
        // sending a screen's words. Off is always allowed; on only when everything it needs is in place.
        fun tap(on: Boolean, serviceOn: Boolean, agreed: Boolean): String = when {
            on -> "off"
            !serviceOn || !agreed -> "open"
            else -> "on"
        }
        fun lit(on: Boolean, serviceOn: Boolean) = on && serviceOn
        const val HOW_TO_ADD = "Pull down the top of the screen twice, tap the pencil (Edit), then drag “Read button” up among the others."
    }

    private fun sp() = getSharedPreferences("sg", Context.MODE_PRIVATE)
    private fun serviceOn() = (Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: "").contains(packageName)

    override fun onStartListening() { show() }
    private fun show() {
        val t = qsTile ?: return
        t.state = if (lit(sp().getBoolean("read_button", false), serviceOn())) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        t.label = LABEL
        try { t.updateTile() } catch (e: Exception) {}
    }

    override fun onClick() {
        val sp = sp()
        when (tap(sp.getBoolean("read_button", false) && serviceOn(), serviceOn(), sp.getBoolean("smart_ok", false))) {
            "off" -> sp.edit().putBoolean("read_button", false).apply()     // the guide service hears this and removes the button
            "on" -> sp.edit().putBoolean("read_button", true).apply()
            else -> {
                val i = Intent(this, MainActivity::class.java).putExtra(EXTRA, true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                try {
                    if (Build.VERSION.SDK_INT >= 34) startActivityAndCollapse(PendingIntent.getActivity(this, 4200, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
                    else @Suppress("DEPRECATION", "StartActivityAndCollapseDeprecated") startActivityAndCollapse(i)
                } catch (e: Exception) {}
            }
        }
        show()
    }
}
