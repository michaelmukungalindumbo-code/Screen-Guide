plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "zm.screenguide"
    compileSdk = 36   // Google Play: new apps and updates must target Android 16 (API 36) from 31 August 2026
    defaultConfig {
        applicationId = "zm.screenguide"
        minSdk = 24
        targetSdk = 36
        versionCode = 113
        versionName = "0.113"
        // ScreensTest: ScreenGuide's own screens opened on a small phone in GitHub's emulator (the "Screens" check)
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        // v0.111: true in the builds GitHub makes for testing (ScreenGuide updates itself); false in the Google Play version
        buildConfigField("boolean", "SELF_UPDATE", "true")
    }
    buildFeatures { buildConfig = true }
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
        // v0.111: Google Play's upload key. It is never in this file or this repository: the "Play bundle" workflow hands it
        // over from GitHub Secrets for the minutes the build runs.
        create("play") {
            val ks = System.getenv("PLAY_KEYSTORE_FILE")
            if (!ks.isNullOrEmpty()) {
                storeFile = file(ks)
                storePassword = System.getenv("PLAY_KEYSTORE_PASSWORD")
                keyAlias = System.getenv("PLAY_KEY_ALIAS")
                keyPassword = System.getenv("PLAY_KEY_PASSWORD")
            }
        }
    }
    // The Google Play version: "gradle bundlePlay". No self-updater (Play does that), not a test build.
    buildTypes {
        create("play") {
            initWith(getByName("release"))
            matchingFallbacks += "release"
            isMinifyEnabled = false
            buildConfigField("boolean", "SELF_UPDATE", "false")
            signingConfig = if (!System.getenv("PLAY_KEYSTORE_FILE").isNullOrEmpty()) signingConfigs.getByName("play") else signingConfigs.getByName("debug")
        }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    // Android's bug finder, on every build. Only bugs that crash or break some phones fail the build: using something
    // newer than Android 7 without checking, a missing permission, the wrong thread, settings never saved.
    lint {
        checkOnly.addAll(listOf("NewApi", "InlinedApi", "MissingPermission", "WrongThread", "CommitPrefEdits", "WrongConstant", "Range",
            "ResourceType", "UnspecifiedRegisterReceiverFlag", "ProtectedPermissions", "ExportedService"))
        abortOnError = true
        warningsAsErrors = false
        checkReleaseBuilds = false
        textReport = true
        textOutput = file("stdout")
    }
}
kotlin { compilerOptions { jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17) } }

// Sign in with Google (Android's Credential Manager). Only used when the person chooses to sign in.
dependencies {
    implementation("androidx.credentials:credentials:1.3.0")
    implementation("androidx.credentials:credentials-play-services-auth:1.3.0")
    implementation("com.google.android.libraries.identity.googleid:googleid:1.1.1")
    // The sign-in library needs these but did not bring them whole: 4 Nov (#26) androidx.core.app.ComponentActivity was
    // missing from the app and "Sign in with Google" closed it. SignInLibrariesTest checks they are inside the app.
    implementation("androidx.core:core:1.13.1")
    implementation("androidx.activity:activity:1.9.3")
    // v0.90: Google's rewarded ads (opt-in, only inside ScreenGuide; AdsGate has the rules). AdsLibraryTest checks it is
    // inside the app. 25.5.0 (17 Sep 2026) needs Android 7 (API 24), like ScreenGuide.
    implementation("com.google.android.gms:play-services-ads:25.5.0")
    // MatchTest: real questions must pick the right action (run on every GitHub build)
    testImplementation("junit:junit:4.13.2")
    // Real org.json for plain JVM tests (Android's own copy is only an empty stub there). Tests only, not in the app.
    testImplementation("org.json:json:20240303")
    // ScreensTest only (GitHub's emulator), not in the app
    androidTestImplementation("androidx.test:runner:1.6.2")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.test.uiautomator:uiautomator:2.3.0")
}
