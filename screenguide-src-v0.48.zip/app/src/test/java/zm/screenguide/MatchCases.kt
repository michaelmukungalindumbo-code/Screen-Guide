package zm.screenguide

import java.io.File

// Real questions and goals, with what must happen. Every time a word picked the wrong action on a phone, the case goes
// here, so it can never come back. Run by MatchTest on every build (GitHub fails the build if any case fails).
object MatchCases {
    // Launcher apps seen on Michael's Infinix HOT 50i, plus common ones. Money apps are filtered out before matching.
    val apps = listOf("Messages", "MovieBox", "Notepad", "Palm Store", "Past Papers ZM", "Phone", "Phone Master", "Photos", "Picsart",
        "Play Store", "Recorder", "Safety", "Settings", "Sheets", "SIM Toolkit", "VidMate", "Weather", "WhatsApp", "XTheme", "YouTube",
        "Camera", "Clock", "Calculator", "Calendar", "Chrome", "Gmail", "Files", "Gallery", "Contacts", "Facebook", "TikTok", "Boomplay",
        "Google", "Maps", "Drive", "Docs", "Meet", "Gemini", "Instagram", "Messenger", "Telegram", "Opera Mini", "Zoom", "Folax", "Music", "FM Radio").map { it to "pkg." + it.lowercase().replace(" ", "") }
    private val labels = apps.map { it.first }

    // id -> keywords, read from the real guides.json (no Android JSON in unit tests, so a small reader).
    fun tasks(json: String): Map<String, List<String>> {
        val out = LinkedHashMap<String, List<String>>()
        for (part in json.split("\"id\": \"").drop(1)) {
            val id = part.substringBefore('"')
            val kw = part.substringAfter("\"keywords\": [", "").substringBefore("]")
            out[id] = Regex("\"([^\"]*)\"").findAll(kw).map { it.groupValues[1] }.toList()
        }
        return out
    }

    // What the home screen does with typed words: a problem or money goes to the helper; otherwise the best task.
    private fun taskFor(text: String, tasks: Map<String, List<String>>): String? {
        if (Match.isProblem(text) || Match.isMoney(text)) return null
        val best = tasks.maxByOrNull { Match.score(it.value, text) } ?: return null
        return if (Match.score(best.value, text) > 0) best.key else null
    }

    private val taskCases = listOf(
        "turn on the torch" to "torch", "How do I turn on my flashlight?" to "torch", "the power went off, I need light" to null,
        "take a screenshot" to "screenshot", "How do I take a screenshot on my phone" to "screenshot",
        "make my battery last longer" to "battery_saver", "battery saver" to "battery_saver",
        "save my data" to "data_saver", "my bundle is finishing too fast" to "data_saver",
        "make the words bigger" to "text_size", "increase font size" to "text_size",
        "turn on wifi" to "wifi", "connect to wi-fi" to "wifi", "turn on bluetooth" to "bluetooth", "connect my earphones" to "bluetooth",
        "share internet with my friend" to "hotspot", "turn on hotspot" to "hotspot", "flight mode" to "airplane",
        // words that once picked a task by accident
        "How do I save a phone number" to null, "Is my order ready" to null, "How do I recharge airtime" to null,
        "Join a Zoom meeting" to null, "Turn on dark mode" to null, "highlight text" to null, "How do I repair my phone" to null,
        "loudspeaker on a call" to null, "buy a data bundle" to null, "Send money to my brother" to null, "What is WhatsApp" to null,
        "WhatsApp video call" to null, "my wifi keeps disconnecting" to null, "why is my battery draining" to null,
        "update whatsapp" to null, "read my messages" to null, "share my location on WhatsApp" to null, "send pictures on whatsapp" to null,
        "call mum" to null, "internet banking" to null, "my phone is slow" to null, "bluetooth is not working" to null,
        // the example questions on the home screen must reach the helper, except the one that is an offline task
        "How do I scan my certificates into one PDF?" to null, "How do I apply for a job online?" to null, "How do I send my CV by email?" to null,
        "How do I back up my photos?" to null, "How do I set up WhatsApp on a new phone?" to null, "How do I join a Zoom class from a link?" to null,
        "Which app is using up my data?" to null, "How do I free up space on my phone?" to null, "How do I create a Google account?" to null,
        "How do I make a WhatsApp group for parents?" to null, "How do I share my internet with a laptop?" to "hotspot",
        "How do I check my ECZ results online?" to null, "How do I sell something on Facebook Marketplace?" to null,
        "How do I make a quiz with Google Forms?" to null, "How do I find my lost phone?" to null, "Is this SMS a scam?" to null)

    private val appCases = listOf(
        "Take a screenshot on your phone" to null, "Upload a video to YouTube" to "YouTube", "Send a photo to Mum on WhatsApp" to "WhatsApp",
        "Send files on WhatsApp" to "WhatsApp", "Check storage space in the Settings" to "Settings",
        "Open Settings and allow WhatsApp to use the camera" to "Settings", "Take a photo with the Camera" to "Camera",
        "Make a call to Mum" to "Phone", "Call my brother on WhatsApp" to "WhatsApp", "Check your messages" to null, "Open messages" to "Messages",
        "I want to use it (about: What is YouTube)" to "YouTube", "Clean my phone with Phone Master" to "Phone Master",
        "Set an alarm in the Clock app" to "Clock", "Find a song on Boomplay" to "Boomplay", "Install WhatsApp from the Play Store" to "Play Store",
        "Update WhatsApp" to "Play Store", "Download an app from Palm Store" to "Palm Store", "Open Chrome and search for the weather" to "Chrome",
        "Check the weather" to "Weather", "Read the news" to null, "Use the calculator" to "Calculator", "Find my phone" to null,
        "Turn on the torch on your phone" to null, "Post a status on WhatsApp" to "WhatsApp", "Write a note in Notepad" to "Notepad",
        "Record a video of my screen" to null, "Check storage on my phone" to null, "Share a photo from the gallery to WhatsApp" to "Gallery",
        "Make my phone faster" to null, "Change the phone language" to null, "Free up space on the phone" to null,
        // Google's apps are named without "Google" (seen: "Google Drive" opened the Google search app)
        "Upload a file to Google Drive" to "Drive", "How can I upload content on Google drive" to "Drive", "Open Google Maps" to "Maps",
        "Find a photo in Google Photos" to "Photos", "Open Google Chrome" to "Chrome", "Write a letter in Google Docs" to "Docs",
        "Join a call on Google Meet" to "Meet", "Search for the news on Google" to "Google", "Ask Gemini a question" to "Gemini",
        "Install Google Drive from the Google Play Store" to "Play Store")

    private val quickCases = listOf(
        "weather" to "weather", "will it rain today" to "weather", "set an alarm" to "clock", "calculator" to "calculator",
        "take a selfie" to "camera", "camera" to "camera", "my photos" to "gallery",
        "Send a photo from my camera roll on WhatsApp" to null, "send a picture from my gallery on whatsapp" to null,
        "how do I set an alarm" to null, "my camera is not working" to null, "how can I navigate settings" to null,
        "share my photos on facebook" to null, "what is the weather" to null, "can you open the camera" to null,
        "watch videos on YouTube" to null, "delete a photo from my gallery" to null, "Is this SMS a scam?" to null,
        "How do I back up my photos?" to null, "Which app is using up my data?" to null)

    private val findCases = listOf(
        "open whatsapp" to "WhatsApp", "open phone" to "Phone", "find my phone" to null, "where is my phone" to null,
        "find phone app" to "Phone", "open the camera" to "Camera", "find phone master" to "Phone Master", "where is youtube" to "YouTube",
        "start a call" to null, "open my files" to "Files", "open play store" to "Play Store", "open drive" to "Drive", "open google" to "Google")

    private val moneyCases = listOf("send money to my brother" to true, "how do I check my momo balance" to true, "internet banking" to true,
        "pay my electricity bill" to true, "buy airtime with mobile money" to true, "how do I buy data" to false, "pay attention" to false,
        "upload a video" to false)

    fun failures(guidesJson: String): List<String> {
        val tasks = tasks(guidesJson)
        val bad = ArrayList<String>()
        if (tasks.size < 9) bad.add("guides.json: expected at least 9 tasks, read ${tasks.size}")
        for ((t, want) in taskCases) { val got = taskFor(t, tasks); if (got != want) bad.add("task \"$t\": got $got, want $want") }
        for ((g, want) in appCases) { val got = Match.pickApp(g, apps)?.first; if (got != want) bad.add("open first \"$g\": got $got, want $want") }
        for ((t, want) in quickCases) { val got = Match.quickTarget(t, labels)?.first(); if (got != want) bad.add("quick open \"$t\": got $got, want $want") }
        for ((t, want) in findCases) { val got = Match.findTarget(t, labels); if (got != want) bad.add("find \"$t\": got $got, want $want") }
        for ((t, want) in moneyCases) { val got = Match.isMoney(t); if (got != want) bad.add("money \"$t\": got $got, want $want") }
        return bad
    }

    fun guidesFile(): File = listOf("src/main/assets/guides.json", "app/src/main/assets/guides.json").map { File(it) }.first { it.exists() }
}
