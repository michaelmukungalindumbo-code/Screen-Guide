package zm.screenguide

// Every rule that turns a person's words into an action lives here: start an offline task, open an app first, open an
// app at once, treat a question as a problem or as money. No Android code, so MatchTest runs hundreds of real questions
// through it on every build. Lessons that made this file: "Take a screenshot on your phone" opened the Phone app;
// "number" matched "mb"; "ready" matched "read". Words are not commands: match whole words, and plain words carefully.
object Match {
    // " take a screenshot on your phone " : lower case, whole words, single spaces, a space at each end.
    fun words(s: String) = " " + s.lowercase().replace(Regex("[^\\p{L}\\p{N}]+"), " ").trim() + " "
    private fun has(w: String, phrase: String): Boolean { val p = words(phrase); return p.isNotBlank() && w.contains(p) }
    private fun norm(s: String) = s.lowercase().filter { it.isLetterOrDigit() }

    // How well an offline task's keywords fit the text. Whole words only; a longer phrase counts more.
    fun score(keywords: List<String>, text: String): Int {
        val w = words(text)
        return keywords.sumOf { k -> if (has(w, k)) words(k).trim().split(" ").size else 0 }
    }

    // A problem needs the helper, not a "turn it on" task or an app opening by itself.
    private val problemWords = listOf("not working", "doesn't", "does not", "doesnt", "won't", "wont", "can't", "cant", "cannot",
        "problem", "keeps", "stopped", "error", "failed", "fails", "slow", "not opening", "not showing", "disconnect", "disconnects",
        "disconnecting", "broken", "fix", "hacked", "stuck")
    fun isProblem(text: String): Boolean {
        val w = words(text)
        return w.startsWith(" why ") || w.startsWith(" what ") || problemWords.any { has(w, it) }   // " whatsapp " is not " what "
    }

    // Money tasks are never guided on screen (money apps are off limits).
    private val money = Regex("\\b(mobile money|momo|airtel money|zamtel kwacha|kwacha|send(ing)? money|withdraw\\w*|cash ?out|" +
        "transfer\\w* (money|funds|cash)|pay(ing)? (a |my |the |for )?(\\w+ )?bills?|bank transfer|deposit|banking|bank account|bank app)\\b",
        RegexOption.IGNORE_CASE)
    fun isMoney(text: String) = money.containsMatchIn(text)

    // App names that are also ordinary words. They count only when used like an app ("open Settings", "the Camera app").
    val plainNames = setOf("phone", "files", "file manager", "messages", "messaging", "camera", "clock", "gallery", "music", "notes",
        "notepad", "contacts", "calendar", "settings", "weather", "photos", "mail", "email", "maps", "calculator", "recorder", "browser",
        "videos", "video", "radio", "compass", "health", "store", "security", "themes", "theme", "translate", "assistant", "search", "sheets")
    private val callWords = Regex("\\b(call|calls|calling|dial|dialer|dialler|keypad|phone app|call log|missed call|ring)\\b")
    private val stores = listOf("play store", "palm store", "app store", "galaxy store", "appgallery", "app gallery")
    private val installWords = Regex("\\b(install|reinstall|update)\\b")

    // The installed app a guide should open first, as (name, package), or null. apps: (label, package) of launcher apps.
    fun pickApp(goal: String, apps: List<Pair<String, String>>): Pair<String, String>? {
        val low = goal.lowercase()
        // Installing or updating happens in the store, even when the goal names the app ("Install WhatsApp").
        apps.firstOrNull { (n, _) -> n.lowercase() in stores && Regex("(?<![\\w])" + Regex.escape(n.lowercase()) + "(?![\\w])").containsMatchIn(low) }?.let { return it }
        if (installWords.containsMatchIn(low)) apps.firstOrNull { it.first.equals("Play Store", true) }?.let { return it }
        var best: Pair<String, String>? = null; var at = Int.MAX_VALUE; var len = 0
        for ((n, p) in apps) {
            val ln = n.lowercase()
            if (ln == "phone" && !callWords.containsMatchIn(low)) continue   // "on your phone" is the device
            // Google's apps are named without "Google" on the phone: "Google Drive" is the app "Drive" (seen: it opened
            // the Google search app). The longer phrase wins over "Google" at the same place.
            val m = (if (ln != "google") Regex("(?<![\\w])google\\s+" + Regex.escape(ln) + "(?![\\w])").find(low) else null) ?: run {
                val rx = if (ln !in plainNames) "(?<![\\w])" + Regex.escape(ln) + "(?![\\w])"
                    else "(?:\\b(?:open|in|the|use|using|launch|from|to|tap|start|into|with)\\s+)" + Regex.escape(ln) + "(?![\\w])|(?<![\\w])" + Regex.escape(ln) + "\\s+app\\b"
                Regex(rx).find(low)
            } ?: continue
            val l = m.value.length
            if (m.range.first < at || (m.range.first == at && l > len)) { best = n to p; at = m.range.first; len = l }
        }
        if (best == null && callWords.containsMatchIn(low)) best = apps.firstOrNull { it.first.equals("phone", true) }   // "Make a call to Mum"
        return best
    }

    // Very short requests open an app at once ("weather", "set an alarm"). Never when another app is named or something
    // is being sent ("send a photo from my gallery on WhatsApp"), never for how/why/what questions or problems.
    private val quick = listOf(
        listOf("weather", "forecast", "will it rain") to listOf("weather"),
        listOf("alarm", "timer", "stopwatch") to listOf("clock"),
        listOf("calculator", "calculate") to listOf("calculator"),
        listOf("take a photo", "take a picture", "take a selfie", "camera") to listOf("camera"),
        listOf("gallery", "my pictures", "my photos") to listOf("gallery", "photos"),
        listOf("calendar") to listOf("calendar"),
        listOf("directions", "maps") to listOf("maps"))
    fun quickTarget(text: String, appLabels: List<String>): List<String>? {
        val w = words(text)
        if (w.trim().split(" ").size > 7 || isProblem(text) || isMoney(text)) return null
        if (listOf("how", "why", "what", "where", "can", "could").any { w.startsWith(" $it ") }) return null
        if (Regex("\\b(send|share|upload|post|attach|forward|delete|edit)\\b").containsMatchIn(w)) return null
        if (appLabels.any { a -> a.length >= 3 && a.lowercase() !in plainNames && has(w, a) }) return null   // another app is named
        return quick.firstOrNull { (terms, _) -> terms.any { has(w, it) } }?.second
    }

    // "open X", "find X", "where is X": the launcher app it names, or null. "find my phone" is the device, not an app.
    fun findTarget(text: String, appLabels: List<String>): String? {
        val t = text.trim().lowercase().trimEnd('?', '.', '!')
        for (p in listOf("open ", "find ", "where is ", "where's ", "launch ", "go to ", "start ")) {
            if (!t.startsWith(p)) continue
            val rest = t.removePrefix(p).trim()
            if (rest.split(Regex("\\s+")).size > 3) return null
            val bare = rest.removePrefix("the ").removePrefix("my ").removeSuffix(" app").trim()
            if (bare == "phone" && !rest.endsWith(" app") && !(p == "open " && !rest.startsWith("my "))) return null
            val n = norm(bare)
            if (n.length < 3) return null
            return appLabels.firstOrNull { norm(it) == n } ?: appLabels.firstOrNull { norm(it).startsWith(n) }
        }
        return null
    }
}
