package zm.screenguide

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.speech.RecognizerIntent
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.*

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

// A small chat that opens over the app the person is stuck in. They tap a reason or explain in their own words.
class HelpActivity : Activity() {
    private lateinit var log: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var showBtn: TextView
    private var lastLabel: String? = null
    private var lastSay = ""

    private val dark: Boolean get() = when (Profile.str(this, "theme", "auto")) {
        "light" -> false; "dark" -> true
        else -> (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    }
    private val bgc: Int get() = if (dark) 0xFF14181B.toInt() else Color.WHITE
    private val ink: Int get() = if (dark) 0xFFF2F4F5.toInt() else 0xFF1F1A14.toInt()
    private val accent: Int get() = if (dark) 0xFF18C3DA.toInt() else 0xFF145A3D.toInt()
    private val onAccent: Int get() = if (dark) 0xFF06262C.toInt() else Color.WHITE
    private val soft: Int get() = if (dark) 0xFF1E2428.toInt() else 0xFFF1EADD.toInt()
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun box(c: Int, r: Int) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat() }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.setGravity(Gravity.BOTTOM)
        window.setLayout(MATCH, WRAP)
        window.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))   // no white corners behind the panel
        setFinishOnTouchOutside(true)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(8), dp(14))
            background = GradientDrawable().apply { setColor(bgc); val r = dp(24).toFloat(); cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f) }
        }
        // Title with a close button, like every panel in the app.
        root.addView(LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; setPadding(0, 0, 0, dp(4))
            addView(TextView(context).apply {
                text = "Tell me what is wrong"; textSize = 20f; typeface = Typeface.DEFAULT_BOLD; setTextColor(ink)
                layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
            })
            addView(IconView(context, "close", ink).apply {
                setPadding(dp(13), dp(13), dp(13), dp(13)); contentDescription = "Close"; isClickable = true
                background = GradientDrawable().apply { setColor(soft); shape = GradientDrawable.OVAL }
                layoutParams = LinearLayout.LayoutParams(dp(44), dp(44)); setOnClickListener { finish() }
            })
        })
        val inner = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 0, dp(8), 0) }
        root.addView(inner)

        // The common reasons, all visible at once: two rows of two.
        listOf("I can\u2019t find it", "Nothing happened", "It looks different", "I don\u2019t understand").chunked(2).forEach { pair ->
            inner.addView(LinearLayout(this).apply {
                layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(8) }
                pair.forEachIndexed { i, r ->
                    addView(TextView(context).apply {
                        text = r; textSize = 14.5f; setTextColor(accent); typeface = Typeface.DEFAULT_BOLD
                        background = box(soft, 20); setPadding(dp(10), dp(10), dp(10), dp(10)); minHeight = dp(48); gravity = Gravity.CENTER
                        layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f).apply { if (i == 0) rightMargin = dp(8) }
                        setOnClickListener { send(r) }
                    })
                }
            })
        }

        log = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(6), 0, dp(6)) }
        scroll = ScrollView(this).apply { addView(log); layoutParams = LinearLayout.LayoutParams(MATCH, dp(200)) }
        inner.addView(scroll)
        bubble("I am looking at your screen. Tap a reason, or tell me in your own words.", false)

        showBtn = TextView(this).apply {
            text = "Show me"; textSize = 17f; setTextColor(onAccent); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            background = box(accent, 26); setPadding(dp(20), dp(14), dp(20), dp(14)); visibility = View.GONE
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(8) }
            setOnClickListener { Guides.adopt(lastLabel, lastSay, Guides.lang); finish() }   // the instruction moves to the screen card
        }
        inner.addView(showBtn)

        input = EditText(this).apply {
            hint = "Type what is wrong"; setSingleLine(true); imeOptions = EditorInfo.IME_ACTION_SEND; textSize = 16f
            setTextColor(ink); setHintTextColor(if (dark) 0xFFADB5BA.toInt() else 0xFF534C45.toInt())
            background = box(soft, 24); setPadding(dp(16), 0, dp(12), 0); minHeight = dp(48)   // a rounded box, like the main chat
            layoutParams = LinearLayout.LayoutParams(0, dp(48), 1f)
            setOnEditorActionListener { v, _, _ -> send(v.text.toString()); true }
        }
        val mic = IconView(this, "mic", ink).apply {
            setPadding(dp(13), dp(13), dp(13), dp(13)); background = GradientDrawable().apply { setColor(soft); shape = GradientDrawable.OVAL }
            layoutParams = LinearLayout.LayoutParams(dp(48), dp(48)).apply { leftMargin = dp(6) }
            contentDescription = "Speak"; isClickable = true; setOnClickListener { listen() }
        }
        val sendBtn = TextView(this).apply {
            text = "Send"; textSize = 16f; setTextColor(onAccent); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            background = box(accent, 24); setPadding(dp(18), 0, dp(18), 0)
            layoutParams = LinearLayout.LayoutParams(WRAP, dp(48)).apply { leftMargin = dp(6) }
            setOnClickListener { send(input.text.toString()) }
        }
        inner.addView(LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; addView(input); addView(mic); addView(sendBtn) })
        setContentView(root)
    }

    // While this panel is open the on-screen guide hides its ring, cards and buttons, so nothing covers it.
    override fun onResume() { super.onResume(); Guides.chatOpen = true }
    override fun onPause() { Guides.chatOpen = false; super.onPause() }

    private fun bubble(text: String, mine: Boolean): TextView {
        val t = TextView(this).apply {
            this.text = text; textSize = 16f; setTextColor(if (mine) onAccent else ink)
            background = box(if (mine) accent else soft, 18); setPadding(dp(14), dp(10), dp(14), dp(10))
            layoutParams = LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(8); gravity = if (mine) Gravity.END else Gravity.START }
        }
        log.addView(t)
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        return t
    }

    private fun send(note: String) {
        val n = note.trim()
        if (n.isEmpty()) return
        bubble(n, true); input.setText(""); showBtn.visibility = View.GONE
        val thinking = bubble("Thinking\u2026", false)
        val id = Server.installId(this)
        Thread {
            val r = Server.next(Guides.chatGoal, Guides.lang, id, Guides.chatLabels, Guides.chatHistory, true, emptyList(), n)
            runOnUiThread {
                thinking.text = r.say.ifBlank { "I am not sure. Tell me more." }
                lastLabel = r.label; lastSay = r.say
                if (r.ok) Guides.chatHistory = Guides.chatHistory + ("User said: " + n) + ("Told: " + r.say)
                showBtn.text = if (r.label != null) "Show me" else "OK, I\u2019ll try that"
                showBtn.visibility = if (r.ok && r.say.isNotBlank()) View.VISIBLE else View.GONE
                if (!r.ok) { lastLabel = null; lastSay = ""; thinking.text = r.say + " Tap a reason to try again." }
                scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
            }
        }.start()
    }

    private fun listen() {
        try {
            startActivityForResult(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM), 11)
        } catch (e: ActivityNotFoundException) { Toast.makeText(this, "Voice input is not available on this phone", Toast.LENGTH_LONG).show() }
    }

    override fun onActivityResult(rc: Int, res: Int, data: Intent?) {
        super.onActivityResult(rc, res, data)
        if (rc == 11 && res == RESULT_OK) data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let { send(it) }
    }
}
