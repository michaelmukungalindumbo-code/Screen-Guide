package zm.screenguide

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class Msg(val mine: Boolean, val text: String, val goal: String? = null, val needsApps: Boolean = false)
class Conv(val id: Long, val title: String, val msgs: ArrayList<Msg>)

// Chats are saved only on this phone. Incognito chats are never saved.
object ChatStore {
    private fun prefs(c: Context) = c.getSharedPreferences("chats", Context.MODE_PRIVATE)

    fun load(c: Context): ArrayList<Conv> {
        val out = ArrayList<Conv>()
        try {
            val arr = JSONArray(prefs(c).getString("all", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val a = o.getJSONArray("m")
                val ms = ArrayList<Msg>()
                for (j in 0 until a.length()) {
                    val x = a.getJSONObject(j)
                    ms.add(Msg(x.getBoolean("me"), x.getString("t"), x.optString("g").ifEmpty { null }, x.optBoolean("a")))
                }
                out.add(Conv(o.getLong("id"), o.getString("title"), ms))
            }
        } catch (e: Exception) {}
        return out
    }

    fun save(c: Context, all: List<Conv>) {
        val arr = JSONArray()
        all.takeLast(30).forEach { cv ->
            val a = JSONArray()
            cv.msgs.forEach { m -> a.put(JSONObject().put("me", m.mine).put("t", m.text).put("g", m.goal ?: "").put("a", m.needsApps)) }
            arr.put(JSONObject().put("id", cv.id).put("title", cv.title).put("m", a))
        }
        prefs(c).edit().putString("all", arr.toString()).apply()
    }

    fun clear(c: Context) { prefs(c).edit().clear().apply() }
}
