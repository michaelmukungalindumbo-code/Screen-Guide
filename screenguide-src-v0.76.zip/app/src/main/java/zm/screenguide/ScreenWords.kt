package zm.screenguide

// The tag after each screen word that goes to the server, so the AI knows what the word is. The phone reads the screen;
// the deciding is here, so it can be tested.
// [switch] its row has an on/off switch; [selected] a tab already chosen; [tap] can be tapped; [text] plain text;
// [typing] a text box that is open, with the keyboard up. 5 Nov: in the Play Store the search box read the same before
// and after it was tapped ("Search apps & games [tap]"), so the guide said "tap the search box" again and again.
object ScreenWords {
    fun tag(switch: Boolean, selected: Boolean, short: Boolean, tappable: Boolean, editable: Boolean, focused: Boolean): String = when {
        switch -> "[switch]"
        selected && short && tappable -> "[selected]"
        tappable -> "[tap]"
        else -> "[text]"
    }
}
