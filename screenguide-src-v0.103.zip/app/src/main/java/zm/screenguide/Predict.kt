package zm.screenguide

// tests first: not built yet
object Predict {
    class Task(val kind: String, val label: String, val id: String, val name: String = "")
    const val HINT = ""
    fun of(text: String, guides: List<Guide>, apps: List<Pair<String, String>>, lang: String = "en"): Task? = Task("x", "x", "x")
}
