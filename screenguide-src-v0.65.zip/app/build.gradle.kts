plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "zm.screenguide"
    compileSdk = 36   // Google Play: new apps and updates must target Android 16 (API 36) from 31 August 2026
    defaultConfig {
        applicationId = "zm.screenguide"
        minSdk = 24
        targetSdk = 36
        versionCode = 65
        versionName = "0.65"
        // ScreensTest: ScreenGuide's own screens opened on a small phone in GitHub's emulator (the "Screens" check)
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    // Android's bug finder, on every build. Only bugs that crash or break some phones fail the build: using something
    // newer than Android 7 without checking, a missing permission, the wrong thread, settings never saved.
    lint {
        checkOnly.addAll(listOf("NewApi", "InlinedApi", "MissingPermission", "WrongThread", "CommitPrefEdits", "WrongConstant", "Range",
            "ResourceType", "UnspecifiedRegisterReceiverFlag", "ProtectedPermissions", "ExportedService"))
        abortOnError = true
        warningsAsErrors = false
        checkReleaseBuilds = false
        textReport = true
        textOutput = file("stdout")
    }
}
kotlin { compilerOptions { jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17) } }

// Sign in with Google (Android's Credential Manager). Only used when the person chooses to sign in.
dependencies {
    implementation("androidx.credentials:credentials:1.3.0")
    implementation("androidx.credentials:credentials-play-services-auth:1.3.0")
    implementation("com.google.android.libraries.identity.googleid:googleid:1.1.1")
    // MatchTest: real questions must pick the right action (run on every GitHub build)
    testImplementation("junit:junit:4.13.2")
    // Real org.json for plain JVM tests (Android's own copy is only an empty stub there). Tests only, not in the app.
    testImplementation("org.json:json:20240303")
    // ScreensTest only (GitHub's emulator), not in the app
    androidTestImplementation("androidx.test:runner:1.6.2")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.test.uiautomator:uiautomator:2.3.0")
}
