package zm.screenguide

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

// v0.104, the owner (10 Nov): "Work on the voice, I want it to sound natural or at least like yours."
class SpeechTest {
    private fun src(n: String) = listOf("src/main/java/zm/screenguide/$n", "app/src/main/java/zm/screenguide/$n").map { File(it) }.first { it.exists() }.readText()
    private fun v(name: String, lang: String, country: String, q: Int, net: Boolean = false, missing: Boolean = false) = Speech.V(name, lang, country, q, net, missing)

    // Of the voices on the phone: the most natural one that needs no internet
    @Test fun theMostNaturalVoiceOnThePhone() {
        val voices = listOf(v("en-us-x-basic", "en", "US", 300), v("en-gb-x-rjs-local", "en", "GB", 400), v("en-us-x-tpf-local", "en", "US", 400),
            v("en-us-x-sfg-network", "en", "US", 500, net = true), v("en-au-x-fine", "en", "AU", 500, missing = true), v("fr-fr-x-best", "fr", "FR", 500))
        assertEquals("en-gb-x-rjs-local", Speech.best(voices, "en")!!.name)             // natural, on the phone; British before American
        assertEquals("en-us-x-tpf-local", Speech.best(voices, "en", "US")!!.name)       // the phone's own country first
        assertEquals("fr-fr-x-best", Speech.best(voices, "fr")!!.name)
        assertNull(Speech.best(voices, "bem"))                                           // no Bemba voice: English is used, as before
        assertEquals("en-us-x-basic", Speech.best(listOf(voices[0], voices[3], voices[4]), "en")!!.name)   // never one that needs the internet
        assertNull(Speech.best(emptyList(), "en"))
        assertTrue(Speech.natural(400)); assertTrue(Speech.natural(500)); assertFalse(Speech.natural(300))
    }

    // A calmer pace, and a breath between sentences
    @Test fun calmerWithPauses() {
        assertEquals(0.92f, Speech.pace(1.0f), 0.001f); assertTrue(Speech.pace(0.8f) < 0.8f)
        assertEquals(listOf("Tap “Settings”.", "Then scroll down to find “Font size”."),
            Speech.sentences("Tap “Settings”. Then scroll down to find “Font size”."))
        assertEquals(listOf("Not on this screen?", "Swipe up to find it."), Speech.sentences("Not on this screen?  Swipe up to find it."))
        assertEquals(1, Speech.sentences("Tap the video, e.g. the one that says 0:14 on it.").size)   // not sentence ends
        assertEquals(listOf("Tap Wi-Fi"), Speech.sentences("  Tap Wi-Fi  "))
        assertTrue(Speech.sentences("").isEmpty())
        assertTrue(Speech.PAUSE_MS in 150L..500L)
    }

    // Settings: which voice the phone has, and how to get a natural one where it only has a basic one
    @Test fun theNoteInSettings() {
        assertEquals("Basic", Speech.label(300)); assertEquals("Natural", Speech.label(400)); assertEquals("Not checked yet", Speech.label(-1))
        assertTrue(Speech.note(300).contains("can sound like a robot") && Speech.note(300).contains("Install voice data"))
        assertTrue(Speech.note(300).contains("uses data"))                                // said before any download
        assertEquals(Speech.NOTE_NATURAL, Speech.note(500)); assertEquals(Speech.NOTE_UNKNOWN, Speech.note(-1))
        val m = src("MainActivity.kt")
        assertTrue(m.contains("Row(\"speaker\", \"Voice\", Speech.label(getSharedPreferences(\"sg\", MODE_PRIVATE).getInt(\"voice_quality\", -1))) { showVoiceNote() }"))
        assertTrue(m.contains("Intent(\"com.android.settings.TTS_SETTINGS\")"))
    }

    @Test fun theWiringIsThere() {
        val g = src("GuideService.kt")
        assertTrue(g.contains("tts = Speech.create(this) { ok, google ->"))                // v0.106: and the phone's own engine if Google's does not start
        assertTrue(g.contains("if (ok || !google) ttsReady = ok"))
        val say = g.substringAfter("    private fun say(texts: Map<String, String>) {").substringBefore("\n    }\n")
        assertTrue(say.indexOf("playVoice(l, msg)") in 1 until say.indexOf("Speech.tune(this, t, l)"))   // a person's recorded voice still comes first
        assertTrue(say.contains("Speech.say(t, msg, \"sg\")"))
        assertFalse(g.contains("setSpeechRate(Profile.speechRate(")); assertFalse(src("MainActivity.kt").contains("setSpeechRate(Profile.speechRate("))
        val s = src("Speech.kt")
        assertTrue(s.contains("t.setSpeechRate(pace(Profile.speechRate(c)))"))            // the person's Slow or Normal still counts
        assertTrue(s.contains("t.playSilentUtterance(PAUSE_MS, TextToSpeech.QUEUE_ADD"))
        assertFalse(s.contains("http")); assertFalse(s.contains("Server."))               // nothing spoken leaves the phone
    }
}
