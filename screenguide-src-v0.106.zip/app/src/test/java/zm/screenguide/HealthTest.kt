package zm.screenguide

import java.io.File
import java.util.Collections
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

// v0.106, the owner (11 Nov): "Review the app for crashes, slowness and memory use on Android 7, low-end phones (Tecno,
// Infinix, itel) and my Samsung tablet. Fix the top problems; list the rest." The three fixed here.
class HealthTest {
    private fun src(n: String) = listOf("src/main/java/zm/screenguide/$n", "app/src/main/java/zm/screenguide/$n").map { File(it) }.first { it.exists() }.readText()

    // 1. Saving the chat (locking it with the phone's key store) ran on the screen's own thread at every Send: a cheap
    // phone stuck for a moment. One background worker now does it, in the order it was asked, so the last save wins.
    @Test fun chatsAreSavedInOrderOffTheScreen() {
        val done = Collections.synchronizedList(ArrayList<Int>())
        for (i in 0 until 200) InOrder.run { if (i == 50) throw IllegalStateException("one bad save"); done.add(i) }
        assertTrue(InOrder.settle())
        assertEquals((0 until 200).filter { it != 50 }, done.toList())                     // in order; a failed one stops nothing
        val ran = arrayOfNulls<String>(1); InOrder.run { ran[0] = Thread.currentThread().name }; InOrder.settle()
        assertEquals("sg-save", ran[0])                                                     // not the caller's thread
        val store = src("ChatStore.kt")
        val save = store.substringAfter("    fun save(c: Context, all: List<Conv>) {").substringBefore("\n    }\n")
        assertTrue(save.indexOf("val text = write(all)") in 0 until save.indexOf("InOrder.run {"))   // what was on the screen is what is saved
        assertTrue(save.contains("InOrder.run { prefs(app).edit().putString(\"all\", Vault.seal(text) ?: text).apply() }"))   // still locked
    }

    // 2. The natural voice (0.104) asks for Google's speech engine. Where that is on the phone but turned off, or does not
    // start, there would have been no voice at all: the phone's own engine is used instead.
    @Test fun aVoiceEvenWithoutGooglesEngine() {
        assertEquals(Speech.GOOGLE, Speech.pickEngine(installed = true, enabled = true))
        assertNull(Speech.pickEngine(installed = true, enabled = false)); assertNull(Speech.pickEngine(installed = false, enabled = false))
        assertTrue(src("GuideService.kt").contains("tts = Speech.fallback(this) { ttsReady = it }"))
        assertTrue(src("MainActivity.kt").contains("tts = Speech.fallback(this) {"))
        assertTrue(src("Speech.kt").contains("getApplicationInfo(GOOGLE, 0).enabled"))
    }

    // 3. Task prediction (0.103) read every app's name from the phone on the screen's own thread while typing: slow on a
    // cheap phone with many apps. It is read in the background; typing never waits for it.
    @Test fun typingNeverWaitsForTheAppList() {
        val m = src("MainActivity.kt")
        val apps = m.substringAfter("    private fun predictApps(): List<Pair<String, String>> {").substringBefore("\n    }\n")
        assertTrue(apps.indexOf("Thread {") in 0 until apps.indexOf("Guides.launcherApps(applicationContext)"))
        assertEquals(1, Regex("Guides\\.launcherApps\\(").findAll(apps).count())
        assertTrue(apps.contains("rePredict?.invoke(it)"))                                  // the button appears once the list is in
        assertTrue(apps.trimEnd().endsWith("return appsList"))                              // what it has now, at once
    }
}
