package zm.screenguide

// v0.105 (the owner, 11 Nov: "even the tablet has issues"): on a tablet, above all turned on its side, the chat ran from
// edge to edge (lines too long to read, buttons stretched) and the guide card was almost as wide as the screen. Words keep
// a width people can read; on a phone nothing changes. Plain functions (pixels in, pixels out), so a unit test can check.
object Wide {
    const val READ_DP = 640    // the chat's widest column
    const val CARD_DP = 520    // the guide card's widest
    // The guide card: 90% of a phone's screen as before, never wider than CARD_DP
    fun card(widthPx: Int, density: Float, share: Float = 0.9f) = minOf((widthPx * share).toInt(), (CARD_DP * density).toInt())
    // The space at each side of the chat: the usual one on a phone, more on a wide screen so the column stays READ_DP
    fun side(widthPx: Int, density: Float, usualDp: Int) = maxOf((usualDp * density).toInt(), ((widthPx - READ_DP * density) / 2).toInt())
    // The widest a message bubble gets: 80% of the column
    fun bubble(widthPx: Int, density: Float) = (minOf(widthPx.toFloat(), READ_DP * density) * 0.8f).toInt()
}
