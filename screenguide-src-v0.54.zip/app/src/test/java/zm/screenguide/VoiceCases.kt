package zm.screenguide

// Which recorded line plays for an instruction, and which button name the phone reads after it.
object VoiceCases {
    fun failures(): List<String> {
        val bad = ArrayList<String>()
        val all: (String) -> Boolean = { true }
        fun check(lang: String, text: String, want: Pair<String, String?>?, has: (String) -> Boolean = all) {
            val got = Voices.matchText(lang, text, has)
            if (got != want) bad.add("$lang \"$text\": got $got, want $want")
        }
        check("bem", "Kandeni “Create new”.", "tap" to "Create new")
        check("ny", "Dinani “Settings”.", "tap" to "Settings")
        check("en", "Tap Settings.", "tap" to "Settings")                      // built-in guides have no quotes
        check("bem", "Kandeni Network & internet.", "tap" to "Network & internet")
        check("bem", "Kandeni ukupyunga Wi-Fi.", null)                          // a Bemba sentence, not a button name
        check("en", "Tap the glowing row.", null)
        check("en", "Tap here.", "tap_here" to null)
        check("bem", "Kandeni apa.", "tap_here" to null)
        check("en", "Tap the switch for “Use Data Saver”.", "switch" to "Use Data Saver")
        check("bem", "Ikeni pansi pa kusanga “Storage”.", "scroll" to "Storage")
        check("ny", "Zabwino!", "well_done" to null)
        check("bem", "nawamya", "well_done" to null)                           // spacing and marks do not matter
        check("en", "Swipe down from the top right corner of the screen.", "pull_right" to null)
        check("bem", "Kandeni “Create new”.", null) { it != "tap" }   // not recorded yet: the phone reads it all
        check("en", "Tapping is fun.", null)
        check("en", "Well done! Drive is open.", null)                         // more than the recording says
        return bad
    }
}
