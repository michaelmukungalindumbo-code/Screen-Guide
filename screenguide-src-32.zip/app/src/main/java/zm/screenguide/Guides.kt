package zm.screenguide

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class Step(val match: List<String>, val say: Map<String, String>, val audio: String?, val toggle: Boolean = false, val skipIn: String? = null, val titles: List<String>? = null)
class Guide(val id: String, val title: Map<String, String>, val done: Map<String, String>, val steps: List<Step>, val keywords: List<String>, val doneWhen: String? = null, val hint: Map<String, String>? = null, val by: String? = null)

object Guides {
    var all: List<Guide> = emptyList()
    var active: Guide? = null
    var index = 0
    var lang = "en"
    fun setLang(c: Context, l: String) { lang = l; c.getSharedPreferences("sg", Context.MODE_PRIVATE).edit().putString("lang", l).apply() }
    var lastSeen = ""
    // Smart guide: the AI picks the next button from the words on screen.
    var aiGoal = ""
    var aiStep: Step? = null
    var aiAsked = 0
    var aiFp = 0
    var aiStuck = false
    var aiNeedsApps = false
    var aiPlan: List<String> = emptyList()
    var aiThinking = false
    // What the "Tell me why" chat needs to know about the screen the person is stuck on.
    var chatLabels: List<String> = emptyList()
    var chatGoal = ""
    var chatHistory: List<String> = emptyList()
    var chatPkg = ""
    var chatSet: Set<String> = emptySet()
    var aiPkg = ""
    var aiLabels: Set<String> = emptySet()
    var aiLast = 0L
    var aiBusy = false
    val aiHistory = ArrayList<String>()
    // The app the task happens in. Getting into it is done like a built-in guide: no AI, no waiting.
    var aiApp: String? = null
    var aiAppPkg: String? = null
    var aiJustOpen = false
    var aiInApp = false
    // The buttons the person really tapped, in order. Saved when the task is done, so next time it runs like a built-in guide.
    val aiTrail = ArrayList<Step>()
    fun aiReset(goal: String) {
        aiGoal = goal; aiStep = null; aiAsked = 0; aiFp = 0; aiStuck = false; aiThinking = false; aiPlan = emptyList(); aiPkg = ""
        aiLabels = emptySet(); aiLast = 0L; aiBusy = false; aiHistory.clear()
        aiApp = null; aiAppPkg = null; aiJustOpen = false; aiInApp = false; aiTrail.clear()
    }

    // Banking, money and wallet apps: ScreenGuide never works in them and never sends their names.
    val blockedApps = listOf("momo", "airtel", "mtn", "bank", "zanaco", "fnb", "stanbic", "absa", "finance", "wallet", "pay", "money",
        "binance", "paypal", "credit", "loan", "cash")

    private val filler = setOf("open", "opening", "use", "using", "start", "launch", "find", "go", "to", "the", "a", "an", "app", "application",
        "i", "want", "need", "it", "this", "that", "my", "on", "please", "how", "do", "can", "me", "show", "where", "is", "get", "into", "in")

    // The installed app a goal is about ("Open the YouTube app", "I want to use it (about: What is YouTube...)"),
    // as (name, package, just open it?). The earliest name mentioned wins, so the person's own words beat the helper's.
    fun appFor(c: Context, goal: String): Triple<String, String, Boolean>? {
        val pm = c.packageManager
        val apps = try {
            pm.queryIntentActivities(android.content.Intent(android.content.Intent.ACTION_MAIN).addCategory(android.content.Intent.CATEGORY_LAUNCHER), 0)
                .map { it.loadLabel(pm).toString().trim() to it.activityInfo.packageName }
                .filter { (n, p) -> n.length >= 3 && blockedApps.none { b -> p.contains(b, true) || n.contains(b, true) } && p != c.packageName }
        } catch (e: Exception) { return null }
        val low = goal.lowercase()
        var best: Pair<String, String>? = null; var at = Int.MAX_VALUE
        for ((n, p) in apps) {
            val m = Regex("(?<![\\w])" + Regex.escape(n.lowercase()) + "(?![\\w])").find(low) ?: continue
            if (m.range.first < at || (m.range.first == at && n.length > (best?.first?.length ?: 0))) { best = n to p; at = m.range.first }
        }
        val (name, pkg) = best ?: return null
        val base = goal.substringBefore("(about:").lowercase()
        val nameWords = name.lowercase().split(Regex("\\W+")).toSet()
        val rest = base.split(Regex("\\W+")).filter { it.isNotBlank() && it !in filler && it !in nameWords }
        return Triple(name, pkg, rest.isEmpty())
    }
    // The chat found a next step: continue the guide from it (built-in guides become Smart guides).
    fun adopt(label: String?, say: String, lang: String) {
        val g = active ?: return
        if (g.id != "ai") { aiReset(chatGoal); active = Guide("ai", g.title, g.done, emptyList(), emptyList()) }
        aiStep = Step(if (label != null) listOf(label) else emptyList(), mapOf(lang to say), null)
        if (!aiInApp) aiApp = null   // the chat's answer takes over from the app-finding stage
        aiPkg = chatPkg; aiLabels = chatSet; aiLast = System.currentTimeMillis(); aiBusy = false; aiThinking = false
    }
    val seen = LinkedHashMap<String, String>()   // last screen text per app, for the debug copy

    fun step(): Step? = active?.steps?.getOrNull(index)

    private fun map(o: JSONObject) = o.keys().asSequence().associateWith { o.getString(it) }
    private fun strings(a: JSONArray?) = if (a == null) emptyList() else (0 until a.length()).map { a.getString(it) }

    private var builtIn: List<Guide> = emptyList()

    // A broken guide is skipped, never allowed to crash the app.
    private fun parse(arr: JSONArray): List<Guide> = (0 until arr.length()).mapNotNull { i ->
        try {
            val g = arr.getJSONObject(i)
            val st = g.getJSONArray("steps")
            val steps = (0 until st.length()).map { j ->
                val o = st.getJSONObject(j)
                Step(strings(o.getJSONArray("match")), map(o.getJSONObject("say")), o.optString("audio").ifEmpty { null }, o.optBoolean("toggle"), o.optString("skipIn").ifEmpty { null }, o.optJSONArray("titles")?.let { strings(it) })
            }
            if (steps.isEmpty()) null
            else Guide(g.getString("id"), map(g.getJSONObject("title")), map(g.getJSONObject("done")), steps, strings(g.optJSONArray("keywords")),
                g.optString("doneWhen").ifEmpty { null }, null, g.optString("by").ifEmpty { null })
        } catch (e: Exception) { null }
    }

    fun load(c: Context) {
        lang = c.getSharedPreferences("sg", Context.MODE_PRIVATE).getString("lang", lang) ?: lang   // remembered between visits
        if (all.isNotEmpty()) return
        builtIn = parse(JSONArray(c.assets.open("guides.json").bufferedReader().readText()))
        all = builtIn
        c.getSharedPreferences("sg", Context.MODE_PRIVATE).getString("remote_guides", null)?.let { merge(it) }
    }

    // Guides from the server replace built-in ones with the same id, or are added after them.
    private fun merge(text: String): Boolean = try {
        val t = text.trim()
        val arr = if (t.startsWith("[")) JSONArray(t) else JSONObject(t).optJSONArray("guides") ?: JSONArray()
        val remote = parse(arr)
        if (remote.isEmpty()) false
        else {
            val byId = LinkedHashMap<String, Guide>()
            builtIn.forEach { byId[it.id] = it }
            remote.forEach { byId[it.id] = it }
            all = byId.values.toList()
            true
        }
    } catch (e: Exception) { false }

    fun applyRemote(c: Context, text: String): Boolean {
        val prefs = c.getSharedPreferences("sg", Context.MODE_PRIVATE)
        if (prefs.getString("remote_guides", null) == text) return false
        if (!merge(text)) return false
        prefs.edit().putString("remote_guides", text).apply()
        return true
    }
}

// Tasks this phone has learned: when a Smart guide finishes, the buttons the person tapped are saved here (on this
// phone only), and the same task next time runs like a built-in guide: instant, numbered, a ring on every step.
object Recipes {
    private fun prefs(c: Context) = c.getSharedPreferences("recipes", Context.MODE_PRIVATE)
    private val skip = setOf("the", "a", "an", "my", "i", "want", "to", "how", "do", "please", "app", "it", "on", "in")

    fun key(goal: String): String =
        goal.substringBefore("(about:").lowercase().split(Regex("\\W+")).filter { it.isNotBlank() && it !in skip }.sorted().joinToString(" ")

    private fun all(c: Context): JSONArray = try { JSONArray(prefs(c).getString("all", "[]")) } catch (e: Exception) { JSONArray() }

    fun save(c: Context, goal: String, steps: List<Step>, lastIsSwitch: Boolean) {
        val k = key(goal)
        if (k.isEmpty() || steps.isEmpty()) return
        val keep = JSONArray()
        val old = all(c)
        for (i in 0 until old.length()) old.optJSONObject(i)?.let { if (it.optString("k") != k) keep.put(it) }
        val arr = JSONArray()
        steps.forEach { st -> arr.put(JSONObject().put("m", JSONArray(st.match)).put("s", JSONObject(st.say))) }
        keep.put(JSONObject().put("k", k).put("t", goal.substringBefore("(about:").trim().take(60)).put("st", arr).put("sw", lastIsSwitch))
        val trimmed = JSONArray()
        for (i in maxOf(0, keep.length() - 30) until keep.length()) trimmed.put(keep.get(i))
        prefs(c).edit().putString("all", trimmed.toString()).apply()
    }

    private fun guideOf(o: JSONObject): Guide? {
        val st = o.optJSONArray("st") ?: return null
        val steps = ArrayList<Step>()
        for (i in 0 until st.length()) {
            val x = st.optJSONObject(i) ?: continue
            val m = x.optJSONArray("m") ?: continue
            val say = x.optJSONObject("s") ?: continue
            val last = i == st.length() - 1
            steps.add(Step((0 until m.length()).map { m.getString(it) }, say.keys().asSequence().associateWith { say.getString(it) }, null,
                toggle = last && o.optBoolean("sw")))
        }
        if (steps.isEmpty()) return null
        val title = o.optString("t")
        return Guide("learned", mapOf("en" to title), mapOf("en" to "Well done!", "ny" to "Zabwino!", "bem" to "Nawamya!"), steps, emptyList(),
            doneWhen = "last_tap")
    }

    fun find(c: Context, goal: String): Guide? {
        val k = key(goal); if (k.isEmpty()) return null
        val a = all(c)
        for (i in a.length() - 1 downTo 0) { val o = a.optJSONObject(i) ?: continue; if (o.optString("k") == k) return guideOf(o) }
        return null
    }

    fun recent(c: Context, n: Int): List<Guide> {
        val a = all(c); val out = ArrayList<Guide>()
        for (i in a.length() - 1 downTo 0) { if (out.size >= n) break; a.optJSONObject(i)?.let { guideOf(it) }?.let { out.add(it) } }
        return out
    }

    fun forget(c: Context, title: String) {
        val a = all(c); val keep = JSONArray()
        for (i in 0 until a.length()) a.optJSONObject(i)?.let { if (it.optString("t") != title) keep.put(it) }
        prefs(c).edit().putString("all", keep.toString()).apply()
    }
}

// Counters kept on the phone only, for the pilot. No screen words, no names.
object Stats {
    private fun prefs(c: android.content.Context) = c.getSharedPreferences("stats", android.content.Context.MODE_PRIVATE)
    fun inc(c: android.content.Context, key: String) { val p = prefs(c); p.edit().putInt(key, p.getInt(key, 0) + 1).apply() }
    // The last few questions that got a thumbs-down, on this phone only, so the pilot can show what to fix.
    fun remember(c: android.content.Context, key: String, text: String) {
        val p = prefs(c)
        val arr = try { JSONArray(p.getString("r_$key", "[]")) } catch (e: Exception) { JSONArray() }
        arr.put(text.take(80))
        val keep = JSONArray()
        for (i in maxOf(0, arr.length() - 8) until arr.length()) keep.put(arr.getString(i))
        p.edit().putString("r_$key", keep.toString()).apply()
    }
    fun dump(c: android.content.Context): String {
        val p = prefs(c)
        val counts = listOf("questions", "started", "finished", "stopped", "stuck", "ai_steps", "screen_pictures", "thumbs_up", "thumbs_down")
            .joinToString("\n") { "$it: ${p.getInt(it, 0)}" }
        val bad = try { JSONArray(p.getString("r_bad", "[]")) } catch (e: Exception) { JSONArray() }
        if (bad.length() == 0) return counts
        return counts + "\nRecent thumbs-down questions:\n" + (0 until bad.length()).joinToString("\n") { "- " + bad.getString(it) }
    }
}
