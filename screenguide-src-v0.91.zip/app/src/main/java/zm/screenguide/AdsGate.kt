package zm.screenguide

// v0.90 (the owner's choice, 7 Nov): rewarded ads. A free user who has used today's help may choose to watch a short ad
// for more: 5 more questions and 20 more guided steps for today, up to 3 ads a day (the server decides and counts).
// Only inside ScreenGuide, only when the person taps "Watch ad", never during a guide or over another app, never for Plus.
// Google's TEST ads until the owner's AdMob account and Play listing are ready. These are the rules, kept apart from
// Google's library so they can be tested.
object AdsGate {
    const val TEST_APP_ID = "ca-app-pub-3940256099942544~3347511713"   // Google's sample app: test ads only
    const val TEST_UNIT = "ca-app-pub-3940256099942544/5224354917"     // Google's sample rewarded ad: always a test ad
    const val DATA = "about 2 MB"
    const val DAY_MS = 24 * 3600_000L
    const val CLOSE_HINT = ""   // v0.91 tests first: not built yet

    enum class Result { WATCHED, CLOSED, NONE }

    // The free daily limit (not "wait a minute", not "the helper is very busy today")
    fun limited(code: Int, body: String): Boolean = code == 429 && body.contains("today's free")

    // Ads left today as last heard from the server, or -1 when not known (never heard, or more than a day ago)
    fun known(adsLeft: Int, at: Long, now: Long): Int = if (at <= 0L || now - at > DAY_MS) -1 else adsLeft

    fun offer(plus: Boolean, adsLeft: Int): Boolean = !plus && adsLeft != 0

    fun offerText(ask: Int, steps: Int): String =
        "Watch a short ad to get $ask more questions and $steps more guided steps for today.\n\n" +
        "The ad is a short video from Google and uses $DATA of data. ScreenGuide never shows ads during a guide."

    fun after(r: Result, claimOk: Boolean, left: Int, adsLeft: Int): String = when {
        r == Result.NONE -> "No ad is ready right now. Please check your internet and try again later."
        r == Result.CLOSED -> "The ad was closed before the end, so no extra help was added."
        !claimOk -> "Thank you for watching. The extra help starts working after the next ScreenGuide server update."
        left > 0 -> "Thank you! You have $left " + (if (left == 1) "question" else "questions") + " left today."
        adsLeft == 0 -> "You have watched today's ads. More help comes back tomorrow."
        else -> "Thank you! Your extra help will be ready in a minute."
    }
}
