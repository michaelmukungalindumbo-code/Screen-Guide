package zm.screenguide

import org.junit.Assert.assertTrue
import org.junit.Test

class TeachTest {
    @Test fun recordedStepsAreSafeAndFollowable() {
        val bad = TeachCases.failures()
        assertTrue(bad.joinToString("\n", "${bad.size} failed:\n"), bad.isEmpty())
    }
}
