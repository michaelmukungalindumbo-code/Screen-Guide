package zm.screenguide

import org.json.JSONObject
import java.net.HttpURLConnection

// Fill these two in after the server is deployed.
object Server {
    const val URL = "https://screen-guide-server.onrender.com/ask"
    const val TOKEN = "screenguide_sec_9841273560_xyz"

    val configured get() = !URL.contains("YOUR-SERVER")

    // The free host sleeps when idle. A quiet request on app start wakes it. Nothing personal is sent.
    fun wake() {
        if (!configured) return
        Thread { try { (java.net.URL(URL.removeSuffix("/ask") + "/health").openConnection() as HttpURLConnection).apply { connectTimeout = 10000; readTimeout = 60000 }.responseCode } catch (e: Exception) {} }.start()
    }

    // Returns (worked, text). Only the typed question and language are sent. Never anything from the screen.
    fun ask(question: String, lang: String, installId: String): Pair<Boolean, String> = try {
        val c = (java.net.URL(URL).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; connectTimeout = 15000; readTimeout = 60000; doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("X-App-Token", TOKEN)
            setRequestProperty("X-Install-Id", installId)
        }
        c.outputStream.use { it.write(JSONObject().put("question", question).put("lang", lang).toString().toByteArray()) }
        val code = c.responseCode
        val text = (if (code in 200..299) c.inputStream else c.errorStream).bufferedReader().readText()
        if (code in 200..299) Pair(true, JSONObject(text).getString("answer"))
        else Pair(false, JSONObject(text).optString("detail", "Sorry, I couldn\u2019t answer that. Please try again."))
    } catch (e: Exception) {
        Pair(false, "No connection. Please check your internet and try again.")
    }
}
