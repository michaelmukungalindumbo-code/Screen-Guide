package zm.screenguide

import java.io.File
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

// v0.127 (the owner's Infinix phone, 25 Nov): "How do I scan a document", then Show me. The guide was "Step 1 of 2: Tap
// Drive", "Step 2 of 2: Tap Scan Document", and "Well done!" the moment Drive's scanner opened, before any picture or
// upload. It was a task learned that morning from a Smart guide that the helper wrongly ended on the scanner (fixed on the
// server in 1.01). Learned tasks keep only the buttons tapped on screens ScreenGuide can read, so one that went through
// the scanner (no words at all) always stops where the scanner opens. Now such a guide is never kept as a learned task,
// and tasks learned before v0.127 are not used any more (they could be cut short the same way); the Smart guide learns
// them again. Tasks the person taught or was sent are kept and used as before.
class LearnedShortTest {
    @Test fun keptOnlyWhenEveryScreenCouldBeRead() {
        assertTrue(Recipes.keep(steps = 3, justOpen = false, firstIsTheApp = false, unseen = false))
        assertFalse(Recipes.keep(steps = 3, justOpen = false, firstIsTheApp = false, unseen = true))   // went through the scanner
        assertFalse(Recipes.keep(steps = 2, justOpen = false, firstIsTheApp = false, unseen = true))
        // As before: one step that only opens the app is not worth keeping
        assertTrue(Recipes.keep(steps = 1, justOpen = false, firstIsTheApp = false, unseen = false))
        assertFalse(Recipes.keep(steps = 1, justOpen = true, firstIsTheApp = false, unseen = false))
        assertFalse(Recipes.keep(steps = 1, justOpen = false, firstIsTheApp = true, unseen = false))
        assertFalse(Recipes.keep(steps = 0, justOpen = false, firstIsTheApp = false, unseen = false))
    }

    @Test fun oldLearnedTasksAreNotUsed() {
        assertFalse(Recipes.usable(by = "", v = 0))                      // learned by ScreenGuide before v0.127
        assertTrue(Recipes.usable(by = "", v = Recipes.LEARNED_V))         // learned from v0.127 on
        assertTrue(Recipes.usable(by = Recipes.ME, v = 0))                 // taught by the person: always
        assertTrue(Recipes.usable(by = Recipes.SHARED, v = 0))             // shared with them: always
        assertTrue(Recipes.LEARNED_V == 127)
    }

    @Test fun theWiringIsThere() {
        fun src(n: String) = listOf("src/main/java/zm/screenguide/$n", "app/src/main/java/zm/screenguide/$n").map { File(it) }.first { it.exists() }.readText()
        val g = src("GuideService.kt")
        // A step asked on a screen with no words marks this Smart guide
        assertTrue(g.contains("if (labels.isEmpty()) Guides.aiUnseen = true"))
        // Kept (here and on the server) only through Recipes.keep, which says no after such a screen
        val done = g.substringAfter("if (r.done) {").substringBefore("finish(Guide(guide.id")
        assertTrue(done.contains("Recipes.keep(trail.size, Guides.aiJustOpen, trail.firstOrNull()?.match?.firstOrNull() == Guides.aiApp, Guides.aiUnseen)"))
        assertTrue(done.indexOf("Recipes.keep(") < done.indexOf("Recipes.save(") && done.indexOf("Recipes.save(") < done.indexOf("Server.learned("))
        val gs = src("Guides.kt")
        assertTrue(gs.contains("aiUnseen = false"))                       // a new Smart guide starts afresh
        assertTrue(gs.contains(".put(\"v\", LEARNED_V)"))                  // saved with the version that may be used
        assertTrue(gs.contains("usable(o.optString(\"by\"), o.optInt(\"v\"))"))   // found only when usable
    }
}
