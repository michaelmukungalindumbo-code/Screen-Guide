package zm.screenguide

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

// v0.134 (the owner's Infinix, 26 Nov): "How do I share internet using my phone?" started "Turn on Hotspot" while the
// hotspot was already on (turned on with ScreenGuide a little earlier). On the first screen the card said at once "Well
// done! Hotspot is on. ... You have learned 8 of 13 phone skills", though he had done nothing.
// The cause: when a guide ended, the app still kept it as "the last guide". Starting the same task again was then not seen
// as a new start, so "was it already on when the guide began?" kept its answer from the run before (off). The hotspot was
// on, so the guide finished at once.
// Now every guide that starts is a new start, and a task that is already done when it starts says so plainly (English
// only: no new Nyanja or Bemba words) instead of "Well done!", and is not counted as a skill learned. Carrying on to
// "Tap the switch to turn Hotspot on" would be worse: that tap turns it off.
class AlreadyOnTest {
    @Test fun theWords() {
        assertEquals("Hotspot is already on. To connect a laptop, open the laptop’s Wi-Fi list and choose this phone’s name.",
            StepNav.alreadyOn("hotspot_on"))
        assertEquals("Wi-Fi is already on.", StepNav.alreadyOn("wifi_on"))
        assertEquals("The torch is already on.", StepNav.alreadyOn("torch_on"))
        assertEquals("Bluetooth is already on.", StepNav.alreadyOn("bluetooth_on"))
        assertEquals("Mobile data is already on.", StepNav.alreadyOn("mobile_data_on"))
        assertNull(StepNav.alreadyOn("last_tap"))       // a task that ends with a tap: as before
        assertNull(StepNav.alreadyOn("text_bigger"))    // "bigger than at the start": never already done
        assertNull(StepNav.alreadyOn(null))
    }

    // Every task in guides.json that checks the phone's own on/off state has its "already on" words
    @Test fun everyOnOffTaskHasWords() {
        val j = listOf("src/main/assets/guides.json", "app/src/main/assets/guides.json").map { File(it) }.first { it.exists() }.readText()
        val ends = Regex("\"doneWhen\"\\s*:\\s*\"([a-z_]+)\"").findAll(j).map { it.groupValues[1] }.toSet()
        for (d in ends - setOf("last_tap", "text_bigger")) assertTrue(d, StepNav.alreadyOn(d) != null)
    }

    private fun service() = listOf("src/main/java/zm/screenguide/GuideService.kt", "app/src/main/java/zm/screenguide/GuideService.kt")
        .map { File(it) }.first { it.exists() }.readText()

    @Test fun theSameTaskAgainIsANewStart() {
        val g = service()
        assertTrue(g.contains("val guide = Guides.active ?: run { lastGuide = null; watchPictures(false); hide(); hideControls(); return }"))
        assertTrue(g.contains("val guide = Guides.active ?: run { lastGuide = null; hide(); return }"))
        assertTrue(g.substringAfter("private fun finish(g: Guide) {").substringBefore("say(g.done)").contains("Guides.active = null; lastGuide = null;"))
    }

    @Test fun alreadyDoneSaysSoAndIsNotASkill() {
        val start = service().substringAfter("startDone = guide.id != \"ai\" && guide.doneWhen != null && isDone(guide)").substringBefore("// \"Find an app\" guide")
        assertTrue(start.contains("if (startDone) StepNav.alreadyOn(guide.doneWhen)?.let { t ->"))
        // id "already" is not one of the tasks, so finish() does not count it as learned
        assertTrue(start.contains("finish(Guide(\"already\", guide.title, mapOf(\"en\" to t), guide.steps, emptyList()))"))
        // Check this phone: a task whose steps were not shown is not counted as tried (an earlier try is kept)
        assertTrue(start.indexOf("PhoneCheck.start(guide.id") > start.indexOf("StepNav.alreadyOn(guide.doneWhen)"))
    }
}
