package zm.screenguide

import java.io.File
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

// v0.142 (the owner's Infinix, 28 Nov): the card "The phone is not connected to the internet" offered Show me how. It
// started a Smart guide, "Turn on mobile data", which needs the internet: "Waking up the helper" for 42 seconds. Then it
// said "Good news, SIM 1 already has Mobile Data on. You are done!" on the page that only chooses which SIM is used for
// data, while Airplane mode was on (the plane at the top of the screen) and mobile data was off. Show me how now starts the
// built-in "Turn on mobile data": no internet needed, Airplane mode said first (v0.135), and on/off read from the phone
// itself (v0.134), never guessed from the screen.
class OfflineFixTest {
    private fun src(n: String) = listOf("src/main/$n", "app/src/main/$n").map { File(it) }.first { it.exists() }.readText()

    @Test fun noInternetNeverNeedsTheInternet() {
        val g = src("java/zm/screenguide/GuideService.kt")
        val tip = g.substringAfter("tip(\"internet\", Trouble.INTERNET,").substringBefore("tip(\"password\"")
        assertTrue(tip.contains("guide = \"mobile_data\""))
        assertFalse(tip.contains("goal = "))   // never a Smart guide (it needs the internet)
        // the built-in task is there, and checks the phone's own state
        val j = src("assets/guides.json")
        assertTrue(j.contains("\"id\": \"mobile_data\",\n  \"doneWhen\": \"mobile_data_on\""))
        assertTrue(StepNav.planeFirst("mobile_data_on", true) != null)
    }
}
