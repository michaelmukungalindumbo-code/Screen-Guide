package zm.screenguide

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

// v0.123 (the owner, 19 Nov: "use whatever I have been sending you to go through the code again and tune ScreenGuide").
class ChoicesTest {
    private fun src(n: String) = listOf("src/main/java/zm/screenguide/$n", "app/src/main/java/zm/screenguide/$n").map { File(it) }.first { it.exists() }.readText()
    private fun tag(on: Boolean?, choice: Boolean, tappable: Boolean = true) = ScreenWords.tag(true, false, true, tappable, false, false, on, choice)

    // A round choice in a list ("30 seconds" among the screen timeouts) was a "[switch on]" or "[switch off]": the helper
    // could say "Tap the switch next to 2 minutes", or ask for the one already chosen. Now it is chosen or not, as a tab is.
    @Test fun aRoundChoiceIsChosenOrNot() {
        assertEquals("[selected]", tag(on = true, choice = true))       // the one in use: never tapped again (server 0.97)
        assertEquals("[tap]", tag(on = false, choice = true))
        assertEquals("[tap]", tag(on = null, choice = true))
        assertEquals("[text]", tag(on = false, choice = true, tappable = false))
        // Switches, toggles and tick boxes: on or off, as in 0.122
        assertEquals("[switch on]", tag(on = true, choice = false))
        assertEquals("[switch off]", tag(on = false, choice = false))
        assertEquals("[tap]", ScreenWords.tag(false, false, true, true, false, false, null, choice = true))   // no checkable at all: as before
        assertTrue(ScreenWords.isChoice("android.widget.RadioButton"))
        assertTrue(ScreenWords.isChoice("androidx.appcompat.widget.AppCompatRadioButton"))
        assertTrue(ScreenWords.isChoice("android.widget.CheckedTextView"))                 // the phone's own lists of choices
        assertTrue(ScreenWords.isChoice("androidx.appcompat.widget.AppCompatCheckedTextView"))
        assertFalse(ScreenWords.isChoice("android.widget.Switch"))
        assertFalse(ScreenWords.isChoice("androidx.appcompat.widget.SwitchCompat"))
        assertFalse(ScreenWords.isChoice("android.widget.CheckBox"))                       // a tick box is on or off
        assertFalse(ScreenWords.isChoice("android.widget.ToggleButton"))
        assertFalse(ScreenWords.isChoice(null))
    }

    // The owner's phone (13 Nov): on the home screen, while the helper looked at it, the card still said the last step,
    // "Tap the switch next to Wi-Fi to turn it on." The last step stays only while its button is still on this screen.
    @Test fun theLastStepOnlyWhereItsButtonIs() {
        assertTrue(Waiting.keepOldStep("com.android.settings", "com.android.settings", buttonHere = true))
        assertFalse(Waiting.keepOldStep("com.android.settings", "com.transsion.XOSLauncher", buttonHere = false))   // the home screen
        assertFalse(Waiting.keepOldStep("com.android.settings", "com.transsion.XOSLauncher", buttonHere = true))    // another app, same word
        assertFalse(Waiting.keepOldStep("com.android.settings", "com.android.settings", buttonHere = false))       // gone from this page
        assertFalse(Waiting.keepOldStep("", "com.android.settings", buttonHere = true))
    }

    @Test fun theWiringIsThere() {
        val g = src("GuideService.kt")
        assertTrue(g.contains("choice = sw != null && ScreenWords.isChoice(sw.className?.toString())"))
        val wait = g.substringAfter("// A new screen, or no step yet: ask again, but not more often than every 2 seconds.").substringBefore("if (!Guides.aiBusy) {")
        assertTrue(wait.contains("Waiting.keepOldStep(Guides.aiPkg, pkg, st.match.isNotEmpty() && find(nodes, st) != null)"))
        assertTrue(wait.contains("else if (keep) st?.say?.get(Guides.lang)"))
        assertTrue(wait.contains("else \"Looking\\u2026\", waitTop, keep && !slow)"))
        assertFalse(wait.contains("waitTop, st != null && !slow)"))                       // never the old step on any screen
    }
}
