package zm.screenguide

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

// v0.130 (the owner's Infinix phone, 25 Nov): "Try it as others see it" on his Status post "How to use the past papers app"
// (Past Papers ZM, Search, English, Navigate up), taught before ScreenGuide wrote down which app each step is in. On the
// home screen it said "Step 2 of 4: Tap Search" with the ring on the phone's own Search bar, never "Tap Past Papers ZM": a
// step that does not know its app may be looked for one step ahead, and the home screen has a "Search" too. He was stuck,
// pressed Help, and the helper, told only the task's name, went round in circles on the app's Help page.
class TaughtHoldTest {
    @Test fun theStepNowComesFirst() {
        // Step 2 ("Search", app not known) while step 1 ("Past Papers ZM") is still on this same screen, not tapped: not yet
        assertTrue(StepNav.holdNow(i = 1, now = 0, stepApp = null, builtIn = false, nowShown = true, nowTapped = false, sameScreen = true))
        assertFalse(StepNav.holdNow(1, 0, null, false, nowShown = false, nowTapped = false, sameScreen = true))   // step 1 is gone: the app opened
        assertFalse(StepNav.holdNow(1, 0, null, false, nowShown = true, nowTapped = true, sameScreen = true))     // they tapped it
        assertFalse(StepNav.holdNow(1, 0, null, false, nowShown = true, nowTapped = false, sameScreen = false))   // the screen changed (a tap not reported)
        assertFalse(StepNav.holdNow(1, 0, "com.example.app", false, true, false, true))   // knows its app: mayLook decides, as before
        assertFalse(StepNav.holdNow(1, 0, null, true, true, false, true))                 // built-in guides skip steps a phone lacks, as before
        assertFalse(StepNav.holdNow(0, 0, null, false, true, false, true))                // the step now itself
    }

    @Test fun theSameScreen() {
        val home = setOf("Maps", "Meet", "Messages", "Meta AI", "MovieBox", "Notepad", "Past Papers ZM", "Search", "Phone", "Photos")
        assertTrue(StepNav.sameScreen(home, home - "Meta AI" + "12:54"))   // a small change (the clock): still the same screen
        assertFalse(StepNav.sameScreen(home, setOf("Home", "Your subjects", "English", "Recently opened", "Search")))   // the app opened
        assertFalse(StepNav.sameScreen(emptySet(), home))
    }

    @Test fun helpGetsTheMakersSteps() {
        fun st(w: String, say: String) = Step(listOf(w), mapOf("en" to say), null)
        val steps = listOf(st("Past Papers ZM", "Tap “Past Papers ZM”."), st("Search", "Tap “Search”."),
            st("English", "Tap “English”."), st("Navigate up", "Tap “Navigate up”."))
        assertEquals(listOf("Tap “Past Papers ZM”.", "Tap “Search”.", "Tap “English”.", "Tap “Navigate up”."),
            StepNav.helpPlan(steps, now = 1, lang = "en"))
        // A built-in step that says only "Tap the glowing row." is named by its button
        assertEquals(listOf("Tap Settings.", "Tap “Sound & vibration”"),
            StepNav.helpPlan(listOf(st("Settings", "Tap Settings."), st("Sound & vibration", "Tap the glowing row.")), now = 0, lang = "en"))
        // Never more than the server takes (6), from the step now on when the task is long; questions left out
        val long = (1..9).map { st("B$it", "Tap “B$it”.") } + Step(listOf(Teach.ASK), mapOf("en" to "?"), null)
        assertEquals((4..9).map { "Tap “B$it”." }, StepNav.helpPlan(long, now = 3, lang = "en"))
    }

    @Test fun theWiringIsThere() {
        val g = listOf("src/main/java/zm/screenguide/GuideService.kt", "app/src/main/java/zm/screenguide/GuideService.kt").map { File(it) }.first { it.exists() }.readText()
        val loop = g.substringAfter("for (i in guide.steps.size - 1 downTo 0) {").substringBefore("val node = find(nodes, guide.steps[i])")
        assertTrue(loop.contains("StepNav.holdNow(i, Guides.index, guide.steps[i].app, builtIn, nowShown, tappedStep == Guides.index, sameScreen)"))
        assertTrue(g.contains("if (tappedSwitch(src, it.match)) tappedStep = Guides.index"))   // a tap on the step now is remembered
        val help = g.substringAfter("private fun onStuck()").substringBefore("helpFrom = g;")
        assertTrue(help.contains("Guides.aiPlan = StepNav.helpPlan(g.steps, Guides.index, Guides.lang)"))   // the helper follows the maker's steps
        assertTrue(help.indexOf("Guides.aiReset(goal)") < help.indexOf("Guides.aiPlan = StepNav.helpPlan("))
    }
}
