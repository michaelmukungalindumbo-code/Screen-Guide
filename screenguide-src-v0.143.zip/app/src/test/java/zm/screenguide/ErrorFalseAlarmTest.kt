package zm.screenguide

import java.io.File
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

// v0.140 (the owner's Infinix, 27 Nov): watching a video on YouTube, nothing wrong, ScreenGuide's card said "What this
// means: Something did not work. Wait a little, check your internet, then try again." Earlier the same kind of card said an
// app "needs a newer version" and offered to show him how to update. In apps full of other people's words (YouTube, the
// browser, TikTok, the Play Store, news) a title, a comment or a hidden placeholder ("Something went wrong") is not this
// phone's error. There, a card comes only for a pop-up (a dialog). Everywhere, the words must really be on the screen
// (not a placeholder with no size), and "must update" (said in many video titles) no longer counts.
class ErrorFalseAlarmTest {
    @Test fun whereCardsCome() {
        assertFalse(StepNav.errorHere("com.google.android.youtube", "android.widget.FrameLayout"))
        assertTrue(StepNav.errorHere("com.google.android.youtube", "android.app.AlertDialog"))
        assertFalse(StepNav.errorHere("com.android.chrome", null))
        assertFalse(StepNav.errorHere("com.android.vending", "com.google.android.finsky.activities.MainActivity"))
        assertFalse(StepNav.errorHere("com.zhiliaoapp.musically", null))
        assertFalse(StepNav.errorHere("com.opera.mini.native", null))
        assertTrue(StepNav.errorHere("com.android.settings", null))                 // other apps: as before
        assertTrue(StepNav.errorHere("com.google.android.apps.docs", "android.widget.FrameLayout"))
    }

    @Test fun theWiring() {
        val g = listOf("src/main/java/zm/screenguide/GuideService.kt", "app/src/main/java/zm/screenguide/GuideService.kt").map { File(it) }.first { it.exists() }.readText()
        val check = g.substringAfter("private fun errorCheck(e: AccessibilityEvent) {").substringBefore("\n    }\n")
        assertTrue(check.contains("if (!StepNav.errorHere(pkg, e.className?.toString())) return"))
        assertTrue(check.contains("val lines = candidates(root).filter { n -> val r = Rect(); n.getBoundsInScreen(r); r.width() > 0 && r.height() > 0 }"))
        val update = g.substringAfter("tip(\"update\", \"").substringBefore("\",")
        assertFalse(update.contains("must update"))
        assertTrue(update.contains("update (is )?required"))
    }
}
