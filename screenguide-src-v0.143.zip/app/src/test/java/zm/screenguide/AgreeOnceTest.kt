package zm.screenguide

import java.io.File
import org.junit.Assert.assertTrue
import org.junit.Test

// v0.132 (the owner, 26 Nov, a recording of turning ScreenGuide on again after an update: "can't we make this process
// shorter?"). He had already agreed to the Accessibility notice, but "Turn on ScreenGuide" showed it again each time. Once
// agreed, it goes straight on: to the Smart guide choice if not asked yet, else to the phone's Accessibility page.
class AgreeOnceTest {
    @Test fun theNoticeIsShownUntilAgreedOnly() {
        val m = listOf("src/main/java/zm/screenguide/MainActivity.kt", "app/src/main/java/zm/screenguide/MainActivity.kt").map { File(it) }.first { it.exists() }.readText()
        val c = m.substringAfter("private fun consent() {").substringBefore(".setNegativeButton(\"No thanks\")")
        val skip = c.indexOf("if (prefs.getBoolean(\"a11y_ok\", false)) {")
        assertTrue(skip in 0 until c.indexOf("AlertDialog.Builder(this).setTitle(\"ScreenGuide uses Accessibility\")"))
        val after = c.substring(skip).substringBefore("return")
        assertTrue(after.contains("if (prefs.getBoolean(\"smart_asked\", false)) openA11ySettings() else smartChoice()"))
    }
}
