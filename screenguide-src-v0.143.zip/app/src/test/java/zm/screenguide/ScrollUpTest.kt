package zm.screenguide

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

// v0.126 (the owner's Infinix phone, 25 Nov): "Make the phone ring louder". Settings opened part-way down its list (Special
// Function at the top), and the guide said "Scroll down to find “Sound & vibration”". That row is near the top on his
// phone. He scrolled to the very bottom (System) and pressed Help, and it still said "Scroll down". The guide only ever said
// "down". Now: down first; when the list cannot go further down but can go up, the row is above: "Scroll up", with the arrow
// the other way, until the row shows (and back to "down" if the top is reached without it).
class ScrollUpTest {
    @Test fun whichWay() {
        assertFalse(StepNav.scrollUp(canDown = true, canUp = false, wasUp = false))    // at the top: down
        assertFalse(StepNav.scrollUp(canDown = true, canUp = true, wasUp = false))     // part-way, nothing known yet: down first
        assertTrue(StepNav.scrollUp(canDown = false, canUp = true, wasUp = false))     // the bottom, and still not found: up
        assertTrue(StepNav.scrollUp(canDown = true, canUp = true, wasUp = true))       // going up from the bottom: stays up
        assertFalse(StepNav.scrollUp(canDown = true, canUp = false, wasUp = true))     // the top reached without it: down again
        assertFalse(StepNav.scrollUp(canDown = false, canUp = false, wasUp = false))   // a page that does not scroll
    }

    @Test fun theWords() {
        assertEquals("Scroll up to find “Sound & vibration”.", StepNav.scrollUpTo("Sound & vibration", "en"))
        // No new Nyanja or Bemba words are made up: English there too
        assertEquals("Scroll up to find “Sound”.", StepNav.scrollUpTo("Sound", "ny"))
        assertEquals("Scroll up to find “Sound”.", StepNav.scrollUpTo("Sound", "bem"))
    }

    @Test fun theWiringIsThere() {
        val g = listOf("src/main/java/zm/screenguide/GuideService.kt", "app/src/main/java/zm/screenguide/GuideService.kt")
            .map { File(it) }.first { it.exists() }.readText()
        // The list says which ways it can still scroll (the phone's own scroll actions)
        assertTrue(g.contains("ACTION_SCROLL_BACKWARD") && g.contains("ACTION_SCROLL_FORWARD"))
        // "Already on this page": the row is further down, or above once the list is at its end; the arrow shows that way
        val page = g.substringAfter("if (page != null) {").substringBefore("// Nothing to point at on this screen")
        assertTrue(page.contains("StepNav.scrollUp("))
        assertTrue(page.contains("StepNav.scrollUpTo(word, l)"))
        assertTrue(page.contains("showSwipe(down = up)"))
        // Lost on a page that scrolls: the small line says which way too
        assertTrue(g.contains("\"Not on this screen? Scroll up, or go back.\""))
    }
}
