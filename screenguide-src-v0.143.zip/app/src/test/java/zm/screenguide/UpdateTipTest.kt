package zm.screenguide

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

// v0.139 (the owner's Infinix, 27 Nov): an app showed "update required", and ScreenGuide's card said "This app needs a newer
// version. Update it in the Play Store", with Show me how. He read it as ScreenGuide asking to be updated. The guide's goal
// was "Update this app in the Play Store", with no name, so the helper could not know which app: it went to Manage apps &
// device and rang "Update all" (27 apps, a lot of data). The card and its guide now name the app. With no name there is no
// Show me how (it could only end at Update all).
class UpdateTipTest {
    @Test fun theWords() {
        assertEquals("WhatsApp needs a newer version. Update it in the Play Store, then open it again.", StepNav.updateSay("WhatsApp"))
        assertEquals("This app needs a newer version. Update it in the Play Store, then open it again.", StepNav.updateSay(null))
        assertEquals("Update WhatsApp in the Play Store", StepNav.updateGoal("WhatsApp"))
        assertNull(StepNav.updateGoal(null))
        assertNull(StepNav.updateGoal(" "))
    }

    @Test fun theWiring() {
        val g = listOf("src/main/java/zm/screenguide/GuideService.kt", "app/src/main/java/zm/screenguide/GuideService.kt").map { File(it) }.first { it.exists() }.readText()
        val check = g.substringAfter("private fun errorCheck(e: AccessibilityEvent) {").substringBefore("\n    }\n")
        assertTrue(check.contains("val app = if (tip.id == \"update\") Guides.shownName(this, pkg) else null"))
        assertTrue(check.contains("val goal = if (tip.id == \"update\") StepNav.updateGoal(app) else tip.fixGoal"))
        assertTrue(check.contains("if (tip.id == \"update\" && l == \"en\") StepNav.updateSay(app)"))   // English only: no new Nyanja or Bemba words
        assertTrue(!g.contains("goal = \"Update this app in the Play Store\""))
    }
}
