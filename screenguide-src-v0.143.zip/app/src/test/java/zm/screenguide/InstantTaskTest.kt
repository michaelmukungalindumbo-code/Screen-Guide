package zm.screenguide

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

// v0.138 (the owner's Infinix, 27 Nov): "How do I make a WhatsApp group for parents?" While the helper was thinking, the
// quick offer "I can take you to WhatsApp now" came first, with Open WhatsApp. He tapped it: WhatsApp opened and the card
// said "Well done! WhatsApp is open." and stopped there, with no group made. A few seconds later the helper's answer came
// (6 steps and Show me on my screen). The quick offer for a question is now the whole task: it opens the app (no helper
// needed for that) and then carries on with the question. "Open WhatsApp" only opens it, as before. Once the helper has
// answered, an offer still showing only opens the app (the helper's own answer has the steps, or said it is not a task).
class InstantTaskTest {
    @Test fun theWords() {
        assertEquals("How do I make a WhatsApp group for parents?", Match.offerGoal("How do I make a WhatsApp group for parents?"))
        assertNull(Match.offerGoal("Open WhatsApp"))
        assertNull(Match.offerGoal("where is whatsapp"))
        assertNull(Match.offerGoal("  "))
        assertEquals("I can take you to WhatsApp now and show you each step.", Match.offerLine("WhatsApp", true))
        assertEquals("I can take you to WhatsApp now.", Match.offerLine("WhatsApp", false))
    }

    @Test fun theWiring() {
        val m = listOf("src/main/java/zm/screenguide/MainActivity.kt", "app/src/main/java/zm/screenguide/MainActivity.kt").map { File(it) }.first { it.exists() }.readText()
        val offer = m.substringAfter("private fun instantOffer(text: String): Msg? {").substringBefore("\n    }\n")
        assertTrue(offer.contains("val goal = Match.offerGoal(text)"))
        assertTrue(offer.contains("return Msg(false, Match.offerLine(name, goal != null), goal = goal, guideId = \"open:\$pkg|\$name\")"))
        // the button, and "Show me" or "yes" typed: a goal means the whole task
        assertTrue(m.contains("addView(primary(\"Open \" + opens.first) { if (g != null) startSmart(g, m.needsApps, m.plan) else openLocal(opens.first, opens.second, rowOf(m.guideId)) })"))
        assertTrue(m.contains("if (opens != null && shown.goal == null) openLocal(opens.first, opens.second, rowOf(shown.guideId))"))
        assertTrue(m.contains("if (opens != null && showable.goal == null) openLocal(opens.first, opens.second, rowOf(showable.guideId))"))
        // after the helper's answer (or none), an offer still showing only opens the app
        val ask = m.substringAfter("private fun askServer(").substringBefore("private fun askNotifyOnce()")
        assertTrue(ask.contains("openOnly(conv, instant)"))
    }
}
