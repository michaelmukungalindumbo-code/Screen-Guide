package zm.screenguide

import java.io.File
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

// v0.125 (the owner's Infinix phone, 25 Nov): "Take a screenshot". He swiped down, the ring was on the Screenshot button (the
// scissors), he tapped it and the screenshot was taken: its small picture showed at the bottom left. But the guide never
// said "Well done": the panel closed by itself, the guide began again with "Swipe down from the top right corner", and the
// same happened the second time, so he stopped it. The phone never reported the tap on its panel button, and the guide only
// knew two other signs (an app named "screenshot", the exact words "Screenshot saved"). Now a new picture saved on the
// phone while the screenshot guide runs also finishes it, and more of the ways phones say it was saved are understood.
class ScreenshotDoneTest {
    @Test fun moreWaysOfSayingItWasSaved() {
        assertTrue(Shade.screenshotTaken("com.android.systemui", listOf("Screenshot saved")))           // as before
        assertTrue(Shade.screenshotTaken("com.android.systemui", listOf("Screenshot has been saved")))
        assertTrue(Shade.screenshotTaken("com.android.systemui", listOf("Screenshot saved to Gallery")))
        assertTrue(Shade.screenshotTaken("com.android.systemui", listOf("Screenshot preview")))           // the small picture
        assertTrue(Shade.screenshotTaken("com.android.systemui", listOf("Share screenshot")))
        assertTrue(Shade.screenshotTaken("com.android.systemui", listOf("Edit screenshot")))
        // A panel button's name alone is not a screenshot, nor a button that only starts one
        assertFalse(Shade.screenshotTaken("com.android.systemui", listOf("Screenshot")))
        assertFalse(Shade.screenshotTaken("com.android.systemui", listOf("Long screenshot")))
        assertFalse(Shade.screenshotTaken("com.android.systemui", listOf("Take screenshot")))
        assertFalse(Shade.screenshotTaken("com.android.settings", listOf("Battery")))
    }

    @Test fun aNewPictureFinishesTheScreenshotGuide() {
        assertTrue(Shade.newPicture("screenshot", 4_000, true))        // a new picture, 4 seconds into the guide
        assertTrue(Shade.newPicture("screenshot", 4_000, null))        // older Android cannot say what kind of change it was
        assertFalse(Shade.newPicture("screenshot", 4_000, false))      // a picture changed or deleted, not a new one
        assertFalse(Shade.newPicture("screenshot", 800, true))         // too soon: from before the guide began
        assertFalse(Shade.newPicture("torch", 4_000, true))            // only the screenshot guide
        assertFalse(Shade.newPicture(null, 4_000, true))
    }

    @Test fun theWiringIsThere() {
        val g = listOf("src/main/java/zm/screenguide/GuideService.kt", "app/src/main/java/zm/screenguide/GuideService.kt")
            .map { File(it) }.first { it.exists() }.readText()
        // The phone tells ScreenGuide when a picture is saved; nothing about the picture is read
        assertTrue(g.contains("MediaStore.Images.Media.EXTERNAL_CONTENT_URI"))
        assertTrue(g.contains("Shade.newPicture("))
        assertTrue(g.contains("Stats.inc(this, \"screenshot_picture\")"))
        // The words the phone says out loud for blind users count too (its announcement and descriptions)
        assertTrue(g.contains("e.contentDescription"))
        // Only while the screenshot guide runs: watching starts and stops with it
        assertTrue(g.contains("watchPictures(guide.id == \"screenshot\")"))
    }
}
