package zm.screenguide

import java.io.File
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

// v0.131 (the owner, 26 Nov): "I want to change the name of status into something more understandable". He chose "Shared
// tasks". No words on screen say "Status" any more (the code keeps its own names, such as showStatus).
class SharedNameTest {
    @Test fun noStatusOnScreen() {
        val m = listOf("src/main/java/zm/screenguide/MainActivity.kt", "app/src/main/java/zm/screenguide/MainActivity.kt").map { File(it) }.first { it.exists() }.readText()
        val shown = Regex("\"([^\"\\\\]|\\\\.)*\"").findAll(m).map { it.value }.filter { Regex("\\b[Ss]tatus\\b").containsMatchIn(it) }.toList()
        assertTrue("words on screen still say Status: $shown", shown.isEmpty())
        assertTrue(m.contains("addView(action(\"play\", \"Shared tasks\", ink) { showStatus() })"))
        assertTrue(m.contains("sheet(\"Shared tasks\", rows,"))
        assertFalse(m.contains("Post it as a status"))
    }
}
