package zm.screenguide

import java.io.File
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

// v0.136 (the owner's Infinix, 27 Nov): "Which app is using up my data?" The first time, the Smart guide went to the list
// and ended "Look at the list: YouTube uses …, WhatsApp uses …. These are the apps that use the most data today." The next
// time the learned guide ran ("Check which apps use data", 3 steps): it stopped on the page before the list and said only
// "Well done!". A learned guide keeps the buttons that were tapped, not what was read out at the end (that changes every
// day). Now a learned guide for a question ends with one look by the Smart guide, which reads the answer from the screen
// (or points at the one button still missing). Guides taught by the person or shared with them end as before.
class LearnedEndingTest {
    @Test fun questions() {
        for (g in listOf("Check which apps use data", "Which app is using up my data?", "How much storage is left?",
                "How many apps do I have", "Why is my phone full", "What version of Android do I have", "See which apps use battery",
                "Find out my phone's name"))
            assertTrue(g, StepNav.asksAnswer(g))
        for (g in listOf("Turn on Wi-Fi", "How do I back up my photos", "Open WhatsApp", "Send a WhatsApp message", "Scan a document",
                "Install Facebook", "Seed a torrent"))
            assertFalse(g, StepNav.asksAnswer(g))
        assertFalse(StepNav.asksAnswer(null))
        assertTrue(StepNav.asksAnswer("Check which apps use data (about: Settings)"))
        assertFalse(StepNav.asksAnswer("Turn on Wi-Fi (about: which app)"))   // only the goal, not the note after it
    }

    @Test fun onlyLearnedByScreenGuide() {
        fun kept(t: String, by: String?) = JSONObject().put("k", t.lowercase()).put("t", t)
            .put("st", JSONArray().put(JSONObject().put("m", JSONArray().put("Settings")).put("s", JSONObject().put("en", "Tap Settings."))))
            .apply { if (by != null) put("by", by) }
        val a = JSONArray().put(kept("Check which apps use data", null)).put(kept("Check my storage", Recipes.ME))
            .put(kept("Which apps use battery", Recipes.SHARED))
        assertFalse(Recipes.byPerson(a, "Check which apps use data"))   // learned by ScreenGuide
        assertTrue(Recipes.byPerson(a, "Check my storage"))             // taught by the person
        assertTrue(Recipes.byPerson(a, "Which apps use battery"))       // shared with them
        assertFalse(Recipes.byPerson(a, "Check how much data is left"))  // learned by other phones of this kind (not kept here)
    }

    private fun src(n: String) = listOf("src/main/java/zm/screenguide/$n", "app/src/main/java/zm/screenguide/$n").map { File(it) }.first { it.exists() }.readText()

    @Test fun theWiring() {
        val g = src("GuideService.kt")
        val fin = g.substringAfter("private fun finish(g: Guide) {").substringBefore("appSaid = \"\"")
        assertTrue(fin.contains("if (g.id == \"learned\" && endOf !== g && StepNav.asksAnswer(g.title[\"en\"]) &&"))
        assertTrue(fin.contains("!Recipes.byPerson(this, g.title[\"en\"] ?: \"\") && askEnding(g)) return"))
        // the steps already learned are the start of the trail: kept again only if the Smart guide added a step
        val ask = g.substringAfter("private fun askEnding(g: Guide): Boolean {").substringBefore("\n    }\n")
        assertTrue(ask.contains("Guides.aiReset(goal); g.steps.forEach { Guides.aiTrail.add(it) }; Guides.aiKnown = g.steps.size"))
        assertTrue(ask.contains("Guides.aiLast = System.currentTimeMillis()"))   // not the page the last tap is leaving
        assertTrue(g.contains("if (trail.size > Guides.aiKnown && Recipes.keep(trail.size,"))
        // the helper cannot be reached (no data, no credit): the learned guide ends as before, never an error
        assertTrue(g.contains("if (!r.ok && Guides.aiKnown > 0) endOf?.let { e -> finish(e); endOf = null; return@post }"))
        assertTrue(src("Guides.kt").contains("aiPath.clear(); aiPathPkg = \"\"; aiThen = null; aiKnown = 0"))
    }
}
