package zm.screenguide

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

// v0.143 (the owner's Infinix, 28 Nov, "Upload on YouTube"): "Tap Upload at the bottom to send your video." The ring was
// on YouTube's Upload button, at the very bottom, and the test strip (test phones only) lay on top of it: the arrow
// pointed at "Smart guide" on the strip, and the button could not be seen or tapped. Whenever the ring is drawn, the strip
// moves to the other edge if it covers the ring.
class StripOffRingTest {
    @Test fun whereTheStripGoes() {
        val h = 1600
        assertEquals("top", StepNav.stripMove(1480, 1590, 1500, 1580, h))      // the report: both at the bottom
        assertEquals("bottom", StepNav.stripMove(60, 170, 80, 150, h))         // both at the top
        assertNull(StepNav.stripMove(60, 170, 1500, 1580, h))                   // apart: it stays
        assertNull(StepNav.stripMove(1480, 1590, 300, 400, h))
        assertNull(StepNav.stripMove(1480, 1590, 1300, 1480, h))                // touching is not covering
    }

    @Test fun theWiring() {
        val g = listOf("src/main/java/zm/screenguide/GuideService.kt", "app/src/main/java/zm/screenguide/GuideService.kt").map { File(it) }.first { it.exists() }.readText()
        val show = g.substringAfter("    private fun show(r: Rect) {").substringBefore("\n    }\n")
        assertTrue(show.contains("ringAt = Rect(r); stripOffRing()"))
        assertTrue(g.substringAfter("    private fun hideRing() {").substringBefore("\n    }\n").contains("ringAt = null"))
        // and after the strip is placed for a new step
        assertTrue(g.substringAfter("    private fun note(step: String").substringBefore("    private var dbgY").contains("stripOffRing()"))
    }
}
