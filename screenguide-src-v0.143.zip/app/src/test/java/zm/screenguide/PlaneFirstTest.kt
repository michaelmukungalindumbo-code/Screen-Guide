package zm.screenguide

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

// v0.135 (the owner's Infinix, 26 Nov): "Turn on mobile data" with Airplane mode on (the plane at the top of the screen).
// Mobile data was already on, so the guide said "Well done! Mobile data is on." But with Airplane mode on, mobile data
// cannot connect: the person still has no internet. Now the task says so first, and how to turn Airplane mode off
// (English only: no new Nyanja or Bemba words). Not counted as a skill learned.
class PlaneFirstTest {
    @Test fun theWords() {
        assertEquals("Airplane mode is on, so mobile data cannot work. Turn it off first: swipe down from the top of the screen " +
            "(twice on some phones) and tap the plane. Then try again.", StepNav.planeFirst("mobile_data_on", true))
        assertNull(StepNav.planeFirst("mobile_data_on", false))   // no Airplane mode: as before
        assertNull(StepNav.planeFirst("wifi_on", true))           // Wi-Fi works with Airplane mode on
        assertNull(StepNav.planeFirst("airplane_on", true))       // the Airplane task itself: "already on"
        assertNull(StepNav.planeFirst(null, true))
    }

    @Test fun itComesFirst() {
        val g = listOf("src/main/java/zm/screenguide/GuideService.kt", "app/src/main/java/zm/screenguide/GuideService.kt").map { File(it) }.first { it.exists() }.readText()
        val start = g.substringAfter("startDone = guide.id != \"ai\" && guide.doneWhen != null && isDone(guide)").substringBefore("// \"Find an app\" guide")
        assertTrue(start.contains("StepNav.planeFirst(guide.doneWhen, airplaneOn())?.let { t ->"))
        assertTrue(start.contains("finish(Guide(\"plane\", guide.title, mapOf(\"en\" to t), guide.steps, emptyList()))"))   // not a skill learned
        // before "Mobile data is already on" and before Check this phone counts a try
        assertTrue(start.indexOf("StepNav.planeFirst(") in 0 until start.indexOf("StepNav.alreadyOn("))
        assertTrue(start.indexOf("StepNav.planeFirst(") < start.indexOf("PhoneCheck.start(guide.id"))
        assertTrue(g.contains("private fun airplaneOn() = try { Settings.Global.getInt(contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) == 1 } catch (e: Exception) { false }"))
    }
}
