package zm.screenguide

import java.io.File
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

// v0.137 (the owner's Infinix, 27 Nov, "Turn on backup in the Photos app", #109 and #110): Google Photos' account menu
// shares no words, so the helper looked at a picture of the screen and pointed at a spot in it ("Photos settings", at the
// bottom). He scrolled the menu: the ring stayed in the same place, over another row. He opened the next page: the ring
// was still there, over "Apps & devices", with "Tap Photos settings" for 10 seconds. A spot from a picture is only right on
// the screen in that picture. Scrolled, a new page, or words where there were none: the ring goes and the helper looks again.
class SpotRingTest {
    @Test fun whenTheSpotIsNoLongerRight() {
        val at = 10_000L
        assertFalse(StepNav.spotMoved(at, at - 2000, 0L, true, true))         // nothing changed: the ring stays
        assertFalse(StepNav.spotMoved(at, at + 200, 0L, true, true))          // the screen still settling just after the answer
        assertTrue(StepNav.spotMoved(at, at + 3000, 0L, true, true))          // a new page opened
        assertTrue(StepNav.spotMoved(at, at - 2000, at + 1500, true, true))   // they scrolled
        assertTrue(StepNav.spotMoved(at, at - 2000, 0L, true, false))         // words now, where there were none: another screen
        assertFalse(StepNav.spotMoved(at, at - 2000, 0L, false, false))       // words then and now: the usual check (same words)
    }

    @Test fun theWiring() {
        val g = listOf("src/main/java/zm/screenguide/GuideService.kt", "app/src/main/java/zm/screenguide/GuideService.kt").map { File(it) }.first { it.exists() }.readText()
        val block = g.substringAfter("if (st === pointFor && pr != null) {").substringBefore("show(Rect(pr))")
        assertTrue(block.contains("if (StepNav.spotMoved(stepAt, screenAt, scrolledAt, Guides.aiLabels.isEmpty(), now.isEmpty())) {"))
        assertTrue(block.contains("pointFor = null; pointRect = null; hideRing(); reask = true"))
        assertTrue(block.contains("aiRefresh(guide, nodes, pkg); return"))
    }
}
