package zm.screenguide

import org.json.JSONArray
import org.json.JSONObject

// v0.124 (the owner, 21 Nov: "someone can put it on the app as a status just like WhatsApp, where someone can view, and
// if they like the guide, they can then request for it"). A taught task is posted for everyone (the server checks it
// first: never money apps, passwords, personal numbers, links or anything that lowers the phone's safety). Others look
// at its steps, and "Get it" keeps it on their phone at once. It stays until its maker removes it; three reports hide it.
// Plain functions (no Android), so a unit test can check them.
object Status {
    class Item(val id: String, val title: String, val steps: Int, val by: String, val device: String, val gets: Int, val mine: Boolean)

    fun items(a: JSONArray?): List<Item> {
        if (a == null) return emptyList()
        return (0 until a.length()).mapNotNull { i ->
            val o = a.optJSONObject(i) ?: return@mapNotNull null
            val id = o.optString("id"); val t = o.optString("title")
            if (id.isEmpty() || t.isEmpty()) null
            else Item(id, t, o.optInt("steps"), o.optString("by"), o.optString("device"), o.optInt("gets"), o.optBoolean("mine"))
        }
    }

    fun steps(n: Int) = if (n == 1) "1 step" else "$n steps"
    fun gotIt(n: Int) = if (n == 1) "1 person got it" else "$n people got it"
    // "infinix phone" -> "Infinix phone": the kind of phone it was taught on (menus differ between makers)
    fun phone(device: String): String? = device.trim().ifEmpty { null }?.replaceFirstChar { it.uppercase() }

    // Under the name in the list: "Michael · Infinix phone · 4 steps · 12 people got it"
    fun line(it: Item): String = listOfNotNull(it.by.ifEmpty { null }, phone(it.device), steps(it.steps), if (it.gets > 0) gotIt(it.gets) else null)
        .joinToString(" · ")

    // What everyone will see: each step's words, in order, each once. The maker checks them for names before posting.
    fun words(steps: List<Step>): List<String> = steps.filter { !Teach.isAsk(it) }
        .mapNotNull { st -> st.match.firstOrNull()?.trim()?.takeIf { it.isNotEmpty() && !it.startsWith("@") } }
        .distinctBy { it.lowercase() }

    // A task with a question still unanswered ("What did you tap here?") is not ready for others
    fun canPost(steps: List<Step>): Boolean = steps.isNotEmpty() && steps.none { Teach.isAsk(it) }

    // The name shown with a post: the first name only, letters only, or "" (then "A ScreenGuide user")
    fun firstName(name: String): String {
        val w = name.replace(Regex("[^\\p{L}' -]"), " ").trim().split(Regex("\\s+")).firstOrNull() ?: ""
        return if (w.length >= 2) w.take(20).lowercase().replaceFirstChar { it.uppercase() } else ""
    }
    fun shownAs(name: String) = name.ifEmpty { "A ScreenGuide user" }

    fun confirm(words: List<String>, name: String): String =
        "Everyone who uses ScreenGuide will see this task and these words:\n\n" + words.joinToString(", ") +
            "\n\nPost it only if none of them is a person’s name, a phone number or anything private.\n\nShown as: " + shownAs(name)

    fun preview(it: Item, says: List<String>): String =
        line(it) + "\n\n" + says.mapIndexed { i, s -> "${i + 1}. $s" }.joinToString("\n") +
            "\n\nIf you get it, I point at each step on your own screen. You do the tapping. ScreenGuide never points at payments or passwords."

    // Posted with where each step was taught (HOME, or the app), so on other phones each step is looked for only there
    fun stepsJson(steps: List<Step>): JSONArray = JSONArray().apply {
        steps.forEach { st -> put(JSONObject().put("m", JSONArray(st.match)).put("s", JSONObject(st.say)).apply { st.app?.let { put("a", it) }; if (st.icon) put("i", true) }) }
    }

    val REPORT_WHY = listOf("Wrong or broken steps", "Rude or harmful", "Personal details in it", "Something else")
}
