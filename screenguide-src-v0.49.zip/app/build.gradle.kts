plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "zm.screenguide"
    compileSdk = 36   // Google Play: new apps and updates must target Android 16 (API 36) from 31 August 2026
    defaultConfig {
        applicationId = "zm.screenguide"
        minSdk = 24
        targetSdk = 36
        versionCode = 49
        versionName = "0.49"
    }
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
}
kotlin { compilerOptions { jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17) } }

// Sign in with Google (Android's Credential Manager). Only used when the person chooses to sign in.
dependencies {
    implementation("androidx.credentials:credentials:1.3.0")
    implementation("androidx.credentials:credentials-play-services-auth:1.3.0")
    implementation("com.google.android.libraries.identity.googleid:googleid:1.1.1")
    // MatchTest: real questions must pick the right action (run on every GitHub build)
    testImplementation("junit:junit:4.13.2")
}
