package zm.screenguide

import android.accessibilityservice.AccessibilityService
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.widget.TextView
import android.media.MediaPlayer
import android.net.wifi.WifiManager
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityWindowInfo
import android.widget.LinearLayout
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.Locale

class RingView(c: Context) : View(c) {
    var arrowBelow = true
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 8f; color = 0xFFF0A935.toInt() }
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = 0xFFF0A935.toInt() }
    private val edgeP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 4f; color = 0xFF1F1A14.toInt() }
    private val still = Settings.Global.getFloat(c.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f
    private var t = 0f
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1200; repeatCount = ValueAnimator.INFINITE
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); if (!still) anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }
    override fun onDraw(c: Canvas) {
        val a = 118f
        val top = if (arrowBelow) 0f else a
        val bottom = height - (if (arrowBelow) a else 0f)
        p.alpha = 255
        c.drawRoundRect(RectF(26f, top + 26f, width - 26f, bottom - 26f), 30f, 30f, p)
        if (!still) {
            val g = 26f - 22f * t
            p.alpha = (255 * (1 - t)).toInt()
            c.drawRoundRect(RectF(g, top + g, width - g, bottom - g), 34f, 34f, p)
        }
        // A pointing arrow that bobs toward the target.
        val bob = if (still) 0f else 14f * kotlin.math.sin(t * 6.2831855f)
        val cx = width / 2f
        val s = if (arrowBelow) 1f else -1f
        val tip = if (arrowBelow) bottom - 26f + 12f - bob else top + 26f - 12f + bob
        val path = Path()
        path.moveTo(cx, tip)
        path.lineTo(cx - 34f, tip + s * 44f); path.lineTo(cx - 14f, tip + s * 44f)
        path.lineTo(cx - 14f, tip + s * 84f); path.lineTo(cx + 14f, tip + s * 84f)
        path.lineTo(cx + 14f, tip + s * 44f); path.lineTo(cx + 34f, tip + s * 44f); path.close()
        c.drawPath(path, fillP); c.drawPath(path, edgeP)
    }
}

class GuideService : AccessibilityService(), TextToSpeech.OnInitListener {
    private var wm: WindowManager? = null
    private var ring: RingView? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var spokenFor = -1
    private var mp: MediaPlayer? = null
    private var label: TextView? = null
    private var holdUntil = 0L
    private var findPkg: String? = null
    private var lastGuide: Guide? = null
    private val handler = Handler(Looper.getMainLooper())

    override fun onServiceConnected() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        tts = TextToSpeech(this, this)
        Guides.load(this)
    }
    override fun onInit(s: Int) { ttsReady = s == TextToSpeech.SUCCESS }
    override fun onInterrupt() {}
    override fun onDestroy() { hide(); hideLabel(); hideControls(); tts?.shutdown(); mp?.release(); super.onDestroy() }

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        val guide = Guides.active ?: run { hide(); hideControls(); return }
        val clicked = e.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED && e.packageName?.toString() != packageName
        if (clicked) bumpProgress()
        if (guide.id == "ai") {
            if (clicked) Guides.aiStep = null   // any tap is progress: ask for the next step
            schedule(e); return
        }
        // Final step: the person tapped the switch, so we are done.
        val last = guide.steps.last()
        if (e.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED && last.toggle && Guides.index == guide.steps.size - 1) {
            val src = e.source
            if (src != null) {
                val r = Rect(); src.getBoundsInScreen(r)
                val belowTitle = r.top > resources.displayMetrics.heightPixels * 0.12
                if (belowTitle && (matches(src, last.match) || matches(src.parent, last.match))) { finish(guide); return }
            }
        }
        schedule(e)
    }

    private fun schedule(e: AccessibilityEvent) {
        val own = e.packageName?.toString() == packageName
        val changed = e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && !own
        if (changed) { hide(); bumpProgress() }   // drop the old ring at once, show the new one when the screen settles
        handler.removeCallbacks(refreshRun)
        handler.postDelayed(refreshRun, if (changed) 300L else 150L)
        if (changed) { handler.removeCallbacks(lateRun); handler.postDelayed(lateRun, 800) }
    }

    private val refreshRun = Runnable { refresh() }
    private val lateRun = Runnable { refresh() }

    private fun refresh() {
        val guide = Guides.active ?: run { hide(); return }
        val root = rootInActiveWindow ?: run { if (classify() == "shade") { hide(); hideControls() }; return }
        val pkg = root.packageName?.toString() ?: ""
        if (pkg == packageName) { hide(); hideControls(); return }
        surface = classify()
        if (surface == "shade") { hide(); hideControls(); return }   // notification shade or quick settings is open
        showControls()
        if (guide !== lastGuide) { lastGuide = guide; findPkg = null }
        // "Find an app" guide: finished once the person has left the screen where the icon was.
        if (guide.id == "find" && findPkg != null && pkg != findPkg && pkg.isNotEmpty() && !pkg.contains("systemui", true)) { findPkg = null; finish(guide); return }
        val nodes = candidates(root)
        val dm0 = resources.displayMetrics
        val dump = nodes.filter { !it.isPassword }.mapNotNull { n ->
            val t = (n.text ?: n.contentDescription)?.toString()?.takeIf { it.isNotBlank() } ?: return@mapNotNull null
            val r = Rect(); n.getBoundsInScreen(r)
            "$t@${r.top * 100 / dm0.heightPixels}%" + (n.className?.toString() ?: "").substringAfterLast('.')
        }.take(70).joinToString(" | ")
        Guides.seen.remove(pkg); Guides.seen[pkg] = "$pkg (h=${dm0.heightPixels}): $dump"
        while (Guides.seen.size > 3) Guides.seen.remove(Guides.seen.keys.first())
        if (guide.id == "ai") { aiRefresh(guide, nodes, pkg); return }
        // Show the LATEST step whose target is on screen. This skips steps a phone brand doesn't have.
        for (i in guide.steps.size - 1 downTo 0) {
            val skip = guide.steps[i].skipIn
            if (skip != null && pkg.contains(skip, true)) continue
            syntheticRect = null
            val node = find(nodes, guide.steps[i]) ?: continue
            if (guide.id == "find") findPkg = pkg
            if (guide.steps[i].toggle && (node.isChecked || isDone(guide))) { finish(guide); return }
            Guides.index = i
            val r = Rect(); node.getBoundsInScreen(r)
            syntheticRect?.let { r.set(it) }
            show(r)
            track(if (syntheticRect == null) node else null)
            val st = guide.steps[i]
            showLabel(st.say[Guides.lang] ?: st.say["en"] ?: "", r.centerY() > resources.displayMetrics.heightPixels / 2)
            if (spokenFor != i) { spokenFor = i; speak(guide.steps[i]) }
            // On the last step, keep checking the real phone state until the task is done.
            if (guide.doneWhen != null && i == guide.steps.size - 1) { handler.removeCallbacks(refreshRun); handler.postDelayed(refreshRun, 700) }
            return
        }
        hide()
        if (guide.id == "find") guide.hint?.let { showLabel(it[Guides.lang] ?: it["en"] ?: "", false) }
    }

    // ---- Smart guide: the AI picks the next button from the words on screen ----
    private val blockedApps = listOf("momo", "airtel", "mtn", "bank", "zanaco", "fnb", "stanbic", "absa", "finance", "wallet", "pay", "money", "binance", "paypal", "credit", "loan", "cash")
    private fun sensitive(pkg: String, nodes: List<AccessibilityNodeInfo>) = blockedApps.any { pkg.contains(it, true) } || nodes.any { it.isPassword }

    private fun hideRing() {
        ringAnim?.cancel(); ringLp = null; trackNode = null; handler.removeCallbacks(trackRun)
        ring?.let { try { wm?.removeView(it) } catch (_: Exception) {} }; ring = null
    }

    private fun aiRefresh(guide: Guide, nodes: List<AccessibilityNodeInfo>, pkg: String) {
        if (sensitive(pkg, nodes)) {   // nothing is sent from these screens
            hideRing(); showLabel("For your safety I cannot guide you on this screen. Please do it yourself, or ask someone you trust.", false); return
        }
        val now = nodes.mapNotNull { (it.text ?: it.contentDescription)?.toString() }.take(60).toSet()
        // Still the same screen as when we last asked? (same app, and most words unchanged)
        val same = pkg == Guides.aiPkg && (Guides.aiLabels.isEmpty() || now.intersect(Guides.aiLabels).size >= 0.5 * minOf(now.size, Guides.aiLabels.size))
        val st = Guides.aiStep
        if (st != null && same) {
            val node = if (st.match.isNotEmpty()) find(nodes, st) else null
            if (node != null) {
                val r = Rect(); node.getBoundsInScreen(r); show(r); track(node)
                showLabel(st.say[Guides.lang] ?: st.say["en"] ?: "", r.centerY() > resources.displayMetrics.heightPixels / 2)
            } else { hideRing(); showLabel(st.say[Guides.lang] ?: st.say["en"] ?: "", false) }
            return
        }
        // A new screen, or no step yet: ask again, but not more often than every 2 seconds.
        hideRing(); showLabel(st?.say?.get(Guides.lang) ?: st?.say?.get("en") ?: "Looking\u2026", false, st != null)
        if (!Guides.aiBusy) {
            if (System.currentTimeMillis() - Guides.aiLast > 2000) askNext(guide, nodes, pkg)
            else { handler.removeCallbacks(refreshRun); handler.postDelayed(refreshRun, 2100) }
        }
    }

    private fun askNext(guide: Guide, nodes: List<AccessibilityNodeInfo>, pkg: String) {
        if (Guides.aiAsked >= 20) {
            Guides.active = null; hideRing(); holdUntil = System.currentTimeMillis() + 4000
            showLabel("Let\u2019s stop here. Ask me again if you still need help.", false); handler.postDelayed({ hideLabel() }, 4000); return
        }
        val labels = nodes.filter { !it.isPassword }
            .mapNotNull { (it.text ?: it.contentDescription)?.toString()?.trim() }
            .filter { it.isNotEmpty() && it.length <= 50 && !Regex("\\d{5,}").containsMatchIn(it) && !it.contains("@") }
            .distinct().take(70)
        if (labels.isEmpty()) return
        Guides.aiBusy = true; Guides.aiAsked++; Guides.aiPkg = pkg; Guides.aiLast = System.currentTimeMillis()
        Guides.aiLabels = nodes.mapNotNull { (it.text ?: it.contentDescription)?.toString() }.take(60).toSet()
        val goal = Guides.aiGoal; val lang = Guides.lang; val hist = ArrayList(Guides.aiHistory)
        val stuck = Guides.aiStuck; Guides.aiStuck = false
        val id = getSharedPreferences("sg", MODE_PRIVATE).getString("id", "") ?: ""
        Thread {
            val r = Server.next(goal, lang, id, labels, hist, stuck)
            handler.post {
                Guides.aiBusy = false
                if (Guides.active !== guide) return@post
                if (r == null) {
                    Guides.aiStep = Step(emptyList(), mapOf(lang to "I could not reach the helper. Please try again."), null)
                } else if (r.done) {
                    finish(Guide(guide.id, guide.title, mapOf(lang to r.say), emptyList(), emptyList()))
                    return@post
                } else {
                    val say = tighten(r.say)
                    Guides.aiHistory.add(say)
                    val step = Step(if (r.label != null) listOf(r.label) else emptyList(), mapOf(lang to say), null)
                    Guides.aiStep = step
                    speak(step)
                }
                refresh()
            }
        }.start()
    }

    // ---- Window awareness, tracking and on-screen controls ----
    private var surface = "app"
    private var imeTop: Int? = null

    // What is on top: the app, a permission pop-up, a file or photo picker, or the notification shade.
    private fun classify(): String {
        imeTop = null
        var activePkg = ""
        try {
            for (w in windows) {
                val b = Rect(); w.getBoundsInScreen(b)
                if (w.type == AccessibilityWindowInfo.TYPE_INPUT_METHOD) imeTop = b.top
                if (w.isActive) activePkg = w.root?.packageName?.toString() ?: activePkg
            }
        } catch (_: Exception) {}
        return when {
            activePkg.contains("permissioncontroller") -> "permission"
            activePkg.contains("providers.media") || activePkg.contains("photopicker") || activePkg.contains("documentsui") -> "picker"
            activePkg == "com.android.systemui" -> "shade"
            else -> "app"
        }
    }

    // Keep measuring the target so the ring follows scrolling and animations.
    private var trackNode: AccessibilityNodeInfo? = null
    private val trackRun = object : Runnable {
        override fun run() {
            val n = trackNode ?: return
            if (ring == null) return
            if (n.refresh() && n.isVisibleToUser) {
                val r = Rect(); n.getBoundsInScreen(r)
                if (!r.isEmpty && r != lastTarget) show(r)
                handler.postDelayed(this, 100)
            } else { trackNode = null; handler.removeCallbacks(refreshRun); handler.post(refreshRun) }
        }
    }
    private fun track(n: AccessibilityNodeInfo?) {
        trackNode = n; handler.removeCallbacks(trackRun)
        if (n != null) handler.postDelayed(trackRun, 100)
    }

    // Keep each instruction short: one action, verb first.
    private fun tighten(say: String): String =
        say.substringBefore(". ").trim().split(" ").take(10).joinToString(" ")

    private var controls: LinearLayout? = null
    private var stuckChip: TextView? = null
    private val stuckRun = Runnable { stuckChip?.let { it.background = pillBg(0xFFF0A935.toInt()); it.setTextColor(Color.BLACK) } }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun pillBg(c: Int) = GradientDrawable().apply { setColor(c); cornerRadius = dp(24).toFloat() }

    // Any progress (a tap, a new screen) resets the quiet timer; after 9 seconds the "I'm stuck" button lights up.
    private fun bumpProgress() {
        stuckChip?.let { it.background = pillBg(0xE61F1A14.toInt()); it.setTextColor(Color.WHITE) }
        handler.removeCallbacks(stuckRun); handler.postDelayed(stuckRun, 9000)
    }

    private fun speakCurrent() {
        val g = Guides.active ?: return
        val st = if (g.id == "ai") Guides.aiStep else g.steps.getOrNull(Guides.index)
        if (st != null) speak(st)
    }

    // Asks the AI for a different way. Built-in guides switch to the Smart guide for the same goal.
    private fun onStuck() {
        val g = Guides.active ?: return
        val ok = getSharedPreferences("sg", MODE_PRIVATE).getBoolean("smart_ok", false)
        if (!Server.configured || !ok) { showLabel("Open ScreenGuide and agree to Smart guide to get help here.", false); return }
        if (g.id != "ai") {
            val goal = if (g.id == "find") "Open " + (g.title["en"] ?: "") else (g.title["en"] ?: g.id)
            Guides.aiReset(goal)
            Guides.active = Guide("ai", g.title, g.done, emptyList(), emptyList())
        }
        Guides.aiStep = null; Guides.aiLast = 0L; Guides.aiStuck = true
        bumpProgress(); handler.removeCallbacks(refreshRun); handler.post(refreshRun)
    }

    private fun showControls() {
        if (controls != null) return
        val w = wm ?: return
        fun chip(text: String, desc: String, onTap: () -> Unit) = TextView(this).apply {
            this.text = text; textSize = 15f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD
            minWidth = dp(48); setPadding(dp(14), 0, dp(14), 0)
            background = pillBg(0xE61F1A14.toInt()); contentDescription = desc
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(48)).apply { bottomMargin = dp(6) }
            setOnClickListener { onTap() }
        }
        val repeat = chip("\u21BB Repeat", "Repeat the instruction") { speakCurrent() }
        val stuck = chip("? I\u2019m stuck", "I am stuck, help me") { onStuck() }
        val stop = chip("\u2715 Stop", "Stop the guide") {
            Guides.active = null; Guides.aiStep = null; hide(); hideControls(); hideLabel()
        }
        stuckChip = stuck
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(repeat); addView(stuck); addView(stop) }
        val lp = WindowManager.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,   // touchable, unlike the ring
            PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.END or Gravity.TOP; lp.x = dp(6); lp.y = dp(150)
        w.addView(col, lp); controls = col
        handler.removeCallbacks(stuckRun); handler.postDelayed(stuckRun, 9000)
    }
    private fun hideControls() {
        controls?.let { try { wm?.removeView(it) } catch (_: Exception) {} }
        controls = null; stuckChip = null; handler.removeCallbacks(stuckRun)
    }

    // Phones draw switches differently; accept anything that looks like one.
    private fun isSwitchLike(n: AccessibilityNodeInfo?): Boolean {
        if (n == null) return false
        val c = n.className?.toString() ?: ""
        return n.isCheckable || c.contains("Switch") || c.contains("Toggle") || c.contains("CheckBox")
    }

    // Ask Android itself whether the task is done, instead of guessing from the screen.
    private fun isDone(g: Guide): Boolean = when (g.doneWhen) {
        "wifi_on" -> try { (applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).isWifiEnabled } catch (e: Exception) { false }
        "bluetooth_on" -> try { Settings.Global.getInt(contentResolver, "bluetooth_on", 0) == 1 } catch (e: Exception) { false }
        "airplane_on" -> try { Settings.Global.getInt(contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) == 1 } catch (e: Exception) { false }
        else -> false
    }

    private fun finish(g: Guide) {
        hide(); hideControls(); Guides.active = null; spokenFor = -1; say(g.done)
        holdUntil = System.currentTimeMillis() + 4000
        showLabel("\u2714 " + (g.done[Guides.lang] ?: g.done["en"] ?: ""), false)
        handler.postDelayed({ hideLabel() }, 4000)
    }

    private fun norm(s: String?) = (s ?: "").lowercase().filter { it.isLetterOrDigit() }

    // Every visible node on screen, as a flat list.
    private fun candidates(root: AccessibilityNodeInfo): List<AccessibilityNodeInfo> {
        val out = ArrayList<AccessibilityNodeInfo>()
        val q = ArrayDeque<AccessibilityNodeInfo>(); q.add(root)
        var seen = 0
        while (q.isNotEmpty() && seen < 800) {
            val n = q.removeFirst(); seen++
            if (n.isVisibleToUser) out.add(n)
            for (i in 0 until n.childCount) n.getChild(i)?.let { q.add(it) }
        }
        return out
    }

    // Some phones never report certain rows (e.g. Airplane mode on Infinix). If the screen's title matches
    // but the row is missing, point at the empty band between the title bar and the next heading.
    private var syntheticRect: Rect? = null
    private fun gapRow(nodes: List<AccessibilityNodeInfo>, s: Step, h: Int): AccessibilityNodeInfo? {
        val tk = (s.titles ?: s.match).map { norm(it) }
        val title = nodes.firstOrNull { n ->
            val r = Rect(); n.getBoundsInScreen(r)
            r.top <= h * 0.12 && norm(n.text?.toString()) in tk
        } ?: return null
        val tr = Rect(); title.getBoundsInScreen(tr)
        val next = nodes.mapNotNull { n ->
            if (n.text.isNullOrBlank()) return@mapNotNull null
            val r = Rect(); n.getBoundsInScreen(r)
            if (r.top > tr.bottom + h * 0.02) r.top else null
        }.minOrNull() ?: return null
        val top = tr.bottom + (h * 0.01).toInt()
        val bottom = next - (h * 0.01).toInt()
        if (bottom - top < h * 0.04) return null
        val mid = (top + bottom) / 2
        val half = minOf((bottom - top) / 2, (h * 0.045).toInt())
        val w = resources.displayMetrics.widthPixels
        syntheticRect = Rect((w * 0.03).toInt(), mid - half, (w * 0.97).toInt(), mid + half)
        return title
    }

    private fun area(n: AccessibilityNodeInfo): Long { val r = Rect(); n.getBoundsInScreen(r); return r.width().toLong() * r.height() }

    private fun find(nodes: List<AccessibilityNodeInfo>, s: Step): AccessibilityNodeInfo? {
        if (s.toggle) {
            nodes.firstOrNull { n ->
                val row = n.parent
                isSwitchLike(n) && row != null && blob(row).length < 120 && matches(row, s.match)
            }?.let { return it }
            // Fallback: the labelled row below the title bar (some phones hide the switch itself).
            val h = resources.displayMetrics.heightPixels
            val keys = s.match.map { norm(it) }
            // Only on the screen that is itself named "Wi-Fi" (label in the title bar), not on the Settings list.
            // Not on the main Settings list (its "Wi-Fi" row is a menu entry, not the switch).
            val onSettingsList = nodes.any { n ->
                val r = Rect(); n.getBoundsInScreen(r)
                r.top <= h * 0.12 && norm(n.text?.toString()) == "settings"
            }
            if (onSettingsList) return null
            val below = nodes.filter { n -> val r = Rect(); n.getBoundsInScreen(r); r.top > h * 0.12 }
            val row = below.filter { n -> norm(n.text?.toString()) in keys || norm(n.contentDescription?.toString()) in keys }.minByOrNull { area(it) }
                ?: below.filter { n -> keys.any { k -> norm(n.text?.toString()).startsWith(k) } }.minByOrNull { area(it) }
                ?: return gapRow(nodes, s, h)
            return target(row)
        }
        val dm = resources.displayMetrics
        val maxArea = dm.widthPixels.toLong() * dm.heightPixels / 6   // ignore huge containers
        for (k in s.match) {
            val nk = norm(k)
            // Same words, ignoring odd hyphens and spacing. The smallest box is the most specific one.
            val best = nodes.filter { norm(it.text?.toString()) == nk || norm(it.contentDescription?.toString()) == nk }
                .filter { area(it) in 1L..maxArea }.minByOrNull { area(it) } ?: continue
            return target(best)
        }
        return null
    }

    // The tappable thing around the label, but never a huge container like a whole screen.
    private fun target(n: AccessibilityNodeInfo): AccessibilityNodeInfo {
        val nr = Rect(); n.getBoundsInScreen(nr)
        val d = resources.displayMetrics
        val limit = minOf(maxOf(1, nr.width() * nr.height()) * 4L, d.widthPixels.toLong() * d.heightPixels / 5)
        var c: AccessibilityNodeInfo = n
        repeat(3) {
            val p = c.parent ?: return n
            val pr = Rect(); p.getBoundsInScreen(pr)
            if (pr.width().toLong() * pr.height() > limit) return n
            if (p.isClickable) return p
            c = p
        }
        return n
    }

    private fun blob(n: AccessibilityNodeInfo?, d: Int = 0): String {
        if (n == null || d > 3) return ""
        var s = "${n.text} ${n.contentDescription} "
        for (i in 0 until n.childCount) s += blob(n.getChild(i), d + 1)
        return s
    }
    private fun matches(n: AccessibilityNodeInfo?, keys: List<String>): Boolean {
        val t = blob(n).lowercase()
        return keys.any { t.contains(it.lowercase()) }
    }

    private val ARROW = 118
    private var ringLp: WindowManager.LayoutParams? = null
    private var ringAnim: ValueAnimator? = null
    private val lastTarget = Rect()

    private fun show(r: Rect) {
        val w = wm ?: return
        val h = resources.displayMetrics.heightPixels
        val below = r.bottom + 26 + ARROW <= h   // arrow goes under the target, or above it near the bottom edge
        val lp = WindowManager.LayoutParams(r.width() + 52, r.height() + 52 + ARROW,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = r.left - 26
        lp.y = if (below) r.top - 26 else r.top - 26 - ARROW
        lastTarget.set(r)
        val v = ring
        if (v == null) {
            ring = RingView(this).also { it.arrowBelow = below; w.addView(it, lp) }
            ringLp = lp
            return
        }
        v.arrowBelow = below; v.invalidate()
        val from = ringLp
        ringAnim?.cancel()
        val still = Settings.Global.getFloat(contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f
        if (from == null || still) { try { w.updateViewLayout(v, lp) } catch (_: Exception) {}; ringLp = lp; return }
        val fx = from.x; val fy = from.y; val tx = lp.x; val ty = lp.y
        ringLp = lp
        ringAnim = ValueAnimator.ofFloat(0f, 1f).apply {   // glide to the new spot instead of jumping
            duration = 120
            addUpdateListener { a ->
                val f = a.animatedFraction
                lp.x = (fx + (tx - fx) * f).toInt(); lp.y = (fy + (ty - fy) * f).toInt()
                try { w.updateViewLayout(v, lp) } catch (_: Exception) {}
            }
            start()
        }
    }

    private fun hide() {
        hideRing()
        if (System.currentTimeMillis() >= holdUntil) hideLabel()
    }

    // Instruction text on screen too, because many phones have no Chinyanja or Icibemba voice.
    private fun showLabel(text: String, top: Boolean, dim: Boolean = false) {
        val w = wm ?: return
        val d = resources.displayMetrics
        val lp = WindowManager.LayoutParams((d.widthPixels * 0.9).toInt(), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT)
        lp.gravity = (if (top) Gravity.TOP else Gravity.BOTTOM) or Gravity.CENTER_HORIZONTAL
        val kb = imeTop?.let { d.heightPixels - it } ?: 0   // keep the card above the keyboard
        lp.y = if (top) (96 * d.density).toInt() else kb + (88 * d.density).toInt()
        val v = label
        if (v == null) {
            val t = TextView(this)
            t.textSize = 20f; t.setTextColor(Color.BLACK); t.typeface = Typeface.DEFAULT_BOLD; t.gravity = Gravity.CENTER
            val p = (14 * d.density).toInt(); t.setPadding(p, p, p, p)
            val g = GradientDrawable(); g.setColor(0xFFF0A935.toInt()); g.cornerRadius = 18 * d.density; t.background = g
            t.text = text; t.alpha = if (dim) 0.55f else 1f; label = t; w.addView(t, lp)
        } else {
            if (v.text.toString() != text) v.text = text
            v.alpha = if (dim) 0.55f else 1f
            w.updateViewLayout(v, lp)
        }
    }
    private fun hideLabel() { label?.let { try { wm?.removeView(it) } catch (_: Exception) {} }; label = null }

    private fun speak(s: Step) {
        val l = Guides.lang
        val res = s.audio?.let { resources.getIdentifier("${it}_$l", "raw", packageName) } ?: 0
        if (res != 0) { mp?.release(); mp = MediaPlayer.create(this, res); mp?.start(); return }
        say(s.say)
    }
    // Uses a voice for the chosen language if the phone has one; otherwise falls back to English.
    private fun say(texts: Map<String, String>) {
        if (!ttsReady) return
        val l = Guides.lang
        val loc = Locale(l)
        val ok = (tts?.isLanguageAvailable(loc) ?: TextToSpeech.LANG_NOT_SUPPORTED) >= TextToSpeech.LANG_AVAILABLE
        val msg = if (ok) texts[l] else texts["en"]
        tts?.language = if (ok) loc else Locale.ENGLISH
        if (msg != null) tts?.speak(msg, TextToSpeech.QUEUE_FLUSH, null, "sg")
    }
}
