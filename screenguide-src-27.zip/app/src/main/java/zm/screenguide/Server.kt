package zm.screenguide

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection

object Server {
    const val URL = "https://screen-guide-server.onrender.com/ask"
    const val TOKEN = "screenguide_sec_9841273560_xyz"

    val configured get() = !URL.contains("YOUR-SERVER")
    private fun base() = URL.removeSuffix("/ask")

    // The free host sleeps when idle. A quiet request on app start wakes it. Nothing personal is sent.
    fun wake() {
        if (!configured) return
        Thread { try { (java.net.URL(base() + "/health").openConnection() as HttpURLConnection).apply { connectTimeout = 10000; readTimeout = 60000 }.responseCode } catch (e: Exception) {} }.start()
    }

    private fun post(path: String, body: JSONObject, installId: String): Pair<Int, String> {
        val c = (java.net.URL(base() + path).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; connectTimeout = 15000; readTimeout = 60000; doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("X-App-Token", TOKEN)
            setRequestProperty("X-Install-Id", installId)
        }
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = c.responseCode
        val text = (if (code in 200..299) c.inputStream else c.errorStream).bufferedReader().readText()
        return Pair(code, text)
    }

    // (worked, text, kind) where kind is "guide" or "answer". Only the typed question and language are sent.
    fun ask(question: String, lang: String, installId: String): Triple<Boolean, String, String> = try {
        val (code, text) = post("/ask", JSONObject().put("question", question).put("lang", lang), installId)
        if (code in 200..299) { val j = JSONObject(text); Triple(true, j.getString("answer"), j.optString("kind", "answer")) }
        else Triple(false, JSONObject(text).optString("detail", "Sorry, I couldn\u2019t answer that. Please try again."), "answer")
    } catch (e: Exception) {
        Triple(false, "No connection. Please check your internet and try again.", "answer")
    }

    class Next(val label: String?, val say: String, val done: Boolean)

    // Smart guide: sends the goal and the words on screen (never passwords or banking apps). Returns the next step.
    fun next(goal: String, lang: String, installId: String, labels: List<String>, history: List<String>, stuck: Boolean = false): Next? = try {
        val body = JSONObject().put("goal", goal).put("lang", lang).put("labels", JSONArray(labels)).put("history", JSONArray(history)).put("stuck", stuck)
        val (code, text) = post("/next", body, installId)
        if (code in 200..299) { val j = JSONObject(text); Next(if (j.isNull("label")) null else j.getString("label"), j.optString("say", ""), j.optBoolean("done")) } else null
    } catch (e: Exception) { null }
}
