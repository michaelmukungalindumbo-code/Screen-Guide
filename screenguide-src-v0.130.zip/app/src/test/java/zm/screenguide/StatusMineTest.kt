package zm.screenguide

import java.io.File
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

// v0.128 (the owner, 25 Nov, after posting "How to use the past papers app" to Status): "what if I want to confirm that it
// actually works, why can't I click on it". Tapping your own post offered only "Remove it from Status". Now it also offers
// "Try it as others see it": the steps come back from the server, exactly as another phone gets them, and start at once.
// It is not counted as a get (the server never counts the maker) and not kept a second time on this phone.
class StatusMineTest {
    private fun src(n: String) = listOf("src/main/java/zm/screenguide/$n", "app/src/main/java/zm/screenguide/$n").map { File(it) }.first { it.exists() }.readText()

    @Test fun yourOwnPostCanBeTried() {
        val m = src("MainActivity.kt")
        val mine = m.substringAfter("private fun myStatus(m: Status.Item)").substringBefore("private fun showGot(")
        assertTrue(mine.contains("Row(\"play\", \"Try it as others see it\") { tryMine(m) }"))
        assertTrue(mine.indexOf("Try it as others see it") < mine.indexOf("Remove it from Status"))   // trying first, removing last
        val tryIt = m.substringAfter("private fun tryMine(m: Status.Item)").substringBefore("private fun showGot(")
        assertTrue(tryIt.contains("Server.statusGet(m.id, Server.installId(this))"))   // the posted copy, from the server
        assertTrue(tryIt.contains("Recipes.fromServer(it, \"shared\")"))
        assertTrue(tryIt.contains("start(g)"))
        assertFalse(tryIt.contains("Recipes.save("))                                     // not kept a second time
    }
}

// v0.129 (the owner, 25 Nov, a picture of the Chats panel: "This feature should be found here"): Status is also in the Chats
// panel, right under "Learn your phone", not only in the ⋮ menu.
class StatusInChatsTest {
    @Test fun statusIsInTheChatsPanel() {
        val m = listOf("src/main/java/zm/screenguide/MainActivity.kt", "app/src/main/java/zm/screenguide/MainActivity.kt").map { File(it) }.first { it.exists() }.readText()
        val panel = m.substringAfter("private fun showChats()").substringBefore("addView(search)")
        val learn = panel.indexOf("addView(action(\"check\", \"Learn your phone\", ink) { showLearn() })")
        val status = panel.indexOf("addView(action(\"play\", \"Status\", ink) { showStatus() })")
        assertTrue(learn > 0 && status > learn)   // right under Learn your phone, above the search box
        assertTrue(m.contains("Row(\"play\", \"Status: tasks others taught\") { showStatus() }"))   // still in the ⋮ menu too
    }
}
