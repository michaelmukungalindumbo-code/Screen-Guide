package zm.screenguide

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

// v0.130, issue #97 (an idea from the watcher's review, sent by the owner, 25 Nov): words like "Navigate up" are unclear to
// a first-time smartphone user. A step that would say "Tap “Navigate up”." now says "Tap the back arrow." (the ring shows
// where). English only: no new Nyanja or Bemba words.
class PlainNamesTest {
    @Test fun plainWords() {
        assertEquals("Tap the back arrow.", StepNav.plainSay("Tap “Navigate up”."))
        assertEquals("Tap the three dots.", StepNav.plainSay("Tap “More options”."))
        assertEquals("Tap the three lines.", StepNav.plainSay("Tap “Open navigation drawer”."))
        assertEquals("Tap “English”.", StepNav.plainSay("Tap “English”."))          // ordinary names stay
        assertEquals("Type “Navigate up”.", StepNav.plainSay("Type “Navigate up”."))  // only "Tap" steps
    }

    @Test fun theWiringIsThere() {
        val g = listOf("src/main/java/zm/screenguide/GuideService.kt", "app/src/main/java/zm/screenguide/GuideService.kt").map { File(it) }.first { it.exists() }.readText()
        assertTrue(g.contains("val st = plain(noted(named(base)))"))
        assertTrue(g.contains("if (Guides.lang != \"en\") return st"))
    }
}
