package zm.screenguide

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

// v0.121, the owner's phone (12 Nov, Infinix, 0.120): his taught "How to scan a document using Google drive". On the
// home screen, with the Drive icon showing at the top, the card said "Not on this screen? Swipe up to find it.
// Tap “Scan Document”." with the swipe arrow. Two causes:
// - Drive was opened from the home screen's Search, an app of its own on Infinix. That step was kept as taught "in the
//   Search app", so on the home screen itself it was never looked for;
// - at a step inside Drive, on the home screen, nothing said "open Drive first".
class TaughtSearchTest {
    private fun src(n: String) = listOf("src/main/java/zm/screenguide/$n", "app/src/main/java/zm/screenguide/$n").map { File(it) }.first { it.exists() }.readText()
    private val drive = "com.google.android.apps.docs"; private val scanner = "com.google.android.gms"

    @Test fun aSearchScreenIsHome() {
        assertTrue(Teach.homeLike("com.transsion.XOSLauncher", isHome = true))
        assertTrue(Teach.homeLike("com.transsion.search", isHome = false))               // Infinix's Search, a screen of its own
        assertTrue(Teach.homeLike("com.sec.android.app.launcher", isHome = false))
        assertFalse(Teach.homeLike(drive, isHome = false))
        assertFalse(Teach.homeLike("com.google.android.googlequicksearchbox", isHome = false))   // the Google app: an app of its own
        assertFalse(Teach.homeLike("", isHome = false))
        assertEquals(Teach.HOME, Teach.where("com.transsion.search", isHome = false))
        assertEquals(Teach.HOME, Teach.where("com.transsion.XOSLauncher", isHome = true))
        assertEquals(drive, Teach.where(drive, isHome = false))
    }

    @Test fun theDriveStepIsLookedForOnTheHomeScreen() {
        // As taught now: a home step, looked for on the home screen and on its Search, never inside Drive
        assertTrue(StepNav.mayLook(0, 3, Teach.where("com.transsion.search", false), "com.transsion.XOSLauncher", home = true, builtIn = false))
        assertTrue(StepNav.mayLook(0, 3, Teach.HOME, "com.transsion.search", home = Teach.homeLike("com.transsion.search", false), builtIn = false))
        assertFalse(StepNav.mayLook(0, 3, Teach.HOME, drive, home = Teach.homeLike(drive, false), builtIn = false))
        // His recording as it is (0.120 kept that step in the Search app): the same
        assertTrue(StepNav.mayLook(0, 3, "com.transsion.search", "com.transsion.XOSLauncher", home = true, builtIn = false))
        assertFalse(StepNav.mayLook(0, 3, "com.transsion.search", drive, home = false, builtIn = false))
        // Steps inside Drive: as before
        assertTrue(StepNav.mayLook(2, 1, drive, drive, home = false, builtIn = false))
        assertFalse(StepNav.mayLook(2, 1, drive, "com.transsion.XOSLauncher", home = true, builtIn = false))
    }

    @Test fun openTheAppFirst() {
        val icons = setOf(drive)
        // Search, Drive (home), +, Scan Document (Drive), then Google's scanner (no icon): at Scan Document, open Drive
        val apps = listOf(Teach.HOME, Teach.HOME, drive, drive, scanner)
        assertEquals(drive, StepNav.appToOpen(apps, 3) { it in icons })
        assertEquals(drive, StepNav.appToOpen(apps, 4) { it in icons })          // in the scanner: the app that opens it
        assertNull(StepNav.appToOpen(apps, 1) { it in icons })                   // a home step: as before
        assertNull(StepNav.appToOpen(apps, 0) { it in icons })
        // A recording that began inside Drive
        assertEquals(drive, StepNav.appToOpen(listOf(drive, drive), 1) { it in icons })
        // Recordings that do not know their apps, built-in guides, and a step in a search screen: as before
        assertNull(StepNav.appToOpen(listOf(null, null, null), 2) { true })
        assertNull(StepNav.appToOpen(listOf("com.transsion.search", drive), 0) { true })
        assertNull(StepNav.appToOpen(listOf(scanner), 0) { it in icons })        // nothing with an icon to open
        assertNull(StepNav.appToOpen(emptyList(), 0) { true })
        assertEquals(drive, StepNav.appToOpen(listOf(Teach.HOME, drive), 7) { it in icons })   // an index past the end
        assertEquals("Tap “Drive” to open it.", StepNav.openIt("Drive"))
        assertEquals("First open “Drive”.", StepNav.openFirst("Drive"))
    }

    @Test fun theWiringIsThere() {
        val g = src("GuideService.kt")
        assertEquals(3, Regex("Teach\\.at = Teach\\.where\\(").findAll(g).count())
        assertFalse(g.contains("Teach.at = if (isHome("))
        val loop = g.substringAfter("for (i in guide.steps.size - 1 downTo 0) {").substringBefore("val node = find(nodes, guide.steps[i])")
        assertTrue(loop.contains("StepNav.mayLook(i, Guides.index, guide.steps[i].app, pkg, Teach.homeLike(pkg, isHome(pkg)),"))
        val lost = g.substringAfter("// Nothing to point at on this screen: never leave the person with nothing.").substringBefore("private fun scrollTo(")
        val open = lost.indexOf("StepNav.appToOpen(guide.steps.map { it.app }, Guides.index)")
        assertTrue(open > 0 && open < lost.indexOf("if (word != null && (home || searchSaid == word)"))   // before the search for an app's name
        assertTrue(lost.indexOf("StepNav.openIt(openName)") in open until lost.indexOf("val word = openName ?: st.match.firstOrNull"))
        assertTrue(lost.contains("if (Teach.homeLike(pkg, home)) StepNav.appToOpen("))                     // only on the home screen or its Search
        assertTrue(lost.contains("if (openName != null) Step(emptyList(), mapOf(\"en\" to StepNav.openFirst(openName)), null) else noted(st)"))
    }
}
