package zm.screenguide

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

// v0.120, the owner's phone (12 Nov, 0.119): he taught "How to make a WhatsApp group call": open WhatsApp, his sister's
// chat, the call button. Recorded: step 2 as "Sis's status. 0 new updates" (the picture's name, not the chat's), and
// step 3 as "Voice call" (the call button, an icon). Trying it: in the chat list the guide skipped step 2 and rang the
// words "Voice call" under a chat; in the chat it rang a "Voice call" message, not the call button.
class TaughtIconsTest {
    private val wa = "com.whatsapp"
    class N(val text: String?, val name: String?)

    @Test fun anIconIsRungAsAnIcon() {
        val screen = listOf(N("Voice call", null), N("Voice call", null), N(null, "Voice call"), N("Sis", null))   // two messages, the call button, a name
        val icon = StepNav.iconFirst(true, screen.filter { it.text == "Voice call" || it.name == "Voice call" }) { it.text.isNullOrBlank() }
        assertEquals(1, icon.size); assertNull(icon[0].text)                                       // the call button only
        val words = StepNav.iconFirst(false, screen.filter { it.text == "Voice call" || it.name == "Voice call" }) { it.text.isNullOrBlank() }
        assertEquals(3, words.size)                                                                 // not an icon step: as before
        val noIcon = StepNav.iconFirst(true, screen.filter { it.text == "Sis" }) { it.text.isNullOrBlank() }
        assertEquals(1, noIcon.size)                                                                // no icon with that name: the words, as before
    }

    @Test fun aRowIsRecordedByItsOwnWords() {
        assertEquals("Sis", StepNav.rowWord(listOf(null, "Sis", "Voice call"), listOf("Sis's status. 0 new updates", null, null)))
        assertEquals("Profile photo", StepNav.rowWord(listOf(null, " "), listOf("Profile photo", null)))   // no words: the picture's name
        assertNull(StepNav.rowWord(emptyList(), emptyList()))
    }

    @Test fun neverFurtherThanTheNextStepInsideAnApp() {
        // In the chat list (step 1 done): step 2, the chat, may be rung; step 3, "Voice call", not yet
        assertTrue(StepNav.mayLook(1, 0, wa, wa, home = false, builtIn = false))
        assertFalse(StepNav.mayLook(2, 0, wa, wa, home = false, builtIn = false))
        assertTrue(StepNav.mayLook(2, 1, wa, wa, home = false, builtIn = false))
    }

    @Test fun keptWithTheStep() {
        Teach.reset("Call")
        Teach.at = wa; assertTrue(Teach.tap("Sis", false)); assertTrue(Teach.tap("Voice call", false, isIcon = true))
        assertEquals(listOf(false, true), Teach.steps.map { it.icon })
        val saved = Teach.pending(); Teach.reset(""); assertTrue(Teach.restore(saved))
        assertEquals(listOf(false, true), Teach.steps.map { it.icon }); assertEquals(listOf(false, true), Teach.guide()!!.steps.map { it.icon })
        Teach.reset("")
        val g = listOf("src/main/java/zm/screenguide/GuideService.kt", "app/src/main/java/zm/screenguide/GuideService.kt").map { File(it) }.first { it.exists() }.readText()
        assertTrue(g.contains("val icon = src != null && !box && src.text.isNullOrBlank() && word == src.contentDescription?.toString()?.trim()"))
        assertTrue(g.contains("val same = StepNav.iconFirst(s.icon,"))
        assertTrue(g.contains("return Teach.pickWord(own(src), row ?: child(src, 0),"))
    }
}
