package zm.screenguide

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

// v0.108, the owner's phone (11 Nov, Infinix, 0.106): Teach a task through a Drive scan. The test line said "0 taps seen"
// through Search, Drive, +, Scan, the camera button and Next, and "1 tap seen" at Upload: the phone reports taps only on
// old-style buttons. The owner chose: work it out from the screen, and ask about the rest.
class TeachWorkedOutTest {
    private fun src(n: String) = listOf("src/main/java/zm/screenguide/$n", "app/src/main/java/zm/screenguide/$n").map { File(it) }.first { it.exists() }.readText()
    private fun says() = Teach.steps.map { it.say["en"] }

    // His own task, as the phone reported it: only Upload's tap
    @Test fun theDriveScan() {
        Teach.reset("How to scan a document using Google drive")
        assertTrue(Teach.opened("Drive"))                                                    // Drive came up from the home screen
        assertEquals("worked out, Drive opened", Teach.note)
        assertTrue(Teach.unknown(listOf("Google Docs", "Scan", "Upload", "Folder", "Home", "Starred", "0971234567", "a@b.com")))   // the scanner opened: which button?
        // v0.119: a new screen gets its own question ("one at a time" lost the camera's steps); the same screen twice: once
        assertFalse(Teach.unknown(listOf("Google Docs", "Scan", "Upload", "Folder", "Home", "Starred")))
        assertTrue(Teach.unknown(listOf("Manual", "Auto capture")))
        Teach.typedIn("Scanned document.pdf"); assertTrue(Teach.tap("Upload", false))        // the one tap the phone reported
        assertEquals(listOf("Tap “Drive”.", "What did you tap here?", "What did you tap here?", "Type “Scanned document.pdf”, then tap “Upload”."), says())
        assertEquals(2, Teach.open())
        assertEquals(listOf("Google Docs", "Scan", "Upload", "Folder", "Home", "Starred"), Teach.choices(1))   // never a number or an address
        // Not answered: left out of the guide, never shared as a step
        assertEquals(listOf(listOf("Drive"), listOf("Upload")), Teach.guide()!!.steps.map { it.match })
        // Answered on the review page
        assertTrue(Teach.answer(1, "Scan")); assertTrue(Teach.answer(2, "Auto capture"))
        assertEquals("Tap “Scan”.", says()[1]); assertEquals(0, Teach.open())
        assertEquals(listOf(listOf("Drive"), listOf("Scan"), listOf("Auto capture"), listOf("Upload")), Teach.guide()!!.steps.map { it.match })
        assertFalse(Teach.answer(1, "Next"))                                                 // no longer a question
        Teach.reset("")
    }

    // The new page is named like exactly one button of the page before: that button was tapped
    @Test fun aPageNamedLikeItsButton() {
        val settings = listOf("Network & internet", "Display", "Sound", "Battery", "Storage")
        assertEquals("Display", Teach.guess(settings, listOf("Display")))
        assertEquals("Network & internet", Teach.guess(settings, listOf("Network and internet", "Network & Internet")))
        assertNull(Teach.guess(settings, listOf("Font size")))                               // no button named so: ask
        assertNull(Teach.guess(listOf("Display", "Display"), emptyList()))
        assertNull(Teach.guess(listOf("Battery", "Battery usage", "OK"), listOf("Battery", "Battery usage")))   // two fit: not sure, ask
        assertEquals("Battery", Teach.guess(listOf("Battery", "Battery usage", "OK"), listOf("Battery", "OK")))  // "OK" is too short to count
        assertNull(Teach.guess(listOf("OK"), listOf("OK")))                                  // too short to be sure
        Teach.reset("x"); assertTrue(Teach.workedOut("Display"))
        assertEquals("Tap “Display”.", says().last()); assertTrue(Teach.note.startsWith("worked out"))
        Teach.reset("")
    }

    @Test fun questionsAreSafeAndFew() {
        Teach.reset("x")
        assertTrue(Teach.unknown((1..40).map { "Button $it" })); assertEquals(12, Teach.choices(0).size)   // a short list to choose from
        Teach.dropLastAsk(); assertTrue(Teach.steps.isEmpty())                               // the tap was reported after all
        Teach.unknown(listOf("Scan")); assertFalse(Teach.answer(0, "0971234567")); assertFalse(Teach.answer(0, "  "))   // typed by hand: never a number
        assertNull(Teach.guide())                                                            // only questions: nothing to share
        Teach.remove(0); assertTrue(Teach.steps.isEmpty() && Teach.asks.isEmpty())
        Teach.reset("")
    }

    @Test fun theWiringIsThere() {
        val g = src("GuideService.kt")
        val scr = g.substringAfter("    private fun teachScreen() {").substringBefore("    // v0.101: the bar never covers")
        assertTrue(scr.contains("if (System.currentTimeMillis() - teachTapAt < 1500) return"))   // a reported tap is never doubled
        // v0.119: and from the home screen's own Search screen
        assertTrue(scr.contains("was != pkg && Teach.openedFrom(was, isHome(was)) && packageManager.getLaunchIntentForPackage(pkg) != null -> Teach.opened(screenName(pkg))"))
        assertTrue(scr.contains("if (isHome(pkg)) return"))
        val read = g.substringAfter("    private fun teachRead()").substringBefore("    private fun teachScreen()")
        assertTrue(read.contains("blockedApps.any { pkg.contains(it, true) }) return null"))    // never in money apps
        assertTrue(read.contains("teachButtons = emptyList(); teachSig = \"secret\""))            // a password screen: nothing kept
        assertFalse(g.contains("dispatchGesture")); assertFalse(g.contains("ACTION_CLICK)"))    // ScreenGuide still never taps
        val m = src("MainActivity.kt")
        assertTrue(m.contains("if (Teach.isAsk(st)) { rows.add(Row(\"\", \"\${i + 1}. What did you tap here?\", \"Choose\", tint = noteColor) { askTaught(i) })"))
    }
}
