package zm.screenguide

import java.io.File
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

// v0.124 (the owner, 21 Nov): "someone can put it on the app as a status just like WhatsApp, where someone can view, and
// if they like the guide, they can then request for it". He chose: everyone sees a posted task (after the server's
// check), "Get it" keeps it on their phone at once, and it stays until its maker removes it.
class StatusTest {
    private fun src(n: String) = listOf("src/main/java/zm/screenguide/$n", "app/src/main/java/zm/screenguide/$n").map { File(it) }.first { it.exists() }.readText()
    private fun step(w: String, app: String? = null, icon: Boolean = false) = Step(listOf(w), mapOf("en" to "Tap “$w”."), null, app = app, icon = icon)
    private val drive = "com.google.android.apps.docs"
    // His taught "How to scan a document using Google drive"
    private val scan = listOf(step("Drive", Teach.HOME), step("Create new", drive), step("Scan", drive), step("Next", "com.google.android.gms", icon = true))

    @Test fun theListFromTheServer() {
        val a = JSONArray()
            .put(JSONObject().put("id", "K7M2QX").put("title", "Scan a document with Drive").put("steps", 4).put("by", "Michael").put("device", "infinix phone").put("gets", 12))
            .put(JSONObject().put("id", "P3RT9W").put("title", "Turn on the torch").put("steps", 1).put("by", "").put("device", "").put("gets", 1).put("mine", true))
            .put(JSONObject().put("id", "").put("title", "broken"))                                  // left out
        val items = Status.items(a)
        assertEquals(listOf("K7M2QX", "P3RT9W"), items.map { it.id })
        assertEquals("Michael · Infinix phone · 4 steps · 12 people got it", Status.line(items[0]))
        assertEquals("1 step · 1 person got it", Status.line(items[1]))                        // no name, no phone kind
        assertTrue(items[1].mine && !items[0].mine)
        assertEquals(emptyList<Status.Item>(), Status.items(null))
        assertEquals("1 step", Status.steps(1)); assertEquals("3 steps", Status.steps(3))
    }

    @Test fun postingItCarefully() {
        assertEquals(listOf("Drive", "Create new", "Scan", "Next"), Status.words(scan + step("scan")))   // each word once
        assertTrue(Status.canPost(scan))
        assertFalse(Status.canPost(scan + Step(listOf(Teach.ASK), mapOf("en" to "?"), null)))            // a question unanswered
        assertFalse(Status.canPost(emptyList()))
        // The maker's first name only, never a number or a whole name
        assertEquals("Michael", Status.firstName("michael Mukunga"))
        assertEquals("", Status.firstName("0977 123"))
        assertEquals("", Status.firstName(""))
        assertEquals("A ScreenGuide user", Status.shownAs(""))
        val c = Status.confirm(Status.words(scan), "Michael")
        assertTrue(c.startsWith("Everyone who uses ScreenGuide will see this task and these words:"))
        assertTrue(c.contains("Drive, Create new, Scan, Next") && c.contains("a person’s name, a phone number or anything private"))
        assertTrue(c.endsWith("Shown as: Michael"))
        // Posted with where each step was taught, so on other phones each step is looked for only there
        val j = Status.stepsJson(scan)
        assertEquals("home", j.getJSONObject(0).getString("a"))
        assertEquals(drive, j.getJSONObject(1).getString("a"))
        assertTrue(j.getJSONObject(3).getBoolean("i") && !j.getJSONObject(1).has("i"))
        assertEquals("Drive", j.getJSONObject(0).getJSONArray("m").getString(0))
    }

    @Test fun lookingBeforeGettingIt() {
        val o = Status.Item("K7M2QX", "Scan a document with Drive", 2, "Michael", "infinix phone", 0, false)
        val p = Status.preview(o, listOf("Tap “Drive” to open it.", "Tap “Create new”."))
        assertTrue(p.startsWith("Michael · Infinix phone · 2 steps\n\n1. Tap “Drive” to open it.\n2. Tap “Create new”."))
        assertTrue(p.contains("never points at payments or passwords"))
        assertEquals(4, Status.REPORT_WHY.size)
    }

    @Test fun theWiringIsThere() {
        val m = src("MainActivity.kt"); val s = src("Server.kt")
        assertTrue(m.contains("Row(\"play\", \"Status: tasks others taught\") { showStatus() }"))
        assertTrue(m.contains("Row(\"globe\", \"Post it as a status, for everyone\") { postKept(k) }"))
        val post = m.substringAfter("private fun postKept(").substringBefore("private fun postNow(")
        assertTrue(post.indexOf("Status.canPost(") in 1 until post.indexOf("Status.confirm("))   // never posted with a "?" step
        assertTrue(m.contains("Server.statusPost(k.title, Status.stepsJson(g.steps)"))
        assertTrue(m.contains("Recipes.save(this, title, g.steps, j.optBoolean(\"sw\"), Recipes.SHARED)"))    // kept as one got from others
        for (p in listOf("\"/status\"", "\"/status/\" + statusId(id) + \"/get\"", "\"/report\"", "\"/remove\"")) assertTrue(p, s.contains(p))
    }
}
