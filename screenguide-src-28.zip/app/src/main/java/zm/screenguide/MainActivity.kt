package zm.screenguide

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.*
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.media.MediaMetadataRetriever
import android.util.Base64
import java.io.ByteArrayOutputStream
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.view.View
import android.speech.tts.TextToSpeech
import java.util.Locale

class MainActivity : Activity() {
    private var typed = ""
    private var note = ""
    private var convs: ArrayList<Conv> = ArrayList()
    private var cur: Conv? = null
    private var incognito = false
    private var lastMsgView: View? = null
    private var attached: List<String> = emptyList()
    private var attachedThumb: Bitmap? = null
    private var input: EditText? = null
    // Light by default (easier in sunlight); follows the phone's dark mode when it is on.
    private val dark: Boolean get() = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    private val ink: Int get() = if (dark) 0xFFF2F4F5.toInt() else 0xFF1F1A14.toInt()
    private val mute: Int get() = if (dark) 0xFF98A2A8.toInt() else 0xFF6B6257.toInt()
    private val green: Int get() = if (dark) 0xFF18C3DA.toInt() else 0xFF1B6B4A.toInt()       // accent
    private val onAccent: Int get() = if (dark) 0xFF06262C.toInt() else Color.WHITE            // text on the accent colour
    private val paper: Int get() = if (dark) 0xFF0B0D0F.toInt() else 0xFFFAF6EF.toInt()
    private val line: Int get() = if (dark) 0xFF2A3034.toInt() else 0xFFE3D8C6.toInt()
    private val card: Int get() = if (dark) 0xFF14181B.toInt() else Color.WHITE
    private val chipBg: Int get() = if (dark) 0xFF1E2428.toInt() else 0xFFF1EADD.toInt()
    private val iconBg: Int get() = if (dark) 0xFF0F2C33.toInt() else 0xFFE3F2EA.toInt()
    private val warmBg: Int get() = if (dark) 0xFF2A2417.toInt() else 0xFFFFF4E0.toInt()
    private val warmLine: Int get() = if (dark) 0xFF5A4A24.toInt() else 0xFFF1D9A8.toInt()
    private val noteColor: Int get() = if (dark) 0xFFF0A935.toInt() else 0xFFB45309.toInt()

    override fun onCreate(b: Bundle?) { super.onCreate(b); Guides.load(this); Server.installId(this); Server.wake(); convs = ChatStore.load(this); build() }
    override fun onResume() { super.onResume(); build() }

    private fun enabled() =
        (Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: "").contains(packageName)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun bg(color: Int, radius: Int, oval: Boolean = false, stroke: Int = 0) = GradientDrawable().apply {
        setColor(color)
        if (stroke != 0) setStroke(dp(1), stroke)
        if (oval) shape = GradientDrawable.OVAL else cornerRadius = dp(radius).toFloat()
    }
    private fun lp(top: Int = 0, bottom: Int = 0) =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(0, dp(top), 0, dp(bottom)) }

    private fun start(g: Guide) {
        if (!enabled()) {
            Toast.makeText(this, "Turn on ScreenGuide first", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); return
        }
        Stats.inc(this, "started"); Guides.active = g; Guides.index = 0
        startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun norm(s: String) = s.lowercase().filter { it.isLetterOrDigit() }
    private fun score(g: Guide, t: String) = g.keywords.count { norm(it).isNotEmpty() && t.contains(norm(it)) }

    private fun ask(text: String) {
        hideKeyboard()
        Stats.inc(this, "questions")
        if (attached.isNotEmpty()) { input = null; typed = text; askServer(if (text.isBlank()) "What should I do next on this screen?" else text); return }
        val t = norm(text)
        if (t.isEmpty()) return
        if (quickOpen(text)) { input = null; typed = ""; return }
        val best = Guides.all.maxByOrNull { score(it, t) }
        input = null; typed = text
        val app = findName(text)
        if (best != null && score(best, t) > 0) { typed = ""; note = ""; start(best) }
        else if (app != null) { typed = ""; note = ""; start(findGuide(app)) }
        else askServer(text)
    }

    private fun persist() { if (!incognito) ChatStore.save(this, convs) }
    private fun newConv(q: String): Conv { val c = Conv(System.currentTimeMillis(), q.trim().take(40), ArrayList()); if (!incognito) convs.add(c); return c }

    private fun askServer(q: String) {
        if (!Server.configured) { note = "I can\u2019t help with that yet. Try these:"; build(); return }
        val imgs = attached; attached = emptyList(); attachedThumb = null
        val conv = cur ?: newConv(q).also { cur = it }
        conv.msgs.add(Msg(true, (if (imgs.isNotEmpty()) "\uD83D\uDCCE " else "") + q))
        persist()
        note = "Looking\u2026"; build()
        val id = Server.installId(this)
        val hist = conv.msgs.dropLast(1).takeLast(8).map { (if (it.mine) "User: " else "Helper: ") + it.text.take(300) }
        Thread {
            val r = Server.ask(q, Guides.lang, id, imgs, hist)
            runOnUiThread {
                note = ""
                if (r.ok) conv.msgs.add(Msg(false, r.text, if (r.kind == "guide") q else null, r.needsApps)) else note = r.text
                persist(); build()
            }
        }.start()
    }

    private fun showPast() {
        if (convs.isEmpty()) { Toast.makeText(this, "No saved chats yet", Toast.LENGTH_SHORT).show(); return }
        val list = convs.reversed()
        AlertDialog.Builder(this).setTitle("Past chats")
            .setItems(list.map { it.title }.toTypedArray()) { _, w -> incognito = false; cur = list[w]; note = ""; build() }
            .setNeutralButton("Clear all") { _, _ -> convs.clear(); cur = null; ChatStore.clear(this); build() }
            .setNegativeButton("Close", null).show()
    }

    private fun toggleIncognito() {
        incognito = !incognito
        cur = null; note = ""   // a new chat starts, and an incognito chat is gone once you leave it
        if (incognito) Toast.makeText(this, "Incognito: this chat will not be saved", Toast.LENGTH_SHORT).show()
        build()
    }

    private fun chatLinks(): LinearLayout = LinearLayout(this).apply {
        layoutParams = lp(0, 4)
        fun link(t: String, f: () -> Unit) = tv(t, 14f, green, 0, true).apply {
            paintFlags = paintFlags or Paint.UNDERLINE_TEXT_FLAG; setPadding(0, dp(8), dp(18), dp(8)); setOnClickListener { f() }
        }
        if (cur != null) addView(link("New chat") { cur = null; note = ""; build() })
        addView(link("Past chats") { showPast() })
        addView(link("Incognito: " + (if (incognito) "On" else "Off")) { toggleIncognito() })
    }

    private fun msgView(m: Msg, last: Boolean): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; layoutParams = lp(0, 10)
        val bubble = tv(m.text, 16f, if (m.mine) onAccent else ink, 0).apply {
            background = if (m.mine) bg(green, 18) else bg(card, 18, false, line)
            setPadding(dp(14), dp(10), dp(14), dp(10))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { gravity = if (m.mine) Gravity.END else Gravity.START }
        }
        addView(bubble)
        if (!m.mine) {
            val gl = m.goal
            val actions = LinearLayout(context).apply { setPadding(0, dp(6), 0, 0) }
            if (gl != null) actions.addView(pill("Show me", green, onAccent) { startSmart(gl, m.needsApps) }.apply {
                setPadding(dp(22), dp(10), dp(22), dp(10))
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { rightMargin = dp(12) }
            })
            actions.addView(tv("Listen", 15f, green, 0, true).apply { setPadding(dp(4), dp(10), dp(14), dp(10)); setOnClickListener { speak(m.text, Guides.lang) } })
            addView(actions)
        }
        if (last) lastMsgView = this
    }

    // Smart guide: needs the person's agreement (given once, usually at setup).
    private fun startSmart(goal: String, needsApps: Boolean = false) {
        val prefs = getSharedPreferences("sg", MODE_PRIVATE)
        if (prefs.getBoolean("smart_ok", false)) { beginSmart(goal, needsApps); return }
        if (prefs.getBoolean("smart_asked", false)) { note = "Smart guide is off. You can turn it on below."; build(); return }
        AlertDialog.Builder(this).setTitle("Let AI help you tap?")
            .setMessage("\u2022 Sends the words on your screen to an AI service, only while you follow a guide. For \"which app can\u2026\" questions it also sends the names of your apps (never banking or money apps)\n\u2022 Never sends passwords\n\u2022 Never works inside banking or mobile money apps")
            .setPositiveButton("Agree") { _, _ -> prefs.edit().putBoolean("smart_ok", true).putBoolean("smart_asked", true).apply(); beginSmart(goal, needsApps) }
            .setNegativeButton("Not now") { _, _ -> note = "OK. I will not use AI on your screen. You can still use these guides:"; build() }.show()
    }

    private fun beginSmart(goal: String, needsApps: Boolean = false) {
        if (!enabled()) { Toast.makeText(this, "Turn on ScreenGuide first", Toast.LENGTH_LONG).show(); startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); return }
        Stats.inc(this, "started"); Guides.aiReset(goal); Guides.aiNeedsApps = needsApps
        Guides.active = Guide("ai", mapOf("en" to goal), mapOf("en" to "Well done!", "ny" to "Zabwino!", "bem" to "Nawamya!"), emptyList(), emptyList())
        Guides.index = 0
        startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun listen(code: Int) {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        try { startActivityForResult(i, code) }
        catch (e: ActivityNotFoundException) { Toast.makeText(this, "Voice input is not available on this phone", Toast.LENGTH_LONG).show() }
    }

    override fun onActivityResult(rc: Int, res: Int, data: Intent?) {
        super.onActivityResult(rc, res, data)
        if (rc == 3) { if (res == RESULT_OK) data?.data?.let { loadMedia(it) }; return }
        if (res != RESULT_OK) return
        val said = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull() ?: return
        if (rc == 2) ask(said) else { input = null; typed = said; build() }
    }

    private fun langDialog() {
        val keys = listOf("en", "ny", "bem")
        AlertDialog.Builder(this).setTitle("Language")
            .setItems(arrayOf("English", "Chinyanja", "Icibemba")) { _, w -> Guides.lang = keys[w]; build() }.show()
    }

    // One screen, shown once: what ScreenGuide does, and the choice about the Smart guide.
    private fun consent() {
        val prefs = getSharedPreferences("sg", MODE_PRIVATE)
        fun go(smart: Boolean) {
            prefs.edit().putBoolean("smart_ok", smart).putBoolean("smart_asked", true).putBoolean("tried_a11y", true).apply()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        AlertDialog.Builder(this).setTitle("Allow ScreenGuide to help you?")
            .setMessage("\u2022 Sees the words on your screen, to show you where to tap\n\u2022 Never taps or types for you\n\u2022 Never works inside banking or mobile money apps\n\nSmart guide (optional): sends the words on your screen to an AI service while you follow a guide, and the names of your apps for \"which app can\u2026\" questions (never banking or money apps). Never passwords.")
            .setPositiveButton("Agree to all") { _, _ -> go(true) }
            .setNeutralButton("Basic only") { _, _ -> go(false) }
            .setNegativeButton("Not now", null).show()
    }

    // "open chrome", "where is whatsapp" -> a one-step guide that points at that app.
    private fun findName(text: String): String? {
        val t = text.trim().lowercase()
        for (p in listOf("open ", "find ", "where is ", "where's ", "show me ", "launch ", "start ", "go to ")) {
            if (t.startsWith(p)) {
                val n = t.removePrefix(p).removePrefix("the ").removePrefix("my ").trim()
                return if (n.isNotEmpty()) n else null
            }
        }
        return null
    }
    private fun findGuide(name: String): Guide {
        val cap = name.split(" ").joinToString(" ") { w -> w.replaceFirstChar { it.uppercase() } }
        return Guide("find", mapOf("en" to cap), mapOf("en" to "Well done!", "ny" to "Zabwino!", "bem" to "Nawamya!"),
            listOf(Step(listOf(name), mapOf("en" to "Tap $cap.", "ny" to "Dinani $cap.", "bem" to "Kandeni $cap."), null)),
            emptyList(), null, mapOf("en" to "Looking for $cap. Swipe up or sideways to see all apps."))
    }

    private var tts: TextToSpeech? = null
    private val tips = listOf(
        "Never tell anyone your PIN. Not even someone who says they work for your mobile money company.",
        "Real mobile money companies never ask for your PIN, by call or by message.",
        "If someone says you won a prize but must send money first, it is a scam.",
        "If someone says they sent you money by mistake and asks you to send it back, check your balance yourself first.",
        "Before you send money, read the name and number on the screen carefully.",
        "If you are not sure, stop and ask someone you trust.")
    private fun showTips() {
        AlertDialog.Builder(this).setTitle("Stay safe from scams")
            .setMessage(tips.joinToString("\n\n") { "\u2022 $it" })
            .setPositiveButton("Close", null).setNeutralButton("Listen") { _, _ -> speakTips() }.show()
    }
    private fun speakTips() = speak(tips.joinToString(" "), "en")

    // Uses a voice for the language if the phone has one, otherwise English.
    private fun speak(text: String, lang: String) {
        fun go(t: TextToSpeech) {
            val loc = Locale(lang)
            t.language = if (t.isLanguageAvailable(loc) >= TextToSpeech.LANG_AVAILABLE) loc else Locale.ENGLISH
            t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "sg")
        }
        val t = tts
        if (t == null) { tts = TextToSpeech(this) { st -> if (st == TextToSpeech.SUCCESS) tts?.let { go(it) } } } else go(t)
    }
    override fun onDestroy() { tts?.shutdown(); super.onDestroy() }

    private fun safeCard(): LinearLayout {
        val icon = IconView(this, "logo", 0xFFB45309.toInt()).apply { background = bg(0xFFFFF0D9.toInt(), 0, true); layoutParams = LinearLayout.LayoutParams(dp(56), dp(56)) }
        val name = TextView(this).apply {
            text = "Stay safe from scams"; textSize = 18f; setTextColor(ink); typeface = Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(16) }
        }
        val go = TextView(this).apply { text = "\u203A"; textSize = 30f; setTextColor(mute) }
        return LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; background = bg(card, 22, false, line); setPadding(dp(16), dp(14), dp(18), dp(14))
            layoutParams = lp(0, 12); setOnClickListener { showTips() }
            addView(icon); addView(name); addView(go)
        }
    }

    // Simple everyday requests open the right app straight away (no AI, no data). Never banking or money apps.
    private val quickApps = listOf(
        listOf("weather", "forecast", "willitrain") to listOf("weather"),
        listOf("alarm", "timer", "stopwatch") to listOf("clock"),
        listOf("calculat") to listOf("calculator"),
        listOf("takeaphoto", "takeapicture", "camera") to listOf("camera"),
        listOf("gallery", "mypictures", "myphotos") to listOf("gallery", "photos"),
        listOf("calendar") to listOf("calendar"),
        listOf("directions", "navigate", "maps") to listOf("maps"))

    private fun quickOpen(text: String): Boolean {
        val low = text.trim().lowercase()
        if (low.split(Regex("\\s+")).size > 9 || low.startsWith("how do") || low.startsWith("how to") || low.startsWith("why")) return false
        val t = norm(text)
        val hit = quickApps.firstOrNull { (terms, _) -> terms.any { t.contains(it) } } ?: return false
        val pm = packageManager
        val ri = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0).firstOrNull { r ->
            val label = r.loadLabel(pm).toString().lowercase()
            hit.second.any { label.contains(it) }
        } ?: return false
        val launch = pm.getLaunchIntentForPackage(ri.activityInfo.packageName) ?: return false
        Toast.makeText(this, "Opening " + ri.loadLabel(pm), Toast.LENGTH_SHORT).show()
        startActivity(launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return true
    }

    // ---- Attach a screenshot or video, then ask what you need ----
    private fun pickMedia() {
        val prefs = getSharedPreferences("sg", MODE_PRIVATE)
        fun open() {
            val i = Intent(Intent.ACTION_GET_CONTENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE)
                .putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/*", "video/*"))
            try { startActivityForResult(Intent.createChooser(i, "Choose a screenshot or video"), 3) }
            catch (e: ActivityNotFoundException) { Toast.makeText(this, "No gallery found on this phone", Toast.LENGTH_LONG).show() }
        }
        if (prefs.getBoolean("attach_ok", false)) { open(); return }
        AlertDialog.Builder(this).setTitle("Attach a picture or video?")
            .setMessage("It is sent to an AI service so it can help you. Do not attach anything that shows PINs, passwords or bank details.")
            .setPositiveButton("OK") { _, _ -> prefs.edit().putBoolean("attach_ok", true).apply(); open() }
            .setNegativeButton("Cancel", null).show()
    }

    private fun shrink(b: Bitmap): Bitmap {
        val m = maxOf(b.width, b.height)
        if (m <= 800) return b
        val f = 800f / m
        return Bitmap.createScaledBitmap(b, (b.width * f).toInt(), (b.height * f).toInt(), true)
    }
    private fun encode(b: Bitmap): String {
        val o = ByteArrayOutputStream(); b.compress(Bitmap.CompressFormat.JPEG, 60, o)
        return Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP)
    }

    private fun loadMedia(uri: android.net.Uri) {
        Toast.makeText(this, "Getting it ready\u2026", Toast.LENGTH_SHORT).show()
        Thread {
            val frames = ArrayList<String>()
            var thumb: Bitmap? = null
            try {
                val type = contentResolver.getType(uri) ?: ""
                if (type.startsWith("video")) {
                    val r = MediaMetadataRetriever(); r.setDataSource(this, uri)
                    val dur = (r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L) * 1000
                    for (f in listOf(0.05, 0.5, 0.95)) {
                        r.getFrameAtTime((dur * f).toLong(), MediaMetadataRetriever.OPTION_CLOSEST_SYNC)?.let { b ->
                            val s = shrink(b); if (thumb == null) thumb = s; frames.add(encode(s))
                        }
                    }
                    r.release()
                } else {
                    contentResolver.openInputStream(uri)?.use { ins ->
                        val bytes = ins.readBytes()
                        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
                        var sample = 1
                        while (o.outWidth / sample > 1600) sample *= 2
                        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })?.let { b ->
                            val s = shrink(b); thumb = s; frames.add(encode(s))
                        }
                    }
                }
            } catch (e: Exception) {}
            val shown = thumb
            runOnUiThread {
                if (frames.isEmpty()) Toast.makeText(this, "I could not open that file.", Toast.LENGTH_LONG).show()
                else { attached = frames; attachedThumb = shown; build() }
            }
        }.start()
    }

    private fun attachRow(): LinearLayout = LinearLayout(this).apply {
        gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(6), 0, dp(6))
        addView(ImageView(context).apply {
            attachedThumb?.let { setImageBitmap(it) }; scaleType = ImageView.ScaleType.CENTER_CROP
            layoutParams = LinearLayout.LayoutParams(dp(56), dp(56))
        })
        addView(TextView(context).apply {
            text = if (attached.size > 1) "Video attached. Now ask your question." else "Picture attached. Now ask your question."
            textSize = 15f; setTextColor(ink)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(12) }
        })
        addView(TextView(context).apply {
            text = "\u2715"; textSize = 20f; setTextColor(mute); setPadding(dp(14), dp(8), dp(14), dp(8)); contentDescription = "Remove"
            setOnClickListener { attached = emptyList(); attachedThumb = null; build() }
        })
    }

    private fun hideKeyboard() {
        val im = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        currentFocus?.let { im.hideSoftInputFromWindow(it.windowToken, 0) }
    }

    // Quick actions in one row right under the Ask box, so they stay visible above the keyboard.
    private fun chipsRow(): HorizontalScrollView = HorizontalScrollView(this).apply {
        isHorizontalScrollBarEnabled = false; layoutParams = lp(0, 14)
        addView(LinearLayout(context).apply {
            Guides.all.forEach { g ->
                addView(TextView(context).apply {
                    text = g.title[Guides.lang] ?: g.title["en"] ?: g.id; textSize = 15f; setTextColor(green); typeface = Typeface.DEFAULT_BOLD
                    background = bg(card, 22, false, green); setPadding(dp(16), dp(10), dp(16), dp(10))
                    layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { rightMargin = dp(8) }
                    setOnClickListener { hideKeyboard(); start(g) }
                })
            }
        })
    }

    private fun tv(t: String, sz: Float, c: Int, pb: Int = 12, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = sz; setTextColor(c); setPadding(0, 0, 0, dp(pb)); if (bold) typeface = Typeface.DEFAULT_BOLD
    }
    private fun pill(t: String, fill: Int, fg: Int, stroke: Int = 0, f: () -> Unit) = TextView(this).apply {
        text = t; textSize = 16f; setTextColor(fg); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
        background = bg(fill, 26, false, stroke); setPadding(dp(20), dp(15), dp(20), dp(15)); setOnClickListener { f() }; layoutParams = lp(0, 10)
    }
    private fun taskCard(g: Guide): LinearLayout {
        val icon = IconView(this, g.id, green).apply { background = bg(iconBg, 0, true); layoutParams = LinearLayout.LayoutParams(dp(56), dp(56)) }
        val name = TextView(this).apply {
            text = g.title[Guides.lang] ?: g.title["en"] ?: g.id; textSize = 18f; setTextColor(ink); typeface = Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(16) }
        }
        val go = TextView(this).apply { text = "\u203A"; textSize = 30f; setTextColor(mute) }
        return LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; background = bg(card, 22, false, line); setPadding(dp(16), dp(14), dp(18), dp(14))
            layoutParams = lp(0, 12); setOnClickListener { start(g) }
            addView(icon); addView(name); addView(go)
        }
    }

    private fun build() {
        typed = input?.text?.toString() ?: typed
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(52), dp(20), dp(28)); setBackgroundColor(paper) }

        val brand = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; layoutParams = lp(0, 28)
            addView(IconView(context, "logo", green).apply { layoutParams = LinearLayout.LayoutParams(dp(34), dp(34)).apply { rightMargin = dp(10) } })
            addView(tv("ScreenGuide", 20f, ink, 0, true))
        }
        col.addView(brand)
        col.addView(tv("What do you need help with?", 28f, ink, 8, true))
        col.addView(tv("I\u2019ll show you where to tap.", 15f, mute, 20))

        val et = EditText(this).apply {
            hint = if (cur?.msgs?.isNotEmpty() == true) "Reply to the helper" else "Type or say what you want to do"; setHintTextColor(0xFF9A8F80.toInt()); setTextColor(ink); textSize = 19f; background = null
            setText(typed); setSingleLine(true); minHeight = dp(56); gravity = Gravity.CENTER_VERTICAL
            inputType = InputType.TYPE_CLASS_TEXT; imeOptions = EditorInfo.IME_ACTION_SEND
            setOnEditorActionListener { v, _, _ -> ask(v.text.toString()); true }
        }
        input = et
        val names = mapOf("en" to "English", "ny" to "Chinyanja", "bem" to "Icibemba")
        val lang = TextView(this).apply {
            text = "${names[Guides.lang]}  \u25BE"; textSize = 15f; setTextColor(ink); gravity = Gravity.CENTER
            background = bg(chipBg, 22); setPadding(dp(16), 0, dp(16), 0)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(44)); setOnClickListener { langDialog() }
        }
        brand.addView(Space(this), LinearLayout.LayoutParams(0, 1, 1f)); brand.addView(lang)   // language sits in the header so the buttons never get squeezed
        val mic = ImageButton(this).apply {
            setImageResource(android.R.drawable.ic_btn_speak_now); setColorFilter(ink); background = bg(chipBg, 0, true)
            layoutParams = LinearLayout.LayoutParams(dp(48), dp(48)).apply { rightMargin = dp(10) }; setOnClickListener { listen(1) }
        }
        val speak = TextView(this).apply {
            text = "Speak"; textSize = 16f; setTextColor(onAccent); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            background = bg(green, 24); setPadding(dp(24), 0, dp(24), 0)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(48)); setOnClickListener { listen(2) }
        }
        val plus = TextView(this).apply {
            text = "+"; textSize = 26f; setTextColor(ink); gravity = Gravity.CENTER; background = bg(chipBg, 0, true)
            contentDescription = "Attach a screenshot or video"
            layoutParams = LinearLayout.LayoutParams(dp(48), dp(48)).apply { rightMargin = dp(8) }; setOnClickListener { pickMedia() }
        }
        val row = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(plus); addView(Space(context), LinearLayout.LayoutParams(0, 1, 1f)); addView(mic); addView(speak)
        }
        col.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = bg(card, 28, false, line); setPadding(dp(20), dp(8), dp(14), dp(14)); layoutParams = lp(0, 20)
            if (attached.isNotEmpty()) addView(attachRow())
            addView(et); addView(row)
        })
        col.addView(tv("Never type your PIN or passwords here.", 12f, mute, 12))
        col.addView(chipsRow())
        if (note.isNotEmpty()) col.addView(tv(note, 15f, noteColor, 12))
        col.addView(chatLinks())
        if (incognito) col.addView(tv("Incognito: this chat will not be saved.", 13f, mute, 8))
        lastMsgView = null
        cur?.let { cv -> cv.msgs.forEachIndexed { i, m -> col.addView(msgView(m, i == cv.msgs.size - 1)) } }

        if (!enabled()) {
            val tried = getSharedPreferences("sg", MODE_PRIVATE).getBoolean("tried_a11y", false)
            col.addView(LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; background = bg(warmBg, 22, false, warmLine); setPadding(dp(18), dp(16), dp(18), dp(8)); layoutParams = lp(0, 20)
                addView(tv("Turn on ScreenGuide", 18f, ink, 8, true))
                addView(tv("\u2022 Sees the words on your screen\n\u2022 Never taps for you\n\u2022 Never in bank or money apps", 15f, ink, 12))
                if (tried) addView(tv("Switch looks grey? Open App info, tap the three dots, then tap Allow restricted settings.", 14f, mute, 10))
                addView(pill("Turn on", green, onAccent) { consent() })
                if (tried) addView(pill("Open App info", card, ink, line) { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) })
            })
        }
        col.addView(tv("All tasks", 15f, mute, 10, true))
        Guides.all.forEach { col.addView(taskCard(it)) }
        col.addView(safeCard())
        if (Guides.active != null) col.addView(pill("Stop guide", card, ink, line) { Guides.active = null; build() })
        if (enabled()) col.addView(tv("Keep ScreenGuide running (battery settings)", 14f, green, 6).apply {
            paintFlags = paintFlags or Paint.UNDERLINE_TEXT_FLAG; setPadding(0, dp(10), 0, dp(6)); setOnClickListener { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
        })
        if (enabled()) {
            val sp = getSharedPreferences("sg", MODE_PRIVATE)
            col.addView(tv("Smart guide: " + (if (sp.getBoolean("smart_ok", false)) "On" else "Off") + " (tap to change)", 14f, green, 6).apply {
                paintFlags = paintFlags or Paint.UNDERLINE_TEXT_FLAG; setPadding(0, dp(6), 0, dp(6))
                setOnClickListener { sp.edit().putBoolean("smart_ok", !sp.getBoolean("smart_ok", false)).putBoolean("smart_asked", true).apply(); build() }
            })
        }
        col.addView(tv("Pilot numbers (tap to copy)", 14f, green, 6).apply {
            paintFlags = paintFlags or Paint.UNDERLINE_TEXT_FLAG; setPadding(0, dp(6), 0, dp(6))
            setOnClickListener {
                (getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager).setPrimaryClip(android.content.ClipData.newPlainText("sg-stats", Stats.dump(this@MainActivity)))
                Toast.makeText(this@MainActivity, Stats.dump(this@MainActivity), Toast.LENGTH_LONG).show()
            }
        })
        if (Guides.seen.isNotEmpty()) col.addView(tv("Copy debug info", 14f, green, 6).apply {
            paintFlags = paintFlags or Paint.UNDERLINE_TEXT_FLAG; setPadding(0, dp(6), 0, dp(6))
            setOnClickListener {
                (getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager).setPrimaryClip(android.content.ClipData.newPlainText("sg", Guides.seen.values.joinToString("\n\n")))
                Toast.makeText(this@MainActivity, "Copied. Paste it to me.", Toast.LENGTH_SHORT).show()
            }
        })
        col.addView(tv("v0.18.1", 12f, 0xFFA89D8C.toInt(), 0).apply { setPadding(0, dp(16), 0, 0) })
        val sv = ScrollView(this).apply { setBackgroundColor(paper); addView(col) }
        setContentView(sv)
        lastMsgView?.let { v -> sv.post { sv.smoothScrollTo(0, maxOf(0, v.top - dp(90))) } }
    }
}

class IconView(c: Context, private val kind: String, private val fg: Int) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; color = fg }
    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        p.strokeWidth = w * 0.085f
        if (kind == "wifi") {
            val cx = w / 2; val cy = h * 0.72f
            for (i in 1..3) { val r = w * 0.15f * i; cv.drawArc(RectF(cx - r, cy - r, cx + r, cy + r), 225f, 90f, false, p) }
            p.style = Paint.Style.FILL; cv.drawCircle(cx, cy, w * 0.05f, p); p.style = Paint.Style.STROKE
        } else {
            cv.drawCircle(w / 2, h / 2, w * 0.3f, p)
            p.style = Paint.Style.FILL; cv.drawCircle(w / 2, h / 2, w * 0.1f, p); p.style = Paint.Style.STROKE
        }
    }
}
