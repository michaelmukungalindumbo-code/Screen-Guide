package zm.screenguide

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.app.Dialog
import android.content.res.ColorStateList
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.text.TextUtils
import android.view.Window
import android.os.CancellationSignal
import androidx.credentials.CredentialManager
import androidx.credentials.CredentialManagerCallback
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.GetCredentialResponse
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.GetCredentialException
import androidx.credentials.exceptions.NoCredentialException
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.util.Base64
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.*
import java.io.ByteArrayOutputStream
import java.util.Locale

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

// The chat screen: header at the top, the conversation in the middle, the message box fixed at the bottom.
class MainActivity : Activity() {
    private var typed = ""
    private var note = ""
    private var convs: ArrayList<Conv> = ArrayList()
    private var cur: Conv? = null
    private var incognito = false
    private var waiting = false
    private var attached: List<String> = emptyList()
    private var attachedThumb: Bitmap? = null
    private var input: EditText? = null
    private var thinkingView: TextView? = null
    private var dots = 0
    private var waitStart = 0L
    private var reqId = 0    // a newer request (or Stop) makes older answers arrive to nobody
    private var failed = false
    private val ui = Handler(Looper.getMainLooper())
    private val dotsRun = object : Runnable {
        override fun run() {
            val v = thinkingView ?: return
            dots = (dots + 1) % 4
            val slow = System.currentTimeMillis() - waitStart > 10000
            v.text = (if (slow) "Still thinking. The connection is slow" else "Thinking") + ".".repeat(dots)
            ui.postDelayed(this, 400)
        }
    }

    // Light by default (easier in sunlight); follows the phone's dark mode when it is on.
    private val dark: Boolean get() = when (Profile.str(this, "theme", "auto")) {
        "light" -> false; "dark" -> true
        else -> (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    }
    private val ink: Int get() = if (dark) 0xFFF2F4F5.toInt() else 0xFF1F1A14.toInt()
    private val mute: Int get() = if (dark) 0xFFADB5BA.toInt() else 0xFF534C45.toInt()
    private val green: Int get() = if (dark) 0xFF18C3DA.toInt() else 0xFF145A3D.toInt()       // accent
    private val onAccent: Int get() = if (dark) 0xFF06262C.toInt() else Color.WHITE            // text on the accent colour
    private val paper: Int get() = if (dark) 0xFF0B0D0F.toInt() else 0xFFFAF6EF.toInt()
    private val line: Int get() = if (dark) 0xFF2A3034.toInt() else 0xFFE3D8C6.toInt()
    private val card: Int get() = if (dark) 0xFF14181B.toInt() else Color.WHITE
    private val chipBg: Int get() = if (dark) 0xFF1E2428.toInt() else 0xFFF1EADD.toInt()
    private val iconBg: Int get() = if (dark) 0xFF0F2C33.toInt() else 0xFFE3F2EA.toInt()
    private val warmBg: Int get() = if (dark) 0xFF2A2417.toInt() else 0xFFFFF4E0.toInt()
    private val warmLine: Int get() = if (dark) 0xFF5A4A24.toInt() else 0xFFF1D9A8.toInt()
    private val noteColor: Int get() = if (dark) 0xFFF0A935.toInt() else 0xFF8A3B05.toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Guides.load(this); Server.installId(this); Server.wake(); convs = ChatStore.load(this)
        Server.pass = getSharedPreferences("sg", MODE_PRIVATE).getString("pass", "") ?: ""
        Account.load(this)
        Server.flush(this)
        build()
        Sync.atStart(this) { runOnUiThread { build() } }
        // Fetch the latest guides from the server in the background; the screen updates if they changed.
        Thread { Server.guides()?.let { t -> runOnUiThread { if (Guides.applyRemote(this, t)) build() } } }.start()
    }
    override fun onResume() {
        super.onResume(); build()
        val p = pending
        if (p != null && enabled()) { pending = null; p() }
    }
    override fun onDestroy() { ui.removeCallbacks(dotsRun); tts?.shutdown(); super.onDestroy() }

    private fun enabled() =
        (Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: "").contains(packageName)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun bg(color: Int, radius: Int, oval: Boolean = false, stroke: Int = 0) = GradientDrawable().apply {
        setColor(color)
        if (stroke != 0) setStroke(dp(1), stroke)
        if (oval) shape = GradientDrawable.OVAL else cornerRadius = dp(radius).toFloat()
    }
    private fun lp(top: Int = 0, bottom: Int = 0) =
        LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(0, dp(top), 0, dp(bottom)) }

    // A short tick under the finger, so people feel that the tap worked.
    private fun View.onTap(f: () -> Unit) = setOnClickListener { v ->
        if (Profile.buzzOn(this@MainActivity)) v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY); f()
    }

    private fun goHome() =
        startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))

    // What the person asked for before ScreenGuide was turned on. It starts by itself when they come back.
    private var pending: (() -> Unit)? = null

    private fun needOn(then: () -> Unit): Boolean {
        if (enabled()) return false
        pending = then; consent(); return true
    }

    private fun start(g: Guide) {
        if (needOn { start(g) }) return
        Stats.inc(this, "started"); Server.event(this, "start", g.id); Guides.active = g; Guides.index = 0
        goHome()
    }

    private fun norm(s: String) = s.lowercase().filter { it.isLetterOrDigit() }
    private fun score(g: Guide, t: String) = g.keywords.count { norm(it).isNotEmpty() && t.contains(norm(it)) }

    // Questions about a problem ("why is my wifi not working") need the helper, not the "turn it on" guide.
    private fun isProblem(text: String): Boolean {
        val low = text.trim().lowercase()
        return listOf("why", "what").any { low.startsWith(it) } ||
            listOf("not working", "doesn't", "does not", "won't", "can't", "cannot", "problem").any { low.contains(it) }
    }

    // Replies that mean "yes, show me" right after an answer that can be shown on screen.
    private val showWords = setOf("showme", "showmehow", "showmewhere", "yesshowme", "okshowme", "pleaseshowme", "showmeplease",
        "guideme", "yes", "yesplease", "ok", "okay", "doit", "go", "start", "letsgo", "yesshowmeplease")

    private fun ask(text: String) {
        hideKeyboard()
        if (waiting) { Toast.makeText(this, "One moment…", Toast.LENGTH_SHORT).show(); return }
        val t = norm(text)
        if (t.isEmpty() && attached.isEmpty()) return
        editing?.let { e ->   // sending an edited message: drop the old one and the answers after it
            val c = cur
            if (c != null) { val i = c.msgs.indexOf(e); if (i >= 0) while (c.msgs.size > i) c.msgs.removeAt(c.msgs.size - 1) }
            editing = null; persist()
        }
        Stats.inc(this, "questions")
        input = null; typed = ""
        if (attached.isNotEmpty()) { askServer(if (text.isBlank()) "What should I do next on this screen?" else text.trim()); return }
        val last = cur?.msgs?.lastOrNull()
        if (t in showWords && last != null && !last.mine && last.goal != null) {
            cur?.msgs?.add(Msg(true, text.trim())); persist()
            startSmart(last.goal, last.needsApps, last.plan); return
        }
        val offered = last?.takeIf { !it.mine }?.guideId?.let { id -> Guides.all.firstOrNull { it.id == id } }
        if (t in showWords && offered != null) { cur?.msgs?.add(Msg(true, text.trim())); persist(); start(offered); return }
        if (quickOpen(text)) { build(); return }
        if (!isProblem(text)) {
            val best = Guides.all.maxByOrNull { score(it, t) }
            if (best != null && score(best, t) > 0) { note = ""; build(); start(best); return }
            val app = findName(text)
            if (app != null) { note = ""; build(); start(findGuide(app)); return }
        }
        askServer(text.trim())
    }

    private val moneyWords = Regex("\\b(mobile money|momo|airtel money|zamtel kwacha|kwacha|send(ing)? money|withdraw\\w*|cash ?out|" +
        "transfer\\w* (money|funds|cash)|pay (a )?bill|bank transfer|deposit)\\b", RegexOption.IGNORE_CASE)
    private fun isMoney(t: String) = moneyWords.containsMatchIn(t)
    private fun noShowMe(t: String): String {
        val kept = t.trim().split(Regex("(?<=[.!?])\\s+")).filterNot { Regex("show me|point to|point at", RegexOption.IGNORE_CASE).containsMatchIn(it) }
        return kept.joinToString(" ").ifBlank { t }
    }

    // The on-screen helper sees only the goal, never the chat. "I want to use it" means nothing on its own,
    // so add the question before it ("What is YouTube"). The server does this too; this covers older servers.
    private fun standAlone(conv: Conv, goal: String): String {
        if (!Regex("\\b(it|this|that|them|there)\\b", RegexOption.IGNORE_CASE).containsMatchIn(goal)) return goal
        if (goal.contains("(about:")) return goal
        val before = conv.msgs.filter { it.mine }.dropLast(1).lastOrNull()?.text?.removePrefix("\uD83D\uDCCE ")?.trim()
        return if (before.isNullOrEmpty()) goal else "$goal (about: $before)"
    }

    private fun persist() { if (!incognito) ChatStore.save(this, convs) }
    private fun newConv(q: String): Conv { val c = Conv(System.currentTimeMillis(), q.trim().take(40), ArrayList()); if (!incognito) convs.add(c); return c }

    // Stop waiting. The answer, if it still comes, is ignored.
    private fun cancelAsk() {
        if (!waiting) return
        reqId++; waiting = false; failed = false; note = "Stopped. Ask again when you are ready."; build()
    }

    // Ask the last question again, without the saved answer.
    private fun retry() {
        val c = cur ?: return
        if (waiting) return
        if (c.msgs.lastOrNull()?.mine == false) c.msgs.removeAt(c.msgs.size - 1)
        val q = c.msgs.lastOrNull()?.takeIf { it.mine && !it.text.startsWith("📎") }?.text ?: return
        askServer(q, again = true)
    }

    private fun askServer(q: String, again: Boolean = false) {
        if (!Server.configured) { note = "I can’t help with that yet. Try these:"; build(); return }
        val imgs = attached; attached = emptyList(); attachedThumb = null
        val conv = cur ?: newConv(q).also { cur = it }
        if (!again) conv.msgs.add(Msg(true, (if (imgs.isNotEmpty()) "📎 " else "") + q))
        persist()
        val my = ++reqId
        note = ""; failed = false; waiting = true; waitStart = System.currentTimeMillis(); build()
        val id = Server.installId(this)
        val hist = conv.msgs.dropLast(1).takeLast(8).map { (if (it.mine) "User: " else "Helper: ") + it.text.take(300) }
        Thread {
            val r = Server.ask(q, Guides.lang, id, imgs, hist, again)
            runOnUiThread {
                if (my != reqId) return@runOnUiThread   // stopped, or a newer question was asked
                waiting = false
                if (r.left >= 0) getSharedPreferences("sg", MODE_PRIVATE).edit().putInt("left", r.left).apply()
                if (r.ok) {
                    // Money tasks are never guided on screen (money apps are off limits), so never offer Show me for them.
                    val money = isMoney(q) || isMoney(r.goal)
                    val goal = if (r.kind == "guide" && !money) standAlone(conv, r.goal.ifBlank { q }) else null
                    conv.msgs.add(Msg(false, if (money) noShowMe(r.text) else r.text, goal, r.needsApps, if (money) emptyList() else r.plan))
                } else {
                    // No answer (no internet, busy, or today's limit): offer what works on the phone alone.
                    failed = true
                    val t = norm(q)
                    val local = Guides.all.maxByOrNull { score(it, t) }?.takeIf { score(it, t) > 0 }
                    if (local != null) conv.msgs.add(Msg(false, r.text + "\n\nThis guide works without the helper:",
                        guideId = local.id))
                    else note = r.text
                }
                persist(); build()
            }
        }.start()
    }

    // ---- Chats, like Claude's side panel: new chat, search, and every saved chat by day ----
    private fun showChats() {
        val d = Dialog(this)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun action(icon: String, text: String, tint: Int, f: () -> Unit) = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; minimumHeight = dp(52); setPadding(dp(20), dp(4), dp(16), dp(4)); background = press(null, 0); isClickable = true
            addView(IconView(context, icon, tint).apply { layoutParams = ll(dp(22), dp(22)).apply { rightMargin = dp(16) } })
            addView(tv(text, 16.5f, tint, 0, true)); onTap { d.dismiss(); f() }
        }
        fun chatRow(c: Conv) = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(9), dp(16), dp(9)); isClickable = true
            background = press(if (c === cur) bg(chipBg, 14) else null, 14)
            layoutParams = lp(0, 0).apply { leftMargin = dp(8); rightMargin = dp(8) }
            addView(tv((if (c.starred) "\u2605 " else "") + c.title.ifBlank { "Chat" }, 16f, ink, 0, c === cur).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END })
            val preview = c.msgs.firstOrNull { !it.mine }?.text ?: c.msgs.lastOrNull()?.text ?: ""
            if (preview.isNotEmpty()) addView(tv(preview.replace("\n", " "), 13.5f, mute, 0).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END; setPadding(0, dp(2), 0, 0) })
            onTap { d.dismiss(); openChat(c) }
            setOnLongClickListener { d.dismiss(); chatOptions(c); true }
        }
        fun fill(q: String) {
            list.removeAllViews()
            val day = 86400000L
            val today = java.util.Calendar.getInstance().apply { set(java.util.Calendar.HOUR_OF_DAY, 0); set(java.util.Calendar.MINUTE, 0); set(java.util.Calendar.SECOND, 0) }.timeInMillis
            val found = convs.filter { c -> q.isBlank() || c.title.contains(q, true) || c.msgs.any { it.text.contains(q, true) } }.sortedByDescending { it.id }
            if (found.isEmpty()) list.addView(tv(if (convs.isEmpty()) "No chats yet. Your chats will appear here." else "No chats match.", 14.5f, mute, 0).apply { setPadding(dp(20), dp(16), dp(20), dp(16)) })
            val groups = LinkedHashMap<String, ArrayList<Conv>>()
            for (c in found) {
                val g = when { c.starred -> "Starred"; c.id >= today -> "Today"; c.id >= today - day -> "Yesterday"; c.id >= today - 6 * day -> "Previous 7 days"; else -> "Older" }
                groups.getOrPut(g) { ArrayList() }.add(c)
            }
            for (g in listOf("Starred", "Today", "Yesterday", "Previous 7 days", "Older")) {
                val cs = groups[g] ?: continue
                list.addView(tv(g, 13f, mute, 0, true).apply { setPadding(dp(20), dp(14), dp(20), dp(4)) })
                cs.forEach { list.addView(chatRow(it)) }
            }
        }
        val search = EditText(this).apply {
            hint = "Search chats"; setHintTextColor(mute); setTextColor(ink); textSize = 16f; setSingleLine(true)
            background = bg(chipBg, 22); setPadding(dp(16), 0, dp(16), 0)
            layoutParams = ll(MATCH, dp(46)).apply { setMargins(dp(16), dp(8), dp(16), dp(4)) }
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(e: Editable?) { fill(e?.toString() ?: "") }
                override fun beforeTextChanged(x: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(x: CharSequence?, a: Int, b: Int, c: Int) {}
            })
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(0, dp(12), 0, dp(10))
            background = GradientDrawable().apply { setColor(card); val r = dp(24).toFloat(); cornerRadii = floatArrayOf(0f, 0f, r, r, r, r, 0f, 0f) }
            addView(LinearLayout(context).apply {
                gravity = Gravity.CENTER_VERTICAL; setPadding(dp(20), 0, dp(8), dp(4))
                addView(tv("Chats", 21f, ink, 0, true).apply { layoutParams = ll(0, WRAP, 1f) })
                addView(iconBtn("close", "Close", ink, 48, 14) { d.dismiss() })
            })
            addView(action("edit", "New chat", green) { newChat() })
            addView(action(if (incognito) "eye" else "eyeoff", if (incognito) "Leave incognito" else "Incognito chat", ink) { toggleIncognito() })
            addView(search)
            addView(ScrollView(context).apply { addView(list) }, ll(MATCH, 0, 1f))
            addView(View(context).apply { setBackgroundColor(line); layoutParams = ll(MATCH, dp(1)).apply { setMargins(0, dp(6), 0, dp(4)) } })
            addView(action("logo", if (Account.signedIn(this@MainActivity)) Account.name(this@MainActivity).ifEmpty { "Your account" } else "Sign in to keep your settings", ink) { showAccount() })
        }
        fill("")
        d.setContentView(box, ViewGroup.LayoutParams(MATCH, MATCH))
        d.window?.let { w ->
            w.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT)); w.setGravity(Gravity.START or Gravity.TOP)
        }
        d.show()
        d.window?.setLayout((resources.displayMetrics.widthPixels * 0.86).toInt(), MATCH)
    }

    private fun openChat(c: Conv) { incognito = false; Guides.incognito = false; cur = c; note = ""; failed = false; editing = null; build() }

    // Hold a chat: star it, rename it, or delete it.
    private fun chatOptions(c: Conv) {
        sheet(c.title.ifBlank { "Chat" }, arrayListOf(
            Row("star", if (c.starred) "Remove star" else "Star") { c.starred = !c.starred; persist(); showChats() },
            Row("edit", "Rename") {
                val box = EditText(this).apply { setText(c.title); textSize = 18f; setSingleLine(true); setSelection(text.length) }
                AlertDialog.Builder(this).setTitle("Rename chat").setView(FrameLayout(this).apply { setPadding(dp(20), dp(8), dp(20), 0); addView(box) })
                    .setPositiveButton("Save") { _, _ -> val t = box.text.toString().trim(); if (t.isNotEmpty()) { c.title = t.take(60); persist(); build() } }
                    .setNegativeButton("Cancel", null).show()
            },
            Row("trash", "Delete", tint = noteColor) {
                AlertDialog.Builder(this).setTitle("Delete this chat?").setMessage(c.title)
                    .setPositiveButton("Delete") { _, _ -> convs.remove(c); if (cur === c) cur = null; persist(); build() }
                    .setNegativeButton("Cancel", null).show()
            }))
    }

    private fun toggleIncognito() {
        incognito = !incognito
        Guides.incognito = incognito
        cur = null; note = ""   // a new chat starts, and an incognito chat is gone once you leave it
        if (incognito) Toast.makeText(this, "Incognito: this chat will not be saved", Toast.LENGTH_SHORT).show()
        build()
    }

    // Everything that is not the conversation lives in one menu, so the chat stays clean.
    private fun showMenu() {
        val rows = ArrayList<Row>()
        rows.add(Row("logo", "Your account", if (Account.signedIn(this)) Account.name(this).ifEmpty { "Signed in" } else "Sign in") { showAccount() })
        if (cur != null) rows.add(Row("edit", "New chat") { newChat() })
        rows.add(Row("menu", "Chats", if (convs.isEmpty()) null else convs.size.toString()) { showChats() })
        rows.add(Row(if (incognito) "eyeoff" else "eye", "Incognito", if (incognito) "On" else "Off") { toggleIncognito() })
        rows.add(Row("star", "Your plan", planValue()) { showPlan() })
        rows.add(Row("sliders", "Customize ScreenGuide") { showCustomize() })
        rows.add(Row("info", "Settings and permissions") { showSettings() })
        rows.add(Row("shield", "Stay safe from scams") { showTips() })
        rows.add(Row("info", "About ScreenGuide", "v0.33") { showAbout() })
        sheet(null, rows)
    }

    private fun newChat() { cur = null; note = ""; failed = false; editing = null; input = null; typed = ""; build() }

    private fun copy(text: String) {
        (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("ScreenGuide", text))
        Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
    }

    private fun share(text: String) {
        try { startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text), "Share with")) }
        catch (e: Exception) { copy(text) }
    }

    // Edit a message you sent: it comes back into the box; sending it again replaces it and everything after it.
    private var editing: Msg? = null
    private fun startEdit(m: Msg) {
        editing = m; input = null; typed = m.text; build()
        ui.post { input?.let { it.requestFocus(); it.setSelection(it.text.length); (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(it, 0) } }
    }

    private fun planValue(): String {
        if (planExpiry() > 0) return "Plus"
        val left = getSharedPreferences("sg", MODE_PRIVATE).getInt("left", -1)
        return if (left >= 0) "Free \u00B7 $left left" else "Free"
    }

    private fun showSettings() {
        val sp = getSharedPreferences("sg", MODE_PRIVATE)
        val smart = sp.getBoolean("smart_ok", false)
        val shot = if (!sp.contains("shot_ok")) "Ask me" else if (sp.getBoolean("shot_ok", false)) "On" else "Off"
        val rows = arrayListOf(
            Row("logo", "Smart guide (AI)", if (smart) "On" else "Off") {
                if (smart) { sp.edit().putBoolean("smart_ok", false).putBoolean("smart_asked", true).apply(); showSettings() }
                else askSmart { showSettings() }
            },
            Row("eye", "Screen pictures when stuck", shot) {
                sp.edit().putBoolean("shot_ok", !sp.getBoolean("shot_ok", false)).apply(); showSettings()
            })
        if (enabled()) rows.add(Row("info", "Keep running in the background", "Battery") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })
        rows.add(Row("sliders", "Accessibility settings") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        sheet("Settings and permissions", rows)
    }

    // ---- Customize: how this person likes ScreenGuide. Kept in their account when signed in. ----
    private fun showCustomize() {
        val names = mapOf("en" to "English", "ny" to "Chinyanja", "bem" to "Icibemba")
        fun cycle(k: String, order: List<String>, def: String) {
            val now = Profile.str(this, k, def); Profile.set(this, k, order[(order.indexOf(now) + 1) % order.size]); build(); showCustomize()
        }
        val name = Profile.str(this, "name", "")
        val rows = arrayListOf(
            Row("edit", "Your name", name.ifEmpty { "Add" }) { askName() },
            Row("globe", "Language", names[Guides.lang]) { langDialog() },
            Row("speaker", "Speak the steps", if (Profile.voiceOn(this)) "On" else "Off") { Profile.set(this, "voice", !Profile.voiceOn(this)); showCustomize() },
            Row("clock", "Speaking speed", if (Profile.str(this, "rate", "normal") == "slow") "Slow" else "Normal") { cycle("rate", listOf("normal", "slow"), "normal") },
            Row("info", "Size of the step card", if (Profile.str(this, "text", "large") == "xl") "Extra large" else "Large") { cycle("text", listOf("large", "xl"), "large") },
            Row("chat", "How I explain", mapOf("auto" to "Learns from you", "simple" to "Very simple", "normal" to "Normal", "short" to "Short")[Profile.str(this, "words", "auto")]) {
                cycle("words", listOf("auto", "simple", "normal", "short"), "auto")
            },
            Row("eye", "Colours", mapOf("auto" to "Like my phone", "light" to "Light", "dark" to "Dark")[Profile.str(this, "theme", "auto")]) {
                cycle("theme", listOf("auto", "light", "dark"), "auto")
            },
            Row("check", "Vibrate on each step", if (Profile.buzzOn(this)) "On" else "Off") { Profile.set(this, "buzz", !Profile.buzzOn(this)); showCustomize() })
        sheet("Customize ScreenGuide", rows, if (Account.signedIn(this)) "Saved to your account, so it comes back on a new phone." else "Sign in to keep these if you change phones.")
    }

    private fun askName() {
        val box = EditText(this).apply {
            setText(Profile.str(this@MainActivity, "name", "")); hint = "Your first name"; textSize = 18f; setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS
        }
        val wrap = FrameLayout(this).apply { setPadding(dp(20), dp(8), dp(20), 0); addView(box) }
        AlertDialog.Builder(this).setTitle("What should I call you?").setView(wrap)
            .setPositiveButton("Save") { _, _ -> Profile.set(this, "name", box.text.toString().trim().take(30)); build(); showCustomize() }
            .setNegativeButton("Cancel", null).show()
    }

    // ---- Your account: sign in with Google (optional) ----
    private fun showAccount() {
        if (!Account.signedIn(this)) {
            sheet("Your account", arrayListOf(Row("logo", "Sign in with Google") { signIn() }),
                "Keep your settings, the tasks your phone learned, and your Plus plan if you change phones. Your chats stay on this phone.")
            return
        }
        val rows = arrayListOf(
            Row("check", Account.name(this).ifEmpty { "Signed in" }, Account.email(this)) {},
            Row("refresh", "Update now") {
                Sync.atStart(this) { runOnUiThread { build(); Toast.makeText(this, "Up to date", Toast.LENGTH_SHORT).show() } }
            },
            Row("close", "Sign out") {
                Account.signOut(this); build(); Toast.makeText(this, "Signed out. Your settings stay on this phone.", Toast.LENGTH_LONG).show()
            },
            Row("trash", "Delete my account", tint = noteColor) { confirmDelete() })
        sheet("Your account", rows, "Your chats are never stored in your account. They stay on this phone.")
    }

    private fun signIn() {
        Toast.makeText(this, "Opening Google sign-in\u2026", Toast.LENGTH_SHORT).show()
        Thread {
            val clientId = Server.googleClientId()
            runOnUiThread {
                if (clientId.isEmpty()) {
                    AlertDialog.Builder(this).setTitle("Sign-in is not ready yet")
                        .setMessage("ScreenGuide accounts are not switched on yet. Everything else works without an account.")
                        .setPositiveButton("OK", null).show()
                    return@runOnUiThread
                }
                val request = GetCredentialRequest.Builder().addCredentialOption(GetSignInWithGoogleOption.Builder(clientId).build()).build()
                CredentialManager.create(this).getCredentialAsync(this, request, CancellationSignal(), java.util.concurrent.Executor { ui.post(it) },
                    object : CredentialManagerCallback<GetCredentialResponse, GetCredentialException> {
                        override fun onResult(result: GetCredentialResponse) {
                            val cred = result.credential
                            val token = if (cred is CustomCredential && cred.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL)
                                try { GoogleIdTokenCredential.createFrom(cred.data).idToken } catch (e: Exception) { null } else null
                            if (token == null) Toast.makeText(this@MainActivity, "Sign-in did not work. Please try again.", Toast.LENGTH_LONG).show()
                            else finishSignIn(token)
                        }
                        override fun onError(e: GetCredentialException) {
                            when (e) {
                                is GetCredentialCancellationException -> {}
                                is NoCredentialException -> AlertDialog.Builder(this@MainActivity).setTitle("No Google account on this phone")
                                    .setMessage("Add one in the phone's Settings, under Accounts, then try again.").setPositiveButton("OK", null).show()
                                else -> Toast.makeText(this@MainActivity, "Sign-in did not work. Please try again.", Toast.LENGTH_LONG).show()
                            }
                        }
                    })
            }
        }.start()
    }

    private fun finishSignIn(idToken: String) {
        val id = Server.installId(this)
        Thread {
            val r = Server.signIn(idToken, id)
            val j = r.json
            if (r.ok && j != null) {
                Account.apply(this, j, j.optString("session"))
                // Bring this phone's settings and learned tasks into the account too.
                Server.saveMe(id, Profile.toJson(this), Recipes.export(this))
            }
            runOnUiThread {
                build()
                if (r.ok) Toast.makeText(this, "Signed in" + (Account.name(this).let { if (it.isEmpty()) "" else " as $it" }), Toast.LENGTH_LONG).show()
                else AlertDialog.Builder(this).setTitle("Sign-in did not work").setMessage(r.message).setPositiveButton("OK", null).show()
            }
        }.start()
    }

    private fun confirmDelete() {
        AlertDialog.Builder(this).setTitle("Delete your account?")
            .setMessage("This deletes your name, email, saved settings, learned tasks and any Plus plan from your account. It cannot be undone. Your chats on this phone are not touched.")
            .setPositiveButton("Delete") { _, _ ->
                val id = Server.installId(this)
                Thread {
                    val ok = Server.deleteMe(id)
                    runOnUiThread {
                        if (ok) { Account.signOut(this); build(); Toast.makeText(this, "Your account is deleted.", Toast.LENGTH_LONG).show() }
                        else Toast.makeText(this, "Could not delete it now. Check your internet and try again.", Toast.LENGTH_LONG).show()
                    }
                }.start()
            }
            .setNegativeButton("Keep it", null).show()
    }

    // Turning on the AI always shows what it sends first (Google Play asks for this, and it is fair).
    private fun askSmart(then: () -> Unit) {
        val prefs = getSharedPreferences("sg", MODE_PRIVATE)
        AlertDialog.Builder(this).setTitle("Let AI help you tap?")
            .setMessage("\u2022 Sends the words on your screen to an AI service, only while you follow a guide. For \"which app can\u2026\" questions it also sends the names of your apps (never banking or money apps)\n\u2022 Never sends passwords\n\u2022 Never works inside banking or mobile money apps")
            .setPositiveButton("Agree") { _, _ -> prefs.edit().putBoolean("smart_ok", true).putBoolean("smart_asked", true).apply(); then() }
            .setNegativeButton("Not now", null).show()
    }

    private fun showAbout() {
        val rows = arrayListOf(
            Row("lock", "Privacy policy") { openLink(Server.privacyUrl) },
            Row("chat", "Pilot numbers (copy)") {
                val s = Stats.dump(this)
                (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("sg-stats", s))
                AlertDialog.Builder(this).setTitle("Pilot numbers (copied)").setMessage(s).setPositiveButton("Close", null).show()
            })
        val sp = getSharedPreferences("sg", MODE_PRIVATE)
        val testBuild = (applicationInfo.flags and android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE) != 0
        val tester = sp.getBoolean("tester", testBuild)
        rows.add(Row("eye", "Show what ScreenGuide sees (for testing)", if (tester) "On" else "Off") {
            sp.edit().putBoolean("tester", !tester).apply(); showAbout()
        })
        if (Guides.seen.isNotEmpty()) rows.add(Row("edit", "Copy debug info") {
            (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("sg",
                "ScreenGuide v" + (try { packageManager.getPackageInfo(packageName, 0).versionName } catch (e: Exception) { "" }) +
                (if (Server.lastProblem.isNotEmpty()) "\nLast server problem: " + Server.lastProblem else "") + "\n\n" + Guides.seen.values.joinToString("\n\n")))
            Toast.makeText(this, "Copied. Paste it to me.", Toast.LENGTH_SHORT).show()
        })
        sheet("ScreenGuide v0.33", rows, "Shows you where to tap, one step at a time. It never taps for you.")
    }

    private fun openLink(url: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
        catch (e: ActivityNotFoundException) { Toast.makeText(this, url, Toast.LENGTH_LONG).show() }
    }

    // ---- Plans: free help every day, more with a code from an organisation ----
    private fun planExpiry(): Long {
        val exp = getSharedPreferences("sg", MODE_PRIVATE).getLong("pass_exp", 0L)
        return if (Server.pass.isNotEmpty() && exp * 1000 > System.currentTimeMillis()) exp else 0L
    }
    private fun day(exp: Long): String = java.text.DateFormat.getDateInstance(java.text.DateFormat.MEDIUM).format(java.util.Date(exp * 1000))

    private fun showPlan() {
        val exp = planExpiry()
        val msg = if (exp > 0)
            "You have ScreenGuide Plus until ${day(exp)}: more questions and more step-by-step help every day."
        else
            "Free every day: a set number of questions and step-by-step help. Quick tasks and safety tips are always free.\n\nGot a ScreenGuide code from a school, church, shop or organisation? Enter it to get Plus."
        AlertDialog.Builder(this).setTitle(if (exp > 0) "ScreenGuide Plus" else "Your plan: Free").setMessage(msg)
            .setPositiveButton("Enter a code") { _, _ -> enterCode() }
            .setNegativeButton("Close", null).show()
    }

    private fun enterCode() {
        val box = EditText(this).apply {
            hint = "For example ABCDE-1234-WXYZ"; textSize = 18f; setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
        }
        val wrap = FrameLayout(this).apply { setPadding(dp(20), dp(8), dp(20), 0); addView(box) }
        AlertDialog.Builder(this).setTitle("Enter your code").setView(wrap)
            .setPositiveButton("Use code") { _, _ ->
                val code = box.text.toString().trim()
                if (code.isEmpty()) return@setPositiveButton
                Toast.makeText(this, "Checking\u2026", Toast.LENGTH_SHORT).show()
                Thread {
                    val r = Server.redeem(code, Server.installId(this))
                    runOnUiThread {
                        if (r.ok) {
                            getSharedPreferences("sg", MODE_PRIVATE).edit().putString("pass", r.pass).putLong("pass_exp", r.expires).apply()
                            Server.pass = r.pass
                            AlertDialog.Builder(this).setTitle("Welcome to Plus!")
                                .setMessage("You have ScreenGuide Plus for ${r.weeks} weeks, until ${day(r.expires)}.")
                                .setPositiveButton("OK", null).show()
                        } else {
                            AlertDialog.Builder(this).setTitle("Code not accepted").setMessage(r.message)
                                .setPositiveButton("Try again") { _, _ -> enterCode() }.setNegativeButton("Close", null).show()
                        }
                        build()
                    }
                }.start()
            }
            .setNegativeButton("Cancel", null).show()
    }

    // Smart guide: needs the person's agreement. Tapping Show me while it is off simply asks again.
    private fun startSmart(goal: String, needsApps: Boolean = false, plan: List<String> = emptyList()) {
        if (getSharedPreferences("sg", MODE_PRIVATE).getBoolean("smart_ok", false)) { beginSmart(goal, needsApps, plan); return }
        askSmart { beginSmart(goal, needsApps, plan) }
    }

    private fun beginSmart(goal: String, needsApps: Boolean, plan: List<String>) {
        if (needOn { beginSmart(goal, needsApps, plan) }) return
        // Done this task on this phone before? Then it runs like a built-in guide: instant, numbered, a ring on every step.
        Recipes.find(this, goal)?.let { learned -> Stats.inc(this, "learned_used"); start(learned); return }
        Stats.inc(this, "started"); Server.event(this, "start", "ai")
        Guides.aiReset(goal); Guides.aiNeedsApps = needsApps; Guides.aiPlan = plan
        // The app the task happens in: getting into it needs no AI (ring on the icon, swipe arrow, done when it opens).
        if (!needsApps) Guides.appFor(this, goal)?.let { (name, pkg, just) -> Guides.aiApp = name; Guides.aiAppPkg = pkg; Guides.aiJustOpen = just }
        Guides.active = Guide("ai", mapOf("en" to goal), mapOf("en" to "Well done!", "ny" to "Zabwino!", "bem" to "Nawamya!"), emptyList(), emptyList())
        Guides.index = 0
        goHome()
    }

    private fun listen(code: Int) {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        try { startActivityForResult(i, code) }
        catch (e: ActivityNotFoundException) { Toast.makeText(this, "Voice input is not available on this phone", Toast.LENGTH_LONG).show() }
    }

    override fun onActivityResult(rc: Int, res: Int, data: Intent?) {
        super.onActivityResult(rc, res, data)
        if (rc == 3) { if (res == RESULT_OK) data?.data?.let { loadMedia(it) }; return }
        if (res != RESULT_OK) return
        val said = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull() ?: return
        if (rc == 2) ask(said) else { input = null; typed = said; build() }
    }

    private fun langDialog() {
        val opts = listOf("en" to "English", "ny" to "Chinyanja", "bem" to "Icibemba")
        sheet("Language", opts.map { (k, n) -> Row(if (k == Guides.lang) "check" else "", n) { Guides.setLang(this, k); Sync.pushProfile(this); build() } },
            "Instructions are spoken and shown in this language.")
    }

    // Google Play needs the accessibility disclosure on its own, with a clear yes. The AI choice comes after, separately.
    private fun consent() {
        val prefs = getSharedPreferences("sg", MODE_PRIVATE)
        AlertDialog.Builder(this).setTitle("ScreenGuide uses Accessibility")
            .setMessage("To show you where to tap, ScreenGuide uses Android\u2019s Accessibility service to read the words on your screen while a guide is running.\n\n" +
                "\u2022 It draws a ring around the button to tap. It never taps or types for you.\n" +
                "\u2022 It skips password boxes and does not work inside banking or mobile money apps.\n" +
                "\u2022 These words stay on your phone, unless you turn on Smart guide on the next screen.")
            .setPositiveButton("I agree") { _, _ ->
                prefs.edit().putBoolean("a11y_ok", true).apply()
                if (prefs.getBoolean("smart_asked", false)) {
                    prefs.edit().putBoolean("tried_a11y", true).apply()
                    Toast.makeText(this, "Find ScreenGuide in the list and turn it on", Toast.LENGTH_LONG).show()
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                } else smartChoice()
            }
            .setNeutralButton("Privacy policy") { _, _ -> openLink(Server.privacyUrl) }
            .setNegativeButton("No thanks") { _, _ -> pending = null }.show()
    }

    private fun smartChoice() {
        val prefs = getSharedPreferences("sg", MODE_PRIVATE)
        fun go(smart: Boolean) {
            prefs.edit().putBoolean("smart_ok", smart).putBoolean("smart_asked", true).putBoolean("tried_a11y", true).apply()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        AlertDialog.Builder(this).setTitle("Turn on Smart guide?")
            .setMessage("Smart guide can help with any app. While you follow a guide, it sends the words on your screen to our AI service so it can choose the next button. For \"which app can\u2026\" questions it also sends the names of your apps.\n\n" +
                "Never passwords. Never banking or mobile money apps. You can change this later in the menu, under Settings.")
            .setPositiveButton("Turn on") { _, _ -> go(true) }
            .setNegativeButton("Not now") { _, _ -> go(false) }
            .setCancelable(false).show()
    }

    // "open chrome", "where is whatsapp" -> a one-step guide that points at that app, only if that app is on the phone.
    private fun findName(text: String): String? {
        val t = text.trim().lowercase().trimEnd('?', '.', '!')
        for (p in listOf("open ", "find ", "where is ", "where's ", "launch ", "go to ", "start ")) {
            if (!t.startsWith(p)) continue
            val n = norm(t.removePrefix(p).removePrefix("the ").removePrefix("my ").removeSuffix(" app"))
            if (n.length < 3 || t.removePrefix(p).trim().split(" ").size > 3) return null
            val pm = packageManager
            return try {
                pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
                    .map { it.loadLabel(pm).toString().trim() }
                    .firstOrNull { norm(it) == n || norm(it).startsWith(n) }
            } catch (e: Exception) { null }
        }
        return null
    }
    private fun findGuide(name: String): Guide =
        Guide("find", mapOf("en" to name), mapOf("en" to "Well done!", "ny" to "Zabwino!", "bem" to "Nawamya!"),
            listOf(Step(listOf(name), mapOf("en" to "Tap $name.", "ny" to "Dinani $name.", "bem" to "Kandeni $name."), null)),
            emptyList(), null, mapOf("en" to "Looking for $name. Swipe up or sideways to see all apps."))

    private var tts: TextToSpeech? = null
    private val tips = listOf(
        "Never tell anyone your PIN. Not even someone who says they work for your mobile money company.",
        "Real mobile money companies never ask for your PIN, by call or by message.",
        "If someone says you won a prize but must send money first, it is a scam.",
        "If someone says they sent you money by mistake and asks you to send it back, check your balance yourself first.",
        "Before you send money, read the name and number on the screen carefully.",
        "If you are not sure, stop and ask someone you trust.")
    private fun showTips() {
        AlertDialog.Builder(this).setTitle("Stay safe from scams")
            .setMessage(tips.joinToString("\n\n") { "• $it" })
            .setPositiveButton("Close", null).setNeutralButton("Listen") { _, _ -> speak(tips.joinToString(" "), "en") }.show()
    }

    // Uses a voice for the language if the phone has one, otherwise English.
    private fun speak(text: String, lang: String) {
        fun go(t: TextToSpeech) {
            val loc = Locale(lang)
            t.language = if (t.isLanguageAvailable(loc) >= TextToSpeech.LANG_AVAILABLE) loc else Locale.ENGLISH
            t.setSpeechRate(Profile.speechRate(this))
            t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "sg")
        }
        val t = tts
        if (t == null) { tts = TextToSpeech(this) { st -> if (st == TextToSpeech.SUCCESS) tts?.let { go(it) } } } else go(t)
    }

    // Simple everyday requests open the right app straight away (no AI, no data). Never banking or money apps.
    private val quickApps = listOf(
        listOf("weather", "forecast", "willitrain") to listOf("weather"),
        listOf("alarm", "timer", "stopwatch") to listOf("clock"),
        listOf("calculat") to listOf("calculator"),
        listOf("takeaphoto", "takeapicture", "camera") to listOf("camera"),
        listOf("gallery", "mypictures", "myphotos") to listOf("gallery", "photos"),
        listOf("calendar") to listOf("calendar"),
        listOf("directions", "navigate", "maps") to listOf("maps"))

    private fun quickOpen(text: String): Boolean {
        val low = text.trim().lowercase()
        if (low.split(Regex("\\s+")).size > 9 || low.startsWith("how do") || low.startsWith("how to") || isProblem(text)) return false
        val t = norm(text)
        val hit = quickApps.firstOrNull { (terms, _) -> terms.any { t.contains(it) } } ?: return false
        val pm = packageManager
        val ri = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0).firstOrNull { r ->
            val label = r.loadLabel(pm).toString().lowercase()
            hit.second.any { label.contains(it) }
        } ?: return false
        val launch = pm.getLaunchIntentForPackage(ri.activityInfo.packageName) ?: return false
        Toast.makeText(this, "Opening " + ri.loadLabel(pm), Toast.LENGTH_SHORT).show()
        startActivity(launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return true
    }

    // ---- Attach a screenshot or video, then ask what you need ----
    private fun pickMedia() {
        val prefs = getSharedPreferences("sg", MODE_PRIVATE)
        fun open() {
            val i = Intent(Intent.ACTION_GET_CONTENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE)
                .putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/*", "video/*"))
            try { startActivityForResult(Intent.createChooser(i, "Choose a screenshot or video"), 3) }
            catch (e: ActivityNotFoundException) { Toast.makeText(this, "No gallery found on this phone", Toast.LENGTH_LONG).show() }
        }
        if (prefs.getBoolean("attach_ok", false)) { open(); return }
        AlertDialog.Builder(this).setTitle("Attach a picture or video?")
            .setMessage("It is sent to an AI service so it can help you. Do not attach anything that shows PINs, passwords or bank details.")
            .setPositiveButton("OK") { _, _ -> prefs.edit().putBoolean("attach_ok", true).apply(); open() }
            .setNegativeButton("Cancel", null).show()
    }

    private fun shrink(b: Bitmap): Bitmap {
        val m = maxOf(b.width, b.height)
        if (m <= 800) return b
        val f = 800f / m
        return Bitmap.createScaledBitmap(b, (b.width * f).toInt(), (b.height * f).toInt(), true)
    }
    private fun encode(b: Bitmap): String {
        val o = ByteArrayOutputStream(); b.compress(Bitmap.CompressFormat.JPEG, 60, o)
        return Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP)
    }

    private fun loadMedia(uri: Uri) {
        Toast.makeText(this, "Getting it ready…", Toast.LENGTH_SHORT).show()
        Thread {
            val frames = ArrayList<String>()
            var thumb: Bitmap? = null
            try {
                val type = contentResolver.getType(uri) ?: ""
                if (type.startsWith("video")) {
                    val r = MediaMetadataRetriever(); r.setDataSource(this, uri)
                    val dur = (r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L) * 1000
                    for (f in listOf(0.05, 0.5, 0.95)) {
                        r.getFrameAtTime((dur * f).toLong(), MediaMetadataRetriever.OPTION_CLOSEST_SYNC)?.let { b ->
                            val s = shrink(b); if (thumb == null) thumb = s; frames.add(encode(s))
                        }
                    }
                    r.release()
                } else {
                    contentResolver.openInputStream(uri)?.use { ins ->
                        val bytes = ins.readBytes()
                        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
                        var sample = 1
                        while (o.outWidth / sample > 1600) sample *= 2
                        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })?.let { b ->
                            val s = shrink(b); thumb = s; frames.add(encode(s))
                        }
                    }
                }
            } catch (e: Exception) {}
            val shown = thumb
            runOnUiThread {
                if (frames.isEmpty()) Toast.makeText(this, "I could not open that file.", Toast.LENGTH_LONG).show()
                else { attached = frames; attachedThumb = shown; build() }
            }
        }.start()
    }

    private fun hideKeyboard() {
        val im = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        currentFocus?.let { im.hideSoftInputFromWindow(it.windowToken, 0) }
    }

    // ---- Small building blocks ----
    private val ripple: Int get() = if (dark) 0x33FFFFFF else 0x1F000000
    // Every tap shows a soft ripple, so people can see that it landed.
    private fun press(base: Drawable?, radius: Int, oval: Boolean = false): Drawable =
        RippleDrawable(ColorStateList.valueOf(ripple), base, bg(Color.BLACK, radius, oval))
    private fun ll(w: Int, h: Int, weight: Float = 0f) = LinearLayout.LayoutParams(w, h, weight)

    private fun tv(t: String, sz: Float, c: Int, pb: Int = 12, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = sz; setTextColor(c); setPadding(0, 0, 0, dp(pb)); if (bold) typeface = Typeface.DEFAULT_BOLD
    }
    private fun pill(t: String, fill: Int, fg: Int, stroke: Int = 0, f: () -> Unit) = TextView(this).apply {
        text = t; textSize = 16f; setTextColor(fg); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
        background = press(bg(fill, 26, false, stroke), 26); setPadding(dp(20), dp(14), dp(20), dp(14)); minHeight = dp(52)
        onTap { f() }; layoutParams = lp(0, 10)
    }
    // A round icon button: 48dp to touch, the picture smaller inside.
    private fun iconBtn(kind: String, desc: String, tint: Int, size: Int = 48, pad: Int = 12, fill: Int = 0, f: () -> Unit) =
        IconView(this, kind, tint).apply {
            contentDescription = desc; setPadding(dp(pad), dp(pad), dp(pad), dp(pad)); layoutParams = ll(dp(size), dp(size))
            background = press(if (fill != 0) bg(fill, 0, true) else null, 0, true); isClickable = true; onTap { f() }
        }
    // The big green button that starts a guide on the real screen. The most important button, so it is the biggest.
    private fun primary(label: String, f: () -> Unit) = LinearLayout(this).apply {
        gravity = Gravity.CENTER; background = press(bg(green, 28), 28); minimumHeight = dp(54)
        setPadding(dp(18), dp(12), dp(18), dp(12)); contentDescription = label; isClickable = true; onTap { f() }
        layoutParams = lp(12, 0)
        addView(IconView(context, "play", onAccent).apply { layoutParams = ll(dp(16), dp(16)).apply { rightMargin = dp(10) } })
        addView(TextView(context).apply { text = label; textSize = 17f; setTextColor(onAccent); typeface = Typeface.DEFAULT_BOLD; maxLines = 2 })
    }
    private fun section(t: String) = tv(t, 14f, mute, 0, true).apply { setPadding(0, dp(20), 0, dp(10)) }
    private fun iconPad(kind: String) = if (kind in listOf("wifi", "bluetooth", "airplane", "hotspot")) 3 else 11

    // A full-width card with a picture, a name and an arrow.
    private fun iconCard(kind: String, title: String, tint: Int, tintBg: Int, sub: String? = null, subColor: Int = green, f: () -> Unit): LinearLayout {
        val icon = IconView(this, kind, tint).apply {
            val pd = dp(iconPad(kind)); setPadding(pd, pd, pd, pd); background = bg(tintBg, 0, true); layoutParams = ll(dp(46), dp(46))
        }
        val name = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; layoutParams = ll(0, WRAP, 1f).apply { leftMargin = dp(14) }
            addView(TextView(context).apply { text = title; textSize = 16.5f; setTextColor(ink); typeface = Typeface.DEFAULT_BOLD })
            if (sub != null) addView(TextView(context).apply { text = sub; textSize = 13.5f; setTextColor(subColor); setPadding(0, dp(2), 0, 0) })
        }
        val go = TextView(this).apply { text = "\u203A"; textSize = 26f; setTextColor(mute); setPadding(dp(8), 0, 0, dp(2)) }
        return LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; background = press(bg(card, 20, false, line), 20); setPadding(dp(14), dp(12), dp(16), dp(12))
            layoutParams = lp(0, 10); minimumHeight = dp(68); isClickable = true; contentDescription = title; onTap { f() }
            addView(icon); addView(name); addView(go)
        }
    }
    // A tile for the quick tasks: picture on top, name below. Two per row, so they all fit on one screen.
    private fun tile(kind: String, title: String, tint: Int, tintBg: Int, sub: String?, f: () -> Unit) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; background = press(bg(card, 22, false, line), 22)
        setPadding(dp(14), dp(14), dp(14), dp(14)); minimumHeight = dp(112); isClickable = true; contentDescription = title; onTap { f() }
        addView(IconView(context, kind, tint).apply {
            val pd = dp(iconPad(kind)); setPadding(pd, pd, pd, pd); background = bg(tintBg, 0, true); layoutParams = ll(dp(46), dp(46))
        })
        addView(TextView(context).apply { text = title; textSize = 16f; setTextColor(ink); typeface = Typeface.DEFAULT_BOLD; maxLines = 2; setPadding(0, dp(12), 0, 0) })
        if (sub != null) addView(TextView(context).apply { text = sub; textSize = 12.5f; setTextColor(green); maxLines = 1; ellipsize = TextUtils.TruncateAt.END; setPadding(0, dp(2), 0, 0) })
    }
    private fun grid(col: LinearLayout, items: List<View>) {
        items.chunked(2).forEach { pair ->
            col.addView(LinearLayout(this).apply {
                layoutParams = lp(0, 10)
                pair.forEachIndexed { i, v -> addView(v, ll(0, MATCH, 1f).apply { if (i == 0) rightMargin = dp(10) }) }
                if (pair.size == 1) addView(Space(context), ll(0, 1, 1f))
            })
        }
    }
    private fun taskTile(g: Guide) = tile(g.id, g.title[Guides.lang] ?: g.title["en"] ?: g.id, green, iconBg,
        g.by?.let { "\u2714 Verified by $it" }) { start(g) }
    private fun safeCard() = iconCard("shield", "Stay safe from scams", noteColor, if (dark) 0xFF2A2417.toInt() else 0xFFFFF0D9.toInt(),
        "Six rules that protect your money", mute) { showTips() }

    private fun setupCard(): LinearLayout {
        val tried = getSharedPreferences("sg", MODE_PRIVATE).getBoolean("tried_a11y", false)
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = bg(warmBg, 22, false, warmLine); setPadding(dp(18), dp(18), dp(18), dp(8)); layoutParams = lp(0, 6)
            addView(LinearLayout(context).apply {
                gravity = Gravity.CENTER_VERTICAL
                addView(IconView(context, "logo", green).apply { setPadding(dp(8), dp(8), dp(8), dp(8)); background = bg(card, 0, true); layoutParams = ll(dp(42), dp(42)).apply { rightMargin = dp(12) } })
                addView(tv("One step before you start", 18f, ink, 0, true).apply { layoutParams = ll(0, WRAP, 1f) })
            })
            listOf("Shows you where to tap", "Never taps for you", "Never works in bank or money apps").forEach { t ->
                addView(LinearLayout(context).apply {
                    gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(10), 0, 0)
                    addView(IconView(context, "check", green).apply { layoutParams = ll(dp(18), dp(18)).apply { rightMargin = dp(10) } })
                    addView(tv(t, 15f, ink, 0))
                })
            }
            if (tried) addView(tv("Switch looks grey? Open App info, tap the three dots, then tap Allow restricted settings.", 14f, mute, 0).apply { setPadding(0, dp(14), 0, 0) })
            addView(pill("Turn on ScreenGuide", green, onAccent) { consent() }.apply { layoutParams = lp(16, 10) })
            if (tried) addView(pill("Open App info", card, ink, line) {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            })
        }
    }

    private fun guideBanner(): LinearLayout = LinearLayout(this).apply {
        gravity = Gravity.CENTER_VERTICAL; background = bg(warmBg, 18, false, warmLine); setPadding(dp(14), dp(4), dp(4), dp(4)); layoutParams = lp(8, 8)
        addView(IconView(context, "logo", noteColor).apply { layoutParams = ll(dp(20), dp(20)).apply { rightMargin = dp(10) } })
        addView(tv("A guide is running on your screen.", 15f, ink, 0).apply { layoutParams = ll(0, WRAP, 1f) })
        addView(TextView(context).apply {
            text = "Stop"; textSize = 15f; setTextColor(green); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            setPadding(dp(16), 0, dp(16), 0); minHeight = dp(48); background = press(null, 24)
            onTap {
                Server.event(this@MainActivity, "stop", Guides.active?.id ?: "unknown")
                Guides.active = null; Guides.aiStep = null; Stats.inc(this@MainActivity, "stopped"); build()
            }
        })
    }

    // A panel that slides up from the bottom, in the app's own colours, instead of the phone's plain pop-up list.
    private class Row(val icon: String?, val text: String, val value: String? = null, val tint: Int = 0, val f: () -> Unit)

    private fun sheet(title: String?, rows: List<Row>, foot: String? = null) {
        val d = Dialog(this)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        rows.forEach { r ->
            val fg = if (r.tint != 0) r.tint else ink
            list.addView(LinearLayout(this).apply {
                gravity = Gravity.CENTER_VERTICAL; minimumHeight = dp(56); setPadding(dp(22), dp(6), dp(20), dp(6))
                background = press(null, 0); isClickable = true; contentDescription = r.text + (r.value?.let { ", $it" } ?: "")
                when {
                    r.icon == "" -> addView(Space(context), ll(dp(22), dp(22)).apply { rightMargin = dp(18) })
                    r.icon != null -> addView(IconView(context, r.icon, if (r.icon == "check") green else fg).apply { layoutParams = ll(dp(22), dp(22)).apply { rightMargin = dp(18) } })
                }
                addView(TextView(context).apply { text = r.text; textSize = 16.5f; setTextColor(fg); maxLines = 2; layoutParams = ll(0, WRAP, 1f) })
                if (r.value != null) addView(TextView(context).apply { text = r.value; textSize = 14.5f; setTextColor(mute); maxLines = 1; setPadding(dp(12), 0, 0, 0) })
                onTap { d.dismiss(); r.f() }
            })
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(0, dp(10), 0, dp(18))
            background = GradientDrawable().apply { setColor(card); val r = dp(24).toFloat(); cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f) }
            addView(View(context).apply { background = bg(line, 3); layoutParams = ll(dp(40), dp(5)).apply { gravity = Gravity.CENTER_HORIZONTAL; bottomMargin = dp(6) } })
            if (title != null) addView(tv(title, 14f, mute, 0, true).apply { setPadding(dp(22), dp(10), dp(22), dp(6)) })
            addView(ScrollView(context).apply { addView(list) }, ll(MATCH, WRAP))
            if (foot != null) addView(tv(foot, 13.5f, mute, 0).apply { setPadding(dp(22), dp(12), dp(22), 0) })
        }
        d.setContentView(box)
        d.window?.let { w ->
            w.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT)); w.setGravity(Gravity.BOTTOM)
            w.attributes = w.attributes.apply { windowAnimations = android.R.style.Animation_InputMethod }
        }
        d.show()
        d.window?.setLayout(MATCH, WRAP)
    }

    // ---- The screen ----
    private fun header(): LinearLayout = LinearLayout(this).apply {
        gravity = Gravity.CENTER_VERTICAL; setPadding(dp(4), dp(8), dp(4), dp(4))
        addView(iconBtn("menu", "Chats", ink, 48, 13) { showChats() })
        addView(IconView(context, if (incognito) "eyeoff" else "logo", if (incognito) noteColor else green).apply {
            layoutParams = ll(dp(24), dp(24)).apply { leftMargin = dp(2); rightMargin = dp(8) }
            if (incognito) { contentDescription = "Incognito is on. Tap to turn it off"; isClickable = true; onTap { toggleIncognito() } }
        })
        addView(LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL; layoutParams = ll(0, WRAP, 1f)
            addView(tv(if (incognito) "Incognito" else "ScreenGuide", 19f, if (incognito) noteColor else ink, 0, true).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END })
            if (incognito) addView(tv("Nothing is saved", 12f, mute, 0))
        })
        addView(iconBtn("edit", "New chat", ink, 48, 13) { newChat() })
        addView(iconBtn("dots", "Menu", ink, 48, 13) { showMenu() })
    }

    // The language, where a first-time user starts (it moved out of the header to make room for Chats).
    private fun langChip(): View = LinearLayout(this).apply {
        gravity = Gravity.CENTER_VERTICAL; background = press(bg(chipBg, 22), 22); setPadding(dp(12), 0, dp(14), 0)
        layoutParams = ll(WRAP, dp(44)).apply { topMargin = dp(2); bottomMargin = dp(4) }; isClickable = true; contentDescription = "Language"
        onTap { langDialog() }
        addView(IconView(context, "globe", ink).apply { layoutParams = ll(dp(16), dp(16)).apply { rightMargin = dp(8) } })
        addView(tv(mapOf("en" to "English", "ny" to "Chinyanja", "bem" to "Icibemba")[Guides.lang] ?: "English", 14.5f, ink, 0))
        addView(tv("  \u25BE", 13f, mute, 0))
    }

    private fun greeting(): String {
        val h = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        val hello = if (h < 12) "Good morning" else if (h < 17) "Good afternoon" else "Good evening"
        val name = Profile.str(this, "name", "").trim()
        return if (name.isEmpty()) hello else "$hello, $name"
    }

    private val examples = listOf("How do I make the text bigger?", "How do I install WhatsApp?", "Why is my phone slow?", "How do I take a screenshot?")

    // Ideas for a first question, for people who do not know what to ask yet.
    private fun suggestions(): View = HorizontalScrollView(this).apply {
        isHorizontalScrollBarEnabled = false; layoutParams = lp(2, 0)
        addView(LinearLayout(context).apply {
            examples.forEach { q ->
                addView(TextView(context).apply {
                    text = q; textSize = 14.5f; setTextColor(ink); gravity = Gravity.CENTER
                    background = press(bg(card, 22, false, line), 22); setPadding(dp(16), 0, dp(16), 0)
                    layoutParams = ll(WRAP, dp(44)).apply { rightMargin = dp(8) }; onTap { ask(q) }
                })
            }
        })
    }

    private fun welcome(col: LinearLayout) {
        col.addView(tv(greeting(), 15f, green, 2, true).apply { setPadding(0, dp(16), 0, dp(4)) })
        col.addView(tv("What do you need help with?", 26f, ink, 6, true))
        col.addView(tv("Ask in your own words. I\u2019ll show you where to tap, one step at a time.", 16f, mute, 12).apply { setLineSpacing(0f, 1.2f) })
        col.addView(langChip())
        if (note.isNotEmpty()) col.addView(tv(note, 15f, noteColor, 12))
        if (!enabled()) col.addView(setupCard())
        col.addView(section("Try asking"))
        col.addView(suggestions())
        col.addView(section("Quick tasks"))
        grid(col, Guides.all.map { taskTile(it) })
        val learned = Recipes.recent(this, 4)
        if (learned.isNotEmpty()) {
            col.addView(section("Learned on this phone"))
            grid(col, learned.map { g ->
                val name = g.title["en"] ?: ""
                tile("logo", name, green, iconBg, "${g.steps.size} steps \u00B7 no waiting") { start(g) }.apply {
                    setOnLongClickListener {
                        AlertDialog.Builder(this@MainActivity).setTitle("Forget this task?").setMessage(name)
                            .setPositiveButton("Forget") { _, _ -> Recipes.forget(this@MainActivity, name); build() }
                            .setNegativeButton("Keep", null).show()
                        true
                    }
                }
            })
        }
        col.addView(safeCard())
    }

    private fun userBubble(m: Msg): LinearLayout = LinearLayout(this).apply {
        gravity = Gravity.END; layoutParams = lp(18, 2)
        addView(TextView(context).apply {
            text = m.text; textSize = 16f; setTextColor(ink); background = press(bg(if (m === editing) line else chipBg, 20), 20); setLineSpacing(0f, 1.15f)
            setPadding(dp(16), dp(10), dp(16), dp(11)); maxWidth = (resources.displayMetrics.widthPixels * 0.8).toInt()
            // Hold your message to edit or copy it.
            setOnLongClickListener {
                val rows = arrayListOf(Row("copy", "Copy") { copy(m.text) })
                if (!m.text.startsWith("\uD83D\uDCCE") && !waiting) rows.add(0, Row("edit", "Edit") { startEdit(m) })
                sheet(null, rows); true
            }
        })
        if (m === editing) addView(tv("Editing", 12f, mute, 0).apply { setPadding(0, dp(4), dp(6), 0) })
    }

    private val rated = HashMap<Msg, String>()   // this session's thumbs, so the choice stays visible

    private fun helperBlock(m: Msg, asked: Msg?, last: Boolean = false): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; layoutParams = lp(18, 2)
        addView(TextView(context).apply {
            text = m.text; textSize = 16.5f; setTextColor(ink); setLineSpacing(0f, 1.3f)
            // Hold an answer to copy, share or hear it.
            setOnLongClickListener {
                sheet(null, arrayListOf(Row("copy", "Copy") { copy(m.text) }, Row("share", "Share") { share(m.text) },
                    Row("speaker", "Listen") { speak(m.text, Guides.lang) })); true
            }
        })
        val g = m.goal
        val builtIn = m.guideId?.let { id -> Guides.all.firstOrNull { it.id == id } }
        if (g != null && m.plan.isNotEmpty()) addView(steps(m.plan))
        if (builtIn != null) addView(primary("Show me: " + (builtIn.title[Guides.lang] ?: builtIn.title["en"] ?: "")) { start(builtIn) })
        else if (g != null) addView(primary("Show me on my screen") { startSmart(g, m.needsApps, m.plan) })
        else if (asked?.mine == true && isMoney(asked.text)) addView(safeCard().apply { layoutParams = lp(12, 0) })
        val row = LinearLayout(context).apply { gravity = Gravity.CENTER_VERTICAL; layoutParams = ll(WRAP, WRAP).apply { leftMargin = -dp(11); topMargin = dp(4) } }
        row.addView(iconBtn("speaker", "Listen", mute, 44, 12) { speak(m.text, Guides.lang) })
        row.addView(iconBtn("copy", "Copy", mute, 44, 12) { copy(m.text) })
        if (last && m.guideId == null && asked?.mine == true && !asked.text.startsWith("\uD83D\uDCCE"))
            row.addView(iconBtn("refresh", "Try again", mute, 44, 12) { retry() })
        val up = iconBtn("up", "Good answer", mute, 44, 12) {}
        val down = iconBtn("down", "Bad answer", mute, 44, 12) {}
        fun showRating(r: String?) {
            up.tint(if (r == "up") green else mute); down.tint(if (r == "down") noteColor else mute)
            up.visibility = if (r == "down") View.GONE else View.VISIBLE
            down.visibility = if (r == "up") View.GONE else View.VISIBLE
        }
        up.onTap {
            if (rated[m] == null) {
                rated[m] = "up"; showRating("up")
                Stats.inc(this@MainActivity, "thumbs_up"); Server.feedback(this@MainActivity, "up", asked?.text ?: "", m.text)
                Toast.makeText(this@MainActivity, "Thanks!", Toast.LENGTH_SHORT).show()
            }
        }
        down.onTap {
            if (rated[m] == null) {
                rated[m] = "down"; showRating("down")
                Stats.inc(this@MainActivity, "thumbs_down"); Server.feedback(this@MainActivity, "down", asked?.text ?: "", m.text)
                if (asked != null) Stats.remember(this@MainActivity, "bad", asked.text)
                Toast.makeText(this@MainActivity, "Thanks. This helps me improve.", Toast.LENGTH_SHORT).show()
            }
        }
        showRating(rated[m]); row.addView(up); row.addView(down)
        addView(row)
    }

    // The plan, so people know what is coming before they start.
    private fun steps(plan: List<String>) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; background = bg(chipBg, 18); setPadding(dp(14), dp(12), dp(14), dp(4)); layoutParams = lp(12, 0)
        plan.take(6).forEachIndexed { i, t ->
            addView(LinearLayout(context).apply {
                setPadding(0, 0, 0, dp(8))
                addView(TextView(context).apply {
                    text = "${i + 1}"; textSize = 12.5f; setTextColor(green); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
                    background = bg(card, 0, true, line); layoutParams = ll(dp(22), dp(22)).apply { rightMargin = dp(10) }
                })
                addView(TextView(context).apply { text = t; textSize = 15f; setTextColor(ink); setPadding(0, dp(1), 0, 0); layoutParams = ll(0, WRAP, 1f) })
            })
        }
    }

    private fun conversation(col: LinearLayout) {
        val c = cur
        if (c != null) c.msgs.forEachIndexed { i, m ->
            col.addView(if (m.mine) userBubble(m) else helperBlock(m, c.msgs.getOrNull(i - 1), i == c.msgs.size - 1 && !waiting))
        }
        if (waiting) {
            val t = tv("Thinking", 16f, mute, 0)
            thinkingView = t
            col.addView(LinearLayout(this).apply {
                gravity = Gravity.CENTER_VERTICAL; layoutParams = lp(20, 8)
                addView(IconView(context, "logo", green).apply { layoutParams = ll(dp(22), dp(22)).apply { rightMargin = dp(10) } })
                addView(t)
            })
        }
        if (note.isNotEmpty()) col.addView(tv(note, 15f, noteColor, 0).apply { setPadding(0, dp(14), 0, dp(6)) })
        if (failed && !waiting) {
            val lastQ = c?.msgs?.lastOrNull { it.mine }
            if (lastQ != null && !lastQ.text.startsWith("\uD83D\uDCCE"))
                col.addView(pill("Try again", card, ink, line) { retry() }.apply { contentDescription = "Ask again"; layoutParams = lp(12, 0) })
            if (c?.msgs?.lastOrNull()?.guideId == null) {
                col.addView(section("These work without internet"))
                grid(col, Guides.all.map { taskTile(it) })
                col.addView(safeCard())
            }
        }
    }

    private fun attachRow(): LinearLayout = LinearLayout(this).apply {
        gravity = Gravity.CENTER_VERTICAL; setPadding(dp(2), dp(6), 0, dp(2))
        addView(ImageView(context).apply {
            attachedThumb?.let { setImageBitmap(it) }; scaleType = ImageView.ScaleType.CENTER_CROP
            layoutParams = LinearLayout.LayoutParams(dp(48), dp(48))
        })
        addView(TextView(context).apply {
            text = if (attached.size > 1) "Video attached. Now ask your question." else "Picture attached. Now ask your question."
            textSize = 14f; setTextColor(ink)
            layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(12) }
        })
        addView(iconBtn("close", "Remove", mute, 48, 14) { attached = emptyList(); attachedThumb = null; build() })
    }

    // The message box, fixed at the bottom like Claude's: + on the left; one green button on the right that is
    // Speak when the box is empty, Send when there is text, and Stop while waiting. One voice button, not two.
    private fun composer(): LinearLayout {
        val et = EditText(this).apply {
            hint = if (incognito) "Incognito: nothing is saved" else if (cur?.msgs?.isNotEmpty() == true) "Reply to ScreenGuide" else "Type or say what you want to do"
            setHintTextColor(mute); setTextColor(ink); textSize = 17f; background = null
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            setHorizontallyScrolling(false); maxLines = 4; minHeight = dp(48)
            imeOptions = EditorInfo.IME_ACTION_SEND
            setPadding(dp(6), dp(8), dp(6), dp(4))
            setText(typed); setSelection(typed.length)
            setOnEditorActionListener { v, _, _ -> ask(v.text.toString()); true }
        }
        input = et
        val actIcon = IconView(this, "mic", onAccent).apply { layoutParams = ll(dp(20), dp(20)) }
        val actText = TextView(this).apply {
            textSize = 16f; setTextColor(onAccent); typeface = Typeface.DEFAULT_BOLD; layoutParams = ll(WRAP, WRAP).apply { leftMargin = dp(8) }
        }
        val action = LinearLayout(this).apply {
            gravity = Gravity.CENTER; background = press(bg(green, 24), 24); layoutParams = ll(WRAP, dp(48)); minimumWidth = dp(48); isClickable = true
            addView(actIcon); addView(actText)
        }
        fun setAction(send: Boolean) {
            val (kind, label) = when { waiting -> "stop" to "Stop"; send -> "send" to ""; else -> "mic" to "Speak" }
            actIcon.kind = kind; actText.text = label
            actText.visibility = if (label.isEmpty()) View.GONE else View.VISIBLE
            val side = if (label.isEmpty()) 14 else 18
            action.setPadding(dp(side - 2), 0, dp(side), 0)
            action.contentDescription = when { waiting -> "Stop waiting"; send -> "Send"; else -> "Speak your question" }
            action.onTap { when { waiting -> cancelAsk(); send -> ask(et.text.toString()); else -> listen(2) } }
        }
        setAction(typed.isNotBlank() || attached.isNotEmpty())
        et.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { setAction(!s.isNullOrBlank() || attached.isNotEmpty()) }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = bg(card, 26, false, line); setPadding(dp(12), dp(6), dp(8), dp(8))
            if (attached.isNotEmpty()) addView(attachRow())
            if (editing != null) addView(LinearLayout(context).apply {
                gravity = Gravity.CENTER_VERTICAL; setPadding(dp(6), dp(2), 0, 0)
                addView(IconView(context, "edit", green).apply { layoutParams = ll(dp(16), dp(16)).apply { rightMargin = dp(8) } })
                addView(tv("Editing your message", 13.5f, green, 0, true).apply { layoutParams = ll(0, WRAP, 1f) })
                addView(iconBtn("close", "Stop editing", mute, 40, 12) { editing = null; input = null; typed = ""; build() })
            })
            addView(et, ll(MATCH, WRAP))
            addView(LinearLayout(context).apply {
                gravity = Gravity.CENTER_VERTICAL
                addView(iconBtn("plus", "Attach a screenshot or video", ink, 48, 13, chipBg) { pickMedia() })
                addView(Space(context), ll(0, 1, 1f))
                addView(action)
            })
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(6), dp(12), dp(8)); setBackgroundColor(paper)
            addView(box, ll(MATCH, WRAP))
            addView(LinearLayout(context).apply {
                gravity = Gravity.CENTER; setPadding(0, dp(6), 0, 0)
                addView(IconView(context, "lock", mute).apply { layoutParams = ll(dp(12), dp(12)).apply { rightMargin = dp(6) } })
                addView(tv("Never type your PIN or passwords here.", 12f, mute, 0))
            })
        }
    }

    private fun build() {
        typed = input?.text?.toString() ?: typed
        ui.removeCallbacks(dotsRun); thinkingView = null
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(paper) }
        root.addView(header())
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(4), dp(18), dp(16)) }
        val chatting = cur?.msgs?.isNotEmpty() == true || waiting
        if (Guides.active != null) col.addView(guideBanner())
        if (chatting) conversation(col) else welcome(col)
        val sv = ScrollView(this).apply { setBackgroundColor(paper); isFillViewport = true; addView(col) }
        root.addView(sv, LinearLayout.LayoutParams(MATCH, 0, 1f))
        root.addView(composer())
        setContentView(root)
        try {
            window.statusBarColor = paper
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = if (dark) 0 else View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        } catch (e: Exception) {}
        if (chatting) sv.post { sv.scrollTo(0, col.height) }
        if (thinkingView != null) ui.postDelayed(dotsRun, 400)
    }
}

// Simple line icons drawn in code, so the app needs no image files. One style everywhere: 2px lines on a
// 24-unit grid (like common icon sets), drawn inside the view's padding.
class IconView(c: Context, kind: String, fg: Int) : View(c) {
    var kind: String = kind
        set(v) { field = v; invalidate() }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND; color = fg }
    fun tint(c: Int) { p.color = c; invalidate() }
    override fun onDraw(cv: Canvas) {
        cv.save(); cv.translate(paddingLeft.toFloat(), paddingTop.toFloat())
        val w = (width - paddingLeft - paddingRight).toFloat(); val h = (height - paddingTop - paddingBottom).toFloat()
        if (w > 0 && h > 0) draw(cv, w, h)
        cv.restore()
    }

    private fun draw(cv: Canvas, w: Float, h: Float) {
        fun x(f: Float) = w * f
        fun y(f: Float) = h * f
        val s = minOf(w, h) / 24f
        val ox = (w - 24 * s) / 2; val oy = (h - 24 * s) / 2
        fun X(v: Float) = ox + v * s
        fun Y(v: Float) = oy + v * s
        fun line(a: Float, b: Float, c: Float, d: Float) = cv.drawLine(X(a), Y(b), X(c), Y(d), p)
        fun circle(cx: Float, cy: Float, r: Float, fill: Boolean = false) {
            p.style = if (fill) Paint.Style.FILL else Paint.Style.STROKE; cv.drawCircle(X(cx), Y(cy), r * s, p); p.style = Paint.Style.STROKE
        }
        fun arc(cx: Float, cy: Float, r: Float, start: Float, sweep: Float) =
            cv.drawArc(RectF(X(cx - r), Y(cy - r), X(cx + r), Y(cy + r)), start, sweep, false, p)
        fun path(fill: Boolean = false, b: Path.() -> Unit) {
            p.style = if (fill) Paint.Style.FILL else Paint.Style.STROKE; cv.drawPath(Path().apply(b), p); p.style = Paint.Style.STROKE
        }
        fun Path.m(a: Float, b: Float) = moveTo(X(a), Y(b))
        fun Path.l(a: Float, b: Float) = lineTo(X(a), Y(b))
        fun Path.q(a: Float, b: Float, c: Float, d: Float) = quadTo(X(a), Y(b), X(c), Y(d))
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2f * s
        when (kind) {
            // ---- quick task pictures (drawn large inside a coloured circle) ----
            "wifi" -> {
                p.strokeWidth = w * 0.075f
                val cx = w / 2; val cy = h * 0.72f
                for (i in 1..3) { val r = w * 0.15f * i; cv.drawArc(RectF(cx - r, cy - r, cx + r, cy + r), 225f, 90f, false, p) }
                p.style = Paint.Style.FILL; cv.drawCircle(cx, cy, w * 0.05f, p)
            }
            "bluetooth" -> {
                p.strokeWidth = w * 0.075f
                cv.drawPath(Path().apply {
                    moveTo(x(0.34f), y(0.34f)); lineTo(x(0.64f), y(0.64f)); lineTo(x(0.5f), y(0.78f)); lineTo(x(0.5f), y(0.22f))
                    lineTo(x(0.64f), y(0.36f)); lineTo(x(0.34f), y(0.66f))
                }, p)
            }
            "airplane" -> {
                p.strokeWidth = w * 0.075f
                cv.drawLine(x(0.5f), y(0.2f), x(0.5f), y(0.78f), p)
                cv.drawPath(Path().apply { moveTo(x(0.2f), y(0.56f)); lineTo(x(0.5f), y(0.4f)); lineTo(x(0.8f), y(0.56f)) }, p)
                cv.drawPath(Path().apply { moveTo(x(0.38f), y(0.8f)); lineTo(x(0.5f), y(0.73f)); lineTo(x(0.62f), y(0.8f)) }, p)
            }
            "hotspot" -> {
                p.strokeWidth = w * 0.075f
                val cx = w / 2; val cy = h / 2
                for (i in 1..2) {
                    val r = w * 0.15f * i; val o = RectF(cx - r, cy - r, cx + r, cy + r)
                    cv.drawArc(o, 140f, 80f, false, p); cv.drawArc(o, -40f, 80f, false, p)
                }
                p.style = Paint.Style.FILL; cv.drawCircle(cx, cy, w * 0.06f, p)
            }
            "shield" -> path { m(12f, 3f); l(19f, 6f); l(19f, 11f); q(19f, 18f, 12f, 21f); q(5f, 18f, 5f, 11f); l(5f, 6f); close() }
                .also { line(12f, 8.5f, 12f, 12.5f); circle(12f, 16f, 1.1f, true) }
            // ---- ScreenGuide's mark: a ring around a tap point ----
            "logo" -> {
                circle(12f, 12f, 9.5f)
                p.alpha = 60; circle(12f, 12f, 6.5f, true); p.alpha = 255
                circle(12f, 12f, 3.4f, true)
            }
            // ---- interface icons ----
            "mic" -> {
                path { addRoundRect(RectF(X(9f), Y(2.5f), X(15f), Y(14f)), 3f * s, 3f * s, Path.Direction.CW) }
                arc(12f, 11f, 6.5f, 0f, 180f); line(12f, 17.5f, 12f, 21.5f); line(8.5f, 21.5f, 15.5f, 21.5f)
            }
            "send" -> { line(12f, 19f, 12f, 5f); path { m(5.5f, 11.5f); l(12f, 5f); l(18.5f, 11.5f) } }
            "plus" -> { line(12f, 5f, 12f, 19f); line(5f, 12f, 19f, 12f) }
            "close" -> { line(6f, 6f, 18f, 18f); line(18f, 6f, 6f, 18f) }
            "stop" -> path(true) { addRoundRect(RectF(X(6.5f), Y(6.5f), X(17.5f), Y(17.5f)), 2.5f * s, 2.5f * s, Path.Direction.CW) }
            "play" -> path(true) { m(8f, 5f); l(19f, 12f); l(8f, 19f); close() }
            "speaker" -> {
                path { m(11f, 5f); l(6f, 9f); l(2.5f, 9f); l(2.5f, 15f); l(6f, 15f); l(11f, 19f); close() }
                arc(12f, 12f, 4.5f, -45f, 90f); arc(12f, 12f, 8.5f, -45f, 90f)
            }
            "refresh" -> { arc(12f, 12f, 8f, 20f, 290f); path { m(13.1f, 5.9f); l(17.1f, 5.9f); l(16.5f, 1.9f) } }
            "up", "down" -> {
                if (kind == "down") { cv.save(); cv.scale(1f, -1f, w / 2, h / 2) }
                path {
                    m(7f, 10.5f); l(10.8f, 3f); q(13.8f, 3f, 13.8f, 6f); l(13.8f, 9f); l(18.6f, 9f)
                    q(20.8f, 9f, 20.4f, 11.2f); l(19.2f, 18.6f); q(18.8f, 21f, 16.6f, 21f); l(7f, 21f); close()
                }
                path { addRoundRect(RectF(X(3f), Y(10.5f), X(7f), Y(21f)), 1.2f * s, 1.2f * s, Path.Direction.CW) }
                if (kind == "down") cv.restore()
            }
            "check" -> path { m(4.5f, 12.5f); l(9.5f, 17.5f); l(19.5f, 6.5f) }
            "help" -> {
                circle(12f, 12f, 9.5f)
                path { m(9.2f, 9.3f); q(9.6f, 6.6f, 12.2f, 6.8f); q(15f, 7.1f, 14.9f, 9.6f); q(14.8f, 11.4f, 12f, 12.6f); l(12f, 13.8f) }
                circle(12f, 17.2f, 1.15f, true)
            }
            "chat" -> path { m(4f, 5.5f); q(4f, 4f, 5.5f, 4f); l(18.5f, 4f); q(20f, 4f, 20f, 5.5f); l(20f, 15f); q(20f, 16.5f, 18.5f, 16.5f)
                l(9f, 16.5f); l(4f, 20.5f); close() }
            "edit" -> { path { m(15.5f, 4.5f); l(19.5f, 8.5f); l(8.5f, 19.5f); l(4f, 20f); l(4.5f, 15.5f); close() }; line(13f, 20f, 20f, 20f) }
            "dots" -> { circle(12f, 5f, 1.7f, true); circle(12f, 12f, 1.7f, true); circle(12f, 19f, 1.7f, true) }
            "menu" -> { line(4f, 7f, 20f, 7f); line(4f, 12f, 20f, 12f); line(4f, 17f, 14f, 17f) }
            "copy" -> {
                path { addRoundRect(RectF(X(8.5f), Y(8.5f), X(20f), Y(20f)), 2f * s, 2f * s, Path.Direction.CW) }
                path { m(15.5f, 8.5f); l(15.5f, 5.5f); q(15.5f, 4f, 14f, 4f); l(5.5f, 4f); q(4f, 4f, 4f, 5.5f); l(4f, 14f); q(4f, 15.5f, 5.5f, 15.5f); l(8.5f, 15.5f) }
            }
            "share" -> {
                circle(18f, 5.5f, 2.6f); circle(6f, 12f, 2.6f); circle(18f, 18.5f, 2.6f)
                line(8.4f, 10.7f, 15.6f, 6.8f); line(8.4f, 13.3f, 15.6f, 17.2f)
            }
            "clock" -> { circle(12f, 12f, 9.5f); path { m(12f, 7f); l(12f, 12f); l(15.5f, 14f) } }
            "eye", "eyeoff" -> {
                path { m(2f, 12f); q(12f, 2.5f, 22f, 12f); q(12f, 21.5f, 2f, 12f); close() }
                circle(12f, 12f, 3f)
                if (kind == "eyeoff") line(4f, 4f, 20f, 20f)
            }
            "star" -> path {
                for (i in 0 until 10) {
                    val r = if (i % 2 == 0) 9.5f else 4.2f
                    val a = Math.toRadians((-90 + i * 36).toDouble())
                    val px = 12f + (r * Math.cos(a)).toFloat(); val py = 12.6f + (r * Math.sin(a)).toFloat()
                    if (i == 0) m(px, py) else l(px, py)
                }
                close()
            }
            "sliders" -> {
                line(4f, 7f, 20f, 7f); line(4f, 12f, 20f, 12f); line(4f, 17f, 20f, 17f)
                circle(9f, 7f, 2.3f, true); circle(15.5f, 12f, 2.3f, true); circle(7f, 17f, 2.3f, true)
            }
            "lock" -> {
                path { addRoundRect(RectF(X(5f), Y(11f), X(19f), Y(21f)), 2f * s, 2f * s, Path.Direction.CW) }
                path { m(8f, 11f); l(8f, 8f); q(8f, 4f, 12f, 4f); q(16f, 4f, 16f, 8f); l(16f, 11f) }
            }
            "info" -> { circle(12f, 12f, 9.5f); line(12f, 11f, 12f, 16.5f); circle(12f, 7.8f, 1.15f, true) }
            "globe" -> { circle(12f, 12f, 9.5f); line(2.5f, 12f, 21.5f, 12f); path { m(12f, 2.5f); q(5.5f, 12f, 12f, 21.5f); m(12f, 2.5f); q(18.5f, 12f, 12f, 21.5f) } }
            "trash" -> { line(4f, 6.5f, 20f, 6.5f); path { m(6f, 6.5f); l(7f, 20.5f); l(17f, 20.5f); l(18f, 6.5f) }; path { m(9f, 6.5f); l(9.5f, 3.5f); l(14.5f, 3.5f); l(15f, 6.5f) } }
            else -> { circle(12f, 12f, 8f); circle(12f, 12f, 2.5f, true) }
        }
    }
}
