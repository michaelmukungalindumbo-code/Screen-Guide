plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "zm.screenguide"
    compileSdk = 34
    defaultConfig {
        applicationId = "zm.screenguide"
        minSdk = 24
        targetSdk = 34
        versionCode = 43
        versionName = "0.43"
    }
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}

// Sign in with Google (Android's Credential Manager). Only used when the person chooses to sign in.
dependencies {
    implementation("androidx.credentials:credentials:1.3.0")
    implementation("androidx.credentials:credentials-play-services-auth:1.3.0")
    implementation("com.google.android.libraries.identity.googleid:googleid:1.1.1")
    // MatchTest: real questions must pick the right action (run on every GitHub build)
    testImplementation("junit:junit:4.13.2")
}
