package zm.screenguide

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

// v0.91, the owner's tests (7 Nov), with no AI credit:
// - "How do I use xtheme?" and "Open xtheme": "the helper is busy", nothing opened. "Are you sure you can predict how a
//   human is able to ask a question? Why can't you use KEY TERMS?"
// - "How do I use YouTube music" (turned off): the question went to the helper; the turned-off check never ran.
// - Safe folder: "a new user can consider it to be an app".
class KeyTermsTest {
    private fun apps(vararg n: String) = n.map { it to "pkg." + it.lowercase().replace(" ", "") }
    private val phone = apps("XTheme", "WhatsApp", "Messages", "Phone", "Camera", "Files", "Settings", "English", "YouTube", "Drive", "Play Store")
    private fun src(name: String) = listOf("src/main/java/zm/screenguide/$name", "app/src/main/java/zm/screenguide/$name")
        .map { File(it) }.first { it.exists() }.readText()

    // However it is asked
    @Test fun anAppNamedAnywhere() {
        for (q in listOf("How do I use xtheme?", "xtheme", "Where is my XTheme", "I can't find xtheme", "show me xtheme please", "How do I use Xthem"))
            assertEquals(q, "XTheme", Match.keyApp(q, phone)?.first)
        assertEquals("WhatsApp", Match.keyApp("How do I send messages on WhatsApp", phone)?.first)   // not Messages
        assertEquals("YouTube", Match.keyApp("how to watch videos on youtube", phone)?.first)
    }

    // Plain words are not apps, and money is never offered
    @Test fun notEveryWordIsAnApp() {
        assertNull(Match.keyApp("How do I make my phone faster", phone))     // "phone" is the device
        assertNull(Match.keyApp("How do I take photos", phone))
        assertNull(Match.keyApp("How do I learn English words", phone))
        assertNull(Match.keyApp("What is a PIN", phone))
        assertNull(Match.keyApp("How do I send money", apps("Airtel Money", "WhatsApp")))
        assertEquals("Phone", Match.keyApp("How do I make a call", phone)?.first)   // calls: the Phone app
    }

    // Parts of apps are said plainly, and never offered for installing
    @Test fun partsOfAppsAreNotApps() {
        assertEquals("Safe folder" to "Files", Match.feature("How do I use safe folder"))
        assertEquals("Safe folder" to "Files", Match.feature("Open the Safe Folder app"))
        assertEquals("App twin" to "Settings", Match.feature("how do i turn on app twin"))
        assertEquals("Safe folder is not an app. It is part of the Files app.", Match.featureLine("Safe folder", "Files"))
        assertNull(Match.missingApp("Open the Safe Folder app", listOf("Files", "Settings")))
        assertNull(Match.keyApp("How do I use safe folder", phone))           // the feature line says it, with Files
        assertNull(Match.installTarget("Install safe folder"))
    }

    @Test fun installRequests() {
        assertEquals("TikTok", Match.installTarget("Install TikTok"))
        assertEquals("Capcut", Match.installTarget("please install the capcut app"))
        assertEquals("Boomplay", Match.installTarget("Download Boomplay from the Play Store"))
        assertEquals("WhatsApp Business", Match.installTarget("install WhatsApp Business"))
        assertNull(Match.installTarget("Download a video"))
        assertNull(Match.installTarget("download my certificate"))
        assertNull(Match.installTarget("Install it"))
        assertNull(Match.installTarget("install updates"))
        assertNull(Match.installTarget("Install Airtel Money"))              // money: never
        assertNull(Match.installTarget("How do I install apps on my phone"))
    }

    // The test phone's note when "Open …" finds nothing: what it looked for, and the closest names
    @Test fun whyNothingWasFound() {
        assertEquals("xtheme", Match.openWord("Open xtheme"))
        assertEquals("xtheme", Match.openWord("where is my xtheme app?"))
        assertNull(Match.openWord("How do I use xtheme"))
        assertEquals(listOf("Theme", "XOS Launcher"), Match.closest("xtheme", listOf("Theme", "XOS Launcher", "WhatsApp Business"), 2))
    }

    @Test fun theWiringIsThere() {
        val m = src("MainActivity.kt")
        val ask = m.substringAfter("    private fun ask(text: String) {").substringBefore("\n    }\n")
        // turned off and install first, all before the helper; "Open X" opens like a Smart guide; any other question gets the offer
        val off = ask.indexOf("Guides.offApp(this, text)?.let { (n, p) -> offerTurnOn(n, p, if (Match.openWord(text) != null) null else ({ askServer(text.trim()) })); return }")
        val inst = ask.indexOf("Match.installTarget(text)?.let")
        val open = ask.indexOf("openLocal(app.first, app.second)")
        val helper = ask.indexOf("askServer(text.trim(), offer = instantOffer(text))")
        assertTrue("$off $inst $open $helper", off in 1 until inst && inst < open && open < helper)
        assertFalse(m.contains("start(findGuide("))                                   // the old guide that said "swipe up"
        val local = m.substringAfter("    private fun openLocal(name: String, pkg: String) {").substringBefore("\n    }\n")
        assertTrue(local.contains("Guides.aiApp = name; Guides.aiAppPkg = pkg; Guides.aiJustOpen = true"))
        assertFalse(local.contains("Server.learnedFor") || local.contains("askServer"))   // nothing asked: works offline
        assertTrue(m.contains("if (opens != null) addView(primary(\"Open \" + opens.first) { openLocal(opens.first, opens.second, rowOf(m.guideId)) })"))
        assertTrue(m.contains("if (goal != null && instant?.guideId != null) conv.msgs.remove(instant)"))
        // both names of an app
        val g = src("Guides.kt")
        assertTrue(g.contains("listOf(ri.loadLabel(pm).toString().trim(), ri.activityInfo.applicationInfo.loadLabel(pm).toString().trim())"))
    }

    // The small fixes from the same tests
    @Test fun adCloseAndHelpGlow() {
        assertTrue(AdsGate.offerText(5, 20).endsWith(AdsGate.CLOSE_HINT))
        assertTrue(AdsGate.CLOSE_HINT.contains("small X at the top right"))
        val back = src("GuideService.kt").substringAfter("    private fun backToGuide(): Boolean {").substringBefore("\n    }\n")
        assertTrue(back.contains("bumpProgress()"))
    }
}
