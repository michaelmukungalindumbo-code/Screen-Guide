package zm.screenguide

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection

object Server {
    const val URL = "https://screen-guide-server.onrender.com/ask"
    const val TOKEN = "screenguide_sec_9841273560_xyz"

    val configured get() = !URL.contains("YOUR-SERVER")
    private fun base() = URL.removeSuffix("/ask")
    val privacyUrl get() = base() + "/privacy"

    // The person's plan pass (from a code). Empty means the free plan.
    @Volatile var pass = ""
    // Set when the person is signed in to their ScreenGuide account. Empty means no account (or incognito).
    @Volatile var session = ""
    // Tester phones (TEST builds, or "Show what ScreenGuide sees" on in About) help the watcher: when a guide goes wrong,
    // the server keeps a cleaned note of that screen (known button names only, never names, messages or numbers), so the
    // AI fixer can fix it. Other phones never send this.
    @Volatile var tester = false
    fun initTester(c: android.content.Context) {
        val testBuild = (c.applicationInfo.flags and android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE) != 0
        tester = c.getSharedPreferences("sg", android.content.Context.MODE_PRIVATE).getBoolean("tester", testBuild)
    }

    // One anonymous id per install. Created on first use, wherever that happens.
    fun installId(c: android.content.Context): String {
        val p = c.getSharedPreferences("sg", android.content.Context.MODE_PRIVATE)
        return p.getString("id", null) ?: java.util.UUID.randomUUID().toString().also { p.edit().putString("id", it).apply() }
    }

    // The free host sleeps after 15 quiet minutes and then needs up to a minute for its first answer. A quiet
    // request wakes it early: when the app opens and when a Smart guide starts. Nothing personal is sent.
    @Volatile private var wokeAt = 0L
    fun wake() {
        if (!configured) return
        val now = System.currentTimeMillis()
        if (now - wokeAt < 4 * 60_000L) return
        wokeAt = now
        Thread { try { (java.net.URL(base() + "/health").openConnection() as HttpURLConnection).apply { connectTimeout = 10000; readTimeout = 60000 }.responseCode } catch (e: Exception) {} }.start()
    }

    // "Samsung tablet, Android 14". Menus differ by maker and tablets lay apps out differently, so the helper is told.
    // Seen: scanning a document failed on a Samsung tablet. Nothing personal: no model number, no name.
    val device: String by lazy {
        val maker = android.os.Build.MANUFACTURER.trim().lowercase().replaceFirstChar { it.uppercase() }.ifEmpty { "Android" }
        val kind = if (android.content.res.Resources.getSystem().configuration.smallestScreenWidthDp >= 600) "tablet" else "phone"
        "$maker $kind, Android ${android.os.Build.VERSION.RELEASE}"
    }

    private fun post(path: String, body: JSONObject, installId: String, quick: Boolean = false): Pair<Int, String> = request("POST", path, body, installId, quick)

    // quick: give up after a few seconds (a shortcut that must never hold up the real thing).
    // A weak mobile network often fails once and works a moment later (3 Nov: "No connection" in the middle of a guide,
    // UnknownHostException, then fine). Failures that happen before the request reaches the server are tried once more.
    private fun request(method: String, path: String, body: JSONObject?, installId: String, quick: Boolean = false): Pair<Int, String> =
        try { requestOnce(method, path, body, installId, quick) } catch (e: java.io.IOException) {
            if (!Net.retryable(e)) throw e
            Thread.sleep(if (quick) 1000L else 2500L)
            requestOnce(method, path, body, installId, quick)
        }

    private fun requestOnce(method: String, path: String, body: JSONObject?, installId: String, quick: Boolean): Pair<Int, String> {
        val c = (java.net.URL(base() + path).openConnection() as HttpURLConnection).apply {
            requestMethod = method; connectTimeout = if (quick) 5000 else 15000; readTimeout = if (quick) 6000 else 60000; doOutput = body != null
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("X-App-Token", TOKEN)
            setRequestProperty("X-Install-Id", installId)
            if (pass.isNotEmpty()) setRequestProperty("X-Pass", pass)
            if (session.isNotEmpty()) setRequestProperty("X-Session", session)
            if (tester) setRequestProperty("X-Tester", "1")
        }
        if (body != null) c.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = c.responseCode
        val text = ((if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.readText()) ?: ""
        return Pair(code, text)
    }

    // ---- Accounts: sign in with Google ----
    private fun detail(text: String, fallback: String) = try { JSONObject(text).optString("detail", fallback) } catch (e: Exception) { fallback }

    // The Google sign-in client id, from our server (so it can be set on Render without a new app). Empty if sign-in is off.
    fun googleClientId(): String = try {
        val c = (java.net.URL(base() + "/config").openConnection() as HttpURLConnection).apply { connectTimeout = 15000; readTimeout = 60000 }
        if (c.responseCode in 200..299) JSONObject(c.inputStream.bufferedReader().readText()).optString("google_client_id", "") else ""
    } catch (e: Exception) { "" }

    class Reply(val ok: Boolean, val json: JSONObject?, val message: String)

    fun signIn(idToken: String, installId: String): Reply = try {
        val (code, text) = post("/auth/google", JSONObject().put("id_token", idToken), installId)
        if (code in 200..299) Reply(true, JSONObject(text), "") else Reply(false, null, detail(text, "Sign-in did not work. Please try again."))
    } catch (e: Exception) { Reply(false, null, "No connection. Please check your internet and try again.") }

    fun me(installId: String): Reply = try {
        val (code, text) = request("GET", "/me", null, installId)
        if (code in 200..299) Reply(true, JSONObject(text), "") else Reply(false, null, detail(text, "") + "|" + code)
    } catch (e: Exception) { Reply(false, null, "offline") }

    fun saveMe(installId: String, profile: JSONObject?, learned: JSONArray?): Boolean = try {
        val b = JSONObject()
        if (profile != null) b.put("profile", profile)
        if (learned != null) b.put("learned", learned)
        request("PUT", "/me", b, installId).first in 200..299
    } catch (e: Exception) { false }

    fun deleteMe(installId: String): Boolean = try { post("/me/delete", JSONObject(), installId).first in 200..299 } catch (e: Exception) { false }

    // The last thing that went wrong talking to the server, in plain technical words, for the TEST card and debug copy.
    @Volatile var lastProblem = ""
    // When the helper last answered. Recently means the server is awake, so a slow answer is not "waking up".
    @Volatile var lastOkAt = 0L

    // What the person sees when the server says no. Never raw server words like "Not Found".
    private fun problem(code: Int, text: String, path: String): String {
        val detail = try { JSONObject(text).optString("detail", "") } catch (e: Exception) { "" }
        lastProblem = "Server answered $code on $path" + (if (detail.isNotEmpty()) ": " + detail.take(80) else "")
        return when {
            code == 404 -> "The helper is being updated right now. Quick tasks still work. Please try again later."
            code == 401 -> "This copy of ScreenGuide needs updating before it can use the helper."
            code == 429 || code == 413 -> detail.ifEmpty { "Please wait a minute and try again." }   // limits: the server explains
            code in 500..599 -> if (detail.isNotEmpty() && !detail.equals("Internal Server Error", true)) detail
                                else "The helper is busy. Please try again in a minute."
            else -> if (detail.isNotEmpty() && detail.length > 12) detail else "Sorry, I could not answer that. Please try again."
        }
    }

    // (worked, text, kind) where kind is "guide" or "answer". Sends the typed question, language and kind of phone,
    // and for "how do I..." questions the names of the person's apps (never money apps).
    class Asked(val ok: Boolean, val text: String, val kind: String, val needsApps: Boolean = false, val goal: String = "", val plan: List<String> = emptyList(), val left: Int = -1,
                val limited: Boolean = false,   // v0.90: today's free questions are used up (an ad can add more)
                val code: Int = 0)              // v0.94: what the server answered when it failed (0: no answer at all)

    private fun list(a: JSONArray?): List<String> = if (a == null) emptyList() else (0 until a.length()).map { a.optString(it) }.filter { it.isNotBlank() }

    fun ask(question: String, lang: String, installId: String, images: List<String> = emptyList(), history: List<String> = emptyList(), fresh: Boolean = false, apps: List<String> = emptyList()): Asked = try {
        val (code, text) = post("/ask", JSONObject().put("question", question).put("lang", lang).put("images", JSONArray(images))
            .put("history", JSONArray(history)).put("fresh", fresh).put("device", device).put("apps", JSONArray(apps)), installId)
        if (code in 200..299) {
            val j = JSONObject(text)
            Asked(true, j.getString("answer"), j.optString("kind", "answer"), j.optBoolean("needs_apps", false), j.optString("goal", ""), list(j.optJSONArray("plan")), j.optInt("left", -1))
        }
        else Asked(false, problem(code, text, "/ask"), "answer", limited = AdsGate.limited(code, text), code = code)
    } catch (e: Exception) {
        lastProblem = "No connection (/ask): " + (e.javaClass.simpleName)
        Asked(false, offline(e), "answer")
    }

    // x and y are set only when a screen picture was sent and the thing to tap has no words: fractions of the screen.
    // lookFor: not on screen yet, but further down this list ("Storage"); the phone rings it when it scrolls into view.
    // needPicture: the AI named an icon it cannot point at from words ("Tap the + button"); a screen picture would help.
    class Next(val label: String?, val say: String, val done: Boolean, val x: Double? = null, val y: Double? = null, val ok: Boolean = true,
               val lookFor: String? = null, val needPicture: Boolean = false, val watch: Int = 0, val watchStep: Int = 0,
               val strong: Boolean = false,   // answered by the stronger AI (after Help; server 0.76)
               val limited: Boolean = false)  // v0.90: today's free guided steps are used up

    // Older servers send words with their [tag]; drop it so the ring can find the word on screen.
    fun clean(label: String?): String? = label?.replace(Regex("\\s*\\[(switch|tap|text|selected)\\]\\s*$"), "")?.trim()?.ifEmpty { null }
    private fun frac(j: JSONObject, k: String): Double? = if (j.isNull(k)) null else j.optDouble(k).takeIf { !it.isNaN() && it in 0.0..1.0 }

    // Smart guide: sends the goal and the words on screen (never passwords or banking apps). Returns the next step.
    // v0.114: how many screens with no words have come in a row, for the one step asked inside f (on this thread)
    private val unseenRow = ThreadLocal<Int>()
    fun <T> unseen(row: Int, f: () -> T): T { unseenRow.set(row); try { return f() } finally { unseenRow.remove() } }
    fun next(goal: String, lang: String, installId: String, labels: List<String>, history: List<String>, stuck: Boolean = false, apps: List<String> = emptyList(), note: String = "", plan: List<String> = emptyList(), image: String = "", level: String = "", tapped: Boolean = false, path: List<String> = emptyList()): Next = try {
        val body = JSONObject().put("goal", goal).put("lang", lang).put("labels", JSONArray(labels)).put("history", JSONArray(history)).put("stuck", stuck).put("apps", JSONArray(apps)).put("note", note).put("plan", JSONArray(plan)).put("image", image).put("level", level).put("device", device)
        if (tapped && Server.tester) body.put("tapped", true)
        (unseenRow.get() ?: 0).let { if (it > 0) body.put("blind", it) }   // v0.114 (server 0.88): this many screens with no words in a row
        // v0.90 (server 0.84), every phone: they tapped what the last step pointed at, so an answer that worked can be
        // given again at once ("known screens"); and where they have been in this guide (Breadcrumbs)
        if (tapped) body.put("followed", true)
        if (path.isNotEmpty()) body.put("path", JSONArray(path))
        val (code, text) = post("/next", body, installId)
        if (code in 200..299) {
            lastOkAt = System.currentTimeMillis()
            val j = JSONObject(text)
            Next(clean(if (j.isNull("label")) null else j.getString("label")), j.optString("say", ""), j.optBoolean("done"), frac(j, "x"), frac(j, "y"),
                lookFor = if (!j.has("look_for") || j.isNull("look_for")) null else j.optString("look_for").trim().ifEmpty { null },
                needPicture = j.optBoolean("need_picture", false), watch = j.optInt("watch", 0), watchStep = j.optInt("watch_step", 0),
                strong = j.optBoolean("strong", false))
        }
        else Next(null, problem(code, text, "/next"), false, ok = false, limited = AdsGate.limited(code, text))
    } catch (e: Exception) { lastProblem = "No connection (/next): " + e.javaClass.simpleName; Next(null, offline(e), false, ok = false) }

    // The Read button: the words on a screen (long numbers already removed) -> what it says, in the person's language.
    // (text, or null and why)
    fun read(words: List<String>, lang: String, app: String, installId: String): Pair<String?, String> = try {
        val (code, text) = post("/read", JSONObject().put("words", JSONArray(words)).put("lang", lang).put("app", app).put("device", device), installId)
        if (code in 200..299) { lastOkAt = System.currentTimeMillis(); Pair(JSONObject(text).optString("text").ifEmpty { null }, "Sorry, I could not read that.") }
        else Pair(null, problem(code, text, "/read"))
    } catch (e: Exception) { Pair(null, "No connection. Please check your internet and try again.") }

    // ---- v0.90 rewarded ads (AdsGate): what is left today, and "this phone watched an ad" ----
    // ok = false: no answer, or an older server without ads (404)
    class AdState(val ok: Boolean, val left: Int = -1, val adsOn: Boolean = false, val adsLeft: Int = -1, val ask: Int = 5, val steps: Int = 20)
    private fun adState(text: String): AdState {
        val j = JSONObject(text); val a = j.optJSONObject("ads") ?: return AdState(true, j.optInt("left", -1))
        return AdState(true, j.optInt("left", -1), a.optBoolean("on", false), a.optInt("left", 0), a.optInt("ask", 5), a.optInt("steps", 20))
    }
    fun plan(installId: String): AdState = try {
        val (code, text) = request("GET", "/plan", null, installId, quick = true)
        if (code in 200..299) adState(text) else AdState(false)
    } catch (e: Exception) { AdState(false) }
    fun adClaim(nonce: String, installId: String): AdState = try {
        val (code, text) = post("/ads/claim", JSONObject().put("nonce", nonce), installId)
        if (code in 200..299) adState(text) else AdState(false)
    } catch (e: Exception) { AdState(false) }

    // ---- Live help: the phone sends its screen as boxes of words and gets the helper's newest point ----
    class LiveStart(val ok: Boolean, val id: String = "", val key: String = "", val url: String = "", val message: String = "")
    fun liveStart(installId: String): LiveStart = try {
        val (code, text) = post("/live/start", JSONObject(), installId)
        if (code in 200..299) JSONObject(text).let { LiveStart(true, it.getString("id"), it.getString("key"), it.getString("url")) }
        else LiveStart(false, message = problem(code, text, "/live"))
    } catch (e: Exception) { LiveStart(false, message = "No connection. Please check your internet and try again.") }

    class LiveReply(val ok: Boolean, val ended: Boolean = false, val helper: Boolean = false, val point: JSONObject? = null)
    fun liveScreen(id: String, key: String, screen: JSONObject?, lastPoint: Int, installId: String): LiveReply = try {
        val b = JSONObject().put("key", key).put("last_point", lastPoint)
        if (screen != null) b.put("screen", screen)
        val (code, text) = post("/live/$id/screen", b, installId, quick = true)
        when {
            code in 200..299 -> JSONObject(text).let { LiveReply(true, false, it.optBoolean("helper"), it.optJSONObject("point")) }
            code == 404 || code == 403 -> LiveReply(false, ended = true)
            else -> LiveReply(false)
        }
    } catch (e: Exception) { LiveReply(false) }

    fun liveEnd(id: String, key: String, installId: String) {
        try { post("/live/$id/end", JSONObject().put("key", key), installId, quick = true) } catch (e: Exception) {}
    }

    // ---- Real voices: recordings shared by ScreenGuide for every phone, and the owner's upload ----
    fun voices(): JSONObject? = try {
        val (code, text) = request("GET", "/voices", null, "voices")
        if (code in 200..299) JSONObject(text).optJSONObject("clips") else null
    } catch (e: Exception) { null }
    fun voice(name: String): ByteArray? = try {
        val (code, text) = request("GET", "/voices/$name", null, "voices")
        if (code in 200..299) android.util.Base64.decode(JSONObject(text).getString("audio"), android.util.Base64.DEFAULT) else null
    } catch (e: Exception) { null }
    // (worked, message). ownerKey is typed by the owner each time; it is never kept on the phone.
    fun uploadVoice(ownerKey: String, lang: String, key: String, audio: ByteArray): Pair<Boolean, String> = try {
        val c = (java.net.URL(base() + "/voices/upload").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; connectTimeout = 15000; readTimeout = 60000; doOutput = true
            setRequestProperty("Content-Type", "application/json"); setRequestProperty("X-Admin-Key", ownerKey)
        }
        c.outputStream.use { it.write(JSONObject().put("lang", lang).put("key", key)
            .put("audio", android.util.Base64.encodeToString(audio, android.util.Base64.NO_WRAP)).toString().toByteArray()) }
        val code = c.responseCode
        Pair(code in 200..299, if (code == 401 || code == 403) "That owner key is not right." else if (code in 200..299) "" else "The server said $code.")
    } catch (e: Exception) { Pair(false, "No connection. Please check your internet and try again.") }

    // A crash report: where in the code (see Crash). True when the server has it.
    fun crash(trace: String, version: String, where: String, installId: String): Boolean = try {
        post("/crash", JSONObject().put("trace", trace).put("version", version).put("where", where).put("device", device), installId).first in 200..299
    } catch (e: Exception) { false }

    // ---- Guides people share (Teach), and guides other phones of this kind already finished ----
    class Shared(val ok: Boolean, val code: String = "", val url: String = "", val message: String = "")

    fun share(title: String, steps: JSONArray, sw: Boolean, shade: Boolean, lang: String, installId: String): Shared = try {
        val (code, text) = post("/share", JSONObject().put("title", title).put("steps", steps).put("sw", sw).put("shade", shade)
            .put("lang", lang).put("device", device), installId)
        if (code in 200..299) JSONObject(text).let { Shared(true, it.getString("code"), it.getString("url")) }
        else Shared(false, message = problem(code, text, "/share"))
    } catch (e: Exception) { Shared(false, message = "No connection. Please check your internet and try again.") }

    // (guide JSON, or null and why)
    fun shared(code: String, installId: String): Pair<JSONObject?, String> = try {
        val (status, text) = request("GET", "/share/" + code.uppercase().filter { it.isLetterOrDigit() }.take(8), null, installId)
        if (status in 200..299) Pair(JSONObject(text), "") else Pair(null, problem(status, text, "/share"))
    } catch (e: Exception) { Pair(null, "No connection. Please check your internet and try again.") }

    // A Smart guide finished: the buttons tapped go to the server, so the next phone of this kind can skip the AI.
    fun learned(c: android.content.Context, goal: String, steps: JSONArray, sw: Boolean) {
        if (!configured || Guides.incognito) return
        val id = installId(c.applicationContext)
        Thread { try { post("/learned", JSONObject().put("goal", goal).put("steps", steps).put("sw", sw).put("device", device), id) } catch (e: Exception) {} }.start()
    }

    // Did two or more phones of this kind already finish this task the same way? Then no AI is needed. Quick: never waits long.
    fun learnedFor(goal: String, installId: String): JSONObject? = try {
        val (code, text) = post("/learned/find", JSONObject().put("goal", goal).put("device", device), installId, quick = true)
        if (code in 200..299) JSONObject(text).takeIf { it.optBoolean("found") } else null
    } catch (e: Exception) { null }

    // ---- Plans, guides from the server, and guide events ----
    class Redeemed(val ok: Boolean, val message: String, val pass: String = "", val expires: Long = 0, val weeks: Int = 0)

    fun redeem(code: String, installId: String): Redeemed = try {
        val (status, text) = post("/redeem", JSONObject().put("code", code), installId)
        val j = JSONObject(text)
        if (status in 200..299) Redeemed(true, "", j.getString("pass"), j.optLong("expires"), j.optInt("weeks"))
        else Redeemed(false, j.optString("detail", "That code did not work."))
    } catch (e: Exception) { Redeemed(false, "No connection. Please check your internet and try again.") }

    // Guides kept on the server, so they can be fixed or added without a new app. Returns the raw text, or null.
    fun guides(): String? = try {
        val c = (java.net.URL(base() + "/guides").openConnection() as HttpURLConnection).apply {
            connectTimeout = 15000; readTimeout = 60000
            setRequestProperty("X-App-Token", TOKEN)
        }
        if (c.responseCode in 200..299) c.inputStream.bufferedReader().readText() else null
    } catch (e: Exception) { null }

    // Only the guide's name ("wifi", "ai", "find") and what happened. Never what is on the screen.
    // With no internet the event waits on the phone and is sent later.
    private val qLock = Any()
    private fun prefs(c: android.content.Context) = c.getSharedPreferences("sg", android.content.Context.MODE_PRIVATE)
    private fun send(event: String, guide: String, installId: String): Boolean = try {
        post("/event", JSONObject().put("event", event).put("guide", guide), installId).first in 200..299
    } catch (e: Exception) { false }

    private fun queue(c: android.content.Context, event: String, guide: String) = synchronized(qLock) {
        val arr = try { JSONArray(prefs(c).getString("events", "[]")) } catch (e: Exception) { JSONArray() }
        if (arr.length() < 30) arr.put(JSONObject().put("e", event).put("g", guide))
        prefs(c).edit().putString("events", arr.toString()).apply()
    }

    fun event(c: android.content.Context, event: String, guide: String) {
        if (!configured) return
        val app = c.applicationContext
        val id = installId(app)
        Thread { if (send(event, guide, id)) drain(app, id) else queue(app, event, guide) }.start()
    }

    // Developer phones only: the problems the watcher saw in the guide just finished, each with what went wrong and how
    // to fix it. They are shown in a pop-up; nothing goes to the AI fixer unless the developer taps Allow.
    class Problem(val id: String, val title: String, val what: String, val fix: String, val kind: String = "problem")
    // After a guide or a test: the list for the pop-up, a short title, and the server's signed copy (kept in Past results,
    // so Allow still works later).
    class Review(val problems: List<Problem>, val title: String, val saved: String, val want: List<Int> = emptyList(), val limits: String = "",
                 val stopped: Int = 0, val error: String = "", val lost: Boolean = false)

    // have: the steps this phone has a picture of. The server may first answer which pictures it wants (want); then ask
    // again with those (shots): the AI review looks at them, and they are not kept (the owner agreed on 2 Nov).
    fun watchReview(installId: String, have: List<Int> = emptyList(), shots: List<Pair<Int, String>> = emptyList()): Review = try {
        if (!configured) Review(emptyList(), "", "") else {
            val body = JSONObject()
            if (have.isNotEmpty()) body.put("have", JSONArray(have))
            if (shots.isNotEmpty()) { val a = JSONArray(); shots.forEach { (n, jpg) -> a.put(JSONObject().put("n", n).put("jpg", jpg)) }; body.put("shots", a) }
            val (code, text) = post("/watch/review", body, installId)
            if (code !in 200..299) Review(emptyList(), "", "", error = "the server answered $code") else {
                val j = JSONObject(text)
                val arr = j.optJSONArray("problems") ?: JSONArray()
                val ps = (0 until arr.length()).mapNotNull { i -> arr.optJSONObject(i) }
                    .map { o -> Problem(o.optString("id"), o.optString("title"), o.optString("what"), o.optString("fix"), o.optString("kind", "problem")) }
                    .filter { it.id.isNotEmpty() && it.title.isNotEmpty() }
                val w = j.optJSONArray("want")
                val lim = j.optJSONObject("limits")
                Review(ps, j.optString("title"), j.optJSONObject("saved")?.toString() ?: "",
                    if (w == null) emptyList() else (0 until w.length()).map { w.optInt(it) }.filter { it > 0 },
                    if (lim == null) "" else "Daily limit: ${lim.optInt("problems", 3)} problems, ${lim.optInt("changes", 5)} changes or ideas. The rest wait in Past results.",
                    j.optInt("stopped", 0), lost = j.optBoolean("lost", false))
            }
        }
    } catch (e: Exception) { Review(emptyList(), "", "", error = "no connection") }

    // Developer phones: a change the developer asked for while testing ("Make this ring thicker"), with where they pointed
    // (fractions of the screen, -1 = nowhere) and the screen's words. Returns the number for its picture, 0 if not kept.
    fun watchChange(installId: String, text: String, x: Float, y: Float, labels: List<String>): Int = try {
        val (code, body) = post("/watch/change", JSONObject().put("text", text).put("x", x.toDouble()).put("y", y.toDouble())
            .put("labels", JSONArray(labels)), installId)
        if (code !in 200..299) 0 else JSONObject(body).let { if (it.optBoolean("ok")) it.optInt("pic", 0) else 0 }
    } catch (e: Exception) { 0 }

    // What to say when the helper cannot be reached. A timeout means the internet works but the helper is slow or waking up
    // (the free server sleeps, and restarts after an update): telling people to check their internet was wrong (2 Nov).
    internal fun offline(e: Exception): String = when (e) {
        is java.net.SocketTimeoutException -> "The helper is waking up. Wait a minute, then try again."
        is java.net.UnknownHostException, is java.net.NoRouteToHostException -> "No connection. Please check your internet and try again."
        else -> "Could not reach the helper. Check your internet, or wait a minute and try again."
    }

    // Developer phones: the phone waited ms for the answer to this step. Returns the problems so far.
    fun watchSlow(installId: String, step: Int, ms: Long): Int = try {
        val (code, text) = post("/watch/slow", JSONObject().put("step", step).put("ms", ms), installId)
        if (code !in 200..299) 0 else JSONObject(text).optInt("watch")
    } catch (e: Exception) { 0 }

    // Developer phones: the screen changed while the same step stayed. Returns (problems so far, picture number).
    fun watchStale(installId: String, step: Int, secs: Int): Pair<Int, Int> = try {
        val (code, text) = post("/watch/stale", JSONObject().put("step", step).put("secs", secs), installId)
        if (code !in 200..299) 0 to 0 else JSONObject(text).let { it.optInt("watch") to it.optInt("pic") }
    } catch (e: Exception) { 0 to 0 }

    // Developer phones: "Test an app". Starts a test of that app; its problems go to its GitHub repository.
    class TestStart(val ok: Boolean, val note: String)
    fun watchTestStart(installId: String, pkg: String, app: String, repo: String, goal: String): TestStart = try {
        val (code, text) = post("/watch/test/start", JSONObject().put("pkg", pkg).put("app", app).put("repo", repo).put("goal", goal)
            .put("device", device), installId)
        if (code !in 200..299) TestStart(false, "Could not start the test. Check the internet and try again.") else {
            val j = JSONObject(text)
            when {
                !j.optBoolean("ok") -> TestStart(false, j.optString("error").ifEmpty { "Could not start the test." })
                !j.optBoolean("repo_ok", true) -> TestStart(true, "Testing. Problems cannot be sent to $repo until it is allowed on the server (AI_FIX_REPOS).")
                else -> TestStart(true, "")
            }
        }
    } catch (e: Exception) { TestStart(false, "Could not start the test. Check the internet and try again.") }

    // One screen of the app under test, and what the phone spotted on it. Returns (problems so far, screen number).
    fun watchScreen(installId: String, labels: List<String>, found: List<Pair<String, String>>, new: Boolean): Pair<Int, Int> = try {
        val f = JSONArray(); found.forEach { (k, d) -> f.put(JSONObject().put("kind", k).put("detail", d)) }
        val (code, text) = post("/watch/screen", JSONObject().put("labels", JSONArray(labels)).put("found", f).put("new", new), installId)
        if (code !in 200..299) 0 to 0 else JSONObject(text).let { it.optInt("watch") to it.optInt("watch_step") }
    } catch (e: Exception) { 0 to 0 }

    // What to tell the developer after Allow: how many went to the AI fixer, or why not.
    // saved: the signed copy from Past results ("" = the result still in the server's memory).
    // Returns what to tell the developer, and whether the server has dealt with them (sent now, or before).
    // Returns what to tell the developer, and the ids now dealt with (sent now, or already on GitHub).
    fun watchSend(installId: String, ids: List<String>, shots: List<Pair<Int, String>> = emptyList(), saved: String = ""): Pair<String, List<String>> = try {
        val pics = JSONArray(); shots.forEach { (n, jpg) -> pics.put(JSONObject().put("n", n).put("jpg", jpg)) }
        val body = JSONObject().put("ids", JSONArray(ids)).put("shots", pics).put("report", true)
        if (saved.isNotEmpty()) body.put("saved", JSONObject(saved))
        val (code, text) = post("/watch/send", body, installId)
        if (code !in 200..299) "Could not send them. Check the internet and try again." to emptyList() else {
            val j = JSONObject(text); val sent = j.optInt("sent")
            val d = j.optJSONArray("done"); val done = if (d == null) emptyList() else (0 until d.length()).map { d.optString(it) }
            val wa = j.optJSONArray("wait"); val waiting = wa?.length() ?: 0
            val before = done.size - sent
            val msg = when {
                j.optString("error").isNotEmpty() -> j.optString("error")
                sent == 0 && waiting > 0 && before <= 0 -> "Not sent: today's limit is reached. They wait in Past results: send them tomorrow."
                sent == 0 && before > 0 && waiting == 0 -> "Already sent before. Nothing new to send."
                sent == 0 && done.isEmpty() -> "Nothing was sent. Try again later."
                else -> listOf("Sent $sent to the AI fixer.", if (before == 1) "1 was sent before." else if (before > 1) "$before were sent before." else "",
                    if (waiting > 0) "$waiting wait for tomorrow (daily limit): send them from Past results." else "You will get a GitHub notification when a fix is ready.")
                    .filter { it.isNotEmpty() }.joinToString(" ")
            }
            msg to done
        }
    } catch (e: Exception) { "Could not send them. Check the internet and try again." to emptyList() }

    // Thumbs up or down on an answer, so the helper can be improved. Numbers are removed on the server.
    fun feedback(c: android.content.Context, rating: String, question: String, answer: String) {
        if (!configured) return
        val id = installId(c.applicationContext)
        Thread {
            try { post("/feedback", JSONObject().put("rating", rating).put("question", question.take(300)).put("answer", answer.take(600)), id) }
            catch (e: Exception) {}
        }.start()
    }

    // Send what waited while the phone was offline.
    fun flush(c: android.content.Context) {
        if (!configured) return
        val app = c.applicationContext
        Thread { drain(app, installId(app)) }.start()
    }

    private fun drain(c: android.content.Context, id: String) {
        val text = synchronized(qLock) {
            val t = prefs(c).getString("events", null)
            prefs(c).edit().remove("events").apply()
            t
        } ?: return
        val arr = try { JSONArray(text) } catch (e: Exception) { return }
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            if (!send(o.optString("e"), o.optString("g"), id)) {
                for (j in i until arr.length()) arr.optJSONObject(j)?.let { queue(c, it.optString("e"), it.optString("g")) }
                return
            }
        }
    }
}

// Network failures that happen before a request reaches the server (no name lookup, no connection, no secure link):
// trying again cannot send anything twice. A timeout or a cut-off answer is not tried again: the server may have acted.
internal object Net {
    fun retryable(e: Throwable): Boolean = e is java.net.UnknownHostException || e is java.net.ConnectException ||
        e is java.net.NoRouteToHostException || e is javax.net.ssl.SSLHandshakeException
}
