package zm.screenguide

// tests first: not built yet
object Voice1st { fun spoken(answer: String): String = "?" }
