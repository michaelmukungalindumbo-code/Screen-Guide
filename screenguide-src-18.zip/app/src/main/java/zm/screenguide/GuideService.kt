package zm.screenguide

import android.accessibilityservice.AccessibilityService
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.widget.TextView
import android.media.MediaPlayer
import android.net.wifi.WifiManager
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.Locale

class RingView(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 8f; color = 0xFFF0A935.toInt() }
    private var t = 0f
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1200; repeatCount = ValueAnimator.INFINITE
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }
    override fun onDraw(c: Canvas) {
        p.alpha = 255
        c.drawRoundRect(RectF(26f, 26f, width - 26f, height - 26f), 30f, 30f, p)
        val g = 26f - 22f * t
        p.alpha = (255 * (1 - t)).toInt()
        c.drawRoundRect(RectF(g, g, width - g, height - g), 34f, 34f, p)
    }
}

class GuideService : AccessibilityService(), TextToSpeech.OnInitListener {
    private var wm: WindowManager? = null
    private var ring: RingView? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var spokenFor = -1
    private var mp: MediaPlayer? = null
    private var label: TextView? = null
    private var holdUntil = 0L
    private var findPkg: String? = null
    private var lastGuide: Guide? = null
    private val handler = Handler(Looper.getMainLooper())

    override fun onServiceConnected() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        tts = TextToSpeech(this, this)
        Guides.load(this)
    }
    override fun onInit(s: Int) { ttsReady = s == TextToSpeech.SUCCESS }
    override fun onInterrupt() {}
    override fun onDestroy() { hide(); hideLabel(); tts?.shutdown(); mp?.release(); super.onDestroy() }

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        val guide = Guides.active ?: run { hide(); return }
        if (guide.id == "ai") {
            if (e.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED) {
                val src = e.source; val st = Guides.aiStep
                if (src != null && st != null && st.match.isNotEmpty() && (matches(src, st.match) || matches(src.parent, st.match))) Guides.aiStep = null
            }
            schedule(e); return
        }
        // Final step: the person tapped the switch, so we are done.
        val last = guide.steps.last()
        if (e.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED && last.toggle && Guides.index == guide.steps.size - 1) {
            val src = e.source
            if (src != null) {
                val r = Rect(); src.getBoundsInScreen(r)
                val belowTitle = r.top > resources.displayMetrics.heightPixels * 0.12
                if (belowTitle && (matches(src, last.match) || matches(src.parent, last.match))) { finish(guide); return }
            }
        }
        schedule(e)
    }

    private fun schedule(e: AccessibilityEvent) {
        val own = e.packageName?.toString() == packageName
        val changed = e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && !own
        if (changed) hide()   // drop the old ring at once, show the new one when the screen settles
        handler.removeCallbacks(refreshRun)
        handler.postDelayed(refreshRun, if (changed) 300L else 150L)
        if (changed) { handler.removeCallbacks(lateRun); handler.postDelayed(lateRun, 800) }
    }

    private val refreshRun = Runnable { refresh() }
    private val lateRun = Runnable { refresh() }

    private fun refresh() {
        val guide = Guides.active ?: run { hide(); return }
        val root = rootInActiveWindow ?: return
        val pkg = root.packageName?.toString() ?: ""
        if (pkg == packageName) { hide(); return }
        if (guide !== lastGuide) { lastGuide = guide; findPkg = null }
        // "Find an app" guide: finished once the person has left the screen where the icon was.
        if (guide.id == "find" && findPkg != null && pkg != findPkg && pkg.isNotEmpty() && !pkg.contains("systemui", true)) { findPkg = null; finish(guide); return }
        val nodes = candidates(root)
        val dm0 = resources.displayMetrics
        val dump = nodes.filter { !it.isPassword }.mapNotNull { n ->
            val t = (n.text ?: n.contentDescription)?.toString()?.takeIf { it.isNotBlank() } ?: return@mapNotNull null
            val r = Rect(); n.getBoundsInScreen(r)
            "$t@${r.top * 100 / dm0.heightPixels}%" + (n.className?.toString() ?: "").substringAfterLast('.')
        }.take(70).joinToString(" | ")
        Guides.seen.remove(pkg); Guides.seen[pkg] = "$pkg (h=${dm0.heightPixels}): $dump"
        while (Guides.seen.size > 3) Guides.seen.remove(Guides.seen.keys.first())
        if (guide.id == "ai") { aiRefresh(guide, nodes, pkg); return }
        // Show the LATEST step whose target is on screen. This skips steps a phone brand doesn't have.
        for (i in guide.steps.size - 1 downTo 0) {
            val skip = guide.steps[i].skipIn
            if (skip != null && pkg.contains(skip, true)) continue
            syntheticRect = null
            val node = find(nodes, guide.steps[i]) ?: continue
            if (guide.id == "find") findPkg = pkg
            if (guide.steps[i].toggle && (node.isChecked || isDone(guide))) { finish(guide); return }
            Guides.index = i
            val r = Rect(); node.getBoundsInScreen(r)
            syntheticRect?.let { r.set(it) }
            show(r)
            val st = guide.steps[i]
            showLabel(st.say[Guides.lang] ?: st.say["en"] ?: "", r.centerY() > resources.displayMetrics.heightPixels / 2)
            if (spokenFor != i) { spokenFor = i; speak(guide.steps[i]) }
            // On the last step, keep checking the real phone state until the task is done.
            if (guide.doneWhen != null && i == guide.steps.size - 1) { handler.removeCallbacks(refreshRun); handler.postDelayed(refreshRun, 700) }
            return
        }
        hide()
        if (guide.id == "find") guide.hint?.let { showLabel(it[Guides.lang] ?: it["en"] ?: "", false) }
    }

    // ---- Smart guide: the AI picks the next button from the words on screen ----
    private val blockedApps = listOf("momo", "airtel", "mtn", "bank", "zanaco", "fnb", "stanbic", "absa", "finance", "wallet", "pay", "money", "binance", "paypal", "credit", "loan", "cash")
    private fun sensitive(pkg: String, nodes: List<AccessibilityNodeInfo>) = blockedApps.any { pkg.contains(it, true) } || nodes.any { it.isPassword }

    private fun hideRing() { ring?.let { try { wm?.removeView(it) } catch (_: Exception) {} }; ring = null }

    private fun aiRefresh(guide: Guide, nodes: List<AccessibilityNodeInfo>, pkg: String) {
        if (sensitive(pkg, nodes)) {   // nothing is sent from these screens
            hideRing(); showLabel("For your safety I cannot guide you on this screen. Please do it yourself, or ask someone you trust.", false); return
        }
        val fp = nodes.mapNotNull { (it.text ?: it.contentDescription)?.toString() }.take(60).hashCode()
        val st = Guides.aiStep
        val node = if (st != null && st.match.isNotEmpty()) find(nodes, st) else null
        if (st != null && node != null) {
            val r = Rect(); node.getBoundsInScreen(r); show(r)
            showLabel(st.say[Guides.lang] ?: st.say["en"] ?: "", r.centerY() > resources.displayMetrics.heightPixels / 2)
            return
        }
        hideRing()
        if (st != null) showLabel(st.say[Guides.lang] ?: st.say["en"] ?: "", false)
        // Ask for the next step when there is none yet, or the screen changed since the last question.
        if (!Guides.aiBusy && (st == null || fp != Guides.aiFp)) askNext(guide, nodes, fp)
    }

    private fun askNext(guide: Guide, nodes: List<AccessibilityNodeInfo>, fp: Int) {
        if (Guides.aiAsked >= 12) {
            Guides.active = null; hideRing(); holdUntil = System.currentTimeMillis() + 4000
            showLabel("Let\u2019s stop here. Ask me again if you still need help.", false); handler.postDelayed({ hideLabel() }, 4000); return
        }
        val labels = nodes.filter { !it.isPassword }
            .mapNotNull { (it.text ?: it.contentDescription)?.toString()?.trim() }
            .filter { it.isNotEmpty() && it.length <= 50 && !Regex("\\d{5,}").containsMatchIn(it) && !it.contains("@") }
            .distinct().take(70)
        if (labels.isEmpty()) return
        Guides.aiBusy = true; Guides.aiFp = fp; Guides.aiAsked++
        val goal = Guides.aiGoal; val lang = Guides.lang; val hist = ArrayList(Guides.aiHistory)
        val id = getSharedPreferences("sg", MODE_PRIVATE).getString("id", "") ?: ""
        Thread {
            val r = Server.next(goal, lang, id, labels, hist)
            handler.post {
                Guides.aiBusy = false
                if (Guides.active !== guide) return@post
                if (r == null) {
                    Guides.aiStep = Step(emptyList(), mapOf(lang to "I could not reach the helper. Please try again."), null)
                } else if (r.done) {
                    finish(Guide(guide.id, guide.title, mapOf(lang to r.say), emptyList(), emptyList()))
                    return@post
                } else {
                    Guides.aiHistory.add(r.say)
                    val step = Step(if (r.label != null) listOf(r.label) else emptyList(), mapOf(lang to r.say), null)
                    Guides.aiStep = step
                    speak(step)
                }
                refresh()
            }
        }.start()
    }

    // Phones draw switches differently; accept anything that looks like one.
    private fun isSwitchLike(n: AccessibilityNodeInfo?): Boolean {
        if (n == null) return false
        val c = n.className?.toString() ?: ""
        return n.isCheckable || c.contains("Switch") || c.contains("Toggle") || c.contains("CheckBox")
    }

    // Ask Android itself whether the task is done, instead of guessing from the screen.
    private fun isDone(g: Guide): Boolean = when (g.doneWhen) {
        "wifi_on" -> try { (applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).isWifiEnabled } catch (e: Exception) { false }
        "bluetooth_on" -> try { Settings.Global.getInt(contentResolver, "bluetooth_on", 0) == 1 } catch (e: Exception) { false }
        "airplane_on" -> try { Settings.Global.getInt(contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) == 1 } catch (e: Exception) { false }
        else -> false
    }

    private fun finish(g: Guide) {
        hide(); Guides.active = null; spokenFor = -1; say(g.done)
        holdUntil = System.currentTimeMillis() + 4000
        showLabel("\u2714 " + (g.done[Guides.lang] ?: g.done["en"] ?: ""), false)
        handler.postDelayed({ hideLabel() }, 4000)
    }

    private fun norm(s: String?) = (s ?: "").lowercase().filter { it.isLetterOrDigit() }

    // Every visible node on screen, as a flat list.
    private fun candidates(root: AccessibilityNodeInfo): List<AccessibilityNodeInfo> {
        val out = ArrayList<AccessibilityNodeInfo>()
        val q = ArrayDeque<AccessibilityNodeInfo>(); q.add(root)
        var seen = 0
        while (q.isNotEmpty() && seen < 800) {
            val n = q.removeFirst(); seen++
            if (n.isVisibleToUser) out.add(n)
            for (i in 0 until n.childCount) n.getChild(i)?.let { q.add(it) }
        }
        return out
    }

    // Some phones never report certain rows (e.g. Airplane mode on Infinix). If the screen's title matches
    // but the row is missing, point at the empty band between the title bar and the next heading.
    private var syntheticRect: Rect? = null
    private fun gapRow(nodes: List<AccessibilityNodeInfo>, s: Step, h: Int): AccessibilityNodeInfo? {
        val tk = (s.titles ?: s.match).map { norm(it) }
        val title = nodes.firstOrNull { n ->
            val r = Rect(); n.getBoundsInScreen(r)
            r.top <= h * 0.12 && norm(n.text?.toString()) in tk
        } ?: return null
        val tr = Rect(); title.getBoundsInScreen(tr)
        val next = nodes.mapNotNull { n ->
            if (n.text.isNullOrBlank()) return@mapNotNull null
            val r = Rect(); n.getBoundsInScreen(r)
            if (r.top > tr.bottom + h * 0.02) r.top else null
        }.minOrNull() ?: return null
        val top = tr.bottom + (h * 0.01).toInt()
        val bottom = next - (h * 0.01).toInt()
        if (bottom - top < h * 0.04) return null
        val mid = (top + bottom) / 2
        val half = minOf((bottom - top) / 2, (h * 0.045).toInt())
        val w = resources.displayMetrics.widthPixels
        syntheticRect = Rect((w * 0.03).toInt(), mid - half, (w * 0.97).toInt(), mid + half)
        return title
    }

    private fun area(n: AccessibilityNodeInfo): Long { val r = Rect(); n.getBoundsInScreen(r); return r.width().toLong() * r.height() }

    private fun find(nodes: List<AccessibilityNodeInfo>, s: Step): AccessibilityNodeInfo? {
        if (s.toggle) {
            nodes.firstOrNull { n ->
                val row = n.parent
                isSwitchLike(n) && row != null && blob(row).length < 120 && matches(row, s.match)
            }?.let { return it }
            // Fallback: the labelled row below the title bar (some phones hide the switch itself).
            val h = resources.displayMetrics.heightPixels
            val keys = s.match.map { norm(it) }
            // Only on the screen that is itself named "Wi-Fi" (label in the title bar), not on the Settings list.
            // Not on the main Settings list (its "Wi-Fi" row is a menu entry, not the switch).
            val onSettingsList = nodes.any { n ->
                val r = Rect(); n.getBoundsInScreen(r)
                r.top <= h * 0.12 && norm(n.text?.toString()) == "settings"
            }
            if (onSettingsList) return null
            val below = nodes.filter { n -> val r = Rect(); n.getBoundsInScreen(r); r.top > h * 0.12 }
            val row = below.filter { n -> norm(n.text?.toString()) in keys || norm(n.contentDescription?.toString()) in keys }.minByOrNull { area(it) }
                ?: below.filter { n -> keys.any { k -> norm(n.text?.toString()).startsWith(k) } }.minByOrNull { area(it) }
                ?: return gapRow(nodes, s, h)
            return target(row)
        }
        val dm = resources.displayMetrics
        val maxArea = dm.widthPixels.toLong() * dm.heightPixels / 6   // ignore huge containers
        for (k in s.match) {
            val nk = norm(k)
            // Same words, ignoring odd hyphens and spacing. The smallest box is the most specific one.
            val best = nodes.filter { norm(it.text?.toString()) == nk || norm(it.contentDescription?.toString()) == nk }
                .filter { area(it) in 1L..maxArea }.minByOrNull { area(it) } ?: continue
            return target(best)
        }
        return null
    }

    // The tappable thing around the label, but never a huge container like a whole screen.
    private fun target(n: AccessibilityNodeInfo): AccessibilityNodeInfo {
        val nr = Rect(); n.getBoundsInScreen(nr)
        val d = resources.displayMetrics
        val limit = minOf(maxOf(1, nr.width() * nr.height()) * 4L, d.widthPixels.toLong() * d.heightPixels / 5)
        var c: AccessibilityNodeInfo = n
        repeat(3) {
            val p = c.parent ?: return n
            val pr = Rect(); p.getBoundsInScreen(pr)
            if (pr.width().toLong() * pr.height() > limit) return n
            if (p.isClickable) return p
            c = p
        }
        return n
    }

    private fun blob(n: AccessibilityNodeInfo?, d: Int = 0): String {
        if (n == null || d > 3) return ""
        var s = "${n.text} ${n.contentDescription} "
        for (i in 0 until n.childCount) s += blob(n.getChild(i), d + 1)
        return s
    }
    private fun matches(n: AccessibilityNodeInfo?, keys: List<String>): Boolean {
        val t = blob(n).lowercase()
        return keys.any { t.contains(it.lowercase()) }
    }

    private fun show(r: Rect) {
        val w = wm ?: return
        val lp = WindowManager.LayoutParams(r.width() + 52, r.height() + 52,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = r.left - 26; lp.y = r.top - 26
        val v = ring
        if (v == null) { ring = RingView(this).also { w.addView(it, lp) } } else w.updateViewLayout(v, lp)
    }
    private fun hide() {
        ring?.let { try { wm?.removeView(it) } catch (_: Exception) {} }; ring = null
        if (System.currentTimeMillis() >= holdUntil) hideLabel()
    }

    // Instruction text on screen too, because many phones have no Chinyanja or Icibemba voice.
    private fun showLabel(text: String, top: Boolean) {
        val w = wm ?: return
        val d = resources.displayMetrics
        val lp = WindowManager.LayoutParams((d.widthPixels * 0.9).toInt(), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT)
        lp.gravity = (if (top) Gravity.TOP else Gravity.BOTTOM) or Gravity.CENTER_HORIZONTAL
        lp.y = (96 * d.density).toInt()
        val v = label
        if (v == null) {
            val t = TextView(this)
            t.textSize = 20f; t.setTextColor(Color.BLACK); t.typeface = Typeface.DEFAULT_BOLD; t.gravity = Gravity.CENTER
            val p = (14 * d.density).toInt(); t.setPadding(p, p, p, p)
            val g = GradientDrawable(); g.setColor(0xFFF0A935.toInt()); g.cornerRadius = 18 * d.density; t.background = g
            t.text = text; label = t; w.addView(t, lp)
        } else {
            if (v.text.toString() != text) v.text = text
            w.updateViewLayout(v, lp)
        }
    }
    private fun hideLabel() { label?.let { try { wm?.removeView(it) } catch (_: Exception) {} }; label = null }

    private fun speak(s: Step) {
        val l = Guides.lang
        val res = s.audio?.let { resources.getIdentifier("${it}_$l", "raw", packageName) } ?: 0
        if (res != 0) { mp?.release(); mp = MediaPlayer.create(this, res); mp?.start(); return }
        say(s.say)
    }
    // Uses a voice for the chosen language if the phone has one; otherwise falls back to English.
    private fun say(texts: Map<String, String>) {
        if (!ttsReady) return
        val l = Guides.lang
        val loc = Locale(l)
        val ok = (tts?.isLanguageAvailable(loc) ?: TextToSpeech.LANG_NOT_SUPPORTED) >= TextToSpeech.LANG_AVAILABLE
        val msg = if (ok) texts[l] else texts["en"]
        tts?.language = if (ok) loc else Locale.ENGLISH
        if (msg != null) tts?.speak(msg, TextToSpeech.QUEUE_FLUSH, null, "sg")
    }
}
