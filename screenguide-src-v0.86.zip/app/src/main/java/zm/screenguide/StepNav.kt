package zm.screenguide

// ◀ and ▶ on the instruction card (6 Nov, the owner's idea; he chose arrows on the card). ScreenGuide never taps for
// the person: ◀ shows the earlier instruction again (with its ring, when its button is on this screen), and ▶ moves on:
// the next step of a numbered guide, or, in a Smart guide, the AI is told they skipped this one and gives the next step
// or another way. A step shown by an arrow stays until the screen changes or PEEK_MS pass; then the guide goes on as usual.
object StepNav {
    const val PEEK_MS = 8000L

    // Numbered guides: the step each arrow shows, or null when there is none that way.
    fun back(index: Int, size: Int): Int? {
        if (size <= 0) return null
        val i = index.coerceIn(0, size - 1)
        return if (i > 0) i - 1 else null
    }
    fun skip(index: Int, size: Int): Int? = if (size > 0 && index + 1 < size) maxOf(index + 1, 0) else null

    // Smart guides: at is the place, in the instructions shown so far, of the one on the card now (the count, when it is
    // not among them, such as an error). The one before it, or null.
    fun before(at: Int): Int? = if (at > 0) at - 1 else null

    // Smart guides: the instructions worth going back to, oldest first. The same words twice in a row are kept once
    // (the newest copy, so the one on the card is found in the list).
    fun remember(shown: MutableList<Step>, s: Step, max: Int = 12) {
        val last = shown.lastOrNull()
        if (last != null && last.say == s.say && last.match == s.match) { shown[shown.size - 1] = s; return }   // the newest copy
        shown.add(s)
        while (shown.size > max) shown.removeAt(0)
    }

    // A numbered step that says "Tap the glowing row" is named by its row's words on this phone. For a step shown by ◀ ▶:
    // its row on this screen if it is here, else its row as it was when that step was shown, else the guide's own name
    // for it. Never another step's row (7 Nov: ◀ on "Tap Data Usage" showed "Step 2 of 4" with the words "Tap Data Usage").
    // null: the step's own words stay.
    fun rowName(say: String, onScreen: String?, seen: String?, match: List<String>): String? {
        if (!say.contains("glowing row")) return null
        return listOf(onScreen, seen, match.firstOrNull { !it.startsWith("@") })
            .firstNotNullOfOrNull { w -> w?.trim()?.takeIf { it.isNotEmpty() && it.length <= 40 } }
    }

    // What the AI is told when the person skips its step
    fun skipNote(say: String): String =
        "They tapped Skip on “${say.trim().take(80)}”: it did not work for them, or they did it already. " +
            "Give the next step, or another way."
}
