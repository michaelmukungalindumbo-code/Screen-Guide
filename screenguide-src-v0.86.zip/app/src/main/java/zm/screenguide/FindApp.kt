package zm.screenguide

// Getting into the app a guide needs when its icon is not on the screen. 6 Nov (issues 39 and 40, Infinix): the list of
// all apps was already open, scrolled past Drive, with a Search box; the guide said "Swipe up to see all your apps", and
// the owner asked "why didn't you just tell me to search?". He chose: point at Search, then say what to type.
object FindApp {
    enum class Way { TYPE, SEARCH, SCROLL, SWIPE, HOME }

    // The phone's own app search ("Search", "Search apps"), never a search inside an app ("Search in Drive").
    private val searchBox = Regex("^search(\\s+(apps|your apps|phone|your phone|apps (and|&) more))?\\W*$", RegexOption.IGNORE_CASE)
    fun isSearchBox(word: String) = searchBox.matches(word.trim())

    private fun norm(s: String) = s.lowercase().filter { it.isLetterOrDigit() }
    private val listWords = setOf("allapps", "searchapps", "applibrary", "searchyourapps")
    private val letter = Regex("^[A-Z#]$")

    // The list of all apps: its own words ("All apps", "Search apps"), the A-Z index down its side, or the app names in
    // A to Z order, which is all Infinix's list has. shown: the screen's words, top to bottom; installed: app names.
    fun isAppList(shown: List<String>, installed: Collection<String>): Boolean {
        if (shown.any { norm(it) in listWords }) return true
        if (shown.count { letter.matches(it.trim()) } >= 8) return true
        val known = installed.map { it.trim().lowercase() }.toSet()
        val names = shown.map { it.trim().lowercase() }.filter { it in known }
        if (names.size < 6) return false
        return names.zipWithNext().count { (a, b) -> a <= b } >= (names.size - 1) * 0.8
    }

    // home: the phone's home or app list is showing. search: its Search box is on the screen. typing: a text box is open.
    // searched: they were already told to tap Search (so an open box is that search, waiting for the name).
    fun way(home: Boolean, appList: Boolean, search: Boolean, typing: Boolean, searched: Boolean): Way = when {
        typing && searched -> Way.TYPE
        home && appList && search -> Way.SEARCH
        home && appList -> Way.SCROLL
        home -> Way.SWIPE
        else -> Way.HOME
    }

    // tests first: not yet (v0.85)
    fun isCopyOf(word: String, app: String) = false
    fun isTwin(word: String, app: String) = false
    fun isCut(word: String, app: String) = false
    fun places(boxes: List<IntArray>) = 0
    fun hiddenHere(app: String, shown: List<String>, installed: Collection<String>) = false
    fun typedName(typed: String, app: String) = false
    fun twoCopies(app: String) = ""
    fun hidden(app: String) = ""

    // English only, like the other words of this step: there are no checked Nyanja or Bemba words for "type" yet.
    fun say(way: Way, app: String, box: String = "Search"): String = when (way) {
        Way.TYPE -> "Type $app."
        Way.SEARCH -> "Tap “$box”, then type $app."
        Way.SCROLL -> "Scroll down to find “$app”."
        Way.SWIPE -> "Swipe up to see all your apps."
        Way.HOME -> "Press Home, then swipe up to see all your apps."
    }
}
