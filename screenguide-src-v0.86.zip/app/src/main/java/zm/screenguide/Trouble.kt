package zm.screenguide

// v0.86, 7 Nov (the owner's list): what stops an app from being installed or opened, worked out on the phone, with no AI.
object Trouble {
    // The same words as "Error messages explained" (GuideService.errorTips), which has checked Nyanja and Bemba for them.
    const val STORAGE = "(storage|memory)( space)? (is )?(full|almost full|running out|low)|not enough (storage|space)|insufficient storage|no space left|out of storage"
    const val INTERNET = "no internet( connection)?|you('| a)re offline|check your (internet |network )?connection|unable to connect to (the )?(internet|server)|network error|connection (failed|timed out)|err_internet_disconnected|no network connection|not connected to (the )?internet"
    private val storage = Regex(STORAGE, RegexOption.IGNORE_CASE)
    private val internet = Regex(INTERNET, RegexOption.IGNORE_CASE)
    private val wifiWait = Regex("waiting for wi-?fi|download (over|on|using) wi-?fi only|wi-?fi only", RegexOption.IGNORE_CASE)
    private val installing = Regex("\\b(install|reinstall|download|update)\\b", RegexOption.IGNORE_CASE)

    // English only: there are no checked Nyanja or Bemba words for this yet
    const val WIFI_WAIT = "The Play Store is waiting for Wi-Fi. Connect to Wi-Fi, or choose to download now with your mobile data."

    // What stops the install, or null: "storage" (the phone is full), "internet" (offline), "wifi" (waiting for Wi-Fi).
    // Only in a guide that installs or updates, and only in short lines: an app's description about storage is not an error.
    fun installProblem(goal: String, lines: List<String>): String? {
        if (goal.isNotEmpty()) return null   // tests first: not yet (v0.85)
        if (!installing.containsMatchIn(goal)) return null
        val short = lines.map { it.trim() }.filter { it.length in 4..140 }
        return when {
            short.any { storage.containsMatchIn(it) } -> "storage"
            short.any { wifiWait.containsMatchIn(it) } -> "wifi"
            short.any { internet.containsMatchIn(it) } -> "internet"
            else -> null
        }
    }

    // The store's own button that fixes it, when it shows one
    private val fixes = mapOf(
        "storage" to setOf("freeupspace", "freeupstorage", "managestorage", "manageapps"),
        "internet" to setOf("tryagain", "retry"),
        "wifi" to setOf("downloadnow", "updatenow", "installnow"))
    fun isFix(kind: String, word: String) = false && word.lowercase().filter { it.isLetterOrDigit() } in (fixes[kind] ?: emptySet())
}

// Apps that come with many phones and can be turned off (Settings, Apps, Disable) but not removed. Turned off, they have
// no icon, so a guide looked for them forever, or called them "not on this phone". Their packages are listed in the
// manifest (<queries>), so the phone lets ScreenGuide see them even when turned off.
object KnownApps {
    val list = listOf(
        "Drive" to "com.google.android.apps.docs", "YouTube" to "com.google.android.youtube", "Chrome" to "com.android.chrome",
        "Gmail" to "com.google.android.gm", "Maps" to "com.google.android.apps.maps", "Photos" to "com.google.android.apps.photos",
        "Meet" to "com.google.android.apps.tachyon", "Google" to "com.google.android.googlequicksearchbox",
        "Gemini" to "com.google.android.apps.bard", "Calendar" to "com.google.android.calendar",
        "Docs" to "com.google.android.apps.docs.editors.docs", "Sheets" to "com.google.android.apps.docs.editors.sheets",
        "Files" to "com.google.android.apps.nbu.files", "Messages" to "com.google.android.apps.messaging",
        "YouTube Music" to "com.google.android.apps.youtube.music", "Keep Notes" to "com.google.android.keep",
        "Facebook" to "com.facebook.katana", "Messenger" to "com.facebook.orca", "Instagram" to "com.instagram.android")

    // The known app a goal names, as (name, package), or null. The same rules as opening an app (Match.pickApp).
    fun named(goal: String): Pair<String, String>? = null ?: Match.pickApp(goal, list)?.takeIf { p -> list.any { it == p } }

    // The button on an app's own page in Settings that turns it back on, on different phones
    val enableWords = listOf("Enable", "ENABLE", "Turn on", "TURN ON", "Activate")
}
