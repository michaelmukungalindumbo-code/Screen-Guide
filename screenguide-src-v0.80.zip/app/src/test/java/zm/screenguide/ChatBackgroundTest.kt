package zm.screenguide

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ChatBackgroundTest {
    // The app's own text colours (MainActivity): ink, mute and the accent, in light and in dark mode
    private val light = Triple(0xFF1F1A14.toInt(), 0xFF534C45.toInt(), 0xFF145A3D.toInt())
    private val dark = Triple(0xFFF2F4F5.toInt(), 0xFFADB5BA.toInt(), 0xFF18C3DA.toInt())

    // v0.78, 6 Nov: the owner asked for a choice of chat background colours, like WhatsApp's chat themes
    @Test fun thereIsAChoice() {
        assertTrue(ChatBackground.choices.size >= 6)
        assertEquals(ChatBackground.choices.size, ChatBackground.choices.map { it.key }.toSet().size)
        assertEquals(ChatBackground.choices.size, ChatBackground.choices.map { it.light }.toSet().size)
        assertEquals("Default", ChatBackground.of("default").name)
        assertEquals("Default", ChatBackground.of("something old").name)                  // an unknown choice: the usual colour
        assertEquals(0xFFFAF6EF.toInt(), ChatBackground.color("default", false))          // the same as before in both modes
        assertEquals(0xFF0B0D0F.toInt(), ChatBackground.color("default", true))
        assertEquals(ChatBackground.of("green").dark, ChatBackground.color("green", true))
    }

    // Every colour keeps the words easy to read, for people with weak eyes and in sunlight
    @Test fun everyColourIsEasyToRead() {
        for (c in ChatBackground.choices) {
            for ((bg, t) in listOf(c.light to light, c.dark to dark)) {
                assertTrue("${c.name}: text", ChatBackground.contrast(t.first, bg) >= 7.0)
                assertTrue("${c.name}: grey text", ChatBackground.contrast(t.second, bg) >= 4.5)
                assertTrue("${c.name}: buttons", ChatBackground.contrast(t.third, bg) >= 4.5)
            }
        }
        assertEquals(21.0, ChatBackground.contrast(0xFF000000.toInt(), 0xFFFFFFFF.toInt()), 0.01)
    }

    // v0.80, 6 Nov: the owner asked for a photo from the gallery as the chat background. It is softened enough that the
    // words stay easy to read on any photo: black, white, bright colours.
    @Test fun aPhotoIsSoftenedEnough() {
        val photos = listOf(0xFF000000, 0xFFFFFFFF, 0xFFFF0000, 0xFF00FF00, 0xFF0000FF, 0xFF808080, 0xFFFFFF00, 0xFF00FFFF).map { it.toInt() }
        for (p in photos) for ((paper, t) in listOf(0xFFFAF6EF.toInt() to light, 0xFF0B0D0F.toInt() to dark)) {
            val bg = ChatBackground.veil(p, paper)
            assertTrue("text on ${Integer.toHexString(p)}", ChatBackground.contrast(t.first, bg) >= 7.0)
            assertTrue("grey text on ${Integer.toHexString(p)}", ChatBackground.contrast(t.second, bg) >= 4.5)
            assertTrue("buttons on ${Integer.toHexString(p)}", ChatBackground.contrast(t.third, bg) >= 4.5)
        }
        assertEquals("Your photo", ChatBackground.name("photo"))
        assertEquals("Green", ChatBackground.name("green"))
        assertEquals(ChatBackground.color("default", true), ChatBackground.color("photo", true))   // no photo yet: the usual colour
    }

    // Made small (cheap phones have little memory) and cut to the screen's shape from the middle, never stretched
    @Test fun aPhotoIsMadeSmallAndFitsTheScreen() {
        assertEquals(2, ChatBackground.sample(4000, 3000, 1080))
        assertEquals(4, ChatBackground.sample(8000, 6000, 1080))
        assertEquals(1, ChatBackground.sample(1080, 2400, 1080))
        assertEquals(1, ChatBackground.sample(500, 500, 1080))
        assertEquals(listOf(1325, 0, 1350, 3000), ChatBackground.crop(4000, 3000, 1080, 2400).toList())   // a wide photo
        assertEquals(listOf(600, 0, 1800, 4000), ChatBackground.crop(3000, 4000, 1080, 2400).toList())    // a phone photo
        assertEquals(listOf(0, 889, 1000, 2222), ChatBackground.crop(1000, 4000, 1080, 2400).toList())    // a very tall one
    }
}
