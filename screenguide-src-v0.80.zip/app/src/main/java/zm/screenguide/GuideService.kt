package zm.screenguide

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.ScreenshotResult
import android.accessibilityservice.AccessibilityService.TakeScreenshotCallback
import android.os.Build
import android.view.Display
import android.animation.ValueAnimator
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.widget.TextView
import android.media.MediaPlayer
import android.net.wifi.WifiManager
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityWindowInfo
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.Locale
import org.json.JSONArray
import org.json.JSONObject

class RingView(c: Context) : View(c) {
    var arrowBelow = true
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 8f; color = 0xFFF0A935.toInt() }
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = 0xE6FFFFFF.toInt() }
    private val edgeP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 5f; color = 0xFFFFA45B.toInt() }
    private val glowP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 14f; color = 0xCCFFA45B.toInt(); maskFilter = BlurMaskFilter(18f, BlurMaskFilter.Blur.NORMAL) }
    private val areaP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = 0x26FFA45B }
    init { setLayerType(LAYER_TYPE_SOFTWARE, null) }   // needed for the soft glow
    private val still = Settings.Global.getFloat(c.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f
    private var t = 0f
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1200; repeatCount = ValueAnimator.INFINITE
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); if (!still) anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }
    override fun onDraw(c: Canvas) {
        val a = 118f
        val top = if (arrowBelow) 0f else a
        val bottom = height - (if (arrowBelow) a else 0f)
        p.alpha = 255
        val box = RectF(26f, top + 26f, width - 26f, bottom - 26f)
        c.drawRoundRect(box, 30f, 30f, areaP)
        c.drawRoundRect(box, 30f, 30f, glowP)
        c.drawRoundRect(box, 30f, 30f, p)
        if (!still) {
            val g = 26f - 22f * t
            p.alpha = (255 * (1 - t)).toInt()
            c.drawRoundRect(RectF(g, top + g, width - g, bottom - g), 34f, 34f, p)
        }
        // A pointing arrow that bobs toward the target.
        val bob = if (still) 0f else 14f * kotlin.math.sin(t * 6.2831855f)
        val cx = width / 2f
        val s = if (arrowBelow) 1f else -1f
        val tip = if (arrowBelow) bottom - 26f + 12f - bob else top + 26f - 12f + bob
        val path = Path()
        path.moveTo(cx, tip)
        path.lineTo(cx - 34f, tip + s * 44f); path.lineTo(cx - 14f, tip + s * 44f)
        path.lineTo(cx - 14f, tip + s * 84f); path.lineTo(cx + 14f, tip + s * 84f)
        path.lineTo(cx + 14f, tip + s * 44f); path.lineTo(cx + 34f, tip + s * 44f); path.close()
        c.drawPath(path, fillP); c.drawPath(path, edgeP)
    }
}

// A scrolling box that grows with its text, up to a limit (a long reading stays inside the card).
class MaxScroll(c: Context, private val max: Int) : ScrollView(c) {
    override fun onMeasure(w: Int, h: Int) = super.onMeasure(w, View.MeasureSpec.makeMeasureSpec(max, View.MeasureSpec.AT_MOST))
}

// A finger that slides upward, showing the swipe the person has to make (on the home screen and the app list).
// A floating piece that one finger can drag anywhere; a short tap still presses the button under the finger (or runs
// onTap on the piece itself). Asked for after the buttons and cards covered YouTube's editor tools.
class DragLayout(c: Context, private val onDrag: (Int, Int) -> Unit, private val onDrop: () -> Unit, private val onTap: (() -> Unit)? = null) : LinearLayout(c) {
    private val slop = android.view.ViewConfiguration.get(c).scaledTouchSlop
    private var sx = 0f; private var sy = 0f; private var lx = 0f; private var ly = 0f; private var dragging = false
    private fun moved(e: android.view.MotionEvent) = Math.abs(e.rawX - sx) > slop || Math.abs(e.rawY - sy) > slop
    override fun onInterceptTouchEvent(e: android.view.MotionEvent): Boolean {
        when (e.actionMasked) {
            android.view.MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; lx = sx; ly = sy; dragging = false }
            android.view.MotionEvent.ACTION_MOVE -> if (!dragging && moved(e)) { dragging = true; lx = e.rawX; ly = e.rawY }
        }
        return dragging
    }
    override fun onTouchEvent(e: android.view.MotionEvent): Boolean {
        when (e.actionMasked) {
            android.view.MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; lx = sx; ly = sy; dragging = false }
            android.view.MotionEvent.ACTION_MOVE -> {
                if (!dragging && moved(e)) dragging = true
                if (dragging) { onDrag((e.rawX - lx).toInt(), (e.rawY - ly).toInt()); lx = e.rawX; ly = e.rawY }
            }
            android.view.MotionEvent.ACTION_UP -> { if (dragging) onDrop() else onTap?.invoke(); dragging = false }
            android.view.MotionEvent.ACTION_CANCEL -> { if (dragging) onDrop(); dragging = false }
        }
        return true
    }
}

// down = true: the finger moves from the top edge downwards, to show how to pull down the panel with the torch.
class SwipeView(c: Context, private val down: Boolean = false) : View(c) {
    private val still = Settings.Global.getFloat(c.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = Color.WHITE }
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 5f; color = 0xFFFFA45B.toInt(); strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    private val trail = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; color = 0xFFFFA45B.toInt() }
    private var t = 0f
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1500; repeatCount = ValueAnimator.INFINITE
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); if (!still) anim.start() else t = 0.6f }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }
    override fun onDraw(c: Canvas) {
        if (down) { c.save(); c.scale(1f, -1f, width / 2f, height / 2f) }
        draw1(c)
        if (down) c.restore()
    }
    private fun draw1(c: Canvas) {
        val cx = width / 2f
        val bottom = height - 40f; val top = 100f
        val move = minOf(1f, t / 0.75f)
        val y = bottom - (bottom - top) * (1f - (1f - move) * (1f - move))   // starts quick, slows at the top
        val a = if (t < 0.85f) 1f else (1f - t) / 0.15f                      // fully visible, then a short fade
        // a short dotted trail behind the finger
        trail.style = Paint.Style.FILL
        for (k in 1..3) {
            val ty = y + 30f + k * 34f
            if (ty < bottom + 10f) { trail.alpha = ((200 - k * 55) * a).toInt(); c.drawCircle(cx, ty, 9f - k * 2f, trail) }
        }
        fill.alpha = (255 * a).toInt(); edge.alpha = (255 * a).toInt()
        c.drawCircle(cx, y, 30f, fill); c.drawCircle(cx, y, 30f, edge)
        // the arrow head above the finger
        val p = Path().apply { moveTo(cx, y - 86f); lineTo(cx - 36f, y - 46f); lineTo(cx + 36f, y - 46f); close() }
        c.drawPath(p, fill); c.drawPath(p, edge)
    }
}

class GuideService : AccessibilityService(), TextToSpeech.OnInitListener {
    private var wm: WindowManager? = null
    private var ring: RingView? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var spokenFor = -1
    private var mp: MediaPlayer? = null
    private var label: TextView? = null
    private var holdUntil = 0L
    private var findPkg: String? = null
    private var lastGuide: Guide? = null
    private val handler = Handler(Looper.getMainLooper())

    // The phone tells us when the torch turns on or off, so "Turn on the torch" finishes the moment the light comes on.
    @Volatile private var torchOn = false
    private val torchCb = object : android.hardware.camera2.CameraManager.TorchCallback() {
        override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
            torchOn = enabled
            if (Guides.active?.doneWhen == "torch_on") { handler.removeCallbacks(refreshRun); handler.post(refreshRun) }
        }
    }

    override fun onServiceConnected() {
        Crash.install(this)
        Server.initTester(this)
        try { (getSystemService(CAMERA_SERVICE) as android.hardware.camera2.CameraManager).registerTorchCallback(torchCb, handler) } catch (_: Exception) {}
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        tts = TextToSpeech(this, this)
        Guides.load(this)
        getSharedPreferences("sg", MODE_PRIVATE).registerOnSharedPreferenceChangeListener(prefsListener)
        applyReadBubble()
    }
    override fun onInit(s: Int) { ttsReady = s == TextToSpeech.SUCCESS }
    override fun onInterrupt() {}
    override fun onDestroy() {
        try { (getSystemService(CAMERA_SERVICE) as android.hardware.camera2.CameraManager).unregisterTorchCallback(torchCb) } catch (_: Exception) {}
        hide(); hideSwipe(); hideLabel(); hideControls(); hideTeachPill(); hideScamCard(); hideInfo()
        readBubble?.let { try { wm?.removeView(it) } catch (_: Exception) {} }; readBubble = null; removeCloseX()
        try { getSharedPreferences("sg", MODE_PRIVATE).unregisterOnSharedPreferenceChangeListener(prefsListener) } catch (_: Exception) {}
        tts?.shutdown(); mp?.release(); super.onDestroy() }

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        if (e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) e.packageName?.toString()?.let { bubbleVisible(it) }
        if (Testing.active) testEvent(e)
        if (Server.tester && Guides.active != null && Build.VERSION.SDK_INT >= 30) staleEvent(e)
        scamCheck(e)
        if (Live.id != null) { liveEvent(e); return }
        if (liveBar != null) liveStop(false)
        errorCheck(e)
        if (Teach.on) { teachEvent(e); return }
        if (teachPill != null) hideTeachPill()
        val guide = Guides.active ?: run { hide(); hideControls(); return }
        val clicked = e.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED && (e.packageName?.toString() != packageName || selfGuide)
        if (clicked) {
            bumpProgress()
            // The person tapped: the old ring must not linger on whatever moves into that spot (it landed on "Private DNS").
            hideRing()
            if (guide.id != "ai") quietUntil = System.currentTimeMillis() + 450
        }
        if (guide.id == "ai") {
            val other = e.packageName?.toString() != packageName
            if (other && e.eventType == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED) {
                typingAt = System.currentTimeMillis(); bumpProgress()
                val src = e.source
                val hint = listOf(if (Build.VERSION.SDK_INT >= 26) src?.hintText else null, src?.contentDescription, src?.viewIdResourceName, src?.text).joinToString(" ")
                typedSearch = hint.contains("search", true)
                typedText = if (e.isPassword || src?.isPassword == true) "" else (e.text?.joinToString(" ") ?: "").trim().take(40)
            }
            if (other && e.eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED && System.currentTimeMillis() - screenAt > 1000) {
                val box = e.source?.let { val r = Rect(); it.getBoundsInScreen(r); r }
                // A page scroll moves a big list. Sliding banners and shelves (YouTube's Shorts row) do not count.
                if (box != null && box.height() >= resources.displayMetrics.heightPixels * 0.35) {
                    scrolledAt = System.currentTimeMillis(); scrollPending = true; scrollBox = box; bumpProgress()
                    scrollAtEnd = (e.itemCount > 0 && e.toIndex >= e.itemCount - 1) || (e.maxScrollY > 0 && e.scrollY >= e.maxScrollY)
                }
            }
            if (clicked) {
                // Keep the step if the tap landed on what we pointed at: that is the path to remember.
                val st = Guides.aiStep; val src = e.source
                if (st != null && st.match.isNotEmpty() && src != null && tappedSwitch(src, st.match)) {
                    Guides.aiTapped = true   // developer phones: if the same step comes back, the watcher notices
                    if (Guides.aiTrail.lastOrNull()?.match != st.match) Guides.aiTrail.add(st)
                }
                Guides.aiStep = null   // any tap is progress: ask for the next step
            }
            schedule(e); return
        }
        if (clicked && guide.doneWhen == "last_tap" && Guides.index == guide.steps.size - 1 && !guide.steps.last().toggle) {
            val src = e.source
            if (src != null && tappedSwitch(src, guide.steps.last().match)) { finish(guide); return }
        }
        // Final step: the person tapped the switch, so we are done.
        val last = guide.steps.last()
        if (e.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED && last.toggle && Guides.index == guide.steps.size - 1 && !stateKnown(guide)) {
            val src = e.source
            if (src != null) {
                val r = Rect(); src.getBoundsInScreen(r)
                val belowTitle = r.top > resources.displayMetrics.heightPixels * 0.12
                if (belowTitle && tappedSwitch(src, last.match)) { finish(guide); return }
            }
        }
        schedule(e)
    }

    private fun schedule(e: AccessibilityEvent) {
        val own = e.packageName?.toString() == packageName && !selfGuide
        val changed = e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && !own
        // A new screen: drop the old ring at once. The card stays until the new screen replaces it, so it never blinks.
        if (changed) { hideRing(); bumpProgress(); screenAt = System.currentTimeMillis() }
        handler.removeCallbacks(refreshRun)
        handler.postDelayed(refreshRun, if (changed) 300L else 150L)
        if (changed) { handler.removeCallbacks(lateRun); handler.postDelayed(lateRun, 800) }
    }

    private val refreshRun = Runnable { refresh() }
    private val lateRun = Runnable { refresh() }

    private fun refresh() {
        if (Guides.chatOpen) { hide(); hideLabel(); hideControls(); return }   // the Tell me panel is open: keep the screen clear
        val guide = Guides.active ?: run { hide(); return }
        val root = rootInActiveWindow ?: run { if (classify() == "shade") { hide(); hideControls() }; return }
        val pkg = root.packageName?.toString() ?: ""
        if (pkg == packageName && !selfGuide) { hide(); hideControls(); return }
        // ScreenGuide's own menus say which row was tapped (their lists close as they are tapped, so Android does not)
        if (guide.id == "self") {
            val t = Guides.ownTap; Guides.ownTap = null
            if (Match.selfFinished(guide.steps.last().match.firstOrNull() ?: "", t)) { finish(guide); return }
        }
        surface = classify()
        // The notification panel is open: keep it clear, unless the task is done there (the torch).
        if (surface == "shade" && !guide.shade) { hide(); hideControls(); return }
        showControls()
        if (guide !== lastGuide) {
            lastGuide = guide; findPkg = null; WatchShots.clear()
            typingAt = 0L; scrollPending = false; scrollAsked = null; ringStep = null; aheadStep = null; reask = false; nextNote = ""
            wantPicture = false; aheadMisses = 0; practiceStart = 0L; labelY = null
            // How things were when the task started, so "done" means the person changed it now.
            fontAtStart = try { Settings.System.getFloat(contentResolver, Settings.System.FONT_SCALE, 1f) } catch (e: Exception) { 1f }
            startDone = guide.id != "ai" && guide.doneWhen != null && isDone(guide)
        }
        // "Find an app" guide: finished once the person has left the screen where the icon was.
        if (guide.id == "find" && findPkg != null && pkg != findPkg && pkg.isNotEmpty() && !pkg.contains("systemui", true)) { findPkg = null; finish(guide); return }
        val nodes = popupNodes() + candidates(root)
        lastNodes = nodes
        val dm0 = resources.displayMetrics
        val dump = nodes.filter { !it.isPassword }.mapNotNull { n ->
            val t = (n.text ?: n.contentDescription)?.toString()?.takeIf { it.isNotBlank() } ?: return@mapNotNull null
            val r = Rect(); n.getBoundsInScreen(r)
            "$t@${r.top * 100 / dm0.heightPixels}%" + (n.className?.toString() ?: "").substringAfterLast('.')
        }.take(70).joinToString(" | ")
        Guides.seen.remove(pkg); Guides.seen[pkg] = "$pkg (h=${dm0.heightPixels}): $dump"
        while (Guides.seen.size > 3) Guides.seen.remove(Guides.seen.keys.first())
        if (guide.id == "ai") { aiRefresh(guide, nodes, pkg); return }
        // The phone itself says it is done (the torch is on, battery saver is on, the words got bigger): finish, wherever
        // the person did it. Not if it was already so at the start; then the switch step finishes it, as before.
        if (guide.doneWhen != null && !startDone && isDone(guide)) { finish(guide); return }
        if (tryAlone(guide, nodes, pkg)) return
        val wait = quietUntil - System.currentTimeMillis()
        if (wait > 0) { handler.removeCallbacks(refreshRun); handler.postDelayed(refreshRun, wait + 30); return }   // let the screen change first
        // Show the LATEST step whose target is on screen. This skips steps a phone brand doesn't have.
        for (i in guide.steps.size - 1 downTo 0) {
            val skip = guide.steps[i].skipIn
            if (skip != null && pkg.contains(skip, true)) continue
            syntheticRect = null
            val node = find(nodes, guide.steps[i]) ?: continue
            if (guide.id == "find") findPkg = pkg
            if (guide.steps[i].toggle && (node.isChecked || isDone(guide))) { finish(guide); return }
            Guides.index = i; lostSince = 0L; hideSwipe()
            val r = Rect(); node.getBoundsInScreen(r)
            syntheticRect?.let { r.set(it) }
            val on = (node.text ?: node.contentDescription)?.toString()?.takeIf { it.isNotBlank() }
                ?: matchedText ?: (if (isSwitchLike(node)) "the switch" else "a button")
            note("Step ${i + 1} of ${guide.steps.size}", "Ring on \u201C$on\u201D, found by $foundHow.", nodes, pkg, Rect(r))
            show(r)
            track(if (syntheticRect == null) node else null)
            val st = named(guide.steps[i])
            showLabel(st.say[Guides.lang] ?: st.say["en"] ?: "", r.centerY() > resources.displayMetrics.heightPixels / 2, false,
                "Step ${i + 1} of ${guide.steps.size}")
            if (spokenFor != i) { spokenFor = i; speak(st); buzz(false) }
            // On the last step, keep checking the real phone state until the task is done.
            if (guide.doneWhen != null && i == guide.steps.size - 1) { handler.removeCallbacks(refreshRun); handler.postDelayed(refreshRun, 700) }
            return
        }
        hideRing()
        val home = isHome(pkg)
        if (guide.id == "find") {
            guide.hint?.let { showLabel(it[Guides.lang] ?: it["en"] ?: "", true) }
            if (home) showSwipe() else hideSwipe()
            return
        }
        if (guide.shade) { shadeHint(nodes, pkg); return }   // first the pull-down panel must open
        // Already on the page a step leads to (its name is this screen's title): the next row is further down the page.
        // Say "Scroll down to find Font size" and show the scroll, instead of pointing back at the title.
        val page = (guide.steps.size - 2 downTo 0).firstOrNull { i ->
            guide.steps[i].match.any { k -> nodes.any { n -> isTitle(n) && norm((n.text ?: n.contentDescription)?.toString()) == norm(k) } }
        }
        if (page != null) {
            val next = guide.steps[page + 1]
            Guides.index = page + 1
            val word = next.match.firstOrNull { !it.startsWith("@") }
            val l = Guides.lang
            val text = if (next.toggle || word == null) next.say[l] ?: next.say["en"] ?: "" else scrollTo(word, l)
            note("Step ${page + 2} of ${guide.steps.size}", "Already on this page; \u201C${word ?: "the next step"}\u201D is further down.", nodes, pkg)
            showLabel(text, true, false, "Step ${page + 2} of ${guide.steps.size}")
            if (!next.toggle) showSwipe() else hideSwipe()
            if (spokenFor != -10 - page) { spokenFor = -10 - page; speak(Step(emptyList(), mapOf(l to text), null)); buzz(false) }
            return
        }
        // Nothing to point at on this screen: never leave the person with nothing. Say what to look for, and show how.
        val st = guide.steps.getOrNull(Guides.index) ?: guide.steps.firstOrNull() ?: return
        val now = System.currentTimeMillis()
        if (pkg != lostPkg) { lostPkg = pkg; lostSince = now }   // only a different app restarts the wait, not every small change
        if (now - lostSince < 1200) { handler.removeCallbacks(refreshRun); handler.postDelayed(refreshRun, 1300); return }   // the screen may still be loading
        note("Step ${Guides.index + 1} of ${guide.steps.size}", "Looking for \u201C${st.match.firstOrNull() ?: ""}\u201D. It is not on this screen" +
            (if (home) ", so the swipe arrow is showing." else "."), nodes, pkg)
        val where = if (home) "Not on this screen? Swipe up to find it." else "Not on this screen? Scroll down, or go back."
        showLabel(st.say[Guides.lang] ?: st.say["en"] ?: "", true, false, where)
        if (home) showSwipe() else hideSwipe()
    }

    private fun scrollTo(w: String, l: String) = when (l) {
        "ny" -> "Pitani pansi kuti mupeze \u201C$w\u201D."
        "bem" -> "Ikeni pansi pa kusanga \u201C$w\u201D."
        else -> "Scroll down to find \u201C$w\u201D."
    }
    private var quietUntil = 0L
    private var screenAt = 0L
    private var fontAtStart = 1f
    private var startDone = false

    // ---- "Your turn": trying a task alone ----
    private val PRACTICE_MS = 15000L
    private var practiceStart = 0L
    private val yourTurn = mapOf("en" to "Your turn", "ny" to "Tsopano ndi inu", "bem" to "Nomba ni imwe")
    private val yourTurnHint = mapOf("en" to "Tap Help if you get stuck.", "ny" to "Dinani Help mukavutika.", "bem" to "Kandeni Help nga mwafilwa.")
    // True while the person is trying alone: no ring, only the goal. Help, or 15 quiet seconds, shows the way.
    private fun tryAlone(guide: Guide, nodes: List<AccessibilityNodeInfo>, pkg: String): Boolean {
        if (!Guides.practice || Guides.practiceHelped) return false
        val now = System.currentTimeMillis()
        if (practiceStart == 0L) practiceStart = now
        val left = PRACTICE_MS - (now - practiceStart)
        if (left <= 0) { Guides.practiceHelped = true; Stats.inc(this, "practice_timeout"); return false }
        hideRing(); hideSwipe()
        val l = Guides.lang
        val goal = guide.title[l] ?: guide.title["en"] ?: ""
        val turn = yourTurn[l] ?: yourTurn["en"] ?: ""
        showLabel(goal + "\n" + (yourTurnHint[l] ?: yourTurnHint["en"] ?: ""), true, false, turn)
        if (spokenFor != -2) { spokenFor = -2; speak(Step(emptyList(), mapOf(l to "$turn. $goal."), null)) }
        note("Your turn", "Trying alone: no ring for ${left / 1000} s more. Help shows the way.", nodes, pkg)
        handler.removeCallbacks(refreshRun); handler.postDelayed(refreshRun, minOf(left + 50, 1000))
        return true
    }

    // ---- The pull-down panel (the torch lives there) ----
    private val transsion = Build.MANUFACTURER.lowercase().let { m -> listOf("infinix", "tecno", "itel", "transsion").any { m.contains(it) } }
    private val pullDown = mapOf("en" to "Swipe down from the top of the screen.", "ny" to "Kokani chala pansi kuchokera pamwamba pa sikilini.",
        "bem" to "Kululeni umunwe ukufuma pa muulu wa sikilini.")
    private val pullRight = mapOf("en" to "Swipe down from the top right corner of the screen.", "ny" to "Kokani chala pansi kuchokera pamwamba kumanja kwa sikilini.",
        "bem" to "Kululeni umunwe ukufuma pa muulu ku kulyo kwa sikilini.")
    private val pullMore = mapOf("en" to "Swipe down once more to see all the buttons.", "ny" to "Kokaninso pansi kuti muone mabatani onse.",
        "bem" to "Kululeni na kabili pa kumona amabatani yonse.")
    private val wrongPanel = mapOf("en" to "Swipe up to close this. Then swipe down from the top right corner.", "ny" to "Kokani mmwamba kuti mutseke. Kenako kokani pansi kuchokera pamwamba kumanja.",
        "bem" to "Kululeni pa muulu ukwisala. Elyo kululeni ukufuma pa muulu ku kulyo.")
    private val panelWords = setOf("wifi", "bluetooth", "airplanemode", "aeroplanemode", "mobiledata", "hotspot", "autorotate", "location", "donotdisturb", "data")
    // The task's button is not showing yet: show how to open (or widen) the panel. On Infinix, Tecno and itel the
    // buttons are in a panel pulled down from the right side; the left side shows messages.
    private fun shadeHint(nodes: List<AccessibilityNodeInfo>, pkg: String) {
        val open = surface == "shade"
        val buttons = nodes.count { norm(txt(it)) in panelWords } >= 2
        val t = when { !open -> if (transsion) pullRight else pullDown; buttons || !transsion -> pullMore; else -> wrongPanel }
        note("Step 1", if (!open) "Showing how to pull the panel down." else if (buttons) "Panel open; no torch button yet." else "Messages panel open, not the buttons.", nodes, pkg)
        showLabel(t[Guides.lang] ?: t["en"] ?: "", false)
        if (!open) showSwipe(down = true, right = transsion) else if (t === pullMore) showSwipe(down = true) else hideSwipe()
        val key = -3 - listOf(pullDown, pullRight, pullMore, wrongPanel).indexOf(t)
        if (spokenFor != key) { spokenFor = key; speak(Step(emptyList(), t, null)); buzz(false) }
    }
    // Typing and scrolling during a Smart guide (see aiRefresh)
    private var typingAt = 0L
    private var typedText = ""
    private var typedSearch = false
    private var scrolledAt = 0L
    private var scrollPending = false
    private var scrollBox: Rect? = null
    private var scrollAsked: Step? = null    // re-asked once already for this step after a scroll
    private var ringStep: Step? = null
    private val firstRect = Rect()           // where the ring first sat for ringStep
    private var nextNote = ""                // what the person just did, for the next AI question
    private var aheadStep: Step? = null      // "Scroll down to find Storage": Storage gets a ring as soon as it shows
    private var askStart = 0L
    private var stepAt = 0L                  // when the current Smart guide step arrived
    private var goneSince = 0L               // when what the step points at disappeared
    private var goneAsked: Step? = null      // asked again once already because its target disappeared
    private var goneAskedAt = 0L             // when (a new screen after it allows one more: see Recheck)
    private var wantPicture = false          // words were not enough (an icon with no name): send a screen picture next
    private var aheadMisses = 0              // scrolls that did not bring the looked-for item
    private var scrollAtEnd = false
    private var reask = false                // the screen is "new" for the AI even if most words stayed (scrolled, typed)
    private var waitTop = false
    private var errStep: Step? = null
    private val swipeWords = Regex("swipe up|scroll down|see all your apps", RegexOption.IGNORE_CASE)
    private var lostPkg = ""
    private var matchedText: String? = null

    // "Tap the glowing row" names the row instead, using the words on this phone's own screen.
    private fun named(st: Step): Step {
        val w = matchedText?.trim()?.takeIf { it.isNotEmpty() && it.length <= 40 } ?: return st
        if (!(st.say["en"] ?: "").contains("glowing row")) return st
        val q = "\u201C$w\u201D"
        return Step(st.match, mapOf("en" to "Tap $q.", "ny" to "Dinani $q.", "bem" to "Kandeni $q."), st.audio, st.toggle, st.skipIn, st.titles)
    }

    private var lostSince = 0L
    private var homePkg: String? = null
    private fun isHome(pkg: String): Boolean {
        if (homePkg == null) homePkg = try {
            packageManager.resolveActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0)?.activityInfo?.packageName ?: ""
        } catch (e: Exception) { "" }
        return pkg.isNotEmpty() && (pkg == homePkg || pkg.contains("launcher", true))
    }

    // ---- Live help: someone the person trusts sees the words on this screen (from a link) and points. They can never
    // tap. The screen goes as boxes of words, only when it changes; never password, bank or money screens, nor ScreenGuide.
    private var liveBar: LinearLayout? = null
    private var liveText: TextView? = null
    private var liveRunning = false
    private var liveBusy = false
    private var liveLastSent: String? = null

    private fun liveEvent(e: AccessibilityEvent) {
        showLiveBar()
        if (!liveRunning) { liveRunning = true; liveLastSent = null; handler.post(liveRun) }
        val other = e.packageName?.toString() != packageName
        // The person tapped, or a new screen came: the helper's ring has done its job.
        if (other && (e.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED || e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED)) { hideRing(); hideLabel() }
    }

    private val liveRun = object : Runnable {
        override fun run() {
            val lid = Live.id ?: run { liveStop(false); return }
            if (System.currentTimeMillis() - Live.started > 2 * 3600_000L) { liveStop(true, "Live help has ended."); return }
            if (!liveBusy) {
                val snap = try { liveSnapshot() } catch (e: Exception) { null }
                val text = snap?.toString()
                val send = if (text != null && text != liveLastSent) snap else null
                if (send != null) liveLastSent = text
                liveBusy = true
                val key = Live.key; val last = Live.lastPoint; val iid = Server.installId(this@GuideService)
                Thread {
                    val r = Server.liveScreen(lid, key, send, last, iid)
                    handler.post {
                        liveBusy = false
                        if (Live.id != lid) return@post
                        if (r.ended) { liveStop(false, "Live help has ended."); return@post }
                        if (!r.ok) { if (send != null) liveLastSent = null; return@post }
                        if (r.helper != Live.helper) { Live.helper = r.helper; updateLiveBar() }
                        val p = r.point
                        if (p != null && p.optInt("id") > Live.lastPoint) { Live.lastPoint = p.optInt("id"); showLivePoint(p) }
                    }
                }.start()
            }
            handler.postDelayed(this, 1500)
        }
    }

    // This screen as boxes of words, in fractions of the screen, for the helper's page.
    private fun liveSnapshot(): JSONObject? {
        val root = rootInActiveWindow ?: return null
        val pkg = root.packageName?.toString() ?: return null
        val name = screenName(pkg)
        val nodes = popupNodes() + candidates(root)
        if (pkg == packageName || sensitive(pkg, nodes)) return JSONObject().put("private", true).put("app", if (pkg == packageName) "ScreenGuide" else name)
        val d = resources.displayMetrics; val sw = d.widthPixels.toFloat(); val sh = d.heightPixels.toFloat()
        val items = JSONArray()
        for (n in nodes) {
            if (items.length() >= 150) break
            val r = Rect(); n.getBoundsInScreen(r)
            if (r.width() < 4 || r.height() < 4 || r.bottom <= 0 || r.top >= sh || r.right <= 0 || r.left >= sw) continue
            val box = n.className?.toString()?.contains("EditText") == true
            val sw0 = isSwitchLike(n)
            var t = (n.text ?: n.contentDescription)?.toString()?.trim().orEmpty()
            if (box) t = if (Build.VERSION.SDK_INT >= 26 && n.isShowingHintText) t else if (t.isEmpty()) "" else "(typed)"
            if (t.isEmpty() && !box && !sw0) continue
            val k = when { sw0 -> if (n.isChecked) "on" else "off"; box -> "box"; tappable(n) -> "tap"; else -> "text" }
            items.put(JSONObject().put("t", t.take(120)).put("k", k)
                .put("x", (r.left / sw).coerceIn(0f, 1f).toDouble()).put("y", (r.top / sh).coerceIn(0f, 1f).toDouble())
                .put("w", (r.width() / sw).coerceIn(0f, 1f).toDouble()).put("h", (r.height() / sh).coerceIn(0f, 1f).toDouble()))
        }
        return JSONObject().put("app", if (isHome(pkg)) "Home screen" else name).put("ratio", (sh / sw).toDouble()).put("items", items)
    }

    private fun showLivePoint(p: JSONObject) {
        val l = Guides.lang
        val label = p.optString("label").trim().take(60)
        val say = p.optString("say").trim().ifEmpty {
            if (label.isEmpty()) mapOf("en" to "Tap here.", "ny" to "Dinani apa.", "bem" to "Kandeni apa.")[l] ?: "Tap here."
            else { val q = "“$label”"; mapOf("en" to "Tap $q.", "ny" to "Dinani $q.", "bem" to "Kandeni $q.")[l] ?: "Tap $q." }
        }
        val d = resources.displayMetrics
        val top: Boolean
        if (p.has("x")) {
            val r = Rect((p.optDouble("x") * d.widthPixels).toInt(), (p.optDouble("y") * d.heightPixels).toInt(),
                ((p.optDouble("x") + p.optDouble("w")) * d.widthPixels).toInt(), ((p.optDouble("y") + p.optDouble("h")) * d.heightPixels).toInt())
            show(r); top = r.centerY() > d.heightPixels / 2
        } else { hideRing(); top = false }
        showLabel(say, top, false, mapOf("en" to "Your helper", "ny" to "Wokuthandizani", "bem" to "Uwamwafwa")[l] ?: "Your helper")
        speak(Step(emptyList(), mapOf(l to say), null)); buzz(false)
    }

    private fun showLiveBar() {
        if (liveBar != null) return
        val w = wm ?: return
        val txt = TextView(this).apply { textSize = 14f; setTextColor(0xFF1A1A1A.toInt()); typeface = Typeface.DEFAULT_BOLD; maxWidth = dp(210) }
        liveText = txt
        val bar = DragLayout(this, { _, dy -> moveLive(dy) }, {}).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(6), dp(6), dp(6))
            background = GradientDrawable().apply { setColor(0xF8FFFFFF.toInt()); cornerRadius = dp(30).toFloat(); setStroke(dp(2), 0xFF1A73E8.toInt()) }
            elevation = dp(6).toFloat()
            addView(TextView(context).apply { text = "●"; textSize = 16f; setTextColor(0xFF1A73E8.toInt()); setPadding(0, 0, dp(6), 0) })
            addView(txt, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { rightMargin = dp(10) })
            addView(TextView(context).apply {
                text = "Stop"; textSize = 15f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
                setPadding(dp(16), dp(9), dp(16), dp(9)); background = pillBg(0xFF1A73E8.toInt())
                setOnClickListener { v -> v.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY); liveStop(true) }
            })
        }
        val lp = WindowManager.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; lp.y = dp(56)
        try { w.addView(bar, lp); liveBar = bar } catch (_: Exception) {}
        updateLiveBar()
    }
    private fun moveLive(dy: Int) {
        val v = liveBar ?: return; val lp = v.layoutParams as? WindowManager.LayoutParams ?: return
        lp.y = (lp.y + dy).coerceIn(dp(24), maxOf(dp(24), resources.displayMetrics.heightPixels - v.height - dp(24)))
        try { wm?.updateViewLayout(v, lp) } catch (_: Exception) {}
    }
    private fun updateLiveBar() {
        liveText?.text = if (Live.helper) "Live help: your helper can see your screen words" else "Live help: waiting for your helper to open the link"
    }
    private fun liveStop(tellServer: Boolean, msg: String? = null) {
        val lid = Live.id; val key = Live.key
        if (tellServer && lid != null) { val iid = Server.installId(this); Thread { Server.liveEnd(lid, key, iid) }.start() }
        Live.stop()
        handler.removeCallbacks(liveRun); liveRunning = false; liveBusy = false; liveLastSent = null
        liveBar?.let { try { wm?.removeView(it) } catch (_: Exception) {} }; liveBar = null; liveText = null
        hideRing(); hideLabel()
        if (msg != null) showInfo("Live help", msg, 0xFF1A73E8.toInt(), emptyList(), false)
    }

    // ---- A card over any app: what a screen says, or what an error means. Buttons, then Close. ----
    private var infoCard: View? = null
    private fun showInfo(title: String, body: String, accent: Int, buttons: List<Pair<String, () -> Unit>>, speakIt: Boolean) {
        hideInfo()
        val w = wm ?: return
        fun btn(t: String, bgc: Int, fg: Int, f: () -> Unit) = TextView(this).apply {
            text = t; textSize = 15.5f; setTextColor(fg); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            setPadding(dp(14), dp(11), dp(14), dp(11)); background = pillBg(bgc)
            setOnClickListener { v -> v.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY); f() }
        }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(16), dp(18), dp(14))
            background = GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = dp(22).toFloat(); setStroke(dp(2), accent) }
            elevation = dp(10).toFloat()
            addView(TextView(context).apply { text = title; textSize = 18f; setTextColor(accent); typeface = Typeface.DEFAULT_BOLD })
            addView(MaxScroll(context, dp(260)).apply {
                addView(TextView(context).apply { text = body; textSize = 17f; setTextColor(0xFF1A1A1A.toInt()); setPadding(0, dp(8), 0, dp(12)); setLineSpacing(0f, 1.15f) })
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            val row = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
            (buttons + ("Close" to { hideInfo() })).forEachIndexed { i, (t, f) ->
                row.addView(btn(t, if (i == 0 && buttons.isNotEmpty()) accent else 0xFFEDE7DD.toInt(), if (i == 0 && buttons.isNotEmpty()) Color.WHITE else 0xFF1A1A1A.toInt(), f),
                    LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { if (i > 0) leftMargin = dp(8) })
            }
            addView(row)
        }
        val wrap = FrameLayout(this).apply { setPadding(dp(12), 0, dp(12), dp(12)); addView(card) }
        val lp = WindowManager.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.BOTTOM; lp.y = dp(24)
        try { w.addView(wrap, lp); infoCard = wrap } catch (_: Exception) { return }
        if (speakIt) speak(Step(emptyList(), mapOf(Guides.lang to body), null))
    }
    private fun hideInfo() { infoCard?.let { try { wm?.removeView(it) } catch (_: Exception) {} }; infoCard = null; try { tts?.stop() } catch (_: Exception) {} }

    // ---- The Read button: a small round button the person can drag anywhere. It reads the screen to them in their
    // language: an English SMS, a form, a letter. Turned on in ScreenGuide's settings. Never on password, bank or money screens.
    private var readBubble: View? = null
    private var readBusy = false
    private val prefsListener = android.content.SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == "read_button") handler.post { applyReadBubble() }
    }
    private fun applyReadBubble() {
        val on = getSharedPreferences("sg", MODE_PRIVATE).getBoolean("read_button", false)
        if (!on) { readBubble?.let { try { wm?.removeView(it) } catch (_: Exception) {} }; readBubble = null; removeCloseX(); return }
        if (readBubble != null) return
        val w = wm ?: return
        val sp = getSharedPreferences("sg", MODE_PRIVATE)
        val b = DragLayout(this, { dx, dy -> moveBubble(dx, dy); showCloseX(bubbleOverX()) }, {
            hideCloseX()
            val lp = readBubble?.layoutParams as? WindowManager.LayoutParams
            if (bubbleOverX()) closeReadButton()
            else if (lp != null) sp.edit().putInt("read_x", lp.x).putInt("read_y", lp.y).apply()
        }, { readScreen() }).apply {
            gravity = Gravity.CENTER; contentDescription = "Read this screen to me"
            background = GradientDrawable().apply { setColor(0xFF145A3D.toInt()); shape = GradientDrawable.OVAL; setStroke(dp(2), Color.WHITE) }
            elevation = dp(6).toFloat(); alpha = 0.92f
            addView(IconView(context, "speaker", Color.WHITE).apply { layoutParams = LinearLayout.LayoutParams(dp(26), dp(26)) })
        }
        val lp = WindowManager.LayoutParams(dp(52), dp(52), WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = sp.getInt("read_x", resources.displayMetrics.widthPixels - dp(64)); lp.y = sp.getInt("read_y", resources.displayMetrics.heightPixels / 2)
        makeCloseX()
        try { w.addView(b, lp); readBubble = b } catch (_: Exception) {}
    }
    // Drag the Read button down to the round X to close it, like a chat head (6 Nov). Where the X is: CloseTarget.
    private var closeX: View? = null
    private fun bubbleOverX(): Boolean {
        val lp = readBubble?.layoutParams as? WindowManager.LayoutParams ?: return false
        val d = resources.displayMetrics
        return CloseTarget.over(lp.x, lp.y, dp(52), d.widthPixels, d.heightPixels, d.density)
    }
    // Made hidden just before the Read button, so the button is always drawn above it while it is dragged
    private fun makeCloseX() {
        val w = wm ?: return
        if (closeX != null) return
        val v = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; visibility = View.GONE
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            addView(FrameLayout(context).apply {
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xCC1A1A1A.toInt()); setStroke(dp(2), Color.WHITE) }
                addView(IconView(context, "close", Color.WHITE).apply { layoutParams = FrameLayout.LayoutParams(dp(28), dp(28), Gravity.CENTER) })
                layoutParams = LinearLayout.LayoutParams(dp(64), dp(64))
            })
            addView(TextView(context).apply {
                text = "Drop here to close"; textSize = 13f; setTextColor(Color.WHITE); setPadding(dp(10), dp(4), dp(10), dp(4))
                background = GradientDrawable().apply { setColor(0xCC1A1A1A.toInt()); cornerRadius = dp(12).toFloat() }
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6) }
            })
        }
        val d = resources.displayMetrics
        val (cx, cy) = CloseTarget.centre(d.widthPixels, d.heightPixels, d.density)
        val lp = WindowManager.LayoutParams(dp(160), ViewGroup.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.START; lp.x = cx - dp(80); lp.y = cy - dp(32)
        try { w.addView(v, lp); closeX = v } catch (_: Exception) {}
    }
    private fun showCloseX(near: Boolean) {
        val x = closeX as? LinearLayout ?: return
        x.visibility = View.VISIBLE
        val ring = x.getChildAt(0) ?: return
        val k = if (near) 1.25f else 1f
        if (ring.scaleX != k) ring.animate().scaleX(k).scaleY(k).setDuration(120).start()
        (ring.background as? GradientDrawable)?.setColor(if (near) 0xEED32F2F.toInt() else 0xCC1A1A1A.toInt())
    }
    private fun hideCloseX() { closeX?.visibility = View.GONE }
    private fun removeCloseX() { closeX?.let { try { wm?.removeView(it) } catch (_: Exception) {} }; closeX = null }
    private fun closeReadButton() {
        getSharedPreferences("sg", MODE_PRIVATE).edit().putBoolean("read_button", false).apply()   // the listener removes it
        Server.event(this, "extra", "read_off")
        android.widget.Toast.makeText(this, "Read button closed. To bring it back: ScreenGuide, menu, Settings and permissions, Read button.",
            android.widget.Toast.LENGTH_LONG).show()
    }
    private fun moveBubble(dx: Int, dy: Int) {
        val v = readBubble ?: return; val lp = v.layoutParams as? WindowManager.LayoutParams ?: return
        val d = resources.displayMetrics
        lp.x = (lp.x + dx).coerceIn(0, d.widthPixels - dp(52)); lp.y = (lp.y + dy).coerceIn(dp(24), d.heightPixels - dp(76))
        try { wm?.updateViewLayout(v, lp) } catch (_: Exception) {}
    }
    // Hidden over ScreenGuide itself, and while a guide or a recording has its own buttons up.
    private fun bubbleVisible(pkg: String) {
        val v = readBubble ?: return
        val show = pkg != packageName && Guides.active == null && !Teach.on && Live.id == null
        v.visibility = if (show) View.VISIBLE else View.GONE
    }

    private fun readScreen() {
        if (readBusy) return
        val l = Guides.lang
        if (!getSharedPreferences("sg", MODE_PRIVATE).getBoolean("smart_ok", false) || !Server.configured) {
            showInfo("Read this screen", "Open ScreenGuide and turn on Smart guide (menu, Settings) to use the Read button.", 0xFF145A3D.toInt(), emptyList(), false); return
        }
        val root = rootInActiveWindow ?: return
        val pkg = root.packageName?.toString() ?: ""
        if (pkg == packageName) return
        val nodes = candidates(root)
        if (sensitive(pkg, nodes)) {
            showInfo("Read this screen", "For your safety I don't read password, bank or mobile money screens. Ask someone you trust.", 0xFF145A3D.toInt(), emptyList(), true); return
        }
        // Words in reading order: top to bottom, then left to right. Long numbers never leave the phone.
        val seen = HashSet<String>()
        val words = nodes.filter { !it.isPassword }.mapNotNull { n ->
            val t = (n.text ?: n.contentDescription)?.toString()?.trim()?.takeIf { it.isNotEmpty() } ?: return@mapNotNull null
            val r = Rect(); n.getBoundsInScreen(r); Triple(r.top / dp(12), r.left, t)
        }.sortedWith(compareBy<Triple<Int, Int, String>>({ it.first }, { it.second })).map { it.third.replace(Regex("\\d{4,}"), "[number]") }
            .filter { seen.add(it) }.take(120)
        if (words.isEmpty()) { showInfo("Read this screen", "I can't find any words on this screen.", 0xFF145A3D.toInt(), emptyList(), true); return }
        readBusy = true; Stats.inc(this, "screens_read")
        showInfo("Reading…", "Looking at the words on your screen.", 0xFF145A3D.toInt(), emptyList(), false)
        val app = screenName(pkg); val id = Server.installId(this)
        Thread {
            val r = Server.read(words, l, app, id)
            handler.post {
                readBusy = false
                if (r.first == null) { showInfo("Read this screen", r.second, 0xFF145A3D.toInt(), emptyList(), false); return@post }
                val text = r.first ?: ""
                showInfo("This screen says", text, 0xFF145A3D.toInt(), listOf("Read again" to { speak(Step(emptyList(), mapOf(Guides.lang to text), null)) }), true)
            }
        }.start()
    }

    // ---- Error messages explained (turned on in ScreenGuide's settings; on this phone only, nothing is sent) ----
    // Short words in a pop-up or a line on screen, matched here, never sent anywhere. Not in chats (a friend writing
    // "no internet" is not an error) and not inside money apps. Each one at most once every 6 hours.
    private class ErrorTip(val id: String, val rx: Regex, val say: Map<String, String>, val fixGuide: String? = null, val fixGoal: String? = null)
    private fun tip(id: String, rx: String, en: String, ny: String, bem: String, guide: String? = null, goal: String? = null) =
        ErrorTip(id, Regex(rx, RegexOption.IGNORE_CASE), mapOf("en" to en, "ny" to ny, "bem" to bem), guide, goal)
    private val errorTips = listOf(
        tip("storage", "(storage|memory)( space)? (is )?(full|almost full|running out|low)|not enough (storage|space)|insufficient storage|no space left|out of storage",
            "Your phone is full. Delete things you don't need, like old videos, to make space.",
            "Foni yanu yadzaza. Chotsani zinthu zimene simukuzifuna, monga makanema akale, kuti mupeze malo.",
            "Foni yenu naiisula. Fumyapo ifyo mushilefwaya, nga mavidiyo ya kale, pa kuti mwasanga incende.", goal = "Free up storage space on my phone"),
        tip("internet", "no internet( connection)?|you('| a)re offline|check your (internet |network )?connection|unable to connect to (the )?(internet|server)|network error|connection (failed|timed out)|err_internet_disconnected|no network connection|not connected to (the )?internet",
            "The phone is not connected to the internet. Turn on mobile data or Wi-Fi, and check that you have bundles.",
            "Foni siyikulumikizidwa ku intaneti. Yatsani mobile data kapena Wi-Fi, ndipo onani ngati muli ndi mabandulo.",
            "Foni taileikatana na intaneti. Shikeni mobile data nangu Wi-Fi, kabili moneni nga muli na mabundles.", goal = "Turn on mobile data"),
        tip("password", "(incorrect|wrong|invalid) (password|pin|passcode|code|otp)|password (is )?(incorrect|wrong)",
            "The password or PIN was not right. Type it again slowly. If you forgot it, look for Forgot password. Never tell anyone your PIN.",
            "Mawu achinsinsi kapena PIN sanali olondola. Lembaninso pang'onopang'ono. Ngati mwaiwala, yang'anani Forgot password. Musauze aliyense PIN yanu.",
            "Password nangu PIN tayali iyalungama. Lembeni na kabili panono panono. Nga mwalaba, fwayeni Forgot password. Mwilaeba umuntu PIN yenu."),
        tip("stuck", "isn'?t responding|is not responding|keeps stopping|has stopped",
            "This app is stuck. Tap Close app, then open it again. If it keeps happening, switch the phone off and on.",
            "Pulogalamuyi yakakamira. Dinani Close app, kenako itsegulenso. Ngati ipitirira, zimitsani foni ndi kuyatsanso.",
            "Iyi app naikakatila. Kandeni Close app, elyo muiisule na kabili. Nga ilecitika fye, shimyeni foni no kuishika na kabili."),
        tip("battery", "battery (is )?(low|running low)|low battery|connect (your |the )?charger",
            "The battery is low. Plug in the charger soon. Battery saver helps it last longer.",
            "Batire yatsala pang'ono. Lumikizani charger posachedwa. Battery saver imathandiza kuti ikhalitse.",
            "Batri yashala panono. Bikeni pa charger nomba line. Battery saver ilaafwa ukuti ikokole.", guide = "battery_saver"),
        tip("update", "update (is )?required|(please )?update (the|this) app|new version (is )?required|app (is )?out of date|must update",
            "This app needs a newer version. Update it in the Play Store, then open it again.",
            "Pulogalamuyi ikufunika mtundu watsopano. Ikonzeni mu Play Store, kenako itsegulenso.",
            "Iyi app ilefwaya ukupyanikwa. Ipyanikeni mu Play Store, elyo muiisule na kabili.", goal = "Update this app in the Play Store"),
        tip("tries", "too many (attempts|tries|requests)|temporarily (locked|blocked)|account (is |has been )?locked",
            "There were too many tries. Wait a while, maybe an hour, then try again slowly.",
            "Mwayesa kambiri. Dikirani kanthawi, mwina ola limodzi, kenako yesaninso pang'onopang'ono.",
            "Mwaesha imiku iingi. Lindeni panono, napamo insa imo, elyo eseshenipo na kabili panono panono."),
        tip("sim", "no sim( card)?|sim card (not detected|missing)|insert (a )?sim|emergency calls only|no service",
            "The phone cannot find the network. Check that the SIM card is in properly, or move to a place with better signal.",
            "Foni sikupeza netiweki. Onani ngati SIM khadi yalowa bwino, kapena pitani kumalo kumene kuli netiweki bwino.",
            "Foni tailesanga network. Moneni nga SIM card yaingila bwino, nangu yeni ku ncende iyo network iliko bwino."),
        tip("balance", "insufficient (balance|funds|airtime|credit)|not enough (balance|airtime|credit)",
            "There is not enough money or airtime for this. Top up first, then try again.",
            "Mulibe ndalama kapena airtime yokwanira. Onjezerani kaye, kenako yesaninso.",
            "Tamwakwata indalama nangu airtime iyakwana. Ikileni pantanshi, elyo eseshenipo na kabili."),
        tip("generic", "something went wrong|an error (has )?occurred|unexpected error",
            "Something did not work. Wait a little, check your internet, then try again.",
            "Chinachake sichinayende. Dikirani pang'ono, onani intaneti yanu, kenako yesaninso.",
            "Cimo tacabombele. Lindeni panono, moneni intaneti yenu, elyo eseshenipo na kabili."))
    private val chatApps = listOf("whatsapp", "telegram", "facebook", "instagram", "messaging", "mms", "messenger", "musically", "twitter", "snapchat", "imo")
    private var errAt = 0L
    private val errSnooze = HashMap<String, Long>()

    private fun errorCheck(e: AccessibilityEvent) {
        val t = e.eventType
        if (t != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && t != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName || Guides.active != null || Teach.on || infoCard != null || scamCard != null) return
        if (blockedApps.any { pkg.contains(it, true) } || chatApps.any { pkg.contains(it, true) }) return
        val now = System.currentTimeMillis()
        if (now - errAt < 2000) return
        if (!getSharedPreferences("sg", MODE_PRIVATE).getBoolean("explain_errors", false)) return
        errAt = now
        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() != pkg) return
        // Error messages are short. Long text is an article or a message about errors, not an error.
        val lines = candidates(root).mapNotNull { n -> (n.text ?: n.contentDescription)?.toString()?.trim()?.takeIf { it.length in 4..140 } }.take(200)
        val tip = errorTips.firstOrNull { tp -> now >= (errSnooze[tp.id] ?: 0L) && lines.any { tp.rx.containsMatchIn(it) } } ?: return
        errSnooze[tip.id] = now + 6 * 3600_000L
        Stats.inc(this, "error_explained_" + tip.id)
        val l = Guides.lang
        val fix = if (tip.fixGuide != null || tip.fixGoal != null) listOf("Show me how" to {
            hideInfo()
            try { startActivity(Intent(this, MainActivity::class.java).putExtra("fix_guide", tip.fixGuide).putExtra("fix_goal", tip.fixGoal)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)) } catch (_: Exception) {}
        }) else listOf("Read to me" to { speak(Step(emptyList(), tip.say, null)) })
        showInfo("What this means", tip.say[l] ?: tip.say["en"] ?: "", 0xFF8A3B05.toInt(), fix, false)
    }

    // ---- Teach: write down each button the person taps, so they can share the task as a guide ----
    private var teachPill: LinearLayout? = null
    private var teachCount: TextView? = null

    private fun teachEvent(e: AccessibilityEvent) {
        showTeachPill()
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName) return
        if (blockedApps.any { pkg.contains(it, true) }) {   // never in banking or money apps
            if (e.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED) { Teach.skipped++; updateTeachPill() }
            return
        }
        when (e.eventType) {
            AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED -> {
                if (e.isPassword || e.source?.isPassword == true) return
                Teach.typedIn(e.text?.joinToString(" ") ?: "")
            }
            AccessibilityEvent.TYPE_VIEW_CLICKED -> {
                val src = e.source ?: return
                if (src.isPassword) return
                val box = src.className?.toString()?.contains("EditText") == true
                val word = teachWord(src, e, box) ?: return
                if (pkg.contains("systemui", true)) Teach.shade = true
                if (Teach.tap(word, isSwitchLike(src), box)) {
                    try { teachPill?.performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK) } catch (_: Exception) {}
                    updateTeachPill()
                }
            }
        }
    }

    // The words that name what was tapped: its own words, else a child's, else (a switch) its row's. A box is named by
    // its hint ("Search apps & games"), never by what is typed in it.
    private fun teachWord(src: AccessibilityNodeInfo, e: AccessibilityEvent, box: Boolean): String? {
        fun own(n: AccessibilityNodeInfo?) = (n?.text ?: n?.contentDescription)?.toString()?.trim()?.takeIf { it.isNotEmpty() && it.length <= 50 }
        if (box) {
            val hint = if (Build.VERSION.SDK_INT >= 26) src.hintText?.toString()?.trim() else null
            val showingHint = Build.VERSION.SDK_INT >= 26 && src.isShowingHintText
            return hint?.takeIf { it.isNotEmpty() && it.length <= 50 } ?: (if (showingHint) own(src) else null)
                ?: src.contentDescription?.toString()?.trim()?.takeIf { it.isNotEmpty() && it.length <= 50 }
        }
        fun child(n: AccessibilityNodeInfo?, d: Int): String? {
            if (n == null || d > 2) return null
            for (i in 0 until n.childCount) { val c = n.getChild(i); own(c)?.let { return it }; child(c, d + 1)?.let { return it } }
            return null
        }
        if (!isSwitchLike(src)) return own(src) ?: child(src, 0) ?: e.text?.joinToString(" ")?.trim()?.takeIf { it.isNotEmpty() && it.length <= 50 }
        var p = src.parent; var level = 0
        while (p != null && level < 3) {
            child(p, 0)?.takeIf { !it.equals("on", true) && !it.equals("off", true) }?.let { return it }
            p = p.parent; level++
        }
        return null
    }

    private fun showTeachPill() {
        if (teachPill != null) return
        val w = wm ?: return
        fun btn(t: String, bgc: Int, fg: Int, f: () -> Unit) = TextView(this).apply {
            text = t; textSize = 15f; setTextColor(fg); typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(16), dp(9), dp(16), dp(9)); background = pillBg(bgc)
            setOnClickListener { v -> v.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY); f() }
        }
        val count = TextView(this).apply { textSize = 14f; setTextColor(0xFF1A1A1A.toInt()); typeface = Typeface.DEFAULT_BOLD }
        teachCount = count
        val row = DragLayout(this, { _, dy -> moveTeach(dy) }, {}).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(6), dp(6), dp(6))
            background = GradientDrawable().apply { setColor(0xF8FFFFFF.toInt()); cornerRadius = dp(30).toFloat(); setStroke(dp(2), 0xFFD93025.toInt()) }
            elevation = dp(6).toFloat()
            addView(TextView(context).apply { text = "●"; textSize = 16f; setTextColor(0xFFD93025.toInt()); setPadding(0, 0, dp(6), 0) })
            addView(count, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { rightMargin = dp(10) })
            addView(btn("Cancel", 0xFFEDE7DD.toInt(), 0xFF1A1A1A.toInt()) { teachCancel() })
            addView(btn("Done", 0xFF145A3D.toInt(), Color.WHITE) { teachDone() },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { leftMargin = dp(6) })
        }
        val lp = WindowManager.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; lp.y = dp(56)
        try { w.addView(row, lp); teachPill = row } catch (_: Exception) {}
        updateTeachPill()
    }
    private fun moveTeach(dy: Int) {
        val v = teachPill ?: return; val lp = v.layoutParams as? WindowManager.LayoutParams ?: return
        lp.y = (lp.y + dy).coerceIn(dp(24), maxOf(dp(24), resources.displayMetrics.heightPixels - v.height - dp(24)))
        try { wm?.updateViewLayout(v, lp) } catch (_: Exception) {}
    }
    private fun updateTeachPill() {
        val n = Teach.steps.size
        teachCount?.text = if (n == 0) "Recording. Do the task" else "Recording · $n step" + (if (n == 1) "" else "s")
    }
    private fun hideTeachPill() { teachPill?.let { try { wm?.removeView(it) } catch (_: Exception) {} }; teachPill = null; teachCount = null }
    private fun teachDone() {
        Teach.tap("", false)   // text typed last goes into its box's step
        Teach.on = false; hideTeachPill()
        try { startActivity(Intent(this, MainActivity::class.java).putExtra("teach_review", true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)) }
        catch (_: Exception) {}
    }
    private fun teachCancel() { Teach.on = false; Teach.reset(""); hideTeachPill() }

    // ---- Scam guard (the person turns it on; works on this phone only, nothing is sent) ----
    // Scammers phone people, talk them into installing an app that lets a stranger control the phone (AnyDesk,
    // TeamViewer...), then empty their mobile money. Warn when such an app opens or its Play Store page shows, more
    // strongly during a call.
    private val remoteApps = linkedMapOf("anydesk" to "AnyDesk", "quicksupport" to "TeamViewer QuickSupport", "teamviewer" to "TeamViewer",
        "rustdesk" to "RustDesk", "airdroid" to "AirDroid", "airmirror" to "AirMirror", "anyviewer" to "AnyViewer", "hoptodesk" to "HopToDesk",
        "zoho assist" to "Zoho Assist", "splashtop" to "Splashtop", "supremo" to "Supremo", "remotepc" to "RemotePC")
    private val remotePkgs = listOf("com.anydesk." to "AnyDesk", "com.teamviewer." to "TeamViewer", "com.carriez.flutter_hbb" to "RustDesk",
        "com.sand.airdroid" to "AirDroid", "com.sand.airmirror" to "AirMirror", "com.aomei.anyviewer" to "AnyViewer", "com.zoho.assist" to "Zoho Assist",
        "com.splashtop." to "Splashtop")
    private var scamCard: View? = null
    private var scamAt = 0L
    private val scamSnooze = HashMap<String, Long>()

    private fun scamCheck(e: AccessibilityEvent) {
        val t = e.eventType
        if (t != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && t != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName || scamCard != null) return
        val remote = remotePkgs.firstOrNull { pkg.startsWith(it.first) }?.second
        val store = pkg == "com.android.vending"
        if (remote == null && !store) return
        if (!getSharedPreferences("sg", MODE_PRIVATE).getBoolean("scam_guard", false)) return
        val now = System.currentTimeMillis()
        if (now - scamAt < 1500) return   // pages change many times a second; looking once in a while is enough
        scamAt = now
        val name = remote ?: storeRemote() ?: return
        if (now < (scamSnooze[name] ?: 0L)) return
        Stats.inc(this, "scam_guard_warned")
        showScamCard(name)
    }

    // On a Play Store page: the remote-control app it shows, if its Install (or Open, Update) button is there too.
    private fun storeRemote(): String? {
        val root = rootInActiveWindow ?: return null
        if (root.packageName?.toString() != "com.android.vending") return null
        val words = ArrayList<String>()
        val q = ArrayDeque<AccessibilityNodeInfo>(); q.add(root)
        while (q.isNotEmpty() && words.size < 300) {
            val n = q.removeFirst()
            (n.text ?: n.contentDescription)?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let { words.add(it.lowercase()) }
            for (i in 0 until n.childCount) n.getChild(i)?.let { q.add(it) }
        }
        if (words.none { it == "install" || it == "update" || it == "open" || it.startsWith("installing") || it == "pending" }) return null
        val all = " " + words.joinToString(" ") + " "
        return remoteApps.entries.firstOrNull { (k, _) -> Regex("(?<![a-z])" + Regex.escape(k) + "(?![a-z])").containsMatchIn(all) }?.value
    }

    private fun inCall(): Boolean = try {
        (getSystemService(AUDIO_SERVICE) as android.media.AudioManager).mode.let { it == android.media.AudioManager.MODE_IN_CALL || it == android.media.AudioManager.MODE_IN_COMMUNICATION }
    } catch (e: Exception) { false }

    private fun scamText(name: String, call: Boolean): Map<String, String> = mapOf(
        "en" to "$name lets another person see and control your phone from far away. Scammers phone people and ask them to install it, then they take their money. " +
            (if (call) "You are on a call now. If the caller asked you to do this, hang up." else "Only use it if you asked for help from someone you know well."),
        "ny" to "$name imalola munthu wina kuona ndi kulamulira foni yanu ali kutali. Akuba amaimbira anthu foni ndi kuwauza kuti aike pulogalamuyi, kenako amatenga ndalama zawo. " +
            (if (call) "Muli pa foni tsopano. Ngati amene akuimbayo wakuuzani kuchita izi, dulani foni." else "Igwiritseni ntchito pokhapokha ngati munapempha thandizo kwa munthu amene mumamudziwa bwino."),
        "bem" to "$name ilenga umuntu umbi ukumona no kubomfya foni yenu ukwabula ukuba nenu. Abapupu balatumina abantu foni no kubeba ukwingisha iyi app, elyo basenda indalama shabo. " +
            (if (call) "Nomba muli pa foni. Nga ulelanda nenu emweba ukucita ici, lekeni ukulanda nankwe." else "Ibomfyeni fye nga mwaipusha ubwafwilisho ku muntu mwaishiba bwino."))

    private fun showScamCard(name: String) {
        val w = wm ?: return
        val call = inCall()
        val l = Guides.lang
        val say = scamText(name, call)
        fun btn(t: String, bgc: Int, fg: Int, f: () -> Unit) = TextView(this).apply {
            text = t; textSize = 16f; setTextColor(fg); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            setPadding(dp(16), dp(13), dp(16), dp(13)); background = pillBg(bgc)
            setOnClickListener { v -> v.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY); f() }
        }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(18), dp(20), dp(16))
            background = GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = dp(22).toFloat(); setStroke(dp(3), 0xFFD93025.toInt()) }
            elevation = dp(10).toFloat()
            addView(TextView(context).apply { text = "⚠  Careful!"; textSize = 22f; setTextColor(0xFFB3261E.toInt()); typeface = Typeface.DEFAULT_BOLD })
            addView(TextView(context).apply { text = say[l] ?: say["en"]; textSize = 17f; setTextColor(0xFF1A1A1A.toInt()); setPadding(0, dp(10), 0, dp(14)); setLineSpacing(0f, 1.15f) })
            addView(btn("Leave this app", 0xFFB3261E.toInt(), Color.WHITE) {
                scamSnooze[name] = System.currentTimeMillis() + 120_000; hideScamCard(); performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            addView(btn("I know this person, continue", 0xFFEDE7DD.toInt(), 0xFF1A1A1A.toInt()) {
                scamSnooze[name] = System.currentTimeMillis() + 12 * 3600_000L; hideScamCard()
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) })
        }
        val wrap = FrameLayout(this).apply { setPadding(dp(16), 0, dp(16), 0); addView(card) }
        val lp = WindowManager.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_DIM_BEHIND,
            PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.CENTER; lp.dimAmount = 0.55f
        try { w.addView(wrap, lp); scamCard = wrap } catch (_: Exception) { return }
        speak(Step(emptyList(), say, null))
        try { wrap.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS) } catch (_: Exception) {}
    }
    private fun hideScamCard() { scamCard?.let { try { wm?.removeView(it) } catch (_: Exception) {} }; scamCard = null }

    // ---- Smart guide: the AI picks the next button from the words on screen ----
    private val blockedApps get() = Guides.blockedApps
    private fun sensitive(pkg: String, nodes: List<AccessibilityNodeInfo>) = blockedApps.any { pkg.contains(it, true) } || nodes.any { it.isPassword }

    // Names of apps on the phone (names only), minus banking, money and wallet apps. Sent once, only for "which app" questions.
    private fun installedApps(): List<String> = Guides.installedNames(this)

    // The on/off switch that belongs to this word's row, if there is one (switches have no words of their own).
    private fun switchNear(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        fun walk(x: AccessibilityNodeInfo?, d: Int): AccessibilityNodeInfo? {
            if (x == null || d > 2) return null
            if (isSwitchLike(x) && x.isVisibleToUser) return x
            for (i in 0 until x.childCount) walk(x.getChild(i), d + 1)?.let { return it }
            return null
        }
        return walk(n, 0) ?: walk(n.parent, 1)
    }

    private fun tappable(n: AccessibilityNodeInfo): Boolean {
        var c: AccessibilityNodeInfo? = n
        repeat(4) { if (c?.isClickable == true) return true; c = c?.parent }
        return false
    }

    // Words on screen, each tagged so the AI can tell switches and buttons from plain text.
    private fun taggedLabels(nodes: List<AccessibilityNodeInfo>): List<String> {
        val out = LinkedHashSet<String>()
        for (n in nodes) {
            if (n.isPassword) continue
            // An empty text box shows its hint ("Search apps & games")
            val hint = if (Build.VERSION.SDK_INT >= 26 && n.isEditable) n.hintText else null
            val t = (n.text ?: n.contentDescription ?: hint)?.toString()?.trim() ?: continue
            if (t.isEmpty() || t.length > 50 || Regex("\\d{5,}").containsMatchIn(t) || t.contains("@")) continue
            // [selected]: a tab already chosen ("Video" in Video | Short | Live), so the AI does not ask for it again.
            // Short words only: long titles can be "selected" just to scroll their text. [typing]: an open text box.
            val tag = ScreenWords.tag(switchNear(n) != null, n.isSelected, t.length <= 20, tappable(n), n.isEditable, n.isFocused)
            out.add("$t $tag")
            if (out.size >= 70) break
        }
        return out.toList()
    }

    // ---- Tester view: a thin strip at the top saying what ScreenGuide sees and why it chose that spot, so a screen
    // recording explains itself. On by default in test builds (the ones GitHub makes), off in a Play Store build.
    private var dbg: LinearLayout? = null
    private var dbgTitle: TextView? = null
    private var dbgStatus: TextView? = null
    private var dbgAi: TextView? = null
    private var dbgSees: TextView? = null
    private var aiNote = ""
    private var watchSeen = 0   // problems the watcher has seen in this guide (developer phones)
    private fun tester(): Boolean {
        val debuggable = (applicationInfo.flags and android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE) != 0
        return getSharedPreferences("sg", MODE_PRIVATE).getBoolean("tester", debuggable)
    }
    private val version: String by lazy { try { packageManager.getPackageInfo(packageName, 0).versionName ?: "" } catch (e: Exception) { "" } }

    // The app's own name for a screen ("Settings", "YouTube"), or "Home screen".
    private val appNames = HashMap<String, String>()
    private fun screenName(pkg: String): String {
        if (isHome(pkg)) return "Home screen"
        return appNames.getOrPut(pkg) {
            try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString() } catch (e: Exception) { pkg.substringAfterLast('.') }
        }
    }

    // What can be tapped on this screen, without clutter (times, dates, page dots, plain text).
    private val noise = Regex("^(\\d{1,2}:\\d{2}|am|pm|\\d{1,2}|.{1}|home screen \\d+ of \\d+|(mon|tue|wed|thu|fri|sat|sun)\\w* .*\\d.*)$", RegexOption.IGNORE_CASE)
    private fun words(nodes: List<AccessibilityNodeInfo>): String =
        taggedLabels(nodes).filter { !it.endsWith("[text]") }
            .map { it.replace(" [switch]", " (switch)").replace(" [selected]", " (selected)").replace(" [tap]", "").trim() }
            .filter { !noise.matches(it) }.distinct().take(9).joinToString("  \u00B7  ")

    private var testerTop = true   // which edge the tester card is on; the instruction card makes room for it
    private fun testerHeight(): Int = dbg?.let { if (it.height > 0) it.height else dp(100) } ?: 0

    private fun note(step: String, status: String, nodes: List<AccessibilityNodeInfo>?, pkg: String, ring: Rect? = null) {
        if (!tester()) { hideDbg(); return }
        val w = wm ?: return
        val g = Guides.active
        val name = if (g?.id == "ai") "Smart guide" else (g?.title?.get("en") ?: g?.id ?: "")
        val box = dbg ?: run {
            fun line(sz: Float, c: Int, bold: Boolean = false, lines: Int = 2) = TextView(this).apply {
                textSize = sz; setTextColor(c); if (bold) typeface = Typeface.DEFAULT_BOLD
                maxLines = lines; ellipsize = android.text.TextUtils.TruncateAt.END; setLineSpacing(0f, 1.1f)
            }
            val title = line(12f, Color.WHITE, true, 1)
            val status = line(12.5f, 0xFFF2F4F5.toInt(), false, 2).apply { setPadding(0, dp(3), 0, 0) }
            val ai = line(11f, 0xFFF0C27A.toInt(), false, 1).apply { setPadding(0, dp(2), 0, 0) }
            val sees = line(11f, 0xFFADB5BA.toInt(), false, 2).apply { setPadding(0, dp(3), 0, 0) }
            val card = DragLayout(this, { _, dy -> moveDbg(dy) }, { }, { toggleCompact() }).apply {
                orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(8), dp(12), dp(9))
                background = GradientDrawable().apply { setColor(0xEB15191C.toInt()); cornerRadius = dp(14).toFloat(); setStroke(maxOf(1, dp(1)), 0x33FFFFFF) }
                elevation = dp(4).toFloat(); importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS
                addView(LinearLayout(context).apply {
                    gravity = Gravity.CENTER_VERTICAL
                    addView(TextView(context).apply {
                        text = "TEST"; textSize = 9.5f; setTextColor(0xFF1A1A1A.toInt()); typeface = Typeface.DEFAULT_BOLD; letterSpacing = 0.08f
                        background = GradientDrawable().apply { setColor(0xFFF0A935.toInt()); cornerRadius = dp(6).toFloat() }
                        setPadding(dp(6), dp(1), dp(6), dp(1))
                        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { rightMargin = dp(8) }
                    })
                    addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                })
                addView(status); addView(ai); addView(sees)
            }
            val lp = WindowManager.LayoutParams(resources.displayMetrics.widthPixels - dp(20), ViewGroup.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,   // touchable: drag it, tap to shrink
                PixelFormat.TRANSLUCENT)
            lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; lp.y = dp(28)
            try { w.addView(card, lp) } catch (_: Exception) { return }
            dbg = card; dbgTitle = title; dbgStatus = status; dbgAi = ai; dbgSees = sees
            card
        }
        fun set(t: TextView?, v: String) { if (t != null && t.text.toString() != v) t.text = v; t?.visibility = if (v.isEmpty()) View.GONE else View.VISIBLE }
        set(dbgTitle, listOf("v$version", name, step, screenName(pkg)).filter { it.isNotEmpty() }.joinToString("  \u00B7  "))
        set(dbgStatus, status)
        val kb = imeTop?.let { resources.displayMetrics.heightPixels - it }?.coerceAtLeast(0) ?: 0
        set(dbgAi, if (g?.id == "ai" && kb == 0) aiNote else "")   // keyboard open: keep the card small
        set(dbgSees, if (nodes != null && kb == 0) words(nodes).let { if (it.isEmpty()) "" else "Sees:  $it" } else "")
        if (compact) { dbgStatus?.visibility = View.GONE; dbgAi?.visibility = View.GONE; dbgSees?.visibility = View.GONE }
        // Three things share the screen: the ring, the instruction card and this card. The instruction card sits away
        // from the ring; this card takes an edge the ring does not reach (never the bottom while the swipe arrow shows),
        // and if it must share an edge with the instruction card, the instruction card moves aside (see showLabel).
        val h = resources.displayMetrics.heightPixels
        val th = testerHeight()
        val labelTop = ring == null || ring.centerY() > h / 2
        val swipeShowing = swipe != null || (ring == null && isHome(pkg) && g?.id != "ai")
        testerTop = when {
            swipeShowing -> !swipeDown   // a downward swipe is drawn at the top, so the card goes to the bottom
            labelTop -> ring != null && ring.bottom > h - kb - (dp(10) + th + dp(8))   // bottom, unless the ring is down there
            else -> ring?.let { it.top >= dp(28) + th + dp(8) } ?: true               // top, unless the ring is up there
        }
        val lp = box.layoutParams as? WindowManager.LayoutParams ?: return
        dbgY?.let { y ->   // where the person dragged it
            testerTop = y < h / 2
            if (lp.gravity != (Gravity.TOP or Gravity.CENTER_HORIZONTAL) || lp.y != y) { lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; lp.y = y; try { w.updateViewLayout(box, lp) } catch (_: Exception) {} }
            return
        }
        val side = (if (testerTop) Gravity.TOP else Gravity.BOTTOM) or Gravity.CENTER_HORIZONTAL
        val y = if (testerTop) dp(28) else kb + dp(10)   // never on top of the keyboard
        if (lp.gravity != side || lp.y != y) { lp.gravity = side; lp.y = y; try { w.updateViewLayout(box, lp) } catch (_: Exception) {} }
    }
    private var dbgY: Int? = null
    private val compact get() = getSharedPreferences("sg", MODE_PRIVATE).getBoolean("tester_compact", false)
    private fun moveDbg(dy: Int) {
        val b = dbg ?: return; val lp = b.layoutParams as? WindowManager.LayoutParams ?: return
        val y0 = dbgY ?: IntArray(2).also { b.getLocationOnScreen(it) }[1]
        val y = (y0 + dy).coerceIn(0, maxOf(0, resources.displayMetrics.heightPixels - b.height))
        dbgY = y; lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; lp.y = y
        try { wm?.updateViewLayout(b, lp) } catch (_: Exception) {}
    }
    private fun toggleCompact() {
        val now = !compact
        getSharedPreferences("sg", MODE_PRIVATE).edit().putBoolean("tester_compact", now).apply()
        val v = if (now) View.GONE else View.VISIBLE
        dbgStatus?.visibility = v; dbgAi?.visibility = v; dbgSees?.visibility = v
    }
    private fun hideDbg() {
        dbg?.let { try { wm?.removeView(it) } catch (_: Exception) {} }
        dbg = null; dbgTitle = null; dbgStatus = null; dbgAi = null; dbgSees = null
    }

    private var swipe: SwipeView? = null
    private var swipeDown = false
    private fun showSwipe(down: Boolean = false, right: Boolean = false) {
        if (Guides.chatOpen) return
        if (swipe != null && swipeDown == down) return
        hideSwipe()
        val w = wm ?: return
        val d = resources.displayMetrics
        val lp = WindowManager.LayoutParams(dp(120), (d.heightPixels * 0.34).toInt(),
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT)
        if (down) { lp.gravity = Gravity.TOP or (if (right) Gravity.END else Gravity.CENTER_HORIZONTAL); lp.y = 0; if (right) lp.x = dp(16) }
        else { lp.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; lp.y = dp(70) }
        try { swipe = SwipeView(this, down).also { w.addView(it, lp); swipeDown = down } } catch (_: Exception) {}
    }
    private fun hideSwipe() { swipe?.let { try { wm?.removeView(it) } catch (_: Exception) {} }; swipe = null }

    private fun hideRing() {
        ringAnim?.cancel(); ringLp = null; trackNode = null; handler.removeCallbacks(trackRun)
        ring?.let { try { wm?.removeView(it) } catch (_: Exception) {} }; ring = null
    }

    private fun aiRefresh(guide: Guide, nodes: List<AccessibilityNodeInfo>, pkg: String) {
        if (askCard != null || capturing) { hideRing(); return }   // waiting for the person's answer, or taking the picture
        if (openApp(guide, nodes, pkg)) return
        if (sensitive(pkg, nodes)) {   // nothing is sent from these screens
            hideRing(); showLabel("For your safety I cannot guide you on this screen. Please do it yourself, or ask someone you trust.", false); return
        }
        val now = nodes.mapNotNull { (it.text ?: it.contentDescription)?.toString() }.take(60).toSet()
        val t = System.currentTimeMillis()
        // Typing changes the screen with every key. Never ask the AI in the middle of a word ("st" gave "you are in the
        // wrong part of Settings"). A result that matches the word they were told to type gets a ring at once, on the phone.
        if (typingAt > 0 && pkg == Guides.aiPkg) {
            val want = typeWord()
            val hit = if (want != null) nodes.firstOrNull { n -> !n.isEditable && n.isVisibleToUser && area(n) > 0 && norm(txt(n)) == norm(want) } else null
            if (hit != null) {
                typingAt = 0L
                if (norm(Guides.aiStep?.match?.firstOrNull()) != norm(txt(hit))) { pointLocal(hit, pkg, now); return }
                Guides.aiLabels = now   // already pointing at it
            } else if (t - typingAt < 1500) {
                hideRing(); handler.removeCallbacks(refreshRun); handler.postDelayed(refreshRun, 1550)
                note(aiProgress() ?: "", "Typing" + (if (want != null) ", watching for \u201C$want\u201D in the results" else "") +
                    ". The AI is asked when they pause.", nodes, pkg)
                return
            } else {
                // They paused. Ask again only for a search or a word we told them to type, never while they write a message.
                if (typedText.isNotEmpty() && (typedSearch || want != null)) {
                    nextNote = if (typedSearch) "They typed \u201C$typedText\u201D in the search box." else "They typed in a box."
                    reask = true
                }
                typingAt = 0L
            }
        }
        // Scrolling: once it stops, check the step still fits. If what we pointed at slid out of sight (or sits outside the
        // list, like a search box under the title bar), ask again once, so the AI can point at what shows now.
        if (scrollPending && pkg == Guides.aiPkg && !Guides.aiBusy) {
            if (t - scrolledAt < 700) { handler.removeCallbacks(refreshRun); handler.postDelayed(refreshRun, 720) }
            else {
                scrollPending = false
                val stp = Guides.aiStep
                val fresh = now.count { it !in Guides.aiLabels }
                if (stp != null && stp === aheadStep && find(nodes, stp) == null && (scrollAtEnd || ++aheadMisses >= 2)) {
                    // "Scroll down to find Storage", but it is not in this list (Samsung keeps it under Device care): ask again.
                    aheadMisses = 0; aheadStep = null; reask = true
                    nextNote = "They scrolled the list twice but \u201C${stp.match.firstOrNull() ?: ""}\u201D is not in it."
                }
                else if (stp != null && stp !== errStep && stp !== aheadStep && scrollAsked !== stp && fresh >= 3) {
                    val n = if (stp.match.isNotEmpty()) find(nodes, stp) else null
                    val r = n?.let { val rr = Rect(); it.getBoundsInScreen(rr); rr }
                    val box = scrollBox
                    val stillGood = n != null && r != null && n.isVisibleToUser && box != null && box.contains(r) &&
                        (ringStep !== stp || r.height() >= firstRect.height() * 0.8)
                    if (!stillGood) { scrollAsked = stp; reask = true; nextNote = "They scrolled the list." }
                }
            }
        }
        // Still the same screen as when we last asked? (same app, and most words unchanged). While they scroll to find what
        // we are looking for, the words change a lot but it is still the same step.
        val st = Guides.aiStep
        val same = !reask && pkg == Guides.aiPkg && (Guides.aiLabels.isEmpty() || (st != null && st === aheadStep) ||
            now.intersect(Guides.aiLabels).size >= 0.5 * minOf(now.size, Guides.aiLabels.size))
        if (st != null && same) {
            val pr = pointRect
            if (st === pointFor && pr != null) {   // a button with no words, found in the screen picture
                show(Rect(pr))
                showLabel(st.say[Guides.lang] ?: st.say["en"] ?: "", pr.centerY() > resources.displayMetrics.heightPixels / 2, false, aiProgress())
                return
            }
            val node = if (st.match.isNotEmpty()) find(nodes, st) else null
            // What we pointed at is gone (they went back, or opened something else): drop the old card and ask again,
            // instead of leaving "Tap your video" on YouTube's home screen. A short grace covers screens still moving.
            val gone = node == null && st.match.isNotEmpty() && st !== aheadStep && st !== errStep &&
                Recheck.goneMayAsk(goneAsked, st, goneAskedAt, screenAt) && (ringStep === st || screenAt > stepAt + 300)
            if (gone) {
                if (goneSince == 0L) goneSince = t
                if (t - goneSince >= 600) {
                    goneSince = 0L; goneAsked = st; goneAskedAt = t; reask = true; nextNote = "What we pointed at is gone: they went back or opened something else."
                    hideRing(); aiRefresh(guide, nodes, pkg); return
                }
                handler.removeCallbacks(refreshRun); handler.postDelayed(refreshRun, 650)
            } else goneSince = 0L
            val nodeRect = node?.let { val rr = Rect(); it.getBoundsInScreen(rr); rr }
            note(aiProgress() ?: "", when {
                st.match.isEmpty() -> "The AI gave words only, nothing to point at."
                node != null -> "The AI chose \u201C${st.match[0]}\u201D. Ring on it, found by $foundHow."
                else -> "The AI chose \u201C${st.match[0]}\u201D, but it is not on this screen."
            }, nodes, pkg, nodeRect)
            if (node != null) {
                hideSwipe()
                val wantsSwitch = st.say.values.any { it.contains("switch", true) }
                // point at the real switch, not just its word (only when the step is about a switch)
                val rn = (if (wantsSwitch) switchFor(nodes, st.match) else null) ?: switchNear(node) ?: tileOf(node)
                val r = Rect(); rn.getBoundsInScreen(r)
                if (ringStep !== st) { ringStep = st; firstRect.set(r) }
                show(r); track(rn)
                val words = if (st === aheadStep) tapWords(txt(node)) else st.say   // "Scroll down to find Storage" became "Tap Storage"
                showLabel(words[Guides.lang] ?: words["en"] ?: "", r.centerY() > resources.displayMetrics.heightPixels / 2, false, aiProgress())
            } else {
                hideRing(); showLabel(st.say[Guides.lang] ?: st.say["en"] ?: "", isHome(pkg), false, aiProgress())
                // Show the swipe only when the step says to swipe up or scroll down; never for an error or anything else.
                val wantsSwipe = st !== errStep && st.say.values.any { swipeWords.containsMatchIn(it) }
                if (wantsSwipe) showSwipe() else hideSwipe()
            }
            return
        }
        note(aiProgress() ?: "", if (Guides.aiBusy) "Waiting for the AI\u2026 ${(t - askStart) / 1000} s" + (if (t - askStart > 6000 && System.currentTimeMillis() - Server.lastOkAt > 10 * 60_000L) " (the server was asleep?)" else "")
            else if (reask) "They scrolled or typed. Asking the AI again." else "New screen. Asking the AI what to tap.", nodes, pkg)
        // A new screen, or no step yet: ask again, but not more often than every 2 seconds.
        hideRing(); hideSwipe(); waitTop = isHome(pkg)
        if (!Guides.aiThinking) {
            val slow = Guides.aiBusy && t - askStart >= 6000
            showLabel(if (slow) waitText() else st?.say?.get(Guides.lang) ?: st?.say?.get("en") ?: "Looking\u2026", waitTop, st != null && !slow)
        }
        if (!Guides.aiBusy) {
            if (System.currentTimeMillis() - Guides.aiLast > 1200) askNext(guide, nodes, pkg)
            else { handler.removeCallbacks(refreshRun); handler.postDelayed(refreshRun, 1300) }
        }
    }

    private fun askNext(guide: Guide, nodes: List<AccessibilityNodeInfo>, pkg: String) {
        if (Guides.aiAsked >= 20) {
            Guides.active = null; hideRing(); holdUntil = System.currentTimeMillis() + 4000
            showLabel("Let’s stop here. Ask me again if you still need help.", false); handler.postDelayed({ hideLabel() }, 4000); return
        }
        val labels = taggedLabels(nodes)
        val stuck = Guides.aiStuck
        val sp = getSharedPreferences("sg", MODE_PRIVATE)
        val pics = Build.VERSION.SDK_INT >= 30
        val auto = pics && sp.getBoolean("shot_ok", false) && sp.getBoolean("shot_auto", false)
        val sparse = labels.size < 3
        // Almost no words right after a screen opens: usually still loading (a splash screen). Wait a moment.
        if (sparse && !stuck && System.currentTimeMillis() - screenAt < 2000) { handler.removeCallbacks(refreshRun); handler.postDelayed(refreshRun, 700); return }
        // Words are not enough: an app that draws its own buttons (Facebook Lite, games), or the AI asked to see an icon.
        val wordsShort = sparse || wantPicture
        wantPicture = false
        if (wordsShort && !stuck && pics && !sp.contains("shot_auto")) { reask = false; askShotConsent(auto = true); return }   // ask once, when it helps
        // After Help, or when words are not enough and the person agreed, a picture of the screen goes too.
        val wantShot = pics && sp.getBoolean("shot_ok", false) && (stuck || (wordsShort && auto))
        if (labels.isEmpty() && !wantShot) {
            reask = false; hideRing()
            showLabel(when {
                !pics -> "I cannot read the words in this app, so I cannot point here. Ask someone you trust, or tap Stop."
                sp.contains("shot_ok") && !sp.getBoolean("shot_ok", false) -> "I cannot read the words in this app. Turn on Screen pictures in ScreenGuide\u2019s settings, or ask someone you trust."
                else -> "I cannot read the words in this app. Tap Help, so I can look at a picture of the screen."
            }, false)
            return
        }
        Stats.inc(this, "ai_steps"); Guides.aiBusy = true; Guides.aiAsked++; Guides.aiPkg = pkg; Guides.aiLast = System.currentTimeMillis()
        askStart = Guides.aiLast; handler.removeCallbacks(waitRun); handler.postDelayed(waitRun, 6000); reask = false
        stale.asked(Guides.aiStep)   // looking again: the watcher must not call the old step "stayed" meanwhile
        val told = nextNote; nextNote = ""
        Guides.aiLabels = nodes.mapNotNull { (it.text ?: it.contentDescription)?.toString() }.take(60).toSet()
        Guides.aiStuck = false
        val tapped = Guides.aiTapped; Guides.aiTapped = false
        val goal = Guides.aiGoal; val lang = Guides.lang; val hist = ArrayList(Guides.aiHistory); val plan = Guides.aiPlan
        val apps = if (Guides.aiNeedsApps) { Guides.aiNeedsApps = false; installedApps() } else emptyList()
        val id = Server.installId(this)
        fun send(image: String) {
            if (image.isNotEmpty()) Stats.inc(this, "screen_pictures")
            Thread {
                val t0 = System.currentTimeMillis()
                val r = Server.next(goal, lang, id, labels, hist, stuck, apps, told, plan, image, level(), tapped)
                val ms = System.currentTimeMillis() - t0
                handler.post {
                    if (Server.tester) {
                        if (r.watch > watchSeen) flashRed(); watchSeen = r.watch; if (r.watchStep > 0) watchShot(r.watchStep, true)
                        // As long as the phone waited, network included (3 Nov: 20 s, which the server's own clock missed)
                        if (r.ok && r.watchStep > 0 && ms > Watch.SLOW_MS) { val n = r.watchStep; Thread { reportSlow(id, n, ms) }.start() }
                    }
                    aiNote = (if (!r.ok) "Problem after ${ms / 100 / 10.0} s: ${Server.lastProblem.ifEmpty { r.say }.take(70)}" else Watch.answerNote(ms, r.strong, image.isNotEmpty())) +
                        "  \u00B7  Goal: " + goal.substringBefore(" (about:").take(50)
                    Guides.aiBusy = false; Guides.aiThinking = false; handler.removeCallbacks(thinkRun); handler.removeCallbacks(waitRun)
                    if (Guides.active !== guide) return@post
                    if (!r.ok) {
                        val err = Step(emptyList(), mapOf(lang to r.say.trimEnd('.') + ". Tap Help to try again."), null)
                        Guides.aiStep = err; errStep = err; pointFor = null; pointRect = null
                        speak(err); refresh(); return@post
                    }
                    if (r.done) {
                        val trail = ArrayList(Guides.aiTrail)
                        if (trail.size >= 2 || (trail.size == 1 && !Guides.aiJustOpen && trail[0].match.firstOrNull() != Guides.aiApp)) {
                            val sw = trail.last().say.values.any { it.contains("switch", true) }
                            Recipes.save(this, Guides.aiGoal, trail, sw)
                            Server.learned(this, Guides.aiGoal, Recipes.stepsJson(trail), sw)   // the next phone of this kind can skip the AI
                            Stats.inc(this, "tasks_learned")
                        }
                        finish(Guide(guide.id, guide.title, mapOf(lang to r.say), emptyList(), emptyList()))
                        return@post
                    }
                    val say = tighten(r.say, r.label != null)
                    val prev = Guides.aiStep
                    if (prev != null && prev !== errStep && r.label != null && norm(prev.match.firstOrNull()) == norm(r.label)) {
                        refresh(); return@post   // a re-check gave the same answer: keep the step, its number and its ring
                    }
                    if (Guides.aiHistory.lastOrNull() != say) Guides.aiHistory.add(say)
                    val ahead = r.label == null && r.lookFor != null && r.x == null
                    val step = Step(if (r.label != null) listOf(r.label) else if (ahead) listOf(r.lookFor!!) else emptyList(), mapOf(lang to say), null)
                    Guides.aiStep = step; aheadStep = if (ahead) step else null; aheadMisses = 0; stepAt = System.currentTimeMillis(); goneSince = 0L
                    // The AI named an icon it cannot point at from words (+, three dots): look at a picture next, if allowed.
                    if (r.needPicture && image.isEmpty() && Build.VERSION.SDK_INT >= 30) {
                        val sp = getSharedPreferences("sg", MODE_PRIVATE)
                        if (!sp.contains("shot_auto") || (sp.getBoolean("shot_ok", false) && sp.getBoolean("shot_auto", false))) { wantPicture = true; reask = true }
                    }
                    val rx = r.x; val ry = r.y
                    if (r.label == null && rx != null && ry != null && image.isNotEmpty() && shotW > 0) {
                        val cx = (rx * shotW).toInt(); val cy = (ry * shotH).toInt(); val half = dp(30)
                        pointFor = step; pointRect = Rect(cx - half, cy - half, cx + half, cy + half)
                    } else { pointFor = null; pointRect = null }
                    speak(step); buzz(false)
                    refresh()
                }
            }.start()
        }
        if (wantShot) captureScreen { send(it) } else send("")
    }

    // Stage one of a Smart guide: get into the app. Done on the phone, like the built-in guides: the icon gets a
    // ring at once, the swipe arrow shows when it is not on screen, and no AI is asked. True while still in this stage.
    private var appSaid = ""
    private var sayFind = ""
    private fun openApp(guide: Guide, nodes: List<AccessibilityNodeInfo>, pkg: String): Boolean {
        val app = Guides.aiApp ?: return false
        val appPkg = Guides.aiAppPkg ?: return false
        if (Guides.aiInApp) return false
        val lang = Guides.lang
        val q = "\u201C$app\u201D"
        val tap = Step(listOf(app), mapOf("en" to "Tap $q.", "ny" to "Dinani $q.", "bem" to "Kandeni $q."), null)
        if (pkg == appPkg) {
            Guides.aiInApp = true
            Guides.aiTrail.add(tap); Guides.aiHistory.add("Tap $q.")
            if (Guides.aiJustOpen) {
                finish(Guide(guide.id, guide.title, mapOf("en" to "Well done! $app is open.", "ny" to "Zabwino! $app yatseguka.",
                    "bem" to "Nawamya! $app yaisuka."), emptyList(), emptyList()))
                return true
            }
            Guides.aiStep = null; Guides.aiLast = 0L   // now the AI helps inside the app
            return false
        }
        val icon = nodes.filter { norm((it.text ?: it.contentDescription)?.toString()) == norm(app) }.filter { area(it) > 0 }.minByOrNull { area(it) }
        val iconRect = icon?.let { val rr = Rect(); it.getBoundsInScreen(rr); rr }
        note("Step 1", "Opening \u201C$app\u201D without the AI. " + (if (icon != null) "Ring on its icon" else "Icon not on this screen, swipe arrow showing") +
            (if (Guides.aiJustOpen) ". Done when it opens." else ". The AI takes over inside it."), nodes, pkg, iconRect)
        val key: String
        if (icon != null) {
            hideSwipe()
            val t = target(icon); val r = Rect(); t.getBoundsInScreen(r)
            show(r); track(t)
            showLabel(tap.say[lang] ?: tap.say["en"] ?: "", r.centerY() > resources.displayMetrics.heightPixels / 2, false, "Step 1")
            key = "tap"
        } else {
            hideRing()
            val home = isHome(pkg)
            // The app list: its heading ("All Apps"), or the A-Z index down its side, which stays while the list scrolls.
            val drawer = home && (nodes.any { norm(txt(it)) in setOf("allapps", "searchapps", "applibrary", "searchyourapps") } ||
                nodes.count { Regex("^[A-Z#]$").matches(txt(it)) } >= 8)
            val how = if (drawer) "Scroll down to find $q." else if (home) "Swipe up to see all your apps." else "Press Home, then swipe up to see all your apps."
            showLabel(how, true, false, "Step 1: find $q")
            if (home) showSwipe() else hideSwipe()
            key = if (drawer) "scroll" else "find"
            sayFind = how
        }
        if (appSaid != key + app) {
            appSaid = key + app
            speak(if (key == "tap") tap else Step(emptyList(), mapOf("en" to sayFind), null))
            buzz(false)
        }
        return true
    }

    // A video length ("0:14") sits on its thumbnail: ring the whole picture, not the small number.
    private val durRx = Regex("^\\d{1,2}:\\d{2}(:\\d{2})?$")
    private fun tileOf(n: AccessibilityNodeInfo): AccessibilityNodeInfo {
        if (!durRx.matches(txt(n))) return n
        val d = resources.displayMetrics
        val cap = d.widthPixels.toLong() * d.heightPixels / 4
        var c = n
        repeat(4) {
            val p = c.parent ?: return n
            val r = Rect(); p.getBoundsInScreen(r)
            if (r.width().toLong() * r.height() > cap) return n
            if (p.isClickable) return p
            c = p
        }
        return n
    }

    private fun txt(n: AccessibilityNodeInfo) = (n.text ?: n.contentDescription)?.toString()?.trim() ?: ""
    private fun tapWords(w: String): Map<String, String> { val q = "\u201C$w\u201D"; return mapOf("en" to "Tap $q.", "ny" to "Dinani $q.", "bem" to "Kandeni $q.") }

    // "Type the word storage." -> "storage". From this step, or the last two (the AI may already have moved on).
    private val typeRx = Regex("\\btype\\s+(?:the\\s+word\\s+|in\\s+)?[\"\u201C']?(\\p{L}[\\p{L}\\- ]{1,25}?)[\"\u201D']?\\s*(?:[.,!]|$|\\s(?:in|into|on)\\b)", RegexOption.IGNORE_CASE)
    private fun typeWord(): String? {
        val texts = listOfNotNull(Guides.aiStep?.say?.values?.joinToString(" ")) + Guides.aiHistory.takeLast(2).reversed()
        for (x in texts) typeRx.find(x)?.let { m -> m.groupValues[1].trim().takeIf { it.length >= 3 }?.let { return it } }
        return null
    }

    // Point at something without asking the AI: a search result that matches the word they typed.
    private fun pointLocal(n: AccessibilityNodeInfo, pkg: String, now: Set<String>) {
        val step = Step(listOf(txt(n)), tapWords(txt(n)), null)
        Guides.aiStep = step; Guides.aiPkg = pkg; Guides.aiLabels = now; stepAt = System.currentTimeMillis(); goneSince = 0L
        Guides.aiHistory.add(step.say["en"] ?: "")
        aheadStep = null; pointFor = null; pointRect = null
        speak(step); buzz(false)
        handler.removeCallbacks(refreshRun); handler.post(refreshRun)
    }

    // A free server sleeps when nobody has used it for a while; its first answer then takes up to a minute. Say so,
    // instead of "Looking…" with no end.
    private fun waitText(): String {
        val s = (System.currentTimeMillis() - askStart) / 1000
        val awake = System.currentTimeMillis() - Server.lastOkAt < 10 * 60_000L   // it answered a moment ago: not asleep
        return when {
            s >= 50 -> "Still waiting. Please check your internet."
            awake -> "Still looking at your screen. This step is taking longer."
            else -> "Waking up the helper. The first answer can take up to a minute."
        }
    }
    private val waitRun = object : Runnable {
        override fun run() {
            if (!Guides.aiBusy || Guides.active?.id != "ai") return
            if (!Guides.aiThinking && askCard == null && !capturing && !Guides.chatOpen) showLabel(waitText(), waitTop)
            handler.postDelayed(this, 1000)
        }
    }

    // "Step 2 of 4": from the AI's plan when there is one.
    private fun aiProgress(): String? {
        val k = Guides.aiHistory.size
        val m = Guides.aiPlan.size
        return if (k <= 0) null else if (m in k..12) "Step $k of $m" else if (m in 1 until k) "Almost there" else "Step $k"
    }

    // New users get the simplest words; confident users get very short ones. Worked out on the phone from counts only.
    private fun level(): String {
        when (Profile.str(this, "words", "auto")) { "simple" -> return "new"; "short" -> return "confident"; "normal" -> return "some" }
        val p = getSharedPreferences("stats", MODE_PRIVATE)
        val done = p.getInt("finished", 0); val stuck = p.getInt("stuck", 0)
        return if (done < 3 || stuck > done) "new" else if (done >= 10 && stuck * 3 < done) "confident" else "some"
    }

    // A light tick for each new step, a stronger one when the task is done. Follows the phone's touch-feedback setting.
    private fun buzz(done: Boolean) {
        if (!Profile.buzzOn(this)) return
        val v: View = label ?: ring ?: return
        val kind = if (!done) android.view.HapticFeedbackConstants.CLOCK_TICK
            else if (Build.VERSION.SDK_INT >= 30) android.view.HapticFeedbackConstants.CONFIRM
            else android.view.HapticFeedbackConstants.LONG_PRESS
        try { v.performHapticFeedback(kind) } catch (e: Exception) {}
    }

    // ---- A picture of the screen: only after "?", only if the person agreed, never on bank, money or password screens ----
    private var capturing = false
    private var shotW = 0
    private var shotH = 0
    private var pointFor: Step? = null
    private var pointRect: Rect? = null
    private var askCard: LinearLayout? = null

    private fun captureScreen(done: (String) -> Unit) {
        if (Build.VERSION.SDK_INT < 30) { done(""); return }
        capturing = true
        hideRing(); hideLabel(); controls?.visibility = View.INVISIBLE; dbg?.visibility = View.INVISIBLE   // keep our own drawings out of the picture
        fun finishShot(out: String) {
            capturing = false; controls?.visibility = View.VISIBLE; dbg?.visibility = View.VISIBLE
            done(out)
        }
        handler.postDelayed({
            try {
                takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
                    override fun onSuccess(result: ScreenshotResult) {
                        var out = ""
                        try {
                            val hb = result.hardwareBuffer
                            val sw = Bitmap.wrapHardwareBuffer(hb, result.colorSpace)?.copy(Bitmap.Config.ARGB_8888, false)
                            hb.close()
                            if (sw != null) { shotW = sw.width; shotH = sw.height; out = encodeShot(sw) }
                        } catch (e: Exception) {}
                        finishShot(out)
                    }
                    override fun onFailure(errorCode: Int) { finishShot("") }
                })
            } catch (e: Exception) { finishShot("") }
        }, 180)
    }

    private fun encodeShot(b: Bitmap): String {
        val m = maxOf(b.width, b.height)
        val s = if (m > 1024) Bitmap.createScaledBitmap(b, b.width * 1024 / m, b.height * 1024 / m, true) else b
        val o = java.io.ByteArrayOutputStream()
        s.compress(Bitmap.CompressFormat.JPEG, 70, o)
        return android.util.Base64.encodeToString(o.toByteArray(), android.util.Base64.NO_WRAP)
    }

    // Asked once: the first time the person taps Help, or the first time a screen's words are not enough (an app that
    // draws its own buttons, an icon like +). The answer can be changed later in the app's settings.
    private fun askShotConsent(auto: Boolean = false) {
        val w = wm ?: return
        if (askCard != null) return
        Guides.aiThinking = false; handler.removeCallbacks(thinkRun); hideLabel(); hideRing()
        val prefs = getSharedPreferences("sg", MODE_PRIVATE)
        fun answer(ok: Boolean) {
            prefs.edit().putBoolean("shot_ok", ok).putBoolean("shot_auto", ok).apply()
            askCard?.let { try { w.removeView(it) } catch (_: Exception) {} }; askCard = null
            if (auto) { if (ok) { wantPicture = true; reask = true } }   // ask again, this time with the picture
            else {
                Guides.aiThinking = true; thinkFor = Guides.active; thinkDots = 0; thinkStart = System.currentTimeMillis()
                handler.removeCallbacks(thinkRun); handler.post(thinkRun)
            }
            handler.removeCallbacks(refreshRun); handler.post(refreshRun)
        }
        fun button(t: String, fill: Int, fg: Int, ok: Boolean) = TextView(this).apply {
            text = t; textSize = 16f; setTextColor(fg); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            background = GradientDrawable().apply { setColor(fill); cornerRadius = dp(22).toFloat() }
            setPadding(dp(18), dp(12), dp(18), dp(12))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { leftMargin = dp(8) }
            setOnClickListener { answer(ok) }
        }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(16), dp(16), dp(14))
            background = GradientDrawable().apply { setColor(0xF5F2F2F2.toInt()); cornerRadius = dp(24).toFloat() }
            addView(TextView(context).apply {
                text = "Can I look at a picture of your screen?"; textSize = 18f; setTextColor(0xFF1A1A1A.toInt()); typeface = Typeface.DEFAULT_BOLD
            })
            addView(TextView(context).apply {
                text = if (auto) "Some buttons here have no words. A picture lets me find them. I look only when words are not enough, and never on bank, money or password screens."
                       else "It helps me find buttons that have no words. I look only when words are not enough, and never on bank, money or password screens."
                textSize = 15f; setTextColor(0xFF333333.toInt()); setPadding(0, dp(6), 0, dp(12))
            })
            addView(LinearLayout(context).apply {
                gravity = Gravity.END
                addView(button("No", 0x00000000, 0xFF333333.toInt(), false))
                addView(button("Yes, look", 0xFF145A3D.toInt(), Color.WHITE, true))
            })
        }
        val d = resources.displayMetrics
        val lp = WindowManager.LayoutParams((d.widthPixels * 0.92).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,   // touchable
            PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; lp.y = dp(96)
        try { w.addView(card, lp); askCard = card } catch (e: Exception) { prefs.edit().putBoolean("shot_ok", false).apply() }
    }

    // ---- Window awareness, tracking and on-screen controls ----
    private var surface = "app"
    private var imeTop: Int? = null

    // What is on top: the app, a permission pop-up, a file or photo picker, or the notification shade.
    private fun classify(): String {
        imeTop = null
        var activePkg = ""
        try {
            for (w in windows) {
                val b = Rect(); w.getBoundsInScreen(b)
                if (w.type == AccessibilityWindowInfo.TYPE_INPUT_METHOD) imeTop = b.top
                if (w.isActive) activePkg = w.root?.packageName?.toString() ?: activePkg
            }
        } catch (_: Exception) {}
        return when {
            activePkg.contains("permissioncontroller") -> "permission"
            activePkg.contains("providers.media") || activePkg.contains("photopicker") || activePkg.contains("documentsui") -> "picker"
            activePkg == "com.android.systemui" -> "shade"
            else -> "app"
        }
    }

    // Keep measuring the target so the ring follows scrolling and animations.
    private var trackNode: AccessibilityNodeInfo? = null
    private val trackRun = object : Runnable {
        override fun run() {
            val n = trackNode ?: return
            if (ring == null) return
            if (n.refresh() && n.isVisibleToUser) {
                val r = Rect(); n.getBoundsInScreen(r)
                if (!r.isEmpty && r != lastTarget) show(r)
                handler.postDelayed(this, 100)
            } else { trackNode = null; handler.removeCallbacks(refreshRun); handler.post(refreshRun) }
        }
    }
    private fun track(n: AccessibilityNodeInfo?) {
        trackNode = n; handler.removeCallbacks(trackRun)
        if (n != null) handler.postDelayed(trackRun, 100)
    }

    // Keep each instruction short. With a ring, one action is enough (the ring shows where). With nothing to
    // point at, the words must carry everything, so keep up to three sentences (for example the safety message).
    private val actionWords = Regex("\\b(tap|press|swipe|scroll|choose|select|type|drag|open|turn|pick|hold|slide|dinani|kandeni|kokani|sankhani|lembani)\\b", RegexOption.IGNORE_CASE)
    private fun tighten(say: String, pointing: Boolean): String {
        val t = say.trim()
        if (pointing) {
            val parts = t.split(Regex("(?<=[.!?])\\s+"))
            val act = parts.firstOrNull { actionWords.containsMatchIn(it) } ?: parts.first()
            return act.trim().split(" ").take(12).joinToString(" ")
        }
        return t.split(Regex("(?<=[.!?])\\s+")).take(3).joinToString(" ").split(" ").take(40).joinToString(" ")
    }

    private var controls: LinearLayout? = null
    private var stuckChip: View? = null
    private val stuckRun = object : Runnable {
        override fun run() {
            if (Guides.aiBusy) { handler.postDelayed(this, 3000); return }   // waiting for the AI is not being stuck
            stuckChip?.let { it.background = pillBg(0xFFF0A935.toInt()) }
        }
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun pillBg(c: Int) = GradientDrawable().apply { setColor(c); cornerRadius = dp(24).toFloat() }

    // Any progress (a tap, a new screen) resets the quiet timer; after 9 seconds the "I'm stuck" button lights up.
    private fun bumpProgress() {
        stuckChip?.let { it.background = null }
        handler.removeCallbacks(stuckRun); handler.postDelayed(stuckRun, 9000)
        handler.removeCallbacks(idleRun); handler.postDelayed(idleRun, IDLE_MS)
    }

    // A guide left untouched (no taps, no new screens) for 4 minutes stops by itself, so an old guide never
    // talks over the next task.
    private val IDLE_MS = 4 * 60_000L
    private val idleRun = Runnable {
        val g = Guides.active
        if (g != null) {
            Server.event(this, "stop", "idle_" + g.id); if (Testing.active) endTest(true) else afterGuide()
            Guides.active = null; Guides.aiStep = null; hide(); hideControls()
            holdUntil = System.currentTimeMillis() + 5000
            showLabel("I stopped the guide because nothing happened for a while. Open ScreenGuide when you need help.", true)
            handler.postDelayed({ hideLabel() }, 5000)
        }
    }

    private fun speakCurrent() {
        val g = Guides.active ?: return
        val st = if (g.id == "ai") Guides.aiStep else g.steps.getOrNull(Guides.index)
        if (st != null) speak(st, asked = true)
    }

    // Asks the AI for a different way. Built-in guides switch to the Smart guide for the same goal.
    // A guide to ScreenGuide's own settings (MainActivity.startSelf): it runs inside ScreenGuide, with no AI
    private val selfGuide: Boolean get() = Guides.active?.id == "self"

    private fun onStuck() {
        val g = Guides.active ?: return
        // ScreenGuide's own menus: Help says the step again and shows the ring (the AI would read the person's chat)
        if (g.id == "self") { Stats.inc(this, "stuck"); spokenFor = -1; handler.removeCallbacks(refreshRun); handler.post(refreshRun); return }
        // Trying alone: Help first shows the way on the phone (the ring), before any AI.
        if (g.id != "ai" && Guides.practice && !Guides.practiceHelped) {
            Guides.practiceHelped = true; Stats.inc(this, "practice_help"); bumpProgress(); spokenFor = -1
            handler.removeCallbacks(refreshRun); handler.post(refreshRun); return
        }
        Stats.inc(this, "stuck")
        val ok = getSharedPreferences("sg", MODE_PRIVATE).getBoolean("smart_ok", false)
        if (!Server.configured || !ok) { showLabel("Open ScreenGuide and agree to Smart guide to get help here.", false); return }
        if (g.id != "ai") {
            val goal = if (g.id == "find") "Open " + (g.title["en"] ?: "") else (g.title["en"] ?: g.id)
            Guides.aiReset(goal)
            Guides.active = Guide("ai", g.title, g.done, emptyList(), emptyList())
        }
        Guides.aiStep = null; Guides.aiLast = 0L; Guides.aiStuck = true
        if (!Guides.aiInApp) Guides.aiApp = null   // could not find the app icon alone: let the AI help from here
        // Show that the AI is thinking, and offer a chat for the person's own words.
        Guides.aiThinking = true; thinkFor = Guides.active; thinkDots = 0; thinkStart = System.currentTimeMillis()
        handler.removeCallbacks(thinkRun); handler.post(thinkRun)
        chatChip?.visibility = View.VISIBLE
        handler.removeCallbacks(hideChatRun); handler.postDelayed(hideChatRun, 25000)
        bumpProgress()
        if (Build.VERSION.SDK_INT >= 30 && !getSharedPreferences("sg", MODE_PRIVATE).contains("shot_ok")) { askShotConsent(); return }
        handler.removeCallbacks(refreshRun); handler.post(refreshRun)
    }

    private var chatChip: View? = null
    private val hideChatRun = Runnable { chatChip?.visibility = View.GONE }
    private var thinkDots = 0
    private var thinkStart = 0L
    private var thinkFor: Any? = null   // the guide that asked; after Stop its "Looking…" must not come back
    private val thinkRun = object : Runnable {
        override fun run() {
            if (!Waiting.keepShowing(Guides.aiThinking, thinkFor, Guides.active)) { Guides.aiThinking = false; return }
            if (Guides.chatOpen) { hideLabel(); handler.postDelayed(this, 450); return }
            val waited = System.currentTimeMillis() - thinkStart
            if (rootInActiveWindow?.packageName?.toString() == packageName) { hideLabel(); handler.postDelayed(this, 450); return }   // our chat is open: it shows its own
            if (waited > 65000) {
                Guides.aiThinking = false
                showLabel("This is taking long. Check your internet, then tap Help to try again.", false)
                return
            }
            if (capturing || askCard != null) { handler.postDelayed(this, 450); return }
            thinkDots = (thinkDots + 1) % 4
            val slow = waited > 7000
            val awake = System.currentTimeMillis() - Server.lastOkAt < 10 * 60_000L   // it answered a moment ago: not asleep
            showLabel((if (!slow) "Looking at your screen" else if (awake) "Still looking at your screen. This is taking longer"
                       else "Waking up the helper. The first answer can take up to a minute") + ".".repeat(thinkDots), false, true)
            handler.postDelayed(this, 450)
        }
    }

    // The person wants to explain in their own words: open a small chat over the current app.
    private fun openChat() {
        val g = Guides.active ?: return
        val ok = getSharedPreferences("sg", MODE_PRIVATE).getBoolean("smart_ok", false)
        if (!Server.configured || !ok) { showLabel("Open ScreenGuide and agree to Smart guide to chat here.", false); return }
        val root = rootInActiveWindow
        val pkg = root?.packageName?.toString() ?: ""
        val nodes = if (root != null) candidates(root) else emptyList()
        if (sensitive(pkg, nodes)) { showLabel("For your safety I cannot help on this screen. Please ask someone you trust.", false); return }
        Guides.chatLabels = taggedLabels(nodes)
        Guides.chatSet = nodes.mapNotNull { (it.text ?: it.contentDescription)?.toString() }.take(60).toSet()
        Guides.chatPkg = pkg
        Guides.chatGoal = if (g.id == "ai") Guides.aiGoal else if (g.id == "find") "Open " + (g.title["en"] ?: "") else (g.title["en"] ?: g.id)
        Guides.chatHistory = ArrayList(Guides.aiHistory)
        hideLabel(); hideRing()
        try { startActivity(Intent(this, HelpActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (e: Exception) { showLabel("Open ScreenGuide to chat.", false) }
    }

    private fun showControls() {
        if (controls != null) return
        val w = wm ?: return
        // Each button has a picture and a short word under it, so nobody has to guess what it does.
        fun icon(kind: String, word: String, desc: String, onTap: () -> Unit) = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; contentDescription = desc
            layoutParams = LinearLayout.LayoutParams(dp(64), dp(62))
            addView(IconView(context, kind, 0xFF1A1A1A.toInt()).apply { layoutParams = LinearLayout.LayoutParams(dp(24), dp(24)) })
            addView(TextView(context).apply {
                text = word; textSize = 11.5f; setTextColor(0xFF1A1A1A.toInt()); gravity = Gravity.CENTER; setPadding(0, dp(3), 0, 0)
                importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            })
            setOnClickListener { v -> v.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY); onTap() }
        }
        val repeat = icon("refresh", "Repeat", "Repeat the instruction") { speakCurrent() }
        val stuck = icon("help", "Help", "I am stuck, help me") { onStuck() }
        val stop = icon("close", "Stop", "Stop the guide") {
            Stats.inc(this, "stopped")
            val gid = Guides.active?.id ?: "unknown"
            Guides.active = null; Guides.aiStep = null; hide(); hideControls(); hideLabel()
            whyStopped(gid) { if (Testing.active) endTest(true) else afterGuide(stopped = true) }
        }
        val chat = icon("chat", "Tell me", "Tell me why I am stuck") { openChat() }
        chat.visibility = View.GONE; chatChip = chat
        // Developer phones: ask for a change to what is on the screen (point at it, then say it).
        val change = icon("edit", "Change", "Ask for a change to this screen") { startChange() }
        change.visibility = if (Server.tester) View.VISIBLE else View.GONE
        stuckChip = stuck
        val col = DragLayout(this, { dx, dy -> movePill(dx, dy) }, { dropPill() }).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(4), dp(6), dp(4), dp(6))
            background = GradientDrawable().apply { setColor(0xF0F7F5F0.toInt()); cornerRadius = dp(32).toFloat(); setStroke(maxOf(1, dp(1)), 0x33000000) }
            elevation = dp(6).toFloat()
            addView(repeat); addView(stuck); addView(chat); addView(change); addView(stop)
        }
        val lp = WindowManager.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,   // touchable, unlike the ring
            PixelFormat.TRANSLUCENT)
        val sp = getSharedPreferences("sg", MODE_PRIVATE)
        pillManual = sp.contains("pill_y")   // where the person last dragged it
        lp.gravity = (if (sp.getString("pill_side", "end") == "start") Gravity.START else Gravity.END) or Gravity.TOP
        lp.x = dp(6); lp.y = sp.getInt("pill_y", dp(150))
        w.addView(col, lp); controls = col
        handler.removeCallbacks(stuckRun); handler.postDelayed(stuckRun, 9000)
        handler.removeCallbacks(idleRun); handler.postDelayed(idleRun, IDLE_MS)
    }

    // Keep the buttons on the side away from the target. Once the person has dragged them, their place wins, unless
    // it would cover what we point at.
    private var pillManual = false
    private fun moveControls(r: Rect) {
        val c = controls ?: return
        val lp = c.layoutParams as? WindowManager.LayoutParams ?: return
        val sw = resources.displayMetrics.widthPixels
        var side = if (!pillManual) (if (r.centerX() > sw / 2) Gravity.START else Gravity.END)
            else if (getSharedPreferences("sg", MODE_PRIVATE).getString("pill_side", "end") == "start") Gravity.START else Gravity.END
        if (pillManual) {
            val pw = if (c.width > 0) c.width else dp(72); val ph = if (c.height > 0) c.height else dp(260)
            val px = if (side == Gravity.START) dp(6) else sw - dp(6) - pw
            if (Rect.intersects(Rect(px, lp.y, px + pw, lp.y + ph), r)) side = if (side == Gravity.START) Gravity.END else Gravity.START
        }
        val g = side or Gravity.TOP
        if (lp.gravity != g || lp.x != dp(6)) { lp.gravity = g; lp.x = dp(6); try { wm?.updateViewLayout(c, lp) } catch (_: Exception) {} }
    }
    private fun movePill(dx: Int, dy: Int) {
        val c = controls ?: return; val lp = c.layoutParams as? WindowManager.LayoutParams ?: return
        lp.x += if ((lp.gravity and Gravity.END) == Gravity.END) -dx else dx
        lp.y = (lp.y + dy).coerceIn(dp(24), maxOf(dp(24), resources.displayMetrics.heightPixels - c.height - dp(24)))
        try { wm?.updateViewLayout(c, lp) } catch (_: Exception) {}
    }
    // Let go: it settles at the nearer side, and stays there next time.
    private fun dropPill() {
        val c = controls ?: return; val lp = c.layoutParams as? WindowManager.LayoutParams ?: return
        val loc = IntArray(2); c.getLocationOnScreen(loc)
        val left = loc[0] + c.width / 2 < resources.displayMetrics.widthPixels / 2
        lp.gravity = (if (left) Gravity.START else Gravity.END) or Gravity.TOP; lp.x = dp(6)
        try { wm?.updateViewLayout(c, lp) } catch (_: Exception) {}
        pillManual = true; Stats.inc(this, "moved_buttons")
        getSharedPreferences("sg", MODE_PRIVATE).edit().putString("pill_side", if (left) "start" else "end").putInt("pill_y", lp.y).apply()
    }
    private fun hideControls() {
        controls?.let { try { wm?.removeView(it) } catch (_: Exception) {} }
        controls = null; stuckChip = null; chatChip = null; handler.removeCallbacks(stuckRun); handler.removeCallbacks(idleRun)
        hideDbg(); aiNote = ""
        askCard?.let { try { wm?.removeView(it) } catch (_: Exception) {} }; askCard = null
    }

    // Phones draw switches differently; accept anything that looks like one.
    private fun isSwitchLike(n: AccessibilityNodeInfo?): Boolean {
        if (n == null) return false
        val c = n.className?.toString() ?: ""
        return n.isCheckable || c.contains("Switch") || c.contains("Toggle") || c.contains("CheckBox")
    }

    // Some phones will not tell us (hotspot is a hidden setting). Then a tap on the switch finishes the guide instead.
    private fun hotspotOn(): Boolean? = try {
        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val method = wm.javaClass.getDeclaredMethod("isWifiApEnabled"); method.isAccessible = true
        method.invoke(wm) as Boolean
    } catch (e: Throwable) { null }
    private fun stateKnown(g: Guide) = when (g.doneWhen) { null -> false; "hotspot_on" -> hotspotOn() != null; else -> true }

    // Ask Android itself whether the task is done, instead of guessing from the screen.
    private fun isDone(g: Guide): Boolean = when (g.doneWhen) {
        "wifi_on" -> try { (applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).isWifiEnabled } catch (e: Exception) { false }
        "hotspot_on" -> hotspotOn() ?: false
        "bluetooth_on" -> try { Settings.Global.getInt(contentResolver, "bluetooth_on", 0) == 1 } catch (e: Exception) { false }
        "airplane_on" -> try { Settings.Global.getInt(contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) == 1 } catch (e: Exception) { false }
        "torch_on" -> torchOn
        "battery_saver_on" -> try { (getSystemService(POWER_SERVICE) as android.os.PowerManager).isPowerSaveMode } catch (e: Exception) { false }
        "data_saver_on" -> try {
            (getSystemService(CONNECTIVITY_SERVICE) as android.net.ConnectivityManager).restrictBackgroundStatus == android.net.ConnectivityManager.RESTRICT_BACKGROUND_STATUS_ENABLED
        } catch (e: Exception) { false }
        "text_bigger" -> try { Settings.System.getFloat(contentResolver, Settings.System.FONT_SCALE, 1f) > fontAtStart + 0.01f } catch (e: Exception) { false }
        else -> false
    }

    // Developer phones: a small picture of the screen after each step, showing what the person saw (ring and card
    // included). Kept on the phone; sent only if the developer taps Allow after the guide. Never on bank, money or
    // password screens, and never of ScreenGuide itself.
    private fun watchShot(n: Int, guideStep: Boolean = false) {
        if (Build.VERSION.SDK_INT < 30) return
        if (!Server.tester) return
        handler.postDelayed({
            if (capturing || (Guides.active == null && !Testing.active)) return@postDelayed
            val key = if (guideStep) Guides.aiStep else null
            val root = rootInActiveWindow ?: return@postDelayed
            val pkg = root.packageName?.toString() ?: ""
            if ((pkg == packageName && !(Testing.active && Testing.pkg == packageName)) || sensitive(pkg, candidates(root))) return@postDelayed
            try {
                takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
                    override fun onSuccess(result: ScreenshotResult) {
                        try {
                            val hb = result.hardwareBuffer
                            val b = Bitmap.wrapHardwareBuffer(hb, result.colorSpace)?.copy(Bitmap.Config.ARGB_8888, false)
                            hb.close()
                            if (b != null) WatchShots.add(n, smallShot(b))
                            if (b != null && key != null && key === Guides.aiStep) {
                                stale.step(key, System.currentTimeMillis()); stale.print(key, lowerPrint(b)); staleN = n
                            }
                        } catch (_: Exception) {}
                    }
                    override fun onFailure(errorCode: Int) {}
                })
            } catch (_: Exception) {}
        }, 1500)
    }

    // ---- Developer phones: the screen changed under a step that stayed (the logic is StaleWatch, in Testing.kt) ----
    private val stale = StaleWatch()
    private var staleN = 0
    private val staleRun = Runnable { staleCheck() }

    private fun staleEvent(e: AccessibilityEvent) {
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName || pkg.contains("systemui")) return
        if (e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && e.eventType != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) return
        val now = System.currentTimeMillis()
        stale.step(Guides.aiStep, now); stale.event(now)
        handler.removeCallbacks(staleRun); handler.postDelayed(staleRun, 1600)
    }

    // A tiny grey picture of the lower part of the screen, where an app's buttons are (a camera's moving picture is
    // mostly above it, and the phone's own navigation bar below is left out).
    private fun lowerPrint(b: Bitmap): IntArray {
        val y0 = (b.height * 0.55).toInt(); val h = maxOf(1, minOf((b.height * 0.37).toInt(), b.height - y0))
        val part = Bitmap.createBitmap(b, 0, y0, b.width, h)
        val small = Bitmap.createScaledBitmap(part, 12, 10, true)
        val px = IntArray(120); small.getPixels(px, 0, 12, 0, 0, 12, 10)
        return StaleWatch.grey(px)
    }

    private fun staleCheck() {
        if (Build.VERSION.SDK_INT < 30) return
        if (!Server.tester || Guides.active == null || capturing) return
        val key = Guides.aiStep
        val now = System.currentTimeMillis()
        stale.step(key, now)
        if (!stale.due(key, now)) { if (stale.waiting) handler.postDelayed(staleRun, 1000); return }
        val root = rootInActiveWindow ?: return
        val pkg = root.packageName?.toString() ?: ""
        if (pkg == packageName || sensitive(pkg, candidates(root))) return
        val n = staleN
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
                override fun onSuccess(result: ScreenshotResult) {
                    try {
                        val hb = result.hardwareBuffer
                        val b = Bitmap.wrapHardwareBuffer(hb, result.colorSpace)?.copy(Bitmap.Config.ARGB_8888, false)
                        hb.close()
                        if (b == null) return
                        val t = System.currentTimeMillis()
                        if (stale.compared(key, lowerPrint(b), t)) reportStale(n, stale.secs(t), smallShot(b))
                        else if (stale.waiting) { handler.removeCallbacks(staleRun); handler.postDelayed(staleRun, 6100) }
                    } catch (_: Exception) {}
                }
                override fun onFailure(errorCode: Int) {}
            })
        } catch (_: Exception) {}
    }

    // Developer phones: a slow answer as the phone saw it goes to the watcher (it flashes red like any other problem)
    private fun reportSlow(id: String, n: Int, ms: Long) {
        val count = Server.watchSlow(id, n, ms)
        handler.post { if (count > watchSeen) flashRed(); watchSeen = maxOf(watchSeen, count) }
    }

    private fun reportStale(n: Int, secs: Int, jpg: String) {
        if (n <= 0) return
        val id = Server.installId(this)
        Thread {
            val (count, pic) = Server.watchStale(id, n, secs)
            if (pic > 0) WatchShots.add(pic, jpg)
            handler.post { if (count > watchSeen) flashRed(); watchSeen = maxOf(watchSeen, count) }
        }.start()
    }

    private fun smallShot(b: Bitmap): String {
        val w = 480
        val s = if (b.width > w) Bitmap.createScaledBitmap(b, w, maxOf(1, b.height * w / b.width), true) else b
        val o = java.io.ByteArrayOutputStream()
        s.compress(Bitmap.CompressFormat.JPEG, 55, o)
        return android.util.Base64.encodeToString(o.toByteArray(), android.util.Base64.NO_WRAP)
    }

    // ---- Developer phones: ask for a change. A picture of the screen (ScreenGuide's card and ring included), a tap on
    // the spot, then the words. It joins the list after the guide, next to the problems. ----
    private var pointView: View? = null

    private fun startChange() {
        if (!Server.tester) return
        val words = (if (Guides.active == null && Testing.active) testLabels else Guides.aiLabels.toList()).take(60)
        testPill?.visibility = View.INVISIBLE
        changeShot { shot -> testPill?.visibility = View.VISIBLE; askPoint(shot, words) }
    }

    private fun changeShot(done: (Bitmap?) -> Unit) {
        if (Build.VERSION.SDK_INT < 30) { done(null); return }
        val root = rootInActiveWindow
        val pkg = root?.packageName?.toString() ?: ""
        if (root == null || (pkg == packageName && !(Testing.active && Testing.pkg == packageName)) || sensitive(pkg, candidates(root))) { done(null); return }
        controls?.visibility = View.INVISIBLE   // the buttons just tapped are not part of the screen
        fun back(b: Bitmap?) { handler.post { controls?.visibility = View.VISIBLE; done(b) } }
        handler.postDelayed({
            try {
                takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
                    override fun onSuccess(result: ScreenshotResult) {
                        var b: Bitmap? = null
                        try {
                            val hb = result.hardwareBuffer
                            b = Bitmap.wrapHardwareBuffer(hb, result.colorSpace)?.copy(Bitmap.Config.ARGB_8888, true)
                            hb.close()
                        } catch (_: Exception) {}
                        back(b)
                    }
                    override fun onFailure(errorCode: Int) { back(null) }
                })
            } catch (_: Exception) { back(null) }
        }, 180)
    }

    private fun askPoint(shot: Bitmap?, words: List<String>) {
        val w = wm ?: run { openChange(shot, -1f, -1f, words); return }
        val dm = resources.displayMetrics
        val fw = (shot?.width ?: dm.widthPixels).toFloat(); val fh = (shot?.height ?: dm.heightPixels).toFloat()
        val v = FrameLayout(this).apply {
            setBackgroundColor(0x40000000)
            addView(TextView(context).apply {
                text = "Tap what you want to change.\nOr tap here to skip pointing."
                textSize = 17f; setTextColor(0xFF1A1A1A.toInt()); gravity = Gravity.CENTER
                background = GradientDrawable().apply { setColor(0xF0F7F5F0.toInt()); cornerRadius = dp(18).toFloat() }
                setPadding(dp(16), dp(14), dp(16), dp(14))
                layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = dp(90) }
                setOnClickListener { closePoint(); openChange(shot, -1f, -1f, words) }
            })
            setOnTouchListener { _, e ->
                if (e.action == android.view.MotionEvent.ACTION_UP) {
                    closePoint(); openChange(shot, (e.rawX / fw).coerceIn(0f, 1f), (e.rawY / fh).coerceIn(0f, 1f), words)
                }
                true
            }
        }
        val lp = WindowManager.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT)
        try { w.addView(v, lp); pointView = v } catch (_: Exception) { openChange(shot, -1f, -1f, words) }
    }

    private fun closePoint() { pointView?.let { try { wm?.removeView(it) } catch (_: Exception) {} }; pointView = null }

    private fun openChange(shot: Bitmap?, x: Float, y: Float, words: List<String>) {
        ChangeDraft.set(shot, x, y, words)
        try { startActivity(Intent(this, ChangeActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
    }

    // ---- Developer phones: "Test an app". Every screen of that app is read, and problems are spotted on the phone:
    // Android's crash and freeze messages, error text, taps that change nothing, long loading, buttons with no name or
    // too small. Each new screen gets a picture. Nothing goes to the AI fixer until the developer taps Allow. ----
    private var testPill: LinearLayout? = null
    private var testScreen = ""
    private var testSeen = 0
    private var testLabels: List<String> = emptyList()
    private val testTaps = Testing.TapWatch()
    private val testLoading = Testing.Loading()
    private var testSysAt = 0L
    private val testLookRun = Runnable { testLook() }
    private val testTickRun: Runnable = object : Runnable {
        override fun run() { if (Testing.active) { testLook(); handler.postDelayed(this, 3000) } }
    }

    private fun testEvent(e: AccessibilityEvent) {
        if (testPill == null) showTestPill()
        val pkg = e.packageName?.toString() ?: return
        val now = System.currentTimeMillis()
        if ((pkg == "android" || pkg.contains("systemui")) && e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            if (now - testSysAt < 5000) return
            val texts = e.text.map { it.toString() } + (e.source?.let { s -> candidates(s).mapNotNull { (it.text ?: it.contentDescription)?.toString() } } ?: emptyList())
            Testing.systemMessage(texts, Testing.app)?.let { testSysAt = now; testReport(listOf(it), testLabels, false) }
            return
        }
        if (pkg != Testing.pkg) return
        if (e.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED) {
            val src = e.source
            val name = (src?.text ?: src?.contentDescription)?.toString()?.trim()?.take(40) ?: ""
            val key = (src?.viewIdResourceName ?: "") + "|" + name
            if (key != "|" && testTaps.tap(key, testScreen, now))
                testReport(listOf(Testing.Found("dead_tap", name.ifEmpty { "A button with no name" })), testLabels, false)
            return
        }
        if (e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED || e.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) {
            handler.removeCallbacks(testLookRun); handler.postDelayed(testLookRun, 900)
        }
    }

    private fun hasWords(n: AccessibilityNodeInfo, depth: Int): Boolean {
        if (depth > 3) return false
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            if (!(c.text ?: c.contentDescription).isNullOrBlank() || hasWords(c, depth + 1)) return true
        }
        return false
    }

    private fun testLook() {
        if (!Testing.active) return
        val root = rootInActiveWindow ?: return
        val pkg = root.packageName?.toString() ?: return
        if (pkg != Testing.pkg) return
        val nodes = candidates(root)
        if (sensitive(pkg, nodes)) return
        val d = resources.displayMetrics.density
        val parts = nodes.take(400).map { n ->
            val r = Rect(); n.getBoundsInScreen(r)
            val t = (n.text ?: n.contentDescription)?.toString() ?: ""
            Testing.Part(t, n.isClickable, n.isEditable, n.className?.toString()?.contains("ProgressBar") == true,
                (r.width() / d).toInt(), (r.height() / d).toInt(), t.isNotBlank() || hasWords(n, 0))
        }
        val labels = parts.map { it.text.trim() }.filter { it.isNotEmpty() }.distinct().take(60)
        val id = labels.sorted().joinToString("|").hashCode().toString()
        val found = ArrayList<Testing.Found>()
        testLoading.seen(parts.any { it.progress }, System.currentTimeMillis())?.let { found.add(Testing.Found("loading", "$it")) }
        val newScreen = id != testScreen
        if (newScreen) { testScreen = id; testLabels = labels; testTaps.screenChanged(id); found.addAll(Testing.look(parts)) }
        if (!newScreen && found.isEmpty()) return
        testReport(found, labels, newScreen)
    }

    private fun testReport(found: List<Testing.Found>, labels: List<String>, newScreen: Boolean) {
        val id = Server.installId(this)
        Thread {
            val (count, n) = Server.watchScreen(id, labels, found.map { it.kind to it.detail }, newScreen)
            handler.post { if (count > testSeen) flashRed(); testSeen = maxOf(testSeen, count); if (newScreen && n > 0) watchShot(n) }
        }.start()
    }

    private fun showTestPill() {
        val w = wm ?: return
        if (testPill != null) return
        fun chip(label: String, onTap: () -> Unit) = TextView(this).apply {
            text = label; textSize = 13.5f; setTextColor(0xFF1A1A1A.toInt()); typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(12), dp(8), dp(12), dp(8)); minHeight = dp(40); gravity = Gravity.CENTER
            background = GradientDrawable().apply { setColor(0x14000000); cornerRadius = dp(18).toFloat() }
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { leftMargin = dp(4) }
            setOnClickListener { v -> v.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY); onTap() }
        }
        val pill = DragLayout(this, { dx, dy -> moveTestPill(dx, dy) }, { dropTestPill() }).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(5), dp(5), dp(5))
            background = GradientDrawable().apply { setColor(0xF0F7F5F0.toInt()); cornerRadius = dp(24).toFloat(); setStroke(maxOf(1, dp(1)), 0x33000000) }
            elevation = dp(6).toFloat()
            addView(TextView(context).apply {
                text = "\u25CF Testing " + Testing.app.take(18); textSize = 13.5f; setTextColor(0xFFC62828.toInt()); typeface = Typeface.DEFAULT_BOLD
                setPadding(0, 0, dp(6), 0)
            })
            addView(chip("Change") { startChange() })
            addView(chip("Stop") { endTest(false) })
        }
        val lp = WindowManager.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT)
        val sp = getSharedPreferences("sg", MODE_PRIVATE)
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = sp.getInt("test_pill_x", dp(6)); lp.y = sp.getInt("test_pill_y", (resources.displayMetrics.heightPixels * 0.38).toInt())
        try { w.addView(pill, lp); testPill = pill; testLp = lp } catch (_: Exception) { return }
        handler.removeCallbacks(testTickRun); handler.postDelayed(testTickRun, 3000)
    }

    private var testLp: WindowManager.LayoutParams? = null
    private fun moveTestPill(dx: Int, dy: Int) {
        val p = testPill ?: return; val lp = testLp ?: return
        val dm = resources.displayMetrics
        lp.x = (lp.x + dx).coerceIn(0, maxOf(0, dm.widthPixels - p.width)); lp.y = (lp.y + dy).coerceIn(0, maxOf(0, dm.heightPixels - p.height))
        try { wm?.updateViewLayout(p, lp) } catch (_: Exception) {}
    }
    private fun dropTestPill() {
        val lp = testLp ?: return
        getSharedPreferences("sg", MODE_PRIVATE).edit().putInt("test_pill_x", lp.x).putInt("test_pill_y", lp.y).apply()
    }

    // The developer tapped Stop (fromGuide = false), or the guide for the test's goal ended (true). Then the pop-up.
    private fun endTest(fromGuide: Boolean) {
        if (!Testing.active) return
        Testing.active = false
        testPill?.let { try { wm?.removeView(it) } catch (_: Exception) {} }; testPill = null
        handler.removeCallbacks(testTickRun); handler.removeCallbacks(testLookRun)
        val g = Guides.active
        testScreen = ""; testSeen = 0; testLabels = emptyList(); testLp = null
        if (!fromGuide && g != null) {
            Guides.active = null; Guides.aiStep = null; hide(); hideControls(); hideLabel()
            whyStopped(g.id) { afterGuide(true, stopped = true) }
            return
        } else if (!fromGuide) Server.event(this, "stop", "test")
        afterGuide(true)
    }

    // Developer phones: Stop in the middle of a guide asks why. "Just testing" is not a problem for the watcher; "I was
    // stuck" (or no answer within 15 seconds) is. Seen 2 Nov: a Stop on purpose came back as "Stopped at step 1".
    private var whyCard: View? = null
    private fun whyStopped(gid: String, then: () -> Unit) {
        val w = wm
        if (!Server.tester || gid == "unknown" || w == null) { Server.event(this, "stop", gid); then(); return }
        whyCard?.let { try { w.removeView(it) } catch (_: Exception) {} }; whyCard = null
        var answered = false
        fun answer(stuck: Boolean) {
            if (answered) return
            answered = true
            whyCard?.let { try { w.removeView(it) } catch (_: Exception) {} }; whyCard = null
            Server.event(this, "stop", if (stuck) gid else "quit_$gid")
            then()
        }
        fun button(t: String, fill: Int, fg: Int, stuck: Boolean) = TextView(this).apply {
            text = t; textSize = 16f; setTextColor(fg); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            background = GradientDrawable().apply { setColor(fill); cornerRadius = dp(22).toFloat() }
            setPadding(dp(18), dp(12), dp(18), dp(12)); minHeight = dp(48)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(8) }
            setOnClickListener { v -> v.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY); answer(stuck) }
        }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(16), dp(16), dp(14))
            background = GradientDrawable().apply { setColor(0xF5F2F2F2.toInt()); cornerRadius = dp(24).toFloat() }
            addView(TextView(context).apply {
                text = "Why did you stop?"; textSize = 18f; setTextColor(0xFF1A1A1A.toInt()); typeface = Typeface.DEFAULT_BOLD
            })
            addView(TextView(context).apply {
                text = "For the watcher (developer phones only). If you were stuck, it goes on the list of problems."
                textSize = 15f; setTextColor(0xFF333333.toInt()); setPadding(0, dp(6), 0, dp(12))
            })
            addView(LinearLayout(context).apply {
                addView(button("Just testing", 0x14000000, 0xFF1A1A1A.toInt(), false))
                addView(button("I was stuck", 0xFF145A3D.toInt(), Color.WHITE, true))
            })
        }
        val d = resources.displayMetrics
        val lp = WindowManager.LayoutParams((d.widthPixels * 0.92).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; lp.y = dp(96)
        try { w.addView(card, lp); whyCard = card } catch (e: Exception) { answer(true); return }
        handler.postDelayed({ answer(true) }, 15000)
    }

    // Developer phones: a short red flash around the screen when the watcher sees a problem in this guide.
    private fun flashRed() {
        val w = wm ?: return
        val v = View(this).apply {
            background = GradientDrawable().apply { setColor(0x22FF1744); setStroke(dp(8), 0xFFFF1744.toInt()) }
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        }
        val lp = WindowManager.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT)
        try { w.addView(v, lp) } catch (_: Exception) { return }
        v.alpha = 0f
        v.animate().alpha(1f).setDuration(150).withEndAction {
            v.animate().alpha(0f).setDuration(650).withEndAction { try { w.removeView(v) } catch (_: Exception) {} }.start()
        }.start()
    }

    // Developer phones: after a guide or a test, the watcher's problems in a pop-up (what went wrong, how to fix it, Allow
    // or not). Each list is also kept in Past results on this phone, so it can be read again and still sent later.
    private fun afterGuide(fromTest: Boolean = false, stopped: Boolean = false) {
        watchSeen = 0
        if (!Server.tester) return
        val id = Server.installId(this)
        Thread {
            try { Thread.sleep(1500) } catch (_: InterruptedException) {}   // let "done" or "stop" reach the server first
            // The step pictures help the AI review see what was really on the screen (the owner agreed, 2 Nov): the server
            // says which ones it wants, then reviews with them. They are not kept unless Allow sends them.
            val shots = WatchShots.all()
            var rv = Server.watchReview(id, shots.map { it.first })
            if (rv.want.isNotEmpty()) rv = Server.watchReview(id, shots.map { it.first }, shots.filter { it.first in rv.want })
            if (rv.problems.isEmpty()) {
                // Always say how it went, after every guide and test (2 and 4 Nov: nothing appeared, was it working?)
                val msg = Watch.afterText(rv.error, rv.lost, stopped, fromTest)
                handler.post { android.widget.Toast.makeText(this, msg, android.widget.Toast.LENGTH_LONG).show() }
                return@Thread
            }
            val arr = JSONArray()
            rv.problems.forEach { arr.put(JSONObject().put("id", it.id).put("title", it.title).put("what", it.what).put("fix", it.fix).put("kind", it.kind)) }
            val title = rv.title.ifEmpty { if (fromTest) "Test" else "Guide" } + (if (rv.stopped > 0) " \u00B7 stopped at step ${rv.stopped}" else "")
            val rid = try { Results.add(this, title, arr, rv.saved, shots, rv.limits) } catch (e: Exception) { 0L }
            handler.postDelayed({
                try {
                    val i = Intent(this, WatchActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra("fresh", true)
                        .putExtra("stopped_at", rv.stopped)
                    // Kept in Past results: the pop-up reads it from there. If it could not be kept, it comes along.
                    if (rid != 0L) i.putExtra("result_id", rid) else i.putExtra("problems", arr.toString()).putExtra("saved", rv.saved)
                    startActivity(i)
                } catch (_: Exception) {}
            }, 1500)
        }.start()
    }

    private fun finish(g: Guide) {
        appSaid = ""
        Stats.inc(this, "finished"); Server.event(this, "done", g.id); if (Testing.active) endTest(true) else afterGuide()
        val task = g.id != "ai" && g.id != "find" && Guides.all.any { it.id == g.id }
        val alone = task && Guides.practice && !Guides.practiceHelped
        if (task) { Skills.record(this, g.id, alone); if (alone) Stats.inc(this, "done_alone") }
        Guides.practice = false; Guides.practiceHelped = false
        hide(); hideControls(); Guides.active = null; spokenFor = -1; say(g.done)
        val l = Guides.lang
        val extra = when {
            !task -> ""
            alone -> "\n" + (starLine[l] ?: starLine["en"])
            else -> "\n" + progressLine(l)
        }
        // A screenshot is taken just after the tap: nothing of ours may be on screen then, so the "Well done" waits.
        val later = if (g.id == "screenshot") { hideDbg(); 1800L } else 0L
        handler.postDelayed({
            holdUntil = System.currentTimeMillis() + 5000
            showLabel("\u2714 " + (g.done[l] ?: g.done["en"] ?: "") + extra, false)
            buzz(true)
            handler.postDelayed({ hideLabel() }, 5000)
        }, later)
    }
    private val starLine = mapOf("en" to "\u2B50 You did it alone, with no help!", "ny" to "\u2B50 Mwachita nokha, popanda thandizo!",
        "bem" to "\u2B50 Mwacita nemwe bene, ukwabula ubwafwilisho!")
    private fun progressLine(l: String): String {
        val n = Skills.learned(this); val m = Skills.tasks().size
        return when (l) { "ny" -> "Mwaphunzira $n mwa $m."; "bem" -> "Mwasambilila $n pali $m."; else -> "You have learned $n of $m phone skills." }
    }

    private fun norm(s: String?) = (s ?: "").lowercase().filter { it.isLetterOrDigit() }

    // Menus and drop-down lists open in a small window of their own, often not the "active" one, so their items were
    // invisible to the helper (YouTube's "Videos | All albums" list, the ⋮ menu in WhatsApp and Chrome). Read them first.
    private fun popupNodes(): List<AccessibilityNodeInfo> {
        val out = ArrayList<AccessibilityNodeInfo>()
        try {
            val ws = windows
            val active = ws.firstOrNull { it.isActive } ?: return out
            for (w in ws) {
                if (w.id == active.id || w.type != AccessibilityWindowInfo.TYPE_APPLICATION || w.layer <= active.layer) continue
                val r = w.root ?: continue
                if (r.packageName?.toString() == packageName) continue
                out.addAll(candidates(r))
            }
        } catch (_: Exception) {}
        return out
    }

    // The screen's own name in its title bar ("Display & Brightness" once you are on that page): words to read, not a
    // button. A step must never point at it (it did, on Infinix, while the next row was further down the page).
    private fun isTitle(n: AccessibilityNodeInfo): Boolean {
        val r = Rect(); n.getBoundsInScreen(r)
        return r.top <= resources.displayMetrics.heightPixels * 0.3 && !tappable(n)
    }

    // Every visible node on screen, as a flat list.
    private fun candidates(root: AccessibilityNodeInfo): List<AccessibilityNodeInfo> {
        val out = ArrayList<AccessibilityNodeInfo>()
        val q = ArrayDeque<AccessibilityNodeInfo>(); q.add(root)
        var seen = 0
        while (q.isNotEmpty() && seen < 800) {
            val n = q.removeFirst(); seen++
            if (n.isVisibleToUser) out.add(n)
            for (i in 0 until n.childCount) n.getChild(i)?.let { q.add(it) }
        }
        return out
    }

    // Some phones never report certain rows (e.g. Airplane mode on Infinix). If the screen's title matches
    // but the row is missing, point at the empty band between the title bar and the next heading.
    private var syntheticRect: Rect? = null
    private fun gapRow(nodes: List<AccessibilityNodeInfo>, s: Step, h: Int): AccessibilityNodeInfo? {
        val tk = (s.titles ?: s.match).map { norm(it) }
        val title = nodes.firstOrNull { n ->
            val r = Rect(); n.getBoundsInScreen(r)
            r.top <= h * 0.12 && norm(n.text?.toString()) in tk
        } ?: return null
        val tr = Rect(); title.getBoundsInScreen(tr)
        val next = nodes.mapNotNull { n ->
            if (n.text.isNullOrBlank()) return@mapNotNull null
            val r = Rect(); n.getBoundsInScreen(r)
            if (r.top > tr.bottom + h * 0.02) r.top else null
        }.minOrNull() ?: return null
        val top = tr.bottom + (h * 0.01).toInt()
        val bottom = next - (h * 0.01).toInt()
        if (bottom - top < h * 0.04) return null
        val mid = (top + bottom) / 2
        val half = minOf((bottom - top) / 2, (h * 0.045).toInt())
        val w = resources.displayMetrics.widthPixels
        syntheticRect = Rect((w * 0.03).toInt(), mid - half, (w * 0.97).toInt(), mid + half)
        return title
    }

    private fun area(n: AccessibilityNodeInfo): Long { val r = Rect(); n.getBoundsInScreen(r); return r.width().toLong() * r.height() }

    private var foundHow = ""
    private fun find(nodes: List<AccessibilityNodeInfo>, s: Step): AccessibilityNodeInfo? {
        foundHow = ""
        if (s.match.firstOrNull() == "@slider") {
            val h = resources.displayMetrics.heightPixels
            val ts = s.titles
            if (ts != null) {   // only on the "Font size" screen, never the brightness slider on the screen before it
                val tk = ts.map { norm(it) }
                if (nodes.none { n -> val r = Rect(); n.getBoundsInScreen(r); r.top <= h * 0.3 && norm(n.text?.toString()) in tk }) return null
            }
            matchedText = null; foundHow = "slider"
            return nodes.filter { it.rangeInfo != null || (it.className?.toString() ?: "").contains("SeekBar") }.maxByOrNull { area(it) }
        }
        if (s.toggle) {
            matchedText = null
            switchFor(nodes, s.match)?.let { return it }
            // Fallback: the labelled row below the title bar (some phones hide the switch itself).
            val h = resources.displayMetrics.heightPixels
            val keys = s.match.map { norm(it) }
            // Only on the screen that is itself named "Wi-Fi" (label in the title bar), not on the Settings list.
            // Not on the main Settings list (its "Wi-Fi" row is a menu entry, not the switch).
            val onSettingsList = nodes.any { n ->
                val r = Rect(); n.getBoundsInScreen(r)
                r.top <= h * 0.12 && norm(n.text?.toString()) == "settings"
            }
            if (onSettingsList) return null
            val ts = s.titles
            if (ts != null) {   // only on the screen whose own title matches, not on the menu that leads to it
                val tk0 = ts.map { norm(it) }
                val okTitle = nodes.any { n -> val r = Rect(); n.getBoundsInScreen(r); r.top <= h * 0.12 && norm(n.text?.toString()) in tk0 }
                if (!okTitle) return null
            }
            val below = nodes.filter { n -> val r = Rect(); n.getBoundsInScreen(r); r.top > h * 0.12 }
            val cands = below.filter { n -> norm(n.text?.toString()) in keys || norm(n.contentDescription?.toString()) in keys }
            // Prefer a row that can be tapped over a plain heading (the ring once sat on the "Portable hotspot" heading).
            val row = cands.firstOrNull { switchNear(it) != null } ?: cands.filter { tappable(it) }.minByOrNull { area(it) } ?: cands.minByOrNull { area(it) }
                ?: below.filter { n -> keys.any { k -> norm(n.text?.toString()).startsWith(k) } }.minByOrNull { area(it) }
                ?: return gapRow(nodes, s, h).also { if (it != null) foundHow = "empty band under the title" }
            foundHow = if (switchNear(row) != null) "switch next to its words" else "row words (no switch seen)"
            return switchNear(row) ?: target(row)
        }
        val dm = resources.displayMetrics
        val maxArea = dm.widthPixels.toLong() * dm.heightPixels / 6   // ignore huge containers
        for (k in s.match) {
            val nk = norm(k)
            // Same words, ignoring odd hyphens and spacing. The smallest box is the most specific one.
            val same = nodes.filter { norm(it.text?.toString()) == nk || norm(it.contentDescription?.toString()) == nk }
                .filter { area(it) in 1L..maxArea && !isTitle(it) }
            var best = same.minByOrNull { area(it) } ?: continue
            foundHow = "same words"
            // The same button several times (an Install for every app): the one next to the name in the step
            if (same.size >= 2) {
                val names = Duplicates.names(s.say[Guides.lang] ?: s.say["en"] ?: "", if (Guides.active?.id == "ai") Guides.aiGoal else "", k)
                if (names.isNotEmpty()) {
                    fun box(n: AccessibilityNodeInfo): Duplicates.Box {
                        val r = Rect(); n.getBoundsInScreen(r)
                        return Duplicates.Box((n.text ?: n.contentDescription)?.toString() ?: "", r.left, r.top, r.right, r.bottom)
                    }
                    val others = nodes.filter { (it.text ?: it.contentDescription) != null && it !in same }
                    val i = Duplicates.pick(same.map { box(it) }, others.map { box(it) }, names)
                    if (i >= 0) { best = same[i]; foundHow = "same words, the one next to its name" }
                }
            }
            matchedText = (best.text ?: best.contentDescription)?.toString()
            return target(best)
        }
        return null
    }

    // The on/off switch for a setting. Phones lay rows out differently: on Infinix the switch sits in its own box,
    // next to (not inside) the box with the setting's name. So: first a switch whose row (up to three levels up)
    // names the setting, then a switch on the same line as the name.
    private fun switchFor(nodes: List<AccessibilityNodeInfo>, keys: List<String>): AccessibilityNodeInfo? {
        val switches = nodes.filter { isSwitchLike(it) }
        if (switches.isEmpty()) return null
        var best: AccessibilityNodeInfo? = null
        var bestArea = Long.MAX_VALUE
        for (sw in switches) {
            var p: AccessibilityNodeInfo? = sw.parent
            var level = 0
            while (p != null && level < 3) {
                if (blob(p).length < 160 && matches(p, keys)) {
                    val a = area(p)
                    if (a < bestArea) { bestArea = a; best = sw }
                    break
                }
                p = p.parent; level++
            }
        }
        if (best != null) { foundHow = "switch in the same row"; return best }
        val nk = keys.map { norm(it) }
        val words = nodes.filter { n -> norm(n.text?.toString()).let { it.isNotEmpty() && it in nk } }.sortedBy { area(it) }
        for (wd in words) {
            val wr = Rect(); wd.getBoundsInScreen(wr)
            switches.firstOrNull { sw ->
                val r = Rect(); sw.getBoundsInScreen(r)
                kotlin.math.abs(r.centerY() - wr.centerY()) < dp(24) && r.left >= wr.left
            }?.let { foundHow = "switch on the same line"; return it }
        }
        return null
    }

    // Did this tap land on the switch for these words? (The switch itself has no words; its row does.)
    private fun tappedSwitch(src: AccessibilityNodeInfo, keys: List<String>): Boolean {
        var p: AccessibilityNodeInfo? = src; var level = 0
        while (p != null && level < 4) {
            if (blob(p).length < 160 && matches(p, keys)) return true
            p = p.parent; level++
        }
        val r = Rect(); src.getBoundsInScreen(r)
        return isSwitchLike(src) && !lastTarget.isEmpty && Rect.intersects(r, lastTarget)
    }

    // The tappable thing around the label, but never a huge container like a whole screen.
    private fun target(n: AccessibilityNodeInfo): AccessibilityNodeInfo {
        val nr = Rect(); n.getBoundsInScreen(nr)
        val d = resources.displayMetrics
        val limit = minOf(maxOf(1, nr.width() * nr.height()) * 4L, d.widthPixels.toLong() * d.heightPixels / 5)
        var c: AccessibilityNodeInfo = n
        repeat(3) {
            val p = c.parent ?: return n
            val pr = Rect(); p.getBoundsInScreen(pr)
            if (pr.width().toLong() * pr.height() > limit) return n
            if (p.isClickable) return p
            c = p
        }
        return n
    }

    private fun blob(n: AccessibilityNodeInfo?, d: Int = 0): String {
        if (n == null || d > 3) return ""
        var s = "${n.text} ${n.contentDescription} "
        for (i in 0 until n.childCount) s += blob(n.getChild(i), d + 1)
        return s
    }
    private fun matches(n: AccessibilityNodeInfo?, keys: List<String>): Boolean {
        val t = blob(n).lowercase()
        return keys.any { t.contains(it.lowercase()) }
    }

    private val ARROW = 118
    private var ringLp: WindowManager.LayoutParams? = null
    private var ringAnim: ValueAnimator? = null
    private val lastTarget = Rect()

    private fun show(r: Rect) {
        val w = wm ?: return
        moveControls(r)
        val h = resources.displayMetrics.heightPixels
        val below = r.bottom + 26 + ARROW <= h   // arrow goes under the target, or above it near the bottom edge
        val lp = WindowManager.LayoutParams(r.width() + 52, r.height() + 52 + ARROW,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = r.left - 26
        lp.y = if (below) r.top - 26 else r.top - 26 - ARROW
        lastTarget.set(r)
        val v = ring
        if (v == null) {
            ring = RingView(this).also { it.arrowBelow = below; w.addView(it, lp) }
            ringLp = lp
            return
        }
        v.arrowBelow = below; v.invalidate()
        val from = ringLp
        ringAnim?.cancel()
        val still = Settings.Global.getFloat(contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f
        if (from == null || still) { try { w.updateViewLayout(v, lp) } catch (_: Exception) {}; ringLp = lp; return }
        val fx = from.x; val fy = from.y; val tx = lp.x; val ty = lp.y
        ringLp = lp
        ringAnim = ValueAnimator.ofFloat(0f, 1f).apply {   // glide to the new spot instead of jumping
            duration = 120
            addUpdateListener { a ->
                val f = a.animatedFraction
                lp.x = (fx + (tx - fx) * f).toInt(); lp.y = (fy + (ty - fy) * f).toInt()
                try { w.updateViewLayout(v, lp) } catch (_: Exception) {}
            }
            start()
        }
    }

    private fun hide() {
        hideRing(); hideSwipe()
        if (System.currentTimeMillis() >= holdUntil) hideLabel()
    }

    // Instruction text on screen too, because many phones have no Chinyanja or Icibemba voice.
    private fun showLabel(text: String, top: Boolean, dim: Boolean = false, step: String? = null) {
        if (Guides.chatOpen) return
        val w = wm ?: return
        val shown: CharSequence = if (step == null) text else android.text.SpannableString(step + "\n" + text).apply {
            setSpan(android.text.style.RelativeSizeSpan(0.7f), 0, step.length, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            setSpan(android.text.style.ForegroundColorSpan(0xFF145A3D.toInt()), 0, step.length, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        val d = resources.displayMetrics
        // Touchable: one finger drags it out of the way, a tap says it again.
        val lp = WindowManager.LayoutParams((d.widthPixels * 0.9).toInt(), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT)
        var atTop = top || surface == "permission"
        val kb = imeTop?.let { d.heightPixels - it } ?: 0   // keep the card above the keyboard
        // Nothing pointed at: sit on the edge that covers fewer buttons (YouTube's bottom bar, an editor's tools).
        if (ring == null && swipe == null && labelY == null && surface != "permission") {
            val est = labelBox?.height?.takeIf { it > 0 } ?: dp(110)
            fun busy(b: Rect) = lastNodes.count { n -> n.isClickable && Rect().also { n.getBoundsInScreen(it) }.let { Rect.intersects(it, b) } }
            val ct = busy(Rect(0, dp(96), d.widthPixels, dp(96) + est))
            val cb = busy(Rect(0, d.heightPixels - kb - dp(88) - est, d.widthPixels, d.heightPixels - kb - dp(88)))
            if (ct + 1 < cb) atTop = true else if (cb + 1 < ct) atTop = false
        }
        lp.gravity = (if (atTop) Gravity.TOP else Gravity.BOTTOM) or Gravity.CENTER_HORIZONTAL
        lp.y = if (atTop) (96 * d.density).toInt() else kb + (88 * d.density).toInt()
        val th = testerHeight()
        if (th > 0 && atTop == testerTop) lp.y = maxOf(lp.y, (if (atTop) dp(28) else kb + dp(10)) + th + dp(8))   // below or above the tester card
        // Where the person dragged it, unless that now covers what we point at.
        labelY?.let { y ->
            val lh = labelBox?.height?.takeIf { it > 0 } ?: dp(110)
            val covers = ring != null && Rect.intersects(Rect(0, y, d.widthPixels, y + lh), lastTarget)
            if (!covers) { lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; lp.y = y }
        }
        val v = label
        if (v == null) {
            val t = TextView(this)
            t.textSize = if (surface == "permission") Profile.cardSize(this) - 4f else Profile.cardSize(this); t.setTextColor(0xFF1A1A1A.toInt()); t.typeface = Typeface.DEFAULT_BOLD; t.gravity = Gravity.CENTER
            val p = (14 * d.density).toInt(); t.setPadding(p, p, p, p)
            val g = GradientDrawable(); g.setColor(0xFFF7F5F0.toInt()); g.cornerRadius = 24 * d.density; g.setStroke(maxOf(1, d.density.toInt()), 0x33000000); t.background = g
            t.elevation = 6 * d.density; t.setLineSpacing(0f, 1.15f)
            t.text = shown; t.alpha = if (dim) 0.55f else 1f
            val box = DragLayout(this, { _, dy -> moveLabel(dy) }, { Stats.inc(this, "moved_card") }, { speakCurrent() })
            box.addView(t, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            label = t; labelBox = box
            try { w.addView(box, lp) } catch (_: Exception) { label = null; labelBox = null; return }
            announce(t, text)
        } else {
            if (v.text.toString() != shown.toString()) { v.text = shown; announce(v, text) }
            v.textSize = if (surface == "permission") Profile.cardSize(this) - 4f else Profile.cardSize(this)
            v.alpha = if (dim) 0.55f else 1f
            labelBox?.let { try { w.updateViewLayout(it, lp) } catch (_: Exception) {} }
        }
    }
    private fun touchExploring(): Boolean =
        (getSystemService(ACCESSIBILITY_SERVICE) as android.view.accessibility.AccessibilityManager).isTouchExplorationEnabled
    @Suppress("DEPRECATION")   // still works on Android 16; TalkBack users hear each new card
    private fun announce(v: View, text: String) { if (touchExploring()) v.announceForAccessibility(text) }

    private fun hideLabel() { labelBox?.let { try { wm?.removeView(it) } catch (_: Exception) {} }; label = null; labelBox = null }
    private var labelBox: DragLayout? = null
    private var labelY: Int? = null          // where the person dragged the card (top of screen = 0), for this guide
    private var lastNodes: List<AccessibilityNodeInfo> = emptyList()
    private fun moveLabel(dy: Int) {
        val b = labelBox ?: return; val lp = b.layoutParams as? WindowManager.LayoutParams ?: return
        val y0 = labelY ?: IntArray(2).also { b.getLocationOnScreen(it) }[1]
        val y = (y0 + dy).coerceIn(dp(24), maxOf(dp(24), resources.displayMetrics.heightPixels - b.height - dp(16)))
        labelY = y; lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; lp.y = y
        try { wm?.updateViewLayout(b, lp) } catch (_: Exception) {}
    }

    private fun speak(s: Step, asked: Boolean = false) {
        if (touchExploring()) return   // TalkBack already reads the card; do not talk over it
        if (!asked && !Profile.voiceOn(this)) return   // the person turned spoken steps off (Repeat still speaks)
        val l = Guides.lang
        val res = s.audio?.let { resources.getIdentifier("${it}_$l", "raw", packageName) } ?: 0
        if (res != 0) { mp?.release(); mp = MediaPlayer.create(this, res); mp?.start(); return }
        say(s.say)
    }
    // A recorded line ("Kandeni"), then the phone reads the button's name ("Create new") in its English voice.
    private fun playVoice(l: String, msg: String): Boolean {
        val m = Voices.match(this, l, msg) ?: return false
        return try {
            try { tts?.stop() } catch (_: Exception) {}
            mp?.release()
            mp = MediaPlayer().apply {
                setDataSource(m.first.absolutePath); prepare()
                setOnCompletionListener {
                    val name = m.second
                    if (name != null && ttsReady) {
                        tts?.language = Locale.ENGLISH; tts?.setSpeechRate(Profile.speechRate(this@GuideService))
                        tts?.speak(name, TextToSpeech.QUEUE_FLUSH, null, "sg_name")
                    }
                }
                start()
            }
            true
        } catch (e: Exception) { false }
    }
    // Uses a voice for the chosen language if the phone has one; otherwise falls back to English.
    private fun say(texts: Map<String, String>) {
        val l = Guides.lang
        texts[l]?.let { msg -> if (playVoice(l, msg)) return }   // a person's recorded voice, where there is one
        if (!ttsReady) return
        val loc = Locale.forLanguageTag(l)
        val ok = (tts?.isLanguageAvailable(loc) ?: TextToSpeech.LANG_NOT_SUPPORTED) >= TextToSpeech.LANG_AVAILABLE
        val msg = if (ok) texts[l] ?: texts["en"] else texts["en"] ?: texts[l]
        tts?.language = if (ok) loc else Locale.ENGLISH
        tts?.setSpeechRate(Profile.speechRate(this))
        if (msg != null) tts?.speak(msg, TextToSpeech.QUEUE_FLUSH, null, "sg")
    }
}
