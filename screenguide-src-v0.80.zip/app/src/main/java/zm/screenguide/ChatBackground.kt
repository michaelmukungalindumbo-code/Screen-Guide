package zm.screenguide

// The chat's background colour, like WhatsApp's chat themes (the owner asked, 6 Nov). Each colour has a pale shade for
// light mode and a deep one for dark mode, so the words on it stay easy to read (ChatBackgroundTest checks it).
object ChatBackground {
    class Choice(val key: String, val name: String, val light: Int, val dark: Int)

    val choices = listOf(
        Choice("default", "Default", 0xFFFAF6EF.toInt(), 0xFF0B0D0F.toInt()),   // the colours from before
        Choice("green", "Green", 0xFFE4F1E8.toInt(), 0xFF0B1E16.toInt()),
        Choice("blue", "Blue", 0xFFE3EDF8.toInt(), 0xFF0B1626.toInt()),
        Choice("purple", "Purple", 0xFFEEE7F6.toInt(), 0xFF181126.toInt()),
        Choice("sand", "Sand", 0xFFF4EAD5.toInt(), 0xFF1E190F.toInt()),
        Choice("pink", "Pink", 0xFFF8E6EC.toInt(), 0xFF251119.toInt()),
        Choice("grey", "Grey", 0xFFECECEC.toInt(), 0xFF1A1C1E.toInt()))

    const val SCRIM = 0.8       // how much of the usual colour lies over a photo (ChatBackgroundTest: readable on any photo)
    const val PHOTO = "photo"   // a photo from the gallery, kept only on this phone (filesDir/chat_bg.jpg)
    fun of(key: String): Choice = choices.firstOrNull { it.key == key } ?: choices[0]
    fun name(key: String): String = of(key).name
    // The photo under a layer of the usual background colour, so the words stay easy to read on it
    fun veil(photo: Int, paper: Int): Int = photo
    // How much to shrink while loading: the photo's short side stays at least want pixels
    fun sample(w: Int, h: Int, want: Int): Int = 1
    // The middle part of a w x h photo with the screen's shape: x, y, width, height
    fun crop(w: Int, h: Int, screenW: Int, screenH: Int): IntArray = intArrayOf(0, 0, w, h)
    fun color(key: String, dark: Boolean): Int = of(key).let { if (dark) it.dark else it.light }

    // How readable one colour is on another (WCAG contrast: 1 to 21; 7 and more is easy to read)
    fun contrast(a: Int, b: Int): Double {
        fun lum(c: Int): Double {
            fun ch(v: Int): Double { val x = v / 255.0; return if (x <= 0.03928) x / 12.92 else Math.pow((x + 0.055) / 1.055, 2.4) }
            return 0.2126 * ch(c shr 16 and 0xFF) + 0.7152 * ch(c shr 8 and 0xFF) + 0.0722 * ch(c and 0xFF)
        }
        val la = lum(a); val lb = lum(b)
        return (maxOf(la, lb) + 0.05) / (minOf(la, lb) + 0.05)
    }
}
