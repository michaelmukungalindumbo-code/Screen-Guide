package zm.screenguide

import android.app.Activity
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

private const val WIDE = ViewGroup.LayoutParams.MATCH_PARENT
private const val SNUG = ViewGroup.LayoutParams.WRAP_CONTENT

// Developer phones: "Test an app". Choose an app (ScreenGuide itself, or any other on the phone), its GitHub repository,
// and if you like a goal for ScreenGuide to guide you through. ScreenGuide then watches that app's screens and spots
// problems by itself; nothing is added to the app. At Stop, a pop-up lists them, and only Allow sends them to the fixer.
class TestActivity : Activity() {
    private class AppItem(val name: String, val pkg: String)
    private var past: LinearLayout? = null

    private val dark: Boolean get() = when (Profile.str(this, "theme", "auto")) {
        "light" -> false; "dark" -> true
        else -> (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    }
    private val bgc: Int get() = if (dark) 0xFF14181B.toInt() else 0xFFFBF8F3.toInt()
    private val ink: Int get() = if (dark) 0xFFF2F4F5.toInt() else 0xFF1F1A14.toInt()
    private val muted: Int get() = if (dark) 0xFFADB5BA.toInt() else 0xFF534C45.toInt()
    private val accent: Int get() = if (dark) 0xFF18C3DA.toInt() else 0xFF145A3D.toInt()
    private val onAccent: Int get() = if (dark) 0xFF06262C.toInt() else Color.WHITE
    private val soft: Int get() = if (dark) 0xFF1E2428.toInt() else 0xFFF1EADD.toInt()
    private val chosenBg: Int get() = if (dark) 0xFF0F3A40.toInt() else 0xFFD9EDE3.toInt()
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun box(c: Int, r: Int) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat() }

    private fun listApps(): List<AppItem> = try {
        val pm = packageManager
        val others = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { AppItem(it.loadLabel(pm).toString().trim(), it.activityInfo.packageName) }
            .filter { a -> a.pkg != packageName && a.name.isNotEmpty() && Guides.blockedApps.none { a.pkg.contains(it, true) || a.name.contains(it, true) } }
            .distinctBy { it.pkg }.sortedBy { it.name.lowercase() }
        listOf(AppItem("ScreenGuide (this app)", packageName)) + others
    } catch (e: Exception) { listOf(AppItem("ScreenGuide (this app)", packageName)) }

    private fun defaultRepo(pkg: String) = if (pkg == packageName) "michaelmukungalindumbo-code/Screen-Guide" else ""

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Server.initTester(this)
        if (!Server.tester) { finish(); return }
        val sp = getSharedPreferences("sg", MODE_PRIVATE)
        val apps = listApps()
        var chosen = apps.firstOrNull { it.pkg == sp.getString("test_pkg", packageName) } ?: apps.first()

        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(24), dp(20), dp(24)) }
        fun label(t: String) = TextView(this).apply {
            text = t; textSize = 15f; typeface = Typeface.DEFAULT_BOLD; setTextColor(ink); setPadding(0, dp(18), 0, dp(8))
        }
        col.addView(TextView(this).apply { text = "Test an app"; textSize = 24f; typeface = Typeface.DEFAULT_BOLD; setTextColor(ink) })
        col.addView(TextView(this).apply {
            text = "ScreenGuide watches the app you choose and spots problems by itself: crashes, freezes, error messages, taps " +
                "that do nothing, long loading, and buttons with no name or too small. Tap Change at any time to ask for a change. " +
                "At Stop, you choose what to send to the AI fixer. Nothing is added to the app."
            textSize = 15f; setTextColor(muted); setPadding(0, dp(6), 0, 0)
        })

        col.addView(label("1. The app"))
        val rows = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val repo = EditText(this).apply {
            hint = "owner/name, e.g. me/my-app"; setSingleLine(true); textSize = 16f
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            setTextColor(ink); setHintTextColor(muted); background = box(soft, 16); setPadding(dp(14), dp(12), dp(14), dp(12))
        }
        val rowViews = ArrayList<Pair<AppItem, TextView>>()
        fun paint() { rowViews.forEach { (a, v) -> v.background = box(if (a.pkg == chosen.pkg) chosenBg else soft, 14) } }
        fun choose(a: AppItem) {
            chosen = a
            repo.setText(sp.getString("test_repo_" + a.pkg, null) ?: defaultRepo(a.pkg))
            paint()
        }
        apps.forEach { a ->
            val v = TextView(this).apply {
                text = a.name; textSize = 16f; setTextColor(ink); setPadding(dp(14), dp(12), dp(14), dp(12)); minHeight = dp(48)
                gravity = Gravity.CENTER_VERTICAL
                layoutParams = LinearLayout.LayoutParams(WIDE, SNUG).apply { bottomMargin = dp(6) }
                setOnClickListener { choose(a) }
            }
            rowViews.add(a to v); rows.addView(v)
        }
        col.addView(ScrollView(this).apply { addView(rows); layoutParams = LinearLayout.LayoutParams(WIDE, dp(250)) })

        col.addView(label("2. Its GitHub repository"))
        col.addView(repo)
        col.addView(label("3. A goal (optional)"))
        val goal = EditText(this).apply {
            hint = "For example: Download a past paper. Leave it empty to just watch."; textSize = 16f; minLines = 1; maxLines = 3
            setTextColor(ink); setHintTextColor(muted); background = box(soft, 16); setPadding(dp(14), dp(12), dp(14), dp(12))
        }
        col.addView(goal)
        val status = TextView(this).apply { textSize = 14.5f; setTextColor(0xFFC62828.toInt()); setPadding(0, dp(10), 0, 0); visibility = View.GONE }
        col.addView(status)
        val start = TextView(this).apply {
            text = "Start testing"; textSize = 17f; setTextColor(onAccent); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            background = box(accent, 26); minHeight = dp(52); setPadding(dp(16), dp(14), dp(16), dp(14))
            layoutParams = LinearLayout.LayoutParams(WIDE, SNUG).apply { topMargin = dp(18) }
        }
        col.addView(start)
        start.setOnClickListener {
            val r = repo.text.toString().trim().trim('/')
            if (!Regex("^[\\w.-]+/[\\w.-]+$").matches(r)) {
                status.text = "Type the repository as owner/name, for example me/my-app."; status.visibility = View.VISIBLE
                return@setOnClickListener
            }
            val g = goal.text.toString().trim()
            val a = chosen
            start.isEnabled = false; start.text = "Starting…"; status.visibility = View.GONE
            val id = Server.installId(this)
            Thread {
                val res = Server.watchTestStart(id, a.pkg, if (a.pkg == packageName) "ScreenGuide" else a.name, r, g)
                runOnUiThread {
                    if (!res.ok) {
                        status.text = res.note; status.visibility = View.VISIBLE; start.isEnabled = true; start.text = "Start testing"
                        return@runOnUiThread
                    }
                    sp.edit().putString("test_pkg", a.pkg).putString("test_repo_" + a.pkg, r).apply()
                    Testing.pkg = a.pkg; Testing.app = if (a.pkg == packageName) "ScreenGuide" else a.name
                    Testing.repo = r; Testing.goal = g; Testing.active = true
                    if (res.note.isNotEmpty()) Toast.makeText(this, res.note, Toast.LENGTH_LONG).show()
                    try {
                        when {
                            g.isNotEmpty() -> startActivity(Intent(this, MainActivity::class.java).putExtra("fix_goal", g)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP))
                            a.pkg == packageName -> startActivity(Intent(this, MainActivity::class.java)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP))
                            else -> packageManager.getLaunchIntentForPackage(a.pkg)?.let { startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                        }
                    } catch (_: Exception) {}
                    finish()
                }
            }.start()
        }
        // Past results: every pop-up from a test or a guide on this phone, to read again or send later
        col.addView(label("Past results"))
        val pastBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(pastBox); past = pastBox
        choose(chosen)
        setContentView(ScrollView(this).apply { setBackgroundColor(bgc); addView(col) })
    }

    override fun onResume() { super.onResume(); showPast() }

    private fun showPast() {
        val holder = past ?: return
        holder.removeAllViews()
        val all = Results.list(this)
        if (all.isEmpty()) {
            holder.addView(TextView(this).apply {
                text = "None yet. After each test or guide, the list in the pop-up is kept here, even if you tap Don\u2019t allow."
                textSize = 14.5f; setTextColor(muted)
            })
            return
        }
        val fmt = java.text.DateFormat.getDateTimeInstance(java.text.DateFormat.MEDIUM, java.text.DateFormat.SHORT)
        all.forEach { r ->
            holder.addView(LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; background = box(soft, 14); setPadding(dp(14), dp(10), dp(14), dp(10)); minimumHeight = dp(48)
                layoutParams = LinearLayout.LayoutParams(WIDE, SNUG).apply { bottomMargin = dp(6) }
                addView(TextView(context).apply { text = r.title; textSize = 15.5f; typeface = Typeface.DEFAULT_BOLD; setTextColor(ink) })
                addView(TextView(context).apply {
                    text = listOf(fmt.format(java.util.Date(r.id)), Results.summary(r.problems), if (r.sent) "Sent" else "Not sent")
                        .filter { it.isNotEmpty() }.joinToString(" \u00B7 ")
                    textSize = 13.5f; setTextColor(if (r.sent) muted else accent); setPadding(0, dp(2), 0, 0)
                })
                setOnClickListener { startActivity(Intent(this@TestActivity, WatchActivity::class.java).putExtra("result_id", r.id)) }
            })
        }
    }
}
