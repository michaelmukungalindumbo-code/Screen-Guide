package zm.screenguide

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

// Past results (v0.62): the pop-up's list must come back exactly as it was, so it can be read again and sent later.
class ResultsTest {
    private fun problems() = JSONArray()
        .put(JSONObject().put("id", "a1").put("title", "Step 2 repeated step 1").put("what", "w").put("fix", "f").put("kind", "problem"))
        .put(JSONObject().put("id", "b2").put("title", "Change: Make the pill smaller").put("what", "w").put("fix", "f").put("kind", "change"))

    @Test fun keepsEverythingNeededToSendLater() {
        val saved = JSONObject().put("data", "{\"s\":1}").put("sig", "ab12").toString()
        val back = Results.decode(Results.encode(SavedResult(1762090000000L, "Test of ScreenGuide: Scan a document", problems(), saved, false)))!!
        assertEquals(1762090000000L, back.id)
        assertEquals("Test of ScreenGuide: Scan a document", back.title)
        assertEquals("Change: Make the pill smaller", back.problems.getJSONObject(1).getString("title"))
        assertEquals("change", back.problems.getJSONObject(1).getString("kind"))
        assertEquals(saved, back.saved)
        assertEquals(false, back.sent)
    }

    @Test fun damagedFileIsSkipped() {
        assertNull(Results.decode("not json"))
        assertNull(Results.decode("{\"id\": 5}"))
    }

    @Test fun picturesComeBackInOrder() {
        val shots = listOf(1 to "AAAA", 2 to "BBBB", 101 to "CCCC")
        assertEquals(shots, Results.decodeShots(Results.encodeShots(shots)))
        assertTrue(Results.decodeShots("[{\"n\":0,\"jpg\":\"x\"},{\"n\":3,\"jpg\":\"\"}]").isEmpty())
        assertTrue(Results.decodeShots("oops").isEmpty())
    }

    @Test fun onlyTheNewestTenStay() {
        val ids = (1L..13L).shuffled()
        assertEquals(listOf(3L, 2L, 1L), Results.toDrop(ids))
        assertTrue(Results.toDrop((1L..10L).toList()).isEmpty())
    }

    @Test fun summaryCountsEachKind() {
        assertEquals("1 problem · 1 change", Results.summary(problems()))
        val three = JSONArray().put(JSONObject().put("kind", "problem")).put(JSONObject().put("kind", "problem")).put(JSONObject().put("kind", "idea"))
        assertEquals("2 problems · 1 idea", Results.summary(three))
    }
}
