package zm.screenguide

// tests first: not built yet
class ReadTile {
    companion object {
        const val EXTRA = "read_tile"
        fun tap(on: Boolean, serviceOn: Boolean, agreed: Boolean): String = ""
        fun lit(on: Boolean, serviceOn: Boolean) = false
    }
}
