package zm.screenguide

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection

object Server {
    const val URL = "https://screen-guide-server.onrender.com/ask"
    const val TOKEN = "screenguide_sec_9841273560_xyz"

    val configured get() = !URL.contains("YOUR-SERVER")
    private fun base() = URL.removeSuffix("/ask")
    val privacyUrl get() = base() + "/privacy"

    // The person's plan pass (from a code). Empty means the free plan.
    @Volatile var pass = ""
    // Set when the person is signed in to their ScreenGuide account. Empty means no account (or incognito).
    @Volatile var session = ""

    // One anonymous id per install. Created on first use, wherever that happens.
    fun installId(c: android.content.Context): String {
        val p = c.getSharedPreferences("sg", android.content.Context.MODE_PRIVATE)
        return p.getString("id", null) ?: java.util.UUID.randomUUID().toString().also { p.edit().putString("id", it).apply() }
    }

    // The free host sleeps after 15 quiet minutes and then needs up to a minute for its first answer. A quiet
    // request wakes it early: when the app opens and when a Smart guide starts. Nothing personal is sent.
    @Volatile private var wokeAt = 0L
    fun wake() {
        if (!configured) return
        val now = System.currentTimeMillis()
        if (now - wokeAt < 4 * 60_000L) return
        wokeAt = now
        Thread { try { (java.net.URL(base() + "/health").openConnection() as HttpURLConnection).apply { connectTimeout = 10000; readTimeout = 60000 }.responseCode } catch (e: Exception) {} }.start()
    }

    private fun post(path: String, body: JSONObject, installId: String): Pair<Int, String> = request("POST", path, body, installId)

    private fun request(method: String, path: String, body: JSONObject?, installId: String): Pair<Int, String> {
        val c = (java.net.URL(base() + path).openConnection() as HttpURLConnection).apply {
            requestMethod = method; connectTimeout = 15000; readTimeout = 60000; doOutput = body != null
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("X-App-Token", TOKEN)
            setRequestProperty("X-Install-Id", installId)
            if (pass.isNotEmpty()) setRequestProperty("X-Pass", pass)
            if (session.isNotEmpty()) setRequestProperty("X-Session", session)
        }
        if (body != null) c.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = c.responseCode
        val text = ((if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.readText()) ?: ""
        return Pair(code, text)
    }

    // ---- Accounts: sign in with Google ----
    private fun detail(text: String, fallback: String) = try { JSONObject(text).optString("detail", fallback) } catch (e: Exception) { fallback }

    // The Google sign-in client id, from our server (so it can be set on Render without a new app). Empty if sign-in is off.
    fun googleClientId(): String = try {
        val c = (java.net.URL(base() + "/config").openConnection() as HttpURLConnection).apply { connectTimeout = 15000; readTimeout = 60000 }
        if (c.responseCode in 200..299) JSONObject(c.inputStream.bufferedReader().readText()).optString("google_client_id", "") else ""
    } catch (e: Exception) { "" }

    class Reply(val ok: Boolean, val json: JSONObject?, val message: String)

    fun signIn(idToken: String, installId: String): Reply = try {
        val (code, text) = post("/auth/google", JSONObject().put("id_token", idToken), installId)
        if (code in 200..299) Reply(true, JSONObject(text), "") else Reply(false, null, detail(text, "Sign-in did not work. Please try again."))
    } catch (e: Exception) { Reply(false, null, "No connection. Please check your internet and try again.") }

    fun me(installId: String): Reply = try {
        val (code, text) = request("GET", "/me", null, installId)
        if (code in 200..299) Reply(true, JSONObject(text), "") else Reply(false, null, detail(text, "") + "|" + code)
    } catch (e: Exception) { Reply(false, null, "offline") }

    fun saveMe(installId: String, profile: JSONObject?, learned: JSONArray?): Boolean = try {
        val b = JSONObject()
        if (profile != null) b.put("profile", profile)
        if (learned != null) b.put("learned", learned)
        request("PUT", "/me", b, installId).first in 200..299
    } catch (e: Exception) { false }

    fun deleteMe(installId: String): Boolean = try { post("/me/delete", JSONObject(), installId).first in 200..299 } catch (e: Exception) { false }

    // The last thing that went wrong talking to the server, in plain technical words, for the TEST card and debug copy.
    @Volatile var lastProblem = ""

    // What the person sees when the server says no. Never raw server words like "Not Found".
    private fun problem(code: Int, text: String, path: String): String {
        val detail = try { JSONObject(text).optString("detail", "") } catch (e: Exception) { "" }
        lastProblem = "Server answered $code on $path" + (if (detail.isNotEmpty()) ": " + detail.take(80) else "")
        return when {
            code == 404 -> "The helper is being updated right now. Quick tasks still work. Please try again later."
            code == 401 -> "This copy of ScreenGuide needs updating before it can use the helper."
            code == 429 || code == 413 -> detail.ifEmpty { "Please wait a minute and try again." }   // limits: the server explains
            code in 500..599 -> if (detail.isNotEmpty() && !detail.equals("Internal Server Error", true)) detail
                                else "The helper is busy. Please try again in a minute."
            else -> if (detail.isNotEmpty() && detail.length > 12) detail else "Sorry, I could not answer that. Please try again."
        }
    }

    // (worked, text, kind) where kind is "guide" or "answer". Only the typed question and language are sent.
    class Asked(val ok: Boolean, val text: String, val kind: String, val needsApps: Boolean = false, val goal: String = "", val plan: List<String> = emptyList(), val left: Int = -1)

    private fun list(a: JSONArray?): List<String> = if (a == null) emptyList() else (0 until a.length()).map { a.optString(it) }.filter { it.isNotBlank() }

    fun ask(question: String, lang: String, installId: String, images: List<String> = emptyList(), history: List<String> = emptyList(), fresh: Boolean = false): Asked = try {
        val (code, text) = post("/ask", JSONObject().put("question", question).put("lang", lang).put("images", JSONArray(images))
            .put("history", JSONArray(history)).put("fresh", fresh), installId)
        if (code in 200..299) {
            val j = JSONObject(text)
            Asked(true, j.getString("answer"), j.optString("kind", "answer"), j.optBoolean("needs_apps", false), j.optString("goal", ""), list(j.optJSONArray("plan")), j.optInt("left", -1))
        }
        else Asked(false, problem(code, text, "/ask"), "answer")
    } catch (e: Exception) {
        lastProblem = "No connection (/ask): " + (e.javaClass.simpleName)
        Asked(false, "No connection. Please check your internet and try again.", "answer")
    }

    // x and y are set only when a screen picture was sent and the thing to tap has no words: fractions of the screen.
    // lookFor: not on screen yet, but further down this list ("Storage"); the phone rings it when it scrolls into view.
    class Next(val label: String?, val say: String, val done: Boolean, val x: Double? = null, val y: Double? = null, val ok: Boolean = true, val lookFor: String? = null)

    // Older servers send words with their [tag]; drop it so the ring can find the word on screen.
    fun clean(label: String?): String? = label?.replace(Regex("\\s*\\[(switch|tap|text)\\]\\s*$"), "")?.trim()?.ifEmpty { null }
    private fun frac(j: JSONObject, k: String): Double? = if (j.isNull(k)) null else j.optDouble(k).takeIf { !it.isNaN() && it in 0.0..1.0 }

    // Smart guide: sends the goal and the words on screen (never passwords or banking apps). Returns the next step.
    fun next(goal: String, lang: String, installId: String, labels: List<String>, history: List<String>, stuck: Boolean = false, apps: List<String> = emptyList(), note: String = "", plan: List<String> = emptyList(), image: String = "", level: String = ""): Next = try {
        val body = JSONObject().put("goal", goal).put("lang", lang).put("labels", JSONArray(labels)).put("history", JSONArray(history)).put("stuck", stuck).put("apps", JSONArray(apps)).put("note", note).put("plan", JSONArray(plan)).put("image", image).put("level", level)
        val (code, text) = post("/next", body, installId)
        if (code in 200..299) {
            val j = JSONObject(text)
            Next(clean(if (j.isNull("label")) null else j.getString("label")), j.optString("say", ""), j.optBoolean("done"), frac(j, "x"), frac(j, "y"),
                lookFor = if (!j.has("look_for") || j.isNull("look_for")) null else j.optString("look_for").trim().ifEmpty { null })
        }
        else Next(null, problem(code, text, "/next"), false, ok = false)
    } catch (e: Exception) { lastProblem = "No connection (/next): " + e.javaClass.simpleName; Next(null, "No connection. Please check your internet.", false, ok = false) }

    // ---- Plans, guides from the server, and guide events ----
    class Redeemed(val ok: Boolean, val message: String, val pass: String = "", val expires: Long = 0, val weeks: Int = 0)

    fun redeem(code: String, installId: String): Redeemed = try {
        val (status, text) = post("/redeem", JSONObject().put("code", code), installId)
        val j = JSONObject(text)
        if (status in 200..299) Redeemed(true, "", j.getString("pass"), j.optLong("expires"), j.optInt("weeks"))
        else Redeemed(false, j.optString("detail", "That code did not work."))
    } catch (e: Exception) { Redeemed(false, "No connection. Please check your internet and try again.") }

    // Guides kept on the server, so they can be fixed or added without a new app. Returns the raw text, or null.
    fun guides(): String? = try {
        val c = (java.net.URL(base() + "/guides").openConnection() as HttpURLConnection).apply {
            connectTimeout = 15000; readTimeout = 60000
            setRequestProperty("X-App-Token", TOKEN)
        }
        if (c.responseCode in 200..299) c.inputStream.bufferedReader().readText() else null
    } catch (e: Exception) { null }

    // Only the guide's name ("wifi", "ai", "find") and what happened. Never what is on the screen.
    // With no internet the event waits on the phone and is sent later.
    private val qLock = Any()
    private fun prefs(c: android.content.Context) = c.getSharedPreferences("sg", android.content.Context.MODE_PRIVATE)
    private fun send(event: String, guide: String, installId: String): Boolean = try {
        post("/event", JSONObject().put("event", event).put("guide", guide), installId).first in 200..299
    } catch (e: Exception) { false }

    private fun queue(c: android.content.Context, event: String, guide: String) = synchronized(qLock) {
        val arr = try { JSONArray(prefs(c).getString("events", "[]")) } catch (e: Exception) { JSONArray() }
        if (arr.length() < 30) arr.put(JSONObject().put("e", event).put("g", guide))
        prefs(c).edit().putString("events", arr.toString()).apply()
    }

    fun event(c: android.content.Context, event: String, guide: String) {
        if (!configured) return
        val app = c.applicationContext
        val id = installId(app)
        Thread { if (send(event, guide, id)) drain(app, id) else queue(app, event, guide) }.start()
    }

    // Thumbs up or down on an answer, so the helper can be improved. Numbers are removed on the server.
    fun feedback(c: android.content.Context, rating: String, question: String, answer: String) {
        if (!configured) return
        val id = installId(c.applicationContext)
        Thread {
            try { post("/feedback", JSONObject().put("rating", rating).put("question", question.take(300)).put("answer", answer.take(600)), id) }
            catch (e: Exception) {}
        }.start()
    }

    // Send what waited while the phone was offline.
    fun flush(c: android.content.Context) {
        if (!configured) return
        val app = c.applicationContext
        Thread { drain(app, installId(app)) }.start()
    }

    private fun drain(c: android.content.Context, id: String) {
        val text = synchronized(qLock) {
            val t = prefs(c).getString("events", null)
            prefs(c).edit().remove("events").apply()
            t
        } ?: return
        val arr = try { JSONArray(text) } catch (e: Exception) { return }
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            if (!send(o.optString("e"), o.optString("g"), id)) {
                for (j in i until arr.length()) arr.optJSONObject(j)?.let { queue(c, it.optString("e"), it.optString("g")) }
                return
            }
        }
    }
}
