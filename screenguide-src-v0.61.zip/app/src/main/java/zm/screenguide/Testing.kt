package zm.screenguide

// Developer phones: "Test an app". ScreenGuide watches one app's screens (with a guide for a goal, or without) and spots
// problems by itself. No code is added to the app under test. The rules here are plain functions, so TestingTest can
// check them on every build.
object Testing {
    @Volatile var active = false
    @Volatile var pkg = ""
    @Volatile var app = ""
    @Volatile var repo = ""
    @Volatile var goal = ""

    // One thing on the screen, as ScreenGuide reads it. labelled: it, or something inside it, has words.
    class Part(val text: String, val clickable: Boolean, val editable: Boolean, val progress: Boolean,
               val wDp: Int, val hDp: Int, val labelled: Boolean)
    class Found(val kind: String, val detail: String)

    // Short messages that say something went wrong. Long text is an article or a message about errors, not an error.
    private val errorWords = Regex("(?i)(something went wrong|an error (has )?occurred|\\berror\\b|\\bfailed\\b|failure|try again|" +
        "no internet|no connection|you are offline|unable to|could not|couldn.t|not found|exception|\\bnull\\b|\\bundefined\\b|" +
        "\\bnan\\b|timed out|timeout|server error|bad request|\\b(400|401|403|404|500|502|503)\\b)")

    fun errorText(texts: List<String>): String? =
        texts.map { it.trim() }.firstOrNull { it.length in 4..140 && errorWords.containsMatchIn(it) }

    // What is wrong with this screen, from its parts alone: an error message, buttons with no name, buttons too small.
    fun look(parts: List<Part>): List<Found> {
        val out = ArrayList<Found>()
        errorText(parts.map { it.text })?.let { out.add(Found("error_text", it.take(90))) }
        val taps = parts.filter { it.clickable && !it.editable && it.wDp >= 8 && it.hDp >= 8 }
        val unnamed = taps.count { !it.labelled }
        if (unnamed > 0) out.add(Found("unlabeled", "$unnamed"))
        val small = taps.count { it.wDp < 32 || it.hDp < 32 }
        if (small > 0) out.add(Found("small_target", "$small"))
        return out
    }

    // Android's own message about the app under test: "Zexam keeps stopping", "Zexam isn't responding".
    fun systemMessage(texts: List<String>, app: String): Found? {
        if (app.isBlank()) return null
        val t = texts.joinToString(" | ")
        val a = Regex.escape(app)
        if (Regex("(?i)$a (keeps stopping|has stopped)").containsMatchIn(t)) return Found("crash", "$app keeps stopping")
        if (Regex("(?i)$a (isn.t responding|is not responding)").containsMatchIn(t)) return Found("freeze", "$app isn't responding")
        return null
    }

    // Taps that change nothing: the same thing tapped 3 times within 4 seconds while the screen stays the same.
    class TapWatch {
        private val taps = ArrayList<Pair<String, Long>>()
        private var screen = ""
        fun tap(key: String, onScreen: String, now: Long): Boolean {
            if (onScreen != screen) { screen = onScreen; taps.clear() }
            taps.add(key to now)
            taps.removeAll { now - it.second > 4000 }
            if (taps.count { it.first == key } >= 3) { taps.clear(); return true }
            return false
        }
        fun screenChanged(onScreen: String) { if (onScreen != screen) { screen = onScreen; taps.clear() } }
    }

    // A loading sign that stays: reported once it has been there for 8 seconds, then again only if it stays 8 more.
    class Loading {
        private var since = -1L
        fun seen(showing: Boolean, now: Long): Int? {
            if (!showing) { since = -1L; return null }
            if (since < 0L) { since = now; return null }
            val secs = ((now - since) / 1000).toInt()
            if (secs >= 8) { since = now; return secs }
            return null
        }
    }
}
