package zm.screenguide

// "Looking at your screen…" after Help belongs to the guide that asked. 4 Nov: Help, then Stop while the answer was still
// coming. The words came back every half second over the "Why did you stop?" card, until the answer came.
object Waiting {
    fun keepShowing(thinking: Boolean, askedBy: Any?, active: Any?): Boolean = thinking
}
