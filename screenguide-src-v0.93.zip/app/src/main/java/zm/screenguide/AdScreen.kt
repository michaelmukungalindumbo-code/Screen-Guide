package zm.screenguide

// v0.93 tests first: not built yet
object AdScreen {
    fun covers(labels: List<String>): Boolean = false
    fun skipButton(labels: List<String>): String? = null
    const val SAY_SKIP = ""
    const val SAY_CLOSE = ""
    const val SAY_WAIT = ""
    fun say(skip: String?): String = ""
}
