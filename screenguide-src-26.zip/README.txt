ScreenGuide (Android, Kotlin). Guides live in app/src/main/assets/guides.json.
Each step lists words the target may show on screen (several, for different phone brands).
Recorded voice: put files named wifi_1_ny.mp3 etc. in app/src/main/res/raw/ (step audio name + _ + language).
