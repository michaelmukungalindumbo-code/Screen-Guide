package zm.screenguide

// Test first: the old behaviour (v0.81), so the new tests fail on GitHub before the fix.
object FindApp {
    enum class Way { TYPE, SEARCH, SCROLL, SWIPE, HOME }
    fun isSearchBox(word: String) = false
    private fun norm(s: String) = s.lowercase().filter { it.isLetterOrDigit() }
    fun isAppList(shown: List<String>, installed: Collection<String>): Boolean =
        shown.any { norm(it) in setOf("allapps", "searchapps", "applibrary", "searchyourapps") } || shown.count { Regex("^[A-Z#]$").matches(it.trim()) } >= 8
    fun way(home: Boolean, appList: Boolean, search: Boolean, typing: Boolean, searched: Boolean): Way = when {
        home && appList -> Way.SCROLL
        home -> Way.SWIPE
        else -> Way.HOME
    }
    fun say(way: Way, app: String, box: String = "Search"): String = when (way) {
        Way.SCROLL -> "Scroll down to find “$app”."
        Way.HOME -> "Press Home, then swipe up to see all your apps."
        else -> "Swipe up to see all your apps."
    }
}
