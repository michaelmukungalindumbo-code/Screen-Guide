package zm.screenguide

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class Step(val match: List<String>, val say: Map<String, String>, val audio: String?, val toggle: Boolean = false, val skipIn: String? = null, val titles: List<String>? = null)
// about: one short line on why it matters ("For when the power goes off"). shade: done in the pull-down panel at the top.
class Guide(val id: String, val title: Map<String, String>, val done: Map<String, String>, val steps: List<Step>, val keywords: List<String>, val doneWhen: String? = null, val hint: Map<String, String>? = null, val by: String? = null,
            val about: Map<String, String>? = null, val shade: Boolean = false)

object Guides {
    var all: List<Guide> = emptyList()
    var active: Guide? = null
    var index = 0
    var lang = "en"
    // Incognito: this session remembers nothing (no saved chat, no learned task, nothing sent to the account).
    @Volatile var incognito = false
    // The Tell me panel is open: the on-screen guide hides everything so nothing covers it.
    @Volatile var chatOpen = false
    // The row last tapped in ScreenGuide's own menus. A guide to its own settings needs it: the lists close as they are
    // tapped, and Android then drops the tap (6 Nov: the guide kept saying "Tap Chat background" on the colour list).
    @Volatile var ownTap: String? = null
    fun setLang(c: Context, l: String) { lang = l; c.getSharedPreferences("sg", Context.MODE_PRIVATE).edit().putString("lang", l).apply() }
    var lastSeen = ""
    // Smart guide: the AI picks the next button from the words on screen.
    var aiGoal = ""
    var aiStep: Step? = null
    var aiAsked = 0
    var aiFp = 0
    var aiStuck = false
    // Developer phones: the person tapped what the last step pointed at (the watcher notices if the same step comes back)
    @Volatile var aiTapped = false
    var aiNeedsApps = false
    var aiPlan: List<String> = emptyList()
    var aiThinking = false
    // What the "Tell me why" chat needs to know about the screen the person is stuck on.
    var chatLabels: List<String> = emptyList()
    var chatGoal = ""
    var chatHistory: List<String> = emptyList()
    var chatPkg = ""
    var chatSet: Set<String> = emptySet()
    var aiPkg = ""
    var aiLabels: Set<String> = emptySet()
    var aiLast = 0L
    var aiBusy = false
    val aiHistory = ArrayList<String>()
    // The app the task happens in. Getting into it is done like a built-in guide: no AI, no waiting.
    var aiApp: String? = null
    var aiAppPkg: String? = null
    var aiJustOpen = false
    var aiInApp = false
    // The buttons the person really tapped, in order. Saved when the task is done, so next time it runs like a built-in guide.
    val aiTrail = ArrayList<Step>()
    fun aiReset(goal: String) {
        Server.wake()   // wake the server now, while the person opens the app; the first AI step is then quick
        aiGoal = goal; aiStep = null; aiAsked = 0; aiFp = 0; aiStuck = false; aiTapped = false; aiThinking = false; aiPlan = emptyList(); aiPkg = ""
        aiLabels = emptySet(); aiLast = 0L; aiBusy = false; aiHistory.clear()
        aiApp = null; aiAppPkg = null; aiJustOpen = false; aiInApp = false; aiTrail.clear()
    }

    // Banking, money and wallet apps: ScreenGuide never works in them and never sends their names.
    val blockedApps = Match.moneyApps   // one list: never guided, never offered for installing

    // Names of the person's apps for the helper: never banking or money apps, never ScreenGuide itself.
    fun installedNames(c: Context): List<String> = try {
        val pm = c.packageManager
        pm.queryIntentActivities(android.content.Intent(android.content.Intent.ACTION_MAIN).addCategory(android.content.Intent.CATEGORY_LAUNCHER), 0)
            .filter { ri -> val n = ri.loadLabel(pm).toString(); ri.activityInfo.packageName != c.packageName &&
                blockedApps.none { ri.activityInfo.packageName.contains(it, true) || n.contains(it, true) } }
            .map { it.loadLabel(pm).toString().trim() }
            .filter { it.isNotEmpty() && it.length <= 40 }
            .distinct().sorted().take(120)
    } catch (e: Exception) { emptyList() }

    private val filler = setOf("open", "opening", "use", "using", "start", "launch", "find", "go", "to", "the", "a", "an", "app", "application",
        "i", "want", "need", "it", "this", "that", "my", "on", "please", "how", "do", "can", "me", "show", "where", "is", "get", "into", "in")

    // The installed app a goal is about ("Open the YouTube app", "I want to use it (about: What is YouTube...)"),
    // as (name, package, just open it?). The earliest name mentioned wins, so the person's own words beat the helper's.
    fun appFor(c: Context, goal: String): Triple<String, String, Boolean>? {
        val pm = c.packageManager
        val apps = try {
            pm.queryIntentActivities(android.content.Intent(android.content.Intent.ACTION_MAIN).addCategory(android.content.Intent.CATEGORY_LAUNCHER), 0)
                .map { it.loadLabel(pm).toString().trim() to it.activityInfo.packageName }
                .filter { (n, p) -> n.length >= 3 && blockedApps.none { b -> p.contains(b, true) || n.contains(b, true) } && p != c.packageName }
        } catch (e: Exception) { return null }
        val best = Match.pickApp(goal, apps)   // the tested rules: plain words, "Phone" only for calls, stores for installing
        val (name, pkg) = best ?: return null
        val base = goal.substringBefore("(about:").lowercase()
        val nameWords = name.lowercase().split(Regex("\\W+")).toSet()
        val rest = base.split(Regex("\\W+")).filter { it.isNotBlank() && it !in filler && it !in nameWords }
        return Triple(name, pkg, rest.isEmpty())
    }
    // The chat found a next step: continue the guide from it (built-in guides become Smart guides).
    fun adopt(label: String?, say: String, lang: String) {
        val g = active ?: return
        if (g.id != "ai") { aiReset(chatGoal); active = Guide("ai", g.title, g.done, emptyList(), emptyList()) }
        aiStep = Step(if (label != null) listOf(label) else emptyList(), mapOf(lang to say), null)
        if (!aiInApp) aiApp = null   // the chat's answer takes over from the app-finding stage
        aiPkg = chatPkg; aiLabels = chatSet; aiLast = System.currentTimeMillis(); aiBusy = false; aiThinking = false
    }
    val seen = LinkedHashMap<String, String>()   // last screen text per app, for the debug copy

    // "I do, we do, you do": after a task is done once, the person can try it alone. No ring at first; Help (or a
    // few quiet seconds) brings the ring back. Doing it with no help at all earns a star.
    @Volatile var practice = false
    @Volatile var practiceHelped = false

    fun step(): Step? = active?.steps?.getOrNull(index)

    private fun map(o: JSONObject) = o.keys().asSequence().associateWith { o.getString(it) }
    private fun strings(a: JSONArray?) = if (a == null) emptyList() else (0 until a.length()).map { a.getString(it) }

    private var builtIn: List<Guide> = emptyList()

    // A broken guide is skipped, never allowed to crash the app.
    private fun parse(arr: JSONArray): List<Guide> = (0 until arr.length()).mapNotNull { i ->
        try {
            val g = arr.getJSONObject(i)
            val st = g.getJSONArray("steps")
            val steps = (0 until st.length()).map { j ->
                val o = st.getJSONObject(j)
                Step(strings(o.getJSONArray("match")), map(o.getJSONObject("say")), o.optString("audio").ifEmpty { null }, o.optBoolean("toggle"), o.optString("skipIn").ifEmpty { null }, o.optJSONArray("titles")?.let { strings(it) })
            }
            if (steps.isEmpty()) null
            else Guide(g.getString("id"), map(g.getJSONObject("title")), map(g.getJSONObject("done")), steps, strings(g.optJSONArray("keywords")),
                g.optString("doneWhen").ifEmpty { null }, null, g.optString("by").ifEmpty { null },
                g.optJSONObject("about")?.let { map(it) }, g.optBoolean("shade"))
        } catch (e: Exception) { null }
    }

    fun load(c: Context) {
        lang = c.getSharedPreferences("sg", Context.MODE_PRIVATE).getString("lang", lang) ?: lang   // remembered between visits
        if (all.isNotEmpty()) return
        builtIn = parse(JSONArray(c.assets.open("guides.json").bufferedReader().readText()))
        all = builtIn
        c.getSharedPreferences("sg", Context.MODE_PRIVATE).getString("remote_guides", null)?.let { merge(it) }
    }

    // Guides from the server replace built-in ones with the same id, or are added after them.
    private fun merge(text: String): Boolean = try {
        val t = text.trim()
        val arr = if (t.startsWith("[")) JSONArray(t) else JSONObject(t).optJSONArray("guides") ?: JSONArray()
        val remote = parse(arr)
        if (remote.isEmpty()) false
        else {
            val byId = LinkedHashMap<String, Guide>()
            builtIn.forEach { byId[it.id] = it }
            remote.forEach { byId[it.id] = it }
            all = byId.values.toList()
            true
        }
    } catch (e: Exception) { false }

    fun applyRemote(c: Context, text: String): Boolean {
        val prefs = c.getSharedPreferences("sg", Context.MODE_PRIVATE)
        if (prefs.getString("remote_guides", null) == text) return false
        if (!merge(text)) return false
        prefs.edit().putString("remote_guides", text).apply()
        return true
    }
}

// What the person has learned from the built-in tasks: done (a tick), and done alone with no help (a star).
// Kept on this phone only.
object Skills {
    private fun p(c: Context) = c.getSharedPreferences("skills", Context.MODE_PRIVATE)
    fun done(c: Context, id: String) = p(c).getInt("done_$id", 0)
    fun alone(c: Context, id: String) = p(c).getBoolean("alone_$id", false)
    fun record(c: Context, id: String, alone: Boolean) {
        if (Guides.incognito) return
        val e = p(c).edit().putInt("done_$id", done(c, id) + 1)
        if (alone) e.putBoolean("alone_$id", true)
        e.apply()
    }
    fun tasks() = Guides.all.filter { it.id != "find" && it.id != "ai" }
    fun learned(c: Context) = tasks().count { done(c, it.id) > 0 }
    fun stars(c: Context) = tasks().count { alone(c, it.id) }
}

// Tasks this phone has learned: when a Smart guide finishes, the buttons the person tapped are saved here (on this
// phone only), and the same task next time runs like a built-in guide: instant, numbered, a ring on every step.
object Recipes {
    private fun prefs(c: Context) = c.getSharedPreferences("recipes", Context.MODE_PRIVATE)
    private val skip = setOf("the", "a", "an", "my", "i", "want", "to", "how", "do", "please", "app", "it", "on", "in")

    fun key(goal: String): String =
        goal.substringBefore("(about:").lowercase().split(Regex("\\W+")).filter { it.isNotBlank() && it !in skip }.sorted().joinToString(" ")

    private fun all(c: Context): JSONArray = try { JSONArray(prefs(c).getString("all", "[]")) } catch (e: Exception) { JSONArray() }

    fun save(c: Context, goal: String, steps: List<Step>, lastIsSwitch: Boolean) {
        val k = key(goal)
        if (k.isEmpty() || steps.isEmpty() || Guides.incognito) return
        val keep = JSONArray()
        val old = all(c)
        for (i in 0 until old.length()) old.optJSONObject(i)?.let { if (it.optString("k") != k) keep.put(it) }
        val arr = JSONArray()
        steps.forEach { st -> arr.put(JSONObject().put("m", JSONArray(st.match)).put("s", JSONObject(st.say))) }
        keep.put(JSONObject().put("k", k).put("t", goal.substringBefore("(about:").trim().take(60)).put("st", arr).put("sw", lastIsSwitch))
        val trimmed = JSONArray()
        for (i in maxOf(0, keep.length() - 30) until keep.length()) trimmed.put(keep.get(i))
        prefs(c).edit().putString("all", trimmed.toString()).apply()
        Sync.pushLearned(c)
    }

    // For the account: everything learned on this phone, and learned tasks from the account added here.
    fun export(c: Context): JSONArray = all(c)
    fun merge(c: Context, from: JSONArray) {
        val mine = all(c)
        val have = HashSet<String>()
        for (i in 0 until mine.length()) mine.optJSONObject(i)?.optString("k")?.let { have.add(it) }
        var added = false
        for (i in 0 until from.length()) {
            val o = from.optJSONObject(i) ?: continue
            val k = o.optString("k")
            if (k.isNotEmpty() && k !in have && o.optJSONArray("st") != null) { mine.put(o); have.add(k); added = true }
        }
        if (added) {
            val trimmed = JSONArray()
            for (i in maxOf(0, mine.length() - 30) until mine.length()) trimmed.put(mine.get(i))
            prefs(c).edit().putString("all", trimmed.toString()).apply()
        }
    }

    // The steps as JSON, for sharing a taught guide or giving a finished one to the next phone.
    fun stepsJson(steps: List<Step>): JSONArray {
        val arr = JSONArray()
        steps.forEach { st -> arr.put(JSONObject().put("m", JSONArray(st.match)).put("s", JSONObject(st.say))) }
        return arr
    }

    // A guide from the server: shared by someone ({"title", "steps", "sw", "shade", "official"}) or learned by other phones.
    fun fromServer(j: JSONObject, id: String): Guide? {
        val g = guideOf(JSONObject().put("t", j.optString("title")).put("st", j.optJSONArray("steps") ?: return null).put("sw", j.optBoolean("sw"))) ?: return null
        return Guide(id, g.title, g.done, g.steps, emptyList(), if (j.optBoolean("sw")) null else "last_tap", null,
            j.optString("official").ifEmpty { null }, null, j.optBoolean("shade"))
    }

    private fun guideOf(o: JSONObject): Guide? {
        val st = o.optJSONArray("st") ?: return null
        val steps = ArrayList<Step>()
        for (i in 0 until st.length()) {
            val x = st.optJSONObject(i) ?: continue
            val m = x.optJSONArray("m") ?: continue
            val say = x.optJSONObject("s") ?: continue
            val last = i == st.length() - 1
            steps.add(Step((0 until m.length()).map { m.getString(it) }, say.keys().asSequence().associateWith { say.getString(it) }, null,
                toggle = last && o.optBoolean("sw")))
        }
        if (steps.isEmpty()) return null
        val title = o.optString("t")
        return Guide("learned", mapOf("en" to title), mapOf("en" to "Well done!", "ny" to "Zabwino!", "bem" to "Nawamya!"), steps, emptyList(),
            doneWhen = "last_tap")
    }

    fun find(c: Context, goal: String): Guide? {
        val k = key(goal); if (k.isEmpty()) return null
        val a = all(c)
        for (i in a.length() - 1 downTo 0) { val o = a.optJSONObject(i) ?: continue; if (o.optString("k") == k) return guideOf(o) }
        return null
    }

    fun recent(c: Context, n: Int): List<Guide> {
        val a = all(c); val out = ArrayList<Guide>()
        for (i in a.length() - 1 downTo 0) { if (out.size >= n) break; a.optJSONObject(i)?.let { guideOf(it) }?.let { out.add(it) } }
        return out
    }

    fun forget(c: Context, title: String) {
        val a = all(c); val keep = JSONArray()
        for (i in 0 until a.length()) a.optJSONObject(i)?.let { if (it.optString("t") != title) keep.put(it) }
        prefs(c).edit().putString("all", keep.toString()).apply()
        Sync.pushLearned(c)
    }
}

// Teach: the person does a task once while ScreenGuide writes down the buttons they tap (GuideService). Then they
// check the steps in the app and share them; the other phone replays them with the ring, with no AI.
object Teach {
    @Volatile var on = false
    var title = ""
    val steps = ArrayList<Step>()
    var shade = false          // done in the pull-down panel (the torch)
    var lastSwitch = false
    var skipped = 0            // taps left out: they looked personal (numbers, emails) or were in a money app
    private var typed = ""     // what was typed in a box, said in the next step ("Type “ECZ results”.")

    fun reset(t: String) { title = t; steps.clear(); shade = false; lastSwitch = false; skipped = 0; typed = ""; lastBox = false }

    fun personal(w: String) = Regex("\\d{4,}|@|\\+\\d").containsMatchIn(w)

    fun typedIn(text: String) { typed = text.trim().take(40) }

    // One tap on a word. A switch says "Tap the switch for Wi-Fi". Text typed in a box goes into the box's step
    // ("Tap the box and type “ECZ results”."), or before the next tap when the box itself had no name.
    private var lastBox = false
    fun tap(word: String, isSwitch: Boolean, isBox: Boolean = false): Boolean {
        val w = word.trim().replace(Regex("\\s+"), " ").take(50)
        var before = ""
        if (typed.isNotEmpty() && !personal(typed)) {
            val q = "\u201C$typed\u201D"
            val box = steps.lastOrNull()
            if (box != null && lastBox) steps[steps.size - 1] = Step(box.match, mapOf("en" to "Tap the box and type $q.",
                "ny" to "Dinani bokosi ndipo lembani $q.", "bem" to "Kandeni pa bokosi no kulemba $q."), null)
            else before = q
        }
        typed = ""
        if (w.isEmpty()) return false
        if (personal(w)) { skipped++; return false }
        if (steps.lastOrNull()?.match == listOf(w) && before.isEmpty()) return false
        if (steps.size >= 25) return false
        val q = "\u201C$w\u201D"
        val say = when {
            isSwitch -> mapOf("en" to "Tap the switch for $q.", "ny" to "Dinani switchi ya $q.", "bem" to "Kandeni pa switchi ya $q.")
            before.isNotEmpty() -> mapOf("en" to "Type $before, then tap $q.", "ny" to "Lembani $before, kenako dinani $q.", "bem" to "Lembeni $before, elyo kandeni $q.")
            else -> mapOf("en" to "Tap $q.", "ny" to "Dinani $q.", "bem" to "Kandeni $q.")
        }
        steps.add(Step(listOf(w), say, null, toggle = isSwitch)); lastSwitch = isSwitch; lastBox = isBox
        return true
    }

    fun remove(i: Int) { if (i in steps.indices) steps.removeAt(i) }

    fun guide(): Guide? {
        if (steps.isEmpty()) return null
        val st = steps.mapIndexed { i, s -> Step(s.match, s.say, null, toggle = i == steps.size - 1 && s.toggle) }
        return Guide("taught", mapOf("en" to title), mapOf("en" to "Well done!", "ny" to "Zabwino!", "bem" to "Nawamya!"), st, emptyList(),
            if (st.last().toggle) null else "last_tap", null, null, null, shade)
    }
}

// Live help: someone the person trusts opens a link and points at this phone's screen (GuideService). Never taps.
object Live {
    @Volatile var id: String? = null
    @Volatile var key = ""
    @Volatile var url = ""
    @Volatile var helper = false
    @Volatile var lastPoint = 0
    @Volatile var started = 0L
    fun stop() { id = null; key = ""; url = ""; helper = false; lastPoint = 0 }
}

// Real voices: the fixed instructions recorded by a person (on this phone, or shared by ScreenGuide for everyone).
// A prefix line ("Kandeni") is said first, then the phone reads the button's name ("Create new").
object Voices {
    class Clip(val key: String, val text: Map<String, String>, val prefix: Boolean = false)
    val clips = listOf(
        Clip("tap", mapOf("en" to "Tap", "ny" to "Dinani", "bem" to "Kandeni"), prefix = true),
        Clip("switch", mapOf("en" to "Tap the switch for", "ny" to "Dinani switchi ya", "bem" to "Kandeni pa switchi ya"), prefix = true),
        Clip("scroll", mapOf("en" to "Scroll down to find", "ny" to "Pitani pansi kuti mupeze", "bem" to "Ikeni pansi pa kusanga"), prefix = true),
        Clip("tap_here", mapOf("en" to "Tap here.", "ny" to "Dinani apa.", "bem" to "Kandeni apa.")),
        Clip("well_done", mapOf("en" to "Well done!", "ny" to "Zabwino!", "bem" to "Nawamya!")),
        Clip("pull_down", mapOf("en" to "Swipe down from the top of the screen.", "ny" to "Kokani chala pansi kuchokera pamwamba pa sikilini.",
            "bem" to "Kululeni umunwe ukufuma pa muulu wa sikilini.")),
        Clip("pull_right", mapOf("en" to "Swipe down from the top right corner of the screen.", "ny" to "Kokani chala pansi kuchokera pamwamba kumanja kwa sikilini.",
            "bem" to "Kululeni umunwe ukufuma pa muulu ku kulyo kwa sikilini.")),
        Clip("pull_more", mapOf("en" to "Swipe down once more to see all the buttons.", "ny" to "Kokaninso pansi kuti muone mabatani onse.",
            "bem" to "Kululeni na kabili pa kumona amabatani yonse.")),
        Clip("help_hint", mapOf("en" to "Tap Help if you get stuck.", "ny" to "Dinani Help mukavutika.", "bem" to "Kandeni Help nga mwafilwa.")))

    private fun norm(s: String) = s.lowercase().replace(Regex("[^\\p{L}\\p{N} ]"), " ").replace(Regex("\\s+"), " ").trim()

    // Which recording says this sentence, as (clip key, button name to read after it, or null). has: is it recorded?
    fun matchText(lang: String, text: String, has: (String) -> Boolean): Pair<String, String?>? {
        val t = text.trim()
        for (cl in clips) {
            val ct = cl.text[lang] ?: continue
            if (!has(cl.key)) continue
            if (!cl.prefix) { if (norm(t) == norm(ct)) return cl.key to null; continue }
            if (!t.startsWith("$ct ")) continue
            val rest = t.removePrefix(ct).trim().trimEnd('.', '!')
            // A button name: in quotes, or a short name with a capital ("Settings"). Never a sentence in Bemba
            // ("Kandeni ukupyunga Wi-Fi" is read whole by the phone instead).
            val quoted = Regex("^[\u201C\"](.+)[\u201D\"]$").find(rest)?.groupValues?.get(1)
            val name = quoted ?: rest.takeIf { r -> r.isNotEmpty() && r.split(" ").size <= 3 && r.first().isUpperCase() }
            if (!name.isNullOrBlank()) return cl.key to name
        }
        return null
    }

    fun mine(c: Context, lang: String, key: String) = java.io.File(c.filesDir, "voice/mine_${lang}_$key.m4a")
    fun pack(c: Context, lang: String, key: String) = java.io.File(c.filesDir, "voice/pack_${lang}_$key.m4a")
    // Your own recording wins over the shared one.
    fun file(c: Context, lang: String, key: String): java.io.File? =
        mine(c, lang, key).takeIf { it.length() > 200 } ?: pack(c, lang, key).takeIf { it.length() > 200 }
    fun match(c: Context, lang: String, text: String): Pair<java.io.File, String?>? {
        val m = matchText(lang, text) { k -> file(c, lang, k) != null } ?: return null
        return (file(c, lang, m.first) ?: return null) to m.second
    }
}

// When the app crashes: keep where in its own code it went wrong (never what was on screen; numbers and emails are
// removed from the message), and send it the next time ScreenGuide opens. Shows in the owner report on the server.
object Crash {
    @Volatile private var installed = false
    fun install(c: Context) {
        if (installed) return
        installed = true
        val app = c.applicationContext
        val before = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try { app.getSharedPreferences("crash", Context.MODE_PRIVATE).edit().putString("trace", text(e)).putString("where", t.name.take(40)).commit() }
            catch (_: Throwable) {}
            before?.uncaughtException(t, e)
        }
    }

    fun clean(msg: String) = msg.replace(Regex("[\\w.+-]+@[\\w-]+\\.[\\w.]+"), "[email]").replace(Regex("\\d{4,}"), "#").take(160)

    // "java.lang.IllegalStateException: ...", then "    at zm.screenguide.GuideService.refresh(GuideService.kt:301)" lines.
    fun text(e: Throwable): String {
        val sb = StringBuilder()
        var x: Throwable? = e
        var depth = 0
        // Down to the first cause: 4 Nov (#26) the report stopped 3 causes deep, before the class that was really missing.
        while (x != null && depth < 8) {
            val msg = clean(x.message ?: "")
            sb.append(if (depth == 0) "" else "Caused by: ").append(x.javaClass.name).append(if (msg.isNotEmpty()) ": $msg" else "").append('\n')
            for (f in x.stackTrace.take(if (depth == 0) 25 else 4))
                sb.append("    at ").append(f.className).append('.').append(f.methodName).append('(').append(f.fileName ?: "?").append(':').append(f.lineNumber).append(")\n")
            x = x.cause; depth++
        }
        return sb.toString().take(6000)
    }

    // A crash that was caught (the app stayed open): kept and sent the same way, so it still reaches the AI fixer.
    fun keep(c: Context, e: Throwable, where: String) {
        try { c.getSharedPreferences("crash", Context.MODE_PRIVATE).edit().putString("trace", text(e)).putString("where", where.take(40)).commit() }
        catch (_: Throwable) {}
        sendPending(c)
    }

    // The next time the app opens: send it, then forget it.
    fun sendPending(c: Context) {
        val p = c.getSharedPreferences("crash", Context.MODE_PRIVATE)
        val trace = p.getString("trace", null) ?: return
        val where = p.getString("where", "") ?: ""
        val version = try { c.packageManager.getPackageInfo(c.packageName, 0).versionName ?: "" } catch (e: Exception) { "" }
        val id = Server.installId(c)
        Thread { if (Server.crash(trace, version, where, id)) p.edit().remove("trace").remove("where").apply() }.start()
    }
}

// Counters kept on the phone only, for the pilot. No screen words, no names.
object Stats {
    private fun prefs(c: android.content.Context) = c.getSharedPreferences("stats", android.content.Context.MODE_PRIVATE)
    fun inc(c: android.content.Context, key: String) { val p = prefs(c); p.edit().putInt(key, p.getInt(key, 0) + 1).apply() }
    // The last few questions that got a thumbs-down, on this phone only, so the pilot can show what to fix.
    fun remember(c: android.content.Context, key: String, text: String) {
        if (Guides.incognito) return
        val p = prefs(c)
        val arr = try { JSONArray(p.getString("r_$key", "[]")) } catch (e: Exception) { JSONArray() }
        arr.put(text.take(80))
        val keep = JSONArray()
        for (i in maxOf(0, arr.length() - 8) until arr.length()) keep.put(arr.getString(i))
        p.edit().putString("r_$key", keep.toString()).apply()
    }
    fun dump(c: android.content.Context): String {
        val p = prefs(c)
        val counts = listOf("questions", "started", "finished", "stopped", "stuck", "ai_steps", "screen_pictures", "thumbs_up", "thumbs_down")
            .joinToString("\n") { "$it: ${p.getInt(it, 0)}" }
        val bad = try { JSONArray(p.getString("r_bad", "[]")) } catch (e: Exception) { JSONArray() }
        if (bad.length() == 0) return counts
        return counts + "\nRecent thumbs-down questions:\n" + (0 until bad.length()).joinToString("\n") { "- " + bad.getString(it) }
    }
}
