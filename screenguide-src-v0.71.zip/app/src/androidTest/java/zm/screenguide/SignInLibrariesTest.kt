package zm.screenguide

import android.content.Context
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

// 4 Nov (#26): tapping "Sign in with Google" closed the app on an Infinix phone. Android's sign-in library could not
// find androidx.activity.ComponentActivity. These check that the parts it needs are inside ScreenGuide itself (not only
// in this test's own files), and that the part that failed can start.
@RunWith(AndroidJUnit4::class)
class SignInLibrariesTest {
    private val ctx = InstrumentationRegistry.getInstrumentation().targetContext

    @Test fun signInPartsAreInTheApp() {
        @Suppress("DEPRECATION")
        val names = dalvik.system.DexFile(ctx.applicationInfo.sourceDir).entries().toList().toHashSet()
        val need = listOf("androidx.activity.ComponentActivity", "androidx.core.app.ComponentActivity", "androidx.lifecycle.LifecycleOwner",
            "androidx.credentials.playservices.CredentialProviderPlayServicesImpl")
        val missing = need.filter { it !in names }
        assertTrue("Missing from the app: $missing (the app has ${names.size} classes)", missing.isEmpty())
    }

    @Test fun signInProviderStarts() {
        val c = Class.forName("androidx.credentials.playservices.CredentialProviderPlayServicesImpl", true, ctx.classLoader)
        c.getConstructor(Context::class.java).newInstance(ctx)
    }
}
