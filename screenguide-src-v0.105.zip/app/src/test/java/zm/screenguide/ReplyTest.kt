package zm.screenguide

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test

// v0.100, the owner (9 Nov): "Long press, and among the options, the reply option to a specific message in the chat...
// something like the WhatsApp message feature."
class ReplyTest {
    private fun src(name: String) = listOf("src/main/java/zm/screenguide/$name", "app/src/main/java/zm/screenguide/$name")
        .map { File(it) }.first { it.exists() }.readText()
    private val answer = Msg(false, "Open Drive, tap the plus, then Scan.", goal = "Scan a document with Drive", plan = listOf("Open Drive", "Tap +", "Tap Scan"))
    private val plain = Msg(false, "A PDF is a document that looks the same on every phone.")
    private val words = setOf("showme", "yes", "ok", "okay", "yesplease")

    @Test fun theQuote() {
        assertEquals("You", Quoted.who(true)); assertEquals("ScreenGuide", Quoted.who(false))
        assertEquals(answer.text, Quoted.of(answer))
        assertEquals(Quoted.KEEP, Quoted.of(Msg(false, "a".repeat(900))).length)                  // a long answer: the start of it
    }

    // The helper is told which message the question is about, as the last line of the conversation it already gets
    @Test fun theHelperIsTold() {
        val asked = Msg(true, "What does that mean?", quote = Quoted.of(plain), quoteMine = false)
        val h = Quoted.history(listOf("User: What is a PDF?", "Helper: " + plain.text), asked)
        assertEquals(3, h.size)
        assertEquals("The user is replying to this earlier Helper message: “${plain.text}”", h.last())
        assertTrue(Quoted.context("x\n\ny  z", true).startsWith("The user is replying to their own earlier message: “x y z”"))
        assertTrue(h.last().length <= 300)                                                          // the server keeps 300 letters a line
        assertTrue(Quoted.context("b".repeat(400), false).length <= 300)
        val base = listOf("User: hello")
        assertSame(base, Quoted.history(base, Msg(true, "no reply here")))                         // not a reply: nothing added
        assertSame(base, Quoted.history(base, null))
    }

    // "Show me" or "yes" as a reply starts that answer's guide, even an older one; anything else is a question
    @Test fun showMeAsAReply() {
        assertSame(answer, Quoted.showable(answer, "Show me", words))
        assertSame(answer, Quoted.showable(answer, "Yes", words))
        assertSame(answer, Quoted.showable(answer, "show me how", words))
        assertNull(Quoted.showable(answer, "Why the plus?", words))
        assertNull(Quoted.showable(plain, "Show me", words))                                       // nothing to show on screen
        assertNull(Quoted.showable(Msg(true, "How do I scan?"), "yes", words))                     // their own message
        assertNull(Quoted.showable(null, "yes", words))
    }

    // Tapping the quote goes to the message it came from
    @Test fun theOriginalIsFound() {
        val msgs = listOf(Msg(true, "How do I scan?"), answer, Msg(true, "What is a PDF?"), plain,
            Msg(true, "Show me", quote = Quoted.of(answer), quoteMine = false))
        assertEquals(1, Quoted.original(msgs, 4, Quoted.of(answer), false))
        assertEquals(0, Quoted.original(msgs, 4, "How do I scan?", true))
        assertEquals(-1, Quoted.original(msgs, 4, "How do I scan?", false))                        // the helper never said that
        assertEquals(-1, Quoted.original(msgs, 4, "Something edited away", true))
        assertEquals(-1, Quoted.original(msgs, 4, "", true))
        assertEquals("How do I scan?", Quoted.about(Msg(true, "open it", quote = "📎 How do I scan?", quoteMine = true)))
        assertNull(Quoted.about(Msg(true, "open it")))
    }

    // The quote is saved with the chat; chats saved before this still open
    @Test fun savedWithTheChat() {
        val c = Conv(7L, "Scan", arrayListOf(Msg(true, "How do I scan?"), answer, Msg(true, "Show me", quote = "Open Drive, tap the plus", quoteMine = false)))
        val back = ChatStore.parse(ChatStore.write(listOf(c)))
        assertEquals(3, back[0].msgs.size)
        assertEquals("Open Drive, tap the plus", back[0].msgs[2].quote); assertFalse(back[0].msgs[2].quoteMine)
        assertNull(back[0].msgs[0].quote)
        assertEquals("Scan a document with Drive", back[0].msgs[1].goal)                           // the rest as before
        val old = """[{"id":1,"title":"Old","s":false,"m":[{"me":true,"t":"hello","g":"","a":false,"p":[],"b":""}]}]"""
        assertNull(ChatStore.parse(old)[0].msgs[0].quote)
        val mine = Conv(8L, "x", arrayListOf(Msg(true, "again", quote = "first", quoteMine = true)))
        assertTrue(ChatStore.parse(ChatStore.write(listOf(mine)))[0].msgs[0].quoteMine)
    }

    @Test fun theWiringIsThere() {
        val m = src("MainActivity.kt")
        assertEquals(2, Regex("Row\\(\"reply\", \"Reply\"\\) \\{ startReply\\(m\\) \\}").findAll(m).count())   // their messages and the helper's
        assertTrue(m.contains("\"Replying to \" + Quoted.who(r.mine)"))                            // above the box
        assertTrue(m.contains("iconBtn(\"close\", \"Stop replying\", mute, 40, 12) { replyTo = null; build() }"))
        assertTrue(m.contains("quote = re?.let { Quoted.of(it) }, quoteMine = re?.mine == true"))  // sent with the question
        assertTrue(m.contains(".let { Quoted.history(it, asked) }"))
        assertTrue(m.contains("onTap { cur?.let { c -> jumpTo(c, m) } }"))                          // tap the quote
        val ask = m.substringAfter("    private fun ask(text: String) {").substringBefore("    private fun openLocal(")
        assertTrue(ask.indexOf("Quoted.showable(re, text, showWords)") in 1 until ask.indexOf("askServer(text.trim(), re = re); return"))
        assertTrue(ask.indexOf("askServer(text.trim(), re = re); return") < ask.indexOf("Guides.offApp(this, text)"))   // never a key-word guide
        assertTrue(m.contains("\"reply\" -> {"))                                                    // its picture
    }
}
