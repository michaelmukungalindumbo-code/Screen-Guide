package zm.screenguide

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

// v0.94, the owner (8 Nov): "How do I receive the response from ScreenGuide even when I'm not on the app's screen, like I
// do when I am using you?"
class NotifyTest {
    private fun src(name: String) = listOf("src/main/$name", "app/src/main/$name").map { File(it) }.first { it.exists() }.readText()

    @Test fun theWordsNeverShowTheAnswer() {
        assertEquals("Your answer is ready. Tap to see it.", Notify.text(true))
        assertEquals("I could not answer just now. Tap to try again.", Notify.text(false))
        val n = src("java/zm/screenguide/Notify.kt")
        assertTrue(n.contains("fun answerReady(c: Context, chatId: Long, ok: Boolean)"))   // no answer text goes in
        assertTrue(n.contains(".setContentText(text(ok))"))
    }

    // Android 13 and newer: asked once; older phones need no asking
    @Test fun askedOnceOnNewPhonesOnly() {
        assertTrue(Notify.needsAsking(33, granted = false, askedBefore = false))
        assertFalse(Notify.needsAsking(33, granted = false, askedBefore = true))
        assertFalse(Notify.needsAsking(34, granted = true, askedBefore = false))
        assertFalse(Notify.needsAsking(30, granted = false, askedBefore = false))
        assertTrue(src("AndroidManifest.xml").contains("<uses-permission android:name=\"android.permission.POST_NOTIFICATIONS\"/>"))
    }

    // Only when ScreenGuide is not on the screen, after the answer is saved; gone when they come back; a tap opens that chat
    @Test fun theWiringIsThere() {
        val m = src("java/zm/screenguide/MainActivity.kt")
        val ask = m.substringAfter("    private fun askServer(").substringBefore("\n    }\n")
        assertTrue(ask.contains("persist(); build()\n                if (!onScreen) Notify.answerReady(this, conv.id, r.ok)"))
        assertTrue(ask.contains("askNotifyOnce()"))
        assertTrue(m.contains("override fun onPause() { onScreen = false; super.onPause() }"))
        assertTrue(m.contains("super.onResume(); onScreen = true; Notify.clear(this)"))
        val intent = m.substringAfter("    private fun handleIntent(i: Intent?) {").substringBefore("\n    }\n")
        assertTrue(intent.contains("val c = convs.firstOrNull { it.id == chat }") && intent.contains("openChat(c)"))
    }
}
