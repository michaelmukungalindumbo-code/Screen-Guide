package zm.screenguide

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

// v0.94, the owner's test (8 Nov, no AI credit, "Open xtheme"):
// - "I have an issue with the 'Sorry, the helper is busy...' being at the top": a small orange line under the question,
//   then a grid of torch and screenshot tasks. "Busy" was not true.
// - The test phone's note: no app named "xtheme" among 47 names. On Infinix, XTheme is part of the home screen.
class ReplyAndFindTest {
    private fun src(name: String) = listOf("src/main/java/zm/screenguide/$name", "app/src/main/java/zm/screenguide/$name")
        .map { File(it) }.first { it.exists() }.readText()

    @Test fun trueAndCalmWords() {
        assertEquals("I can’t reach the helper right now.", Replies.fail(503, "Sorry, the helper is busy. Please try again.", 1))
        assertEquals("The helper isn’t available at the moment. Please try later.", Replies.fail(503, "Sorry, the helper is busy. Please try again.", 2))
        assertEquals(Replies.CANT_REACH, Replies.fail(500, "The helper is busy. Please try again in a minute.", 1))
        // Words that say what to do are kept: today's limit, no internet, resting until tomorrow
        val limit = "You have used today's free questions. Quick tasks still work."
        assertEquals(limit, Replies.fail(429, limit, 3))
        assertEquals("No connection. Please check your internet and try again.", Replies.fail(0, "No connection. Please check your internet and try again.", 2))
        assertEquals("The helper is resting until tomorrow. Quick tasks still work.", Replies.fail(503, "The helper is resting until tomorrow. Quick tasks still work.", 1))
        assertFalse(Replies.CANT_REACH.contains("busy") || Replies.NOT_AVAILABLE.contains("busy"))
    }

    @Test fun whatStillWorksIsSaid() {
        assertEquals("I can’t reach the helper right now. The button above works without it.", Replies.withWayOn(Replies.CANT_REACH, true, false))
        assertEquals("I can’t reach the helper right now.\n\nThis guide works without the helper:", Replies.withWayOn(Replies.CANT_REACH, false, true))
        assertEquals(Replies.CANT_REACH, Replies.withWayOn(Replies.CANT_REACH, false, false))
    }

    // Said as a reply, not an orange line; the torch and screenshot tiles only when nothing above fits, and fewer
    @Test fun aReplyLikeAnyOther() {
        val m = src("MainActivity.kt")
        val ask = m.substringAfter("    private fun askServer(").substringBefore("\n    }\n")
        assertTrue(ask.contains("conv.msgs.add(Msg(false, Replies.withWayOn(Replies.fail(r.code, r.text, failsInRow), hasOffer, local != null), guideId = local?.id))"))
        assertFalse(ask.contains("else note = r.text"))
        assertTrue(m.contains("if (!wayOn) {") && m.contains("grid(col, Skills.tasks().take(4).map { taskTile(it) })"))
        // Try again takes away every reply after the question, and the Open or Find button comes again
        val retry = m.substringAfter("    private fun retry() {").substringBefore("\n    }\n")
        assertTrue(retry.contains("while (c.msgs.lastOrNull()?.mine == false)") && retry.contains("offer = instantOffer(q)"))
        assertTrue(src("Server.kt").contains("limited = AdsGate.limited(code, text), code = code)"))
    }

    // XTheme: looked for by what is written under the icon, then done when they tap it
    @Test fun findByTheNameUnderTheIcon() {
        assertTrue(Match.findableName("xtheme")); assertTrue(Match.findableName("Phone Master"))
        assertFalse(Match.findableName("camera"))                  // a plain word
        assertFalse(Match.findableName("my phone")); assertFalse(Match.findableName("it"))
        assertFalse(Match.findableName("airtel money")); assertFalse(Match.findableName("safe folder"))
        assertFalse(Match.findableName("the settings page for wifi"))
        assertEquals("Xtheme", Match.titleCase("xtheme"))
        assertTrue(FindApp.sameName("XTheme", "Xtheme")); assertTrue(FindApp.sameName("XTheme, App", "Xtheme"))
        assertFalse(FindApp.sameName("Themes", "Xtheme"))
        val m = src("MainActivity.kt")
        assertTrue(m.contains("return Msg(false, \"I can look for \\u201C\$name\\u201D among your apps.\", guideId = \"find:\$name\")"))
        assertTrue(m.contains("else if (finds != null) addView(primary(\"Find \$finds\") { openByName(finds) })"))
        val byName = m.substringAfter("    private fun openByName(name: String) {").substringBefore("\n    }\n")
        assertTrue(byName.contains("Guides.aiApp = name; Guides.aiAppPkg = \"\"; Guides.aiJustOpen = true"))
        val g = src("GuideService.kt")
        assertTrue(g.contains("if (clicked && nameTapped(e)) return"))
        assertTrue(g.contains("if (hidden && hiddenOffered != app && appPkg.isNotEmpty())"))   // no package: no "Open" button
    }
}
