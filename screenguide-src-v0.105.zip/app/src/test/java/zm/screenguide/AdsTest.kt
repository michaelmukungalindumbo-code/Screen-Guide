package zm.screenguide

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

// v0.90 (the owner's choice, 7 Nov): rewarded ads, opt-in, only inside ScreenGuide, Google's test ads for now.
class AdsTest {
    private fun src(name: String) = listOf("src/main/$name", "app/src/main/$name").map { File(it) }.first { it.exists() }.readText()

    // Only the free daily limit offers an ad: not "wait a minute", not "very busy today", not Plus's limit
    @Test fun onlyTheFreeDailyLimit() {
        assertTrue(AdsGate.limited(429, "{\"detail\":\"You have used today's free questions. Quick tasks still work. Ask your helper or organisation for a ScreenGuide code for more.\"}"))
        assertTrue(AdsGate.limited(429, "{\"detail\":\"You have used today's free step-by-step help. Quick tasks still work.\"}"))
        assertFalse(AdsGate.limited(429, "{\"detail\":\"Please wait a minute and try again.\"}"))
        assertFalse(AdsGate.limited(429, "{\"detail\":\"The helper is very busy today. Quick tasks still work. Please try again tomorrow.\"}"))
        assertFalse(AdsGate.limited(429, "{\"detail\":\"You have used today's help. It comes back tomorrow.\"}"))   // Plus
        assertFalse(AdsGate.limited(500, "today's free"))
    }

    @Test fun neverForPlusNorAfterTodaysAds() {
        assertTrue(AdsGate.offer(false, -1)); assertTrue(AdsGate.offer(false, 2))
        assertFalse(AdsGate.offer(true, 3)); assertFalse(AdsGate.offer(false, 0))
        val now = 1_000_000_000_000L
        assertEquals(0, AdsGate.known(0, now - 3600_000L, now))           // used up an hour ago
        assertEquals(-1, AdsGate.known(0, now - 25 * 3600_000L, now))     // yesterday: ask the server again
        assertEquals(-1, AdsGate.known(3, 0L, now))                       // never heard
    }

    @Test fun theWordsSayWhatHappens() {
        val o = AdsGate.offerText(5, 20)
        assertTrue(o.contains("5 more questions and 20 more guided steps") && o.contains("about 2 MB") && o.contains("never shows ads during a guide"))
        assertTrue(AdsGate.after(AdsGate.Result.CLOSED, true, 5, 2).contains("no extra help"))
        assertTrue(AdsGate.after(AdsGate.Result.NONE, false, -1, -1).startsWith("No ad is ready"))
        assertEquals("Thank you! You have 5 questions left today.", AdsGate.after(AdsGate.Result.WATCHED, true, 5, 2))
        assertEquals("Thank you! You have 1 question left today.", AdsGate.after(AdsGate.Result.WATCHED, true, 1, 2))
        assertTrue(AdsGate.after(AdsGate.Result.WATCHED, false, -1, -1).contains("after the next ScreenGuide server update"))   // server 0.82
        assertTrue(AdsGate.after(AdsGate.Result.WATCHED, true, 0, 0).contains("comes back tomorrow"))
    }

    // Google's test ids only, until the owner's AdMob app is ready: a real id in a test build could get his account banned
    @Test fun testAdsOnly() {
        assertEquals("ca-app-pub-3940256099942544~3347511713", AdsGate.TEST_APP_ID)
        assertEquals("ca-app-pub-3940256099942544/5224354917", AdsGate.TEST_UNIT)
        assertTrue(src("AndroidManifest.xml").contains("android:name=\"com.google.android.gms.ads.APPLICATION_ID\" android:value=\"${AdsGate.TEST_APP_ID}\""))
        assertTrue(src("java/zm/screenguide/Ads.kt").contains("var unit = AdsGate.TEST_UNIT"))
    }

    @Test fun theWiringIsThere() {
        val ads = src("java/zm/screenguide/Ads.kt")
        assertTrue(ads.contains("setUserId(installId).setCustomData(nonce)"))         // Google tells our server which phone
        assertTrue(ads.contains("MAX_AD_CONTENT_RATING_PG"))                         // family-friendly ads only
        assertTrue(ads.indexOf("shown = true") in 1 until ads.indexOf("ad.show(a)"))
        val m = src("java/zm/screenguide/MainActivity.kt")
        assertTrue(m.contains("if (r.limited) {") && m.contains("offerAd(again = true)"))   // the chat's limit
        assertTrue(m.contains("b.setNeutralButton(\"Watch an ad\")"))                       // Your plan
        assertTrue(m.contains(".setPositiveButton(\"Watch ad\") { _, _ -> watchAd(again) }"))   // only when they choose it
        // Never from the guide on top of another app: the guide only says where more help is
        val g = src("java/zm/screenguide/GuideService.kt")
        assertFalse(g.contains("Ads.watch") || g.contains("RewardedAd"))
        assertTrue(g.contains("if (r.limited) \". Or open ScreenGuide, tap Your plan, and watch a short ad for more.\""))
    }
}
