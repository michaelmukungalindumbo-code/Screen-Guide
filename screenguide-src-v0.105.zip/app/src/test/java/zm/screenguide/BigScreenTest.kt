package zm.screenguide

import java.io.File
import org.json.JSONArray
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

// v0.105, the owner (11 Nov): "I have noticed that you mentioned phones, even the tablet has issues, remember?"
// His tablet: a Samsung Galaxy Tab A with Samsung's older settings.
class BigScreenTest {
    private fun file(p: String) = listOf("src/main/$p", "app/src/main/$p").map { File(it) }.first { it.exists() }.readText()
    private val battery = listOf("Battery", "Battery & Power Saving", "Battery and device care", "Power management", "Device care", "Device maintenance")

    // Since 0.98 a step is done on the page named like it. On Samsung, "Device care" is the page that HOLDS the Battery
    // row: the guide skipped it and said "Scroll down to find Battery Saver". Another of the step's names still to tap: not done.
    @Test fun deviceCareStillHasBatteryToTap() {
        assertFalse(StepNav.onPageOf(listOf("Device care"), battery, listOf("Battery", "Storage", "Memory", "Security")))
        assertFalse(StepNav.onPageOf(listOf("Battery and device care"), battery, listOf("Optimise now", "Battery", "Storage")))
        assertTrue(StepNav.onPageOf(listOf("Battery"), battery, listOf("Power mode", "Battery usage")))            // on Battery's own page: done
        // The Infinix case of 0.98 stays: the slider "Display brightness" is the title's own words, not another name
        val display = listOf("Display", "Display & Brightness", "Display & brightness", "Display and brightness")
        assertTrue(StepNav.onPageOf(listOf("Display & Brightness"), display, listOf("Display brightness", "Font size", "Dark theme")))
        assertTrue(StepNav.onPageOf(listOf("Display"), display, listOf("Font size and style", "Screen zoom")))
        assertFalse(StepNav.onPageOf(listOf("Settings"), display, listOf("Display", "Sound")))
    }

    // Every built-in guide knows Samsung's names for its steps (One UI and the older Samsung Experience)
    @Test fun samsungsNamesInEveryGuide() {
        val arr = JSONArray(file("assets/guides.json"))
        fun names(id: String, step: Int): List<String> {
            val g = (0 until arr.length()).map { arr.getJSONObject(it) }.first { it.getString("id") == id }
            return g.getJSONArray("steps").getJSONObject(step).getJSONArray("match").let { a -> (0 until a.length()).map { a.getString(it) } }
        }
        fun has(id: String, step: Int, vararg n: String) = n.forEach { assertTrue("$id step ${step + 1}: $it", names(id, step).contains(it)) }
        has("torch", 0, "Torch", "Flashlight")
        has("battery_saver", 1, "Device care", "Battery and device care", "Device maintenance", "Battery")
        has("battery_saver", 2, "Power mode", "Power saving mode")
        has("battery_saver", 3, "Medium power saving", "Power saving mode")
        has("data_saver", 1, "Connections"); has("data_saver", 2, "Data usage", "Data saver"); has("data_saver", 3, "Turn on now")
        has("text_size", 1, "Display"); has("text_size", 2, "Font size and style", "Font and screen zoom")
        has("wifi", 1, "Connections"); has("wifi", 3, "Wi-Fi")
        has("bluetooth", 1, "Connections"); has("bluetooth", 2, "Bluetooth")
        has("hotspot", 1, "Connections"); has("hotspot", 2, "Mobile Hotspot and Tethering"); has("hotspot", 3, "Mobile Hotspot")
        has("airplane", 1, "Connections"); has("airplane", 2, "Flight mode")
    }

    // The chat and the guide card keep a readable width on a big screen; a phone stays as it was
    @Test fun readableOnABigScreen() {
        // a phone: 1080 px wide at density 3 (360dp)
        assertEquals(972, Wide.card(1080, 3f)); assertEquals(54, Wide.side(1080, 3f, 18)); assertEquals(864, Wide.bubble(1080, 3f))
        // the tablet upright: 800 px at density 1.33 (600dp): the card is capped, the chat is its usual self
        assertEquals((520 * 1.33f).toInt(), Wide.card(800, 1.33f)); assertEquals((18 * 1.33f).toInt(), Wide.side(800, 1.33f, 18))
        // the tablet on its side: 1280 px (962dp): a 640dp column in the middle
        val side = Wide.side(1280, 1.33f, 18)
        assertEquals((1280 - 2 * side).toDouble(), (640 * 1.33f).toDouble(), 2.0)
        assertEquals((640 * 1.33f * 0.8f).toInt(), Wide.bubble(1280, 1.33f))
        assertTrue(Wide.card(1280, 1.33f) < 1280 * 0.6)
        val m = file("java/zm/screenguide/MainActivity.kt")
        assertTrue(m.contains("setPadding(wideSide(18), dp(4), wideSide(18), dp(16))") && m.contains("setPadding(wideSide(12), dp(6), wideSide(12), dp(8))"))
        assertTrue(m.contains("override fun onConfigurationChanged(c: android.content.res.Configuration) { super.onConfigurationChanged(c); build() }"))
        assertTrue(file("AndroidManifest.xml").contains("android:configChanges=\"orientation|screenSize|screenLayout|smallestScreenSize|keyboardHidden\""))   // turning keeps the chat
        val g = file("java/zm/screenguide/GuideService.kt")
        assertTrue(g.contains("WindowManager.LayoutParams(Wide.card(d.widthPixels, d.density), WindowManager.LayoutParams.WRAP_CONTENT"))
        assertTrue(g.contains("super.onConfigurationChanged(c); labelY = null"))                    // turned: the card is placed afresh
    }

    // Samsung's list of all apps (pages, no A to Z, no heading): its own Search box at the top is the way to an app
    @Test fun samsungsAppList() {
        val launcher = "com.sec.android.app.launcher"
        assertTrue(FindApp.ownSearchOnTop(launcher, launcher, 90, 1280))
        assertFalse(FindApp.ownSearchOnTop("com.google.android.googlequicksearchbox", launcher, 90, 1280))   // Google's bar on a home screen
        assertFalse(FindApp.ownSearchOnTop(launcher, launcher, 1100, 1280))                                  // a search bar at the bottom
        assertFalse(FindApp.ownSearchOnTop(null, launcher, 90, 1280)); assertFalse(FindApp.ownSearchOnTop("", "", 0, 0))
        assertEquals(FindApp.Way.SEARCH, FindApp.way(home = true, appList = true, search = true, typing = false, searched = false))
        val g = file("java/zm/screenguide/GuideService.kt")
        assertEquals(2, Regex("FindApp\\.isAppList\\(\\w+, launcherNames\\(\\)\\) \\|\\| ownSearch\\(searchNode, pkg\\)").findAll(g).count())   // opening apps, and built-in steps
    }

    // The tablet changes of 0.96 and 0.97 are still wired (no torch without a flash, the full quick panel, no Screenshot button)
    @Test fun earlierTabletFixesStillThere() {
        val g = file("java/zm/screenguide/GuideService.kt")
        assertTrue(file("java/zm/screenguide/Guides.kt").contains("!(it.id == \"torch\" && Guides.noTorch)"))
        assertTrue(file("java/zm/screenguide/MainActivity.kt").contains("if (g.id == \"torch\" && Guides.noTorch)"))
        assertTrue(g.contains("Shade.fullyOpen(")); assertTrue(g.contains("if (guide.id == \"screenshot\" && Shade.screenshotTaken("))
        assertEquals("This device has no torch light: its camera has no flash.", Guides.NO_TORCH)
    }
}
