package zm.screenguide

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

// v0.89, 7 Nov (the owner's recording, "Turn on Hotspot", step 3, no AI credit): Help in a built-in guide asked the
// helper, the screen said "Waking up the helper..." and the working guide with its ring was gone. The owner chose: when
// the helper cannot be reached, back to the same guide and step, with its ring, saying so.
class HelpBackTest {
    private val src = listOf("src/main/java/zm/screenguide/GuideService.kt", "app/src/main/java/zm/screenguide/GuideService.kt")
        .map { File(it) }.first { it.exists() }.readText()
    private fun part(from: String, to: String) = src.substringAfter(from).substringBefore(to)

    @Test fun theWordsSayWhatToDo() {
        assertEquals("I can't reach the helper right now. Follow the ring.", StepNav.NO_HELPER)
        assertTrue(StepNav.NO_HELPER_MS in 3000L..10000L)
    }

    // Help remembers the built-in guide and its step before the Smart guide takes over
    @Test fun helpRemembersTheGuide() {
        val stuck = part("    private fun onStuck()", "    private var chatChip")
        val keep = stuck.indexOf("helpFrom = g; helpFromIndex = Guides.index")
        assertTrue(keep > 0 && keep < stuck.indexOf("Guides.active = Guide(\"ai\""))
    }

    // No answer from the helper (an error, or nothing for 65 s): back to that guide. An answer: the Smart guide goes on.
    @Test fun noHelperMeansBackToTheGuide() {
        val reply = part("if (Guides.active !== guide) return@post", "if (r.done) {")
        assertTrue(reply.indexOf("if (!r.ok && backToGuide()) return@post") in 0 until reply.indexOf("Tap Help to try again."))
        assertTrue(reply.contains("if (r.ok) { helpFrom = null; helpAi = null }"))
        val slow = part("if (waited > 65000) {", "This is taking long.")
        assertTrue(slow.contains("if (backToGuide()) return"))
        val back = part("    private fun backToGuide(): Boolean {", "    private fun noted(")
        assertTrue(back.contains("if (ai == null || Guides.active !== ai) return false"))   // only the guide Help left
        assertTrue(back.contains("Guides.active = g; Guides.index = helpFromIndex"))
    }

    // The card and the voice say it with the step, for a few seconds
    @Test fun theCardSaysIt() {
        // v0.99: the step's words (guide.steps[i], or "Tap Make larger" on a phone without a slider) still go through noted()
        assertTrue(src.contains("val st = noted(named(base))"))
        assertTrue(src.contains("else guide.steps[i]\n            val st = noted(named(base))"))
        assertTrue(src.contains("StepNav.NO_HELPER + \"\\n\" + v"))
    }
}
