package zm.screenguide

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

// v0.95, the owner's tests of 0.94 (8 Nov), "Go ahead and update it"
class V95Test {
    private fun src(name: String) = listOf("src/main/java/zm/screenguide/$name", "app/src/main/java/zm/screenguide/$name")
        .map { File(it) }.first { it.exists() }.readText()
    private val g = src("GuideService.kt")
    private val m = src("MainActivity.kt")

    // 1. XTheme opened inside the home screen; the card kept saying "Tap XTheme", then "Swipe up to see all your apps"
    @Test fun anAppFoundByNameIsSeenToOpen() {
        assertTrue(FindApp.leftTheList(0, namedTappable = false, typing = false))      // XTheme's own pages
        assertTrue(FindApp.leftTheList(1, namedTappable = false, typing = false))      // its splash: a title, not a button
        assertFalse(FindApp.leftTheList(12, namedTappable = true, typing = false))     // the app list
        assertFalse(FindApp.leftTheList(0, namedTappable = true, typing = false))      // search results: its icon to tap
        assertFalse(FindApp.leftTheList(0, namedTappable = false, typing = true))      // still typing its name
        val open = g.substringAfter("    private fun openApp(guide").substringBefore("\n    }\n")
        assertTrue(open.contains("if (appPkg.isEmpty() && nameRung) {") && open.contains("FindApp.leftTheList(apps, tappable, typing)"))
        assertTrue(open.contains("nameRung = true"))
    }

    // 2. "Open YouTube Music", "Not now": nothing more; a question still goes to the helper
    @Test fun notNowForOpenJustCloses() {
        val ask = m.substringAfter("    private fun ask(text: String) {").substringBefore("\n    }\n")
        assertTrue(ask.contains("offerTurnOn(n, p, if (Match.openWord(text) != null) null else ({ askServer(text.trim()) }))"))
        assertEquals("youtube music", Match.openWord("Open YouTube Music"))
        assertNull(Match.openWord("How do I use YouTube Music"))
    }

    // 3. Two "Try again" under a failed answer: the button stays, the small arrow goes
    @Test fun oneTryAgain() {
        assertTrue(m.contains("!asked.text.startsWith(\"\\uD83D\\uDCCE\") && !failed)"))
    }

    // 4. "Tap Files" stayed 2 seconds over Files: its own window ends the opening at once
    @Test fun theCardGoesAtOnce() {
        val ev = g.substringAfter("    override fun onAccessibilityEvent(e: AccessibilityEvent) {").substringBefore("\n    }\n")
        assertTrue(ev.contains("e.packageName?.toString() == Guides.aiAppPkg) {") && ev.contains("hideRing(); if (openingDone(guide)) return"))
        assertTrue(g.substringAfter("    private fun openApp(guide").substringBefore("\n    }\n").contains("if (pkg == appPkg) return openingDone(guide)"))
    }

    // 5. Safe folder: Files opened, then its "Safe folder" row is rung, with no helper
    @Test fun safeFolderOneStepFurther() {
        assertEquals("Safe folder", Match.featureRow("Safe folder"))
        assertNull(Match.featureRow("App twin"))                                       // deep in Settings: the helper's job
        assertTrue(m.contains("guideId = pkg?.let { \"open:\$it|\$appName\" + (if (row != null) \"|\$row\" else \"\") })"))
        assertTrue(m.contains("Guides.aiThen = then"))
        val done = g.substringAfter("    private fun openingDone(guide: Guide): Boolean {").substringBefore("\n    }\n")
        assertTrue(done.contains("Guides.active = Guide(\"then\"") && done.contains("\"last_tap\")"))
        assertTrue(src("Guides.kt").contains("aiPath.clear(); aiPathPkg = \"\"; aiThen = null"))
    }

    // 6. The loading message was cut off on the owner's phone
    @Test fun aShorterLoadingMessage() {
        assertEquals("Loading the ad… When it ends, tap the small X at the top right.", AdsGate.LOADING)
        assertTrue(AdsGate.LOADING.length <= 70)
        assertTrue(m.contains("Toast.makeText(this, AdsGate.LOADING, Toast.LENGTH_LONG).show()"))
    }
}
