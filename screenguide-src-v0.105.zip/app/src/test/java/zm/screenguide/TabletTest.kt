package zm.screenguide

import java.io.File
import org.json.JSONArray
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

// v0.96, the owner's tablet (8 Nov, Galaxy Tab A 8.0 2019, Samsung): "Make your battery last" said "Scroll down to find
// Battery" through the whole of Settings. Samsung's older Settings have "Device care", then Battery, then "Power mode".
class TabletTest {
    private fun file(p: String) = listOf("src/main/$p", "app/src/main/$p").map { File(it) }.first { it.exists() }
    private fun st(vararg m: String) = Step(m.toList(), mapOf("en" to "Tap the glowing row."), null)
    private fun g(id: String, vararg steps: Step) = Guide(id, mapOf("en" to id), mapOf("en" to "Well done!"), steps.toList(), listOf(id))

    @Test fun samsungsOlderNamesAreKnown() {
        val arr = JSONArray(file("assets/guides.json").readText())
        val battery = (0 until arr.length()).map { arr.getJSONObject(it) }.first { it.getString("id") == "battery_saver" }.getJSONArray("steps")
        fun names(i: Int) = battery.getJSONObject(i).getJSONArray("match").let { a -> (0 until a.length()).map { a.getString(it) } }
        assertTrue(names(1).contains("Device care") && names(1).contains("Battery"))      // Settings, then Device care, then Battery
        assertTrue(names(2).contains("Power mode"))
        assertTrue(names(3).contains("Medium power saving"))
    }

    // The server's guides (still the old list) no longer wipe out names the app knows; the server can still add its own
    @Test fun theNamesOfBothAreKept() {
        val app = listOf(g("battery_saver", st("Settings"), st("Battery", "Device care"), st("Power saving mode")), g("wifi", st("Wi-Fi")))
        val server = listOf(g("battery_saver", st("Settings"), st("Battery", "Power management"), st("Power saving mode")),
            g("torch", st("Flashlight")))
        val all = Guides.combine(app, server)
        assertEquals(listOf("battery_saver", "wifi", "torch"), all.map { it.id })
        assertEquals(listOf("Battery", "Power management", "Device care"), all[0].steps[1].match)   // the server's first, then the app's
        assertEquals("Battery", all[0].steps[1].match.first())
        // A guide the server changed into other steps is the server's, as it is
        val changed = Guides.combine(app, listOf(g("battery_saver", st("Settings"), st("Battery"))))
        assertEquals(2, changed[0].steps.size)
        assertEquals(listOf("Battery"), changed[0].steps[1].match)
    }

    // No flash on the tablet's camera: no torch task, and asking for it says so
    @Test fun noTorchWhereThereIsNoFlash() {
        assertEquals("This device has no torch light: its camera has no flash.", Guides.NO_TORCH)
        val guides = file("java/zm/screenguide/Guides.kt").readText()
        assertTrue(guides.contains("noTorch = !c.packageManager.hasSystemFeature(android.content.pm.PackageManager.FEATURE_CAMERA_FLASH)"))
        assertTrue(guides.contains("!(it.id == \"torch\" && Guides.noTorch)"))
        val m = file("java/zm/screenguide/MainActivity.kt").readText()
        val start = m.substringAfter("    private fun start(g: Guide, alone: Boolean = false) {").substringBefore("\n    }\n")
        assertTrue(start.indexOf("if (g.id == \"torch\" && Guides.noTorch)") in 0 until start.indexOf("if (needOn"))
        val saved = Guides.all; val was = Guides.noTorch
        try {
            Guides.all = listOf(g("torch", st("Flashlight")), g("wifi", st("Wi-Fi")))
            Guides.noTorch = true; assertEquals(listOf("wifi"), Skills.tasks().map { it.id })
            Guides.noTorch = false; assertEquals(listOf("torch", "wifi"), Skills.tasks().map { it.id })
        } finally { Guides.all = saved; Guides.noTorch = was }
        assertFalse(Guides.NO_TORCH.contains("tochi"))   // English only: no new Nyanja or Bemba words
    }
}
