package zm.screenguide

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

// v0.90 (the owner's list, 7 Nov): the helper is told where the person has been in this guide (server 0.84 <path>), and,
// on every phone, that they tapped what the last step pointed at (server 0.84 known screens).
class BreadcrumbsTest {
    private fun src(name: String) = listOf("src/main/java/zm/screenguide/$name", "app/src/main/java/zm/screenguide/$name")
        .map { File(it) }.first { it.exists() }.readText()

    @Test fun oldestFirstNoRepeats() {
        val p = ArrayList<String>()
        for (n in listOf("Home screen", "Settings", "settings", "Hotspot & Connections", " ", null, "Personal  Hotspot")) Breadcrumbs.add(p, n)
        assertEquals(listOf("Home screen", "Settings", "Hotspot & Connections", "Personal Hotspot"), p)
    }

    @Test fun onlyTheLastFew() {
        val p = ArrayList<String>()
        for (i in 1..20) Breadcrumbs.add(p, "Screen $i")
        assertEquals(Breadcrumbs.MAX, p.size); assertEquals("Screen 20", p.last())
        Breadcrumbs.add(p, "x".repeat(200)); assertEquals(40, p.last().length)
    }

    // A new guide starts a new path (read from the code: aiReset also wakes the real server)
    @Test fun aNewGuideStartsAgain() {
        val reset = src("Guides.kt").substringAfter("fun aiReset(goal: String) {").substringBefore("\n    }\n")
        assertTrue(reset.contains("aiPath.clear(); aiPathPkg = \"\""))
    }

    @Test fun theWiringIsThere() {
        val s = src("Server.kt")
        assertTrue(s.contains("if (tapped) body.put(\"followed\", true)"))             // every phone, not only testers
        assertTrue(s.contains("if (path.isNotEmpty()) body.put(\"path\", JSONArray(path))"))
        val g = src("GuideService.kt")
        assertTrue(g.contains("if (pkg != Guides.aiPathPkg) { Guides.aiPathPkg = pkg; Breadcrumbs.add(Guides.aiPath, screenName(pkg)) }"))
        assertTrue(g.contains("Breadcrumbs.add(Guides.aiPath, st.match.firstOrNull())"))   // the button they tapped
        assertTrue(g.contains("level(), tapped, path)"))
    }
}
