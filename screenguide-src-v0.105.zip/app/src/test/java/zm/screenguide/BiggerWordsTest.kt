package zm.screenguide

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

// v0.99, the owner's phone (8 Nov, Infinix, "Make words bigger" on 0.98). Step 3 worked. Then:
// - on the Font size page, "Drag the dot to the right." had no ring, and a scroll arrow: this phone's page has no standard
//   slider, but a "Make larger" button (the big A);
// - on the list of all apps, step 1 said "Not on this screen? Swipe up to find it", while opening an app points at the
//   phone's Search (the owner's choice, 6 Nov).
class BiggerWordsTest {
    private fun src(name: String) = listOf("src/main/java/zm/screenguide/$name", "app/src/main/java/zm/screenguide/$name")
        .map { File(it) }.first { it.exists() }.readText()

    @Test fun theMakeLargerButton() {
        assertTrue(StepNav.largerButton("Make larger"))           // Infinix's big A, as the test note read it
        assertTrue(StepNav.largerButton("Larger"))
        assertTrue(StepNav.largerButton("Increase font size"))
        assertFalse(StepNav.largerButton("Make smaller"))         // never the small A
        assertFalse(StepNav.largerButton("Font size"))
        assertFalse(StepNav.largerButton("Navigate up"))
        assertFalse(StepNav.largerButton(""))
        assertEquals("Tap “Make larger” to make the words bigger.", StepNav.tapLarger("Make larger"))
    }

    // Only on the Font size page (the slider step's titles), only when there is no slider, and its words say what to tap
    @Test fun theWiringIsThere() {
        val g = src("GuideService.kt")
        val slider = g.substringAfter("if (s.match.firstOrNull() == \"@slider\") {").substringBefore("if (s.toggle) {")
        assertTrue(slider.indexOf("StepNav.largerButton(") > slider.indexOf("contains(\"SeekBar\")"))   // a real slider first
        assertTrue(slider.indexOf("StepNav.largerButton(") > slider.indexOf("if (ts != null)"))         // after the page check
        assertTrue(g.contains("StepNav.tapLarger(matchedText ?: \"Make larger\")"))
        // The slider step (no word to scroll to) never shows the scroll arrow
        assertTrue(g.contains("if (!next.toggle && word != null) showSwipe() else hideSwipe()"))
        assertFalse(g.contains("if (!next.toggle) showSwipe() else hideSwipe()"))
    }

    // A built-in step whose button is not on the list of all apps: "Tap Search, then type Settings." (as opening apps does)
    @Test fun searchForTheSettingsApp() {
        assertEquals(FindApp.Way.SEARCH, FindApp.way(home = true, appList = true, search = true, typing = false, searched = false))
        assertEquals("Tap “Search”, then type Settings.", FindApp.say(FindApp.Way.SEARCH, "Settings"))
        assertEquals(FindApp.Way.TYPE, FindApp.way(home = true, appList = true, search = false, typing = true, searched = true))
        assertEquals(FindApp.Way.SWIPE, FindApp.way(home = true, appList = false, search = false, typing = false, searched = false))
        val g = src("GuideService.kt")
        val lost = g.substringAfter("// Nothing to point at on this screen: never leave the person with nothing.")
            .substringBefore("private fun scrollTo(")
        assertTrue(lost.indexOf("FindApp.say(way, word,") in 1 until lost.indexOf("Not on this screen? Swipe up to find it."))
        assertTrue(lost.contains("if (word != null && (home || searchSaid == word))"))
        assertTrue(g.contains("keysFor = null; searchSaid = \"\""))   // a new guide starts afresh
    }
}
