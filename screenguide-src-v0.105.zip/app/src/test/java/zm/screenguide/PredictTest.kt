package zm.screenguide

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

// v0.103, the owner (10 Nov), "task prediction": as the user is typing, the key words figure out the task before Send.
class PredictTest {
    private fun g(id: String, title: String, vararg k: String) =
        Guide(id, mapOf("en" to title, "ny" to "$title (ny)"), mapOf("en" to "Well done!"), listOf(Step(listOf("Settings"), mapOf("en" to "Tap Settings."), null)), k.toList())
    private val guides = listOf(g("wifi", "Turn on Wi-Fi", "wifi", "wi fi", "wi-fi", "wireless"),
        g("text_size", "Make words bigger", "font size", "bigger words", "make words bigger"),
        g("screenshot", "Take a screenshot", "screenshot", "screen shot"), g("hotspot", "Share your internet", "hotspot", "share internet"))
    private val apps = listOf("WhatsApp" to "com.whatsapp", "YouTube Music" to "com.google.android.apps.youtube.music", "Drive" to "com.google.android.apps.docs",
        "Camera" to "com.cam", "Phone" to "com.dialer", "MTN MoMo" to "com.mtn.momo")
    private fun p(t: String) = Predict.of(t, guides, apps)

    // The words fit a built-in task: Start, before Send
    @Test fun aTaskFromItsKeyWords() {
        val t = p("How do I turn on wifi")!!
        assertEquals("guide", t.kind); assertEquals("wifi", t.id); assertEquals("Start: Turn on Wi-Fi", t.label)
        assertEquals("text_size", p("make words bigger")!!.id)
        assertEquals("screenshot", p("I want to take a screenshot")!!.id)
        assertEquals("Start: Turn on Wi-Fi (ny)", Predict.of("wifi please", guides, apps, "ny")!!.label)   // the title in their language
        // As it is typed: nothing until a key word is whole
        assertNull(p("How")); assertNull(p("How do I")); assertNull(p("How do I turn on wi"))
        assertEquals("wifi", p("How do I turn on wifi")!!.id)
    }

    // The words name an app on this phone: Open
    @Test fun anAppFromItsName() {
        val t = p("Open whatsapp")!!
        assertEquals("open", t.kind); assertEquals("Open WhatsApp", t.label); assertEquals("com.whatsapp", t.id); assertEquals("WhatsApp", t.name)
        assertEquals("com.google.android.apps.youtube.music", p("How do I use YouTube Music")!!.id)   // a key term, however it is asked
        assertEquals("com.whatsapp", p("open watsap")!!.id)                                         // a spelling slip
        assertNull(p("Open TikTok"))                                                                 // not on this phone: the helper's work
    }

    // Never for money, a problem, a part of an app, an app to install, or a bare "yes"
    @Test fun whatIsLeftToTheHelper() {
        assertNull(p("Send money with MTN MoMo")); assertNull(p("how do I withdraw from airtel money"))
        assertNull(p("My wifi is not working")); assertNull(p("Why is my wifi slow"))
        assertNull(p("Open the Safe folder app"))
        assertNull(p("Install TikTok"))
        assertNull(p("yes")); assertNull(p("ok")); assertNull(p("show me"))
        assertNull(p("")); assertNull(p("   ")); assertNull(p("wif"))
        assertNull(p("How do I write a letter to my landlord"))                                      // nothing on the phone fits
        assertNull(p("wifi ".repeat(40)))                                                            // a pasted page is not a task
    }

    // On the phone only: nothing typed is sent before Send
    @Test fun nothingLeavesThePhone() {
        fun src(n: String) = listOf("src/main/java/zm/screenguide/$n", "app/src/main/java/zm/screenguide/$n").map { File(it) }.first { it.exists() }.readText()
        val pr = src("Predict.kt")
        assertFalse(pr.contains("Server.")); assertFalse(pr.contains("java.net")); assertFalse(pr.contains("URL("))
        val m = src("MainActivity.kt")
        val typing = m.substringAfter("        fun predict(text: String) {").substringBefore("        if (typed.isNotBlank()) predict(typed)")
        assertTrue(typing.contains("Predict.of(text, Guides.all, predictApps(), Guides.lang)"))
        assertEquals(listOf("Server.wake()"), Regex("Server\\.\\w+\\([^)]*\\)").findAll(typing).map { it.value }.toList())   // only "wake up", with no words
        assertFalse(typing.contains("askServer(")); assertFalse(typing.contains("Server.ask("))
        val run = m.substringAfter("    private fun runPredicted(task: Predict.Task) {").substringBefore("\n    }\n")
        assertFalse(run.contains("askServer(")); assertTrue(run.contains("start(it)")); assertTrue(run.contains("openLocal("))
        assertTrue(m.contains("if (waiting || editing != null || replyTo != null || attached.isNotEmpty()) null"))
        val wake = src("Server.kt").substringAfter("    fun wake() {").substringBefore("\n    }\n")
        assertTrue(wake.contains("\"/health\"")); assertFalse(wake.contains("outputStream"))          // a bare "are you awake?": nothing is posted
    }
}
