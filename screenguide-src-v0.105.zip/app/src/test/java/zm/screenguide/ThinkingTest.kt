package zm.screenguide

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

// v0.90 (the owner's list, 7 Nov, "thinking mode"): while the helper thinks, the card says what comes next in the plan
// and short tips, not only "Looking…".
class ThinkingTest {
    private val plan = listOf("Open Settings", "Tap Hotspot & Connections", "Tap Personal Hotspot", "Turn on the switch.")

    @Test fun theNextStepOfThePlan() {
        assertEquals("Coming up: Tap Personal Hotspot.", Waiting.comingUp(plan, 2))     // 2 steps shown: the 3rd is next
        assertEquals("Coming up: Turn on the switch.", Waiting.comingUp(plan, 3))
        assertNull(Waiting.comingUp(plan, 4))                                            // the plan is done
        assertNull(Waiting.comingUp(emptyList(), 0))                                     // no plan (a built-in guide's Help)
    }

    @Test fun notAtOnceThenTakingTurns() {
        assertNull(Waiting.extra("en", plan, 2, 1000))                                    // a quick answer: nothing more
        assertEquals("Coming up: Tap Personal Hotspot.", Waiting.extra("en", plan, 2, 3000))
        assertEquals(Waiting.TIPS[0], Waiting.extra("en", plan, 2, 3000 + Waiting.EXTRA_EVERY_MS))
        assertEquals("Coming up: Tap Personal Hotspot.", Waiting.extra("en", plan, 2, 3000 + 2 * Waiting.EXTRA_EVERY_MS))
        assertEquals(Waiting.TIPS[1], Waiting.extra("en", plan, 2, 3000 + 3 * Waiting.EXTRA_EVERY_MS))
        assertEquals(Waiting.TIPS[0], Waiting.extra("en", emptyList(), 0, 3000))           // no plan: tips only
        assertEquals(Waiting.TIPS[1], Waiting.extra("en", emptyList(), 0, 3000 + Waiting.EXTRA_EVERY_MS))
        for (n in 0..40) assertTrue(Waiting.extra("en", emptyList(), 0, 3000 + n * Waiting.EXTRA_EVERY_MS)!!.startsWith("Tip: "))
    }

    // No new Nyanja or Bemba words are made up: other languages keep the card as it was
    @Test fun englishOnly() {
        assertNull(Waiting.extra("ny", plan, 2, 9000)); assertNull(Waiting.extra("bem", plan, 2, 9000))
        assertEquals("Looking", Waiting.withExtra("Looking", null))
        assertEquals("Looking\nTip: x", Waiting.withExtra("Looking", "Tip: x"))
    }

    // Both waits use it: a slow answer (waitRun) and after Help (thinkRun)
    @Test fun bothWaitsShowIt() {
        val src = listOf("src/main/java/zm/screenguide/GuideService.kt", "app/src/main/java/zm/screenguide/GuideService.kt")
            .map { File(it) }.first { it.exists() }.readText()
        val wait = src.substringAfter("private val waitRun = object : Runnable {").substringBefore("\n    }\n")
        assertTrue(wait.contains("Waiting.extra(Guides.lang, Guides.aiPlan, Guides.aiHistory.size, System.currentTimeMillis() - askStart)"))
        val think = src.substringAfter("private val thinkRun = object : Runnable {").substringBefore("\n    }\n")
        assertTrue(think.contains("Waiting.extra(Guides.lang, Guides.aiPlan, Guides.aiHistory.size, waited)"))
    }
}
