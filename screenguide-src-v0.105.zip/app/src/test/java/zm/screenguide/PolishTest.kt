package zm.screenguide

import java.io.File
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

// v0.92, the owner: "Go ahead and polish everything" (7 Nov, after testing 0.91)
class PolishTest {
    private val m = listOf("src/main/java/zm/screenguide/MainActivity.kt", "app/src/main/java/zm/screenguide/MainActivity.kt")
        .map { File(it) }.first { it.exists() }.readText()

    // The YouTube Music test: the question stayed in the typing box behind the "turned off" box
    @Test fun theBoxIsEmptiedAtOnce() {
        val ask = m.substringAfter("    private fun ask(text: String) {").substringBefore("\n    }\n")
        val cleared = ask.indexOf("input = null; typed = \"\"\n        build()")
        assertTrue(cleared in 1 until ask.indexOf("Guides.offApp(this, text)"))
    }

    // After "Not now", the offer does not come back by itself the same day; Your plan still offers it
    @Test fun noNagging() {
        assertFalse(AdsGate.autoOffer("2026-11-07", "2026-11-07"))
        assertTrue(AdsGate.autoOffer("2026-11-06", "2026-11-07"))
        assertTrue(AdsGate.autoOffer("", "2026-11-07"))
        val offer = m.substringAfter("    private fun offerAd(again: Boolean) {").substringBefore("\n    }\n")
        assertTrue(offer.contains("if (again && !AdsGate.autoOffer("))
        assertTrue(offer.contains("sp.edit().putString(\"ads_no_day\", today).apply()"))
    }

    // Your plan already says what the ad gives and costs: one tap to the ad, not a second box
    @Test fun yourPlanGoesStraightToTheAd() {
        val t = AdsGate.planText(5, 20)
        assertTrue(t.contains("5 more questions and 20 more guided steps") && t.contains("up to 3 a day") && t.contains(AdsGate.DATA))
        assertTrue(m.contains("b.setNeutralButton(\"Watch an ad\") { _, _ -> watchAd(again = false) }"))
    }
}
