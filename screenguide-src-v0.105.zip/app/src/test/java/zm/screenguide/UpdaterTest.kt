package zm.screenguide

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

// v0.102, the owner (8 Nov): every update switched ScreenGuide off behind "restricted settings". "It is time consuming,
// and a new user can get irritated easily." ScreenGuide now updates itself the way an app store does.
class UpdaterTest {
    private fun file(p: String) = listOf("src/main/$p", "app/src/main/$p").map { File(it) }.first { it.exists() }.readText()
    private val from = "https://github.com/michaelmukungalindumbo-code/Screen-Guide/releases/download/"
    private fun page(tag: String, url: String = from + "$tag/ScreenGuide.apk", name: String = "ScreenGuide.apk", extra: String = "") =
        """{"tag_name":"$tag","draft":false,"prerelease":false$extra,"assets":[{"name":"notes.txt","browser_download_url":"${from}x/notes.txt","size":10},
            {"name":"$name","browser_download_url":"$url","size":7729626}]}"""

    @Test fun whichVersionIsNewer() {
        assertTrue(Updater.newer("0.102", "0.99"))        // as numbers: "0.102" comes before "0.99" as words
        assertTrue(Updater.newer("v0.103", "0.102"))
        assertTrue(Updater.newer("1.0", "0.150"))
        assertFalse(Updater.newer("0.102", "0.102"))
        assertFalse(Updater.newer("0.99", "0.102"))
        assertFalse(Updater.newer("", "0.102"))
        assertFalse(Updater.newer("rubbish", "0.102"))
    }

    @Test fun onlyOurOwnNewerRelease() {
        val f = Updater.parse(page("v0.103"), "0.102")!!
        assertEquals("0.103", f.version); assertEquals(from + "v0.103/ScreenGuide.apk", f.url); assertEquals(7729626L, f.bytes)
        assertNull(Updater.parse(page("v0.102"), "0.102"))                                           // the same: nothing to do
        assertNull(Updater.parse(page("v0.101"), "0.102"))                                           // never back to an older one
        assertNull(Updater.parse(page("v0.103", url = "https://example.com/ScreenGuide.apk"), "0.102"))   // only from our releases
        assertNull(Updater.parse(page("v0.103", url = "https://github.com/someone-else/Screen-Guide/releases/download/v0.103/a.apk"), "0.102"))
        assertNull(Updater.parse(page("v0.103", name = "ScreenGuide.zip"), "0.102"))
        assertNull(Updater.parse(page("v0.103", extra = ""","x":1""").replace("\"draft\":false", "\"draft\":true"), "0.102"))
        assertNull(Updater.parse("not json", "0.102")); assertNull(Updater.parse("{}", "0.102"))
    }

    // It looks once a day at most, and says the size before any download (data costs money)
    @Test fun gentleOnData() {
        val day = 24 * 3600 * 1000L
        assertTrue(Updater.due(0L, day)); assertFalse(Updater.due(day, day + 3600 * 1000L)); assertTrue(Updater.due(day, 2 * day))
        assertTrue(Updater.due(5 * day, day))                                                        // the clock was set back
        assertEquals("7 MB", Updater.size(7729626L)); assertEquals("1 MB", Updater.size(1000L)); assertEquals("", Updater.size(0L))
        assertEquals("ScreenGuide 0.103 is ready (7 MB to download). Update now? ScreenGuide stays switched on.",
            Updater.offer(Updater.Found("0.103", from + "v0.103/ScreenGuide.apk", 7729626L)))
        val m = file("java/zm/screenguide/MainActivity.kt")
        val offer = m.substringAfter("    private fun offerUpdate(f: Updater.Found) {").substringBefore("\n    }\n")
        assertTrue(offer.contains("setPositiveButton(\"Update\") { _, _ -> startUpdate(f) }"))       // a download only after a tap
        val check = m.substringAfter("    private fun checkUpdate(asked: Boolean) {").substringBefore("    private fun offerUpdate(")
        assertFalse(check.contains("Updater.download(")); assertFalse(check.contains("startUpdate("))
        assertTrue(offer.contains("if (Guides.active != null) return"))                              // never in the middle of a guide
    }

    // Installed the way an app store does (a session), so Android does not treat it as a loose file
    @Test fun theWiringIsThere() {
        val u = file("java/zm/screenguide/Updater.kt")
        assertTrue(u.contains("PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL)"))
        assertTrue(u.contains("params.setAppPackageName(c.packageName)"))                            // only ScreenGuide itself, ever
        assertTrue(u.contains("if (!f.url.startsWith(FROM)) return null"))
        assertTrue(u.contains("if (done < 500_000 || (f.bytes > 0 && done != f.bytes)) { out.delete(); null }"))   // a cut download is never installed
        assertFalse(u.contains("ACTION_VIEW")); assertFalse(u.contains("ACTION_INSTALL_PACKAGE"))    // never the loose-file way
        val man = file("AndroidManifest.xml")
        assertTrue(man.contains("android.permission.REQUEST_INSTALL_PACKAGES"))
        assertTrue(man.contains("<receiver android:name=\".UpdateReceiver\" android:exported=\"false\"/>"))
        val m = file("java/zm/screenguide/MainActivity.kt")
        assertTrue(m.contains("Row(\"refresh\", \"Check for updates\") { checkUpdate(true) }"))
        assertTrue(m.contains("private fun canInstall() = android.os.Build.VERSION.SDK_INT < 26 || packageManager.canRequestPackageInstalls()"))
        assertEquals("The phone is too full for the update. Free some space and try again.", Updater.failed(6))   // STATUS_FAILURE_STORAGE
        assertEquals("The update did not go in. Nothing changed.", Updater.failed(-1))
    }
}
