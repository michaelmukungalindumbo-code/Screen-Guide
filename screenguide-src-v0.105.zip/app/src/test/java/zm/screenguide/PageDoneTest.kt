package zm.screenguide

import java.io.File
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

// v0.98, the owner's phone (8 Nov, Infinix, "Make words bigger"): on the Display & Brightness page, the guide said
// "Tap Display brightness" with the ring on the brightness slider, instead of "Scroll down to find Font size".
class PageDoneTest {
    private val display = listOf("Display", "Display & Brightness", "Display & brightness", "Display and brightness")   // step 2's names

    @Test fun onItsOwnPageAStepIsDone() {
        assertTrue(StepNav.onPageOf(listOf("Display & Brightness"), display))              // the Infinix page title
        assertTrue(StepNav.onPageOf(listOf("Display"), display))                           // Samsung's
        assertFalse(StepNav.onPageOf(listOf("Settings"), display))                         // still on Settings: ring Display
        assertFalse(StepNav.onPageOf(listOf("Sound & Vibration"), display))               // another page
        // (The slider "Display brightness" is the same words as "Display & Brightness": what keeps it out is that only
        // titles count, words near the top that cannot be tapped, and the slider is lower down and can be tapped.)
        assertFalse(StepNav.onPageOf(emptyList(), display))
        assertFalse(StepNav.onPageOf(listOf(""), listOf("")))
    }

    // In the step loop, before a step's button is looked for; never for the last step (its switch is often named like the page)
    @Test fun theWiringIsThere() {
        val g = listOf("src/main/java/zm/screenguide/GuideService.kt", "app/src/main/java/zm/screenguide/GuideService.kt")
            .map { File(it) }.first { it.exists() }.readText()
        val loop = g.substringAfter("for (i in guide.steps.size - 1 downTo 0) {").substringBefore("val node = find(nodes, guide.steps[i])")
        // v0.105: the same check, now also given the page's rows (BigScreenTest: Samsung's "Device care" still has Battery to tap)
        assertTrue(loop.contains("if (i < guide.steps.size - 1 && StepNav.onPageOf(titles, guide.steps[i].match, rows)) continue"))
        assertTrue(g.contains("val titles = nodes.filter { isTitle(it) }.map { txt(it) }"))
    }
}
