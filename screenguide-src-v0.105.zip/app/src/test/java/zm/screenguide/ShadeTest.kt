package zm.screenguide

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

// v0.97, the owner's tablet (8 Nov, Samsung Galaxy Tab A): "Take a screenshot" with the quick panel fully open kept saying
// "Swipe down once more to see all the buttons". Samsung's panel has no Screenshot button.
class ShadeTest {
    // The tablet's panel, as the test note read it
    private val samsung = listOf("Brightness settings panel", "Wi-Fi,On.,Button", "Sound On.,Button", "Bluetooth,On.,Button", "Portrait",
        "Flight mode,Off.,Button", "Power mode", "Mobile data", "Blue light filter", "Mobile Hotspot", "Location", "Do not disturb",
        "Sync", "Quick Share", "Dolby Atmos", "Samsung Kids")
    private val firstRow = listOf("Wi-Fi,On.,Button", "Sound On.,Button", "Bluetooth,On.,Button", "Auto rotate,Off.,Button", "Flight mode,Off.,Button")

    @Test fun allTheButtonsShow() {
        assertTrue(Shade.tiles(samsung) >= 14)
        assertTrue(Shade.fullyOpen(samsung))
        assertFalse(Shade.fullyOpen(firstRow))                     // only the first row: "swipe down once more" is right
        assertFalse(Shade.fullyOpen(listOf("WhatsApp", "Messages", "Clear all")))   // messages, not buttons
    }

    @Test fun whatWorksInstead() {
        assertEquals("There is no Screenshot button here. Swipe up to close this, then press the Power button and the Volume down button at the same time.",
            Shade.missing("screenshot")["en"])
        assertEquals("Swipe left on the buttons to see more of them.", Shade.missing("torch")["en"])
        assertFalse(Shade.KEYS.containsKey("ny") || Shade.KEYS.containsKey("bem"))   // no new Nyanja or Bemba words
    }

    // Taken with the side buttons: the phone's own screenshot bar (Samsung) or message says so
    @Test fun aScreenshotIsSeen() {
        assertTrue(Shade.screenshotTaken("com.samsung.android.app.smartcapture", emptyList()))
        assertTrue(Shade.screenshotTaken("com.android.systemui", listOf("Screenshot saved")))
        assertFalse(Shade.screenshotTaken("com.android.systemui", listOf("Screenshot")))          // a panel button's name
        assertFalse(Shade.screenshotTaken("com.android.settings", listOf("Battery")))
    }

    @Test fun theWiringIsThere() {
        val g = listOf("src/main/java/zm/screenguide/GuideService.kt", "app/src/main/java/zm/screenguide/GuideService.kt")
            .map { File(it) }.first { it.exists() }.readText()
        val hint = g.substringAfter("    private fun shadeHint(nodes: List<AccessibilityNodeInfo>, pkg: String) {").substringBefore("\n    }\n")
        assertTrue(hint.indexOf("Shade.fullyOpen(") in 1 until hint.indexOf("pullMore"))
        assertTrue(hint.contains("if (keysFor != null && keysFor == id)"))                    // closed again: the same words
        assertFalse(hint.contains("no torch button"))
        assertTrue(g.contains("if (guide.id == \"screenshot\" && Shade.screenshotTaken("))
    }
}
