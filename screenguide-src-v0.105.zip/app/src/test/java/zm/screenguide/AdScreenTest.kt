package zm.screenguide

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

// v0.93, the owner (7 Nov): "What happens when you are using YouTube, and then an ad pops up?" The screens are the ones
// YouTube and full-screen game ads show (the owner's own recording can replace them: the rules are made for these words).
class AdScreenTest {
    private val videoAd = listOf("Ad · 0:15 [text]", "Visit advertiser [tap]", "Skip in 5 [text]", "Learn more [tap]", "Install [tap]")
    private val skipNow = listOf("Ad · 0:09 [text]", "Visit advertiser [tap]", "Skip ad [tap]", "Install [tap]")

    @Test fun aVideoAdCoversTheScreen() {
        assertTrue(AdScreen.covers(videoAd)); assertTrue(AdScreen.covers(skipNow))
        assertTrue(AdScreen.covers(listOf("Ad 1 of 2 · 0:05 [text]", "Skip [tap]")))
        assertTrue(AdScreen.covers(listOf("Your video will play after ads [text]")))
        assertTrue(AdScreen.covers(listOf("Close ad [tap]", "Install [tap]")))                 // a game's full-screen ad
    }

    // Only the ad's own way out is rung, once it can be tapped; never Install, Learn more or Visit advertiser
    @Test fun onlySkipOrClose() {
        assertNull(AdScreen.skipButton(videoAd))                                               // "Skip in 5": not yet
        assertEquals(AdScreen.SAY_WAIT, AdScreen.say(AdScreen.skipButton(videoAd)))
        assertEquals("Skip ad", AdScreen.skipButton(skipNow))
        assertEquals(AdScreen.SAY_SKIP, AdScreen.say("Skip ad"))
        assertEquals("Skip", AdScreen.skipButton(listOf("Ad 1 of 2 · 0:05 [text]", "Skip [tap]")))   // YouTube's short "Skip"
        assertEquals("Close ad", AdScreen.skipButton(listOf("Close ad [tap]", "Install [tap]")))
        assertEquals(AdScreen.SAY_CLOSE, AdScreen.say("Close ad"))
        assertTrue(AdScreen.SAY_WAIT.contains("Do not tap anything else"))
    }

    // Not an ad that covers the screen: the guide goes on as usual
    @Test fun notEveryAdWordIsAnAd() {
        assertFalse(AdScreen.covers(listOf("Sponsored [text]", "Like [tap]", "Comment [tap]", "Share [tap]")))   // a feed post
        assertFalse(AdScreen.covers(listOf("Welcome [text]", "Skip [tap]", "Next [tap]")))                        // an app's first screens
        assertNull(AdScreen.skipButton(listOf("Welcome [text]", "Skip [tap]", "Next [tap]")))
        assertFalse(AdScreen.covers(listOf("Ads [tap]", "Privacy [tap]", "Security [tap]")))                      // Google settings
        assertFalse(AdScreen.covers(listOf("Add account [tap]", "Address [text]")))
    }

    // Wired in before the helper and before "Not on this screen? Scroll down, or go back"; waiting is not being stuck
    @Test fun theWiringIsThere() {
        val g = listOf("src/main/java/zm/screenguide/GuideService.kt", "app/src/main/java/zm/screenguide/GuideService.kt")
            .map { File(it) }.first { it.exists() }.readText()
        val refresh = g.substringAfter("    private fun refresh() {").substringBefore("\n    }\n")
        val ad = refresh.indexOf("if (otherAd(nodes, pkg)) return")
        assertTrue(ad > 0 && ad < refresh.indexOf("if (guide.id == \"ai\") { aiRefresh(guide, nodes, pkg); return }"))
        val other = g.substringAfter("    private fun otherAd(").substringBefore("\n    }\n")
        assertTrue(other.contains("bumpProgress()") && other.contains("AdScreen.skipButton(words)"))
        assertFalse(other.contains("askNext") || other.contains("Server."))                    // no helper on an ad
    }
}
