package zm.screenguide

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

// v0.101, the owner's phone (10 Nov, Infinix, bigger words): "Teach a task" through a whole Drive scan. The bar said
// "Recording. Do the task" to the end, then "Nothing was recorded"; its Done button was cut off at the edge of the screen;
// and it sat on the file name box.
class TeachBarTest {
    private fun src(name: String) = listOf("src/main/java/zm/screenguide/$name", "app/src/main/java/zm/screenguide/$name")
        .map { File(it) }.first { it.exists() }.readText()

    // A tap whose button can no longer be read (the screen changed): the words the phone sent with the tap
    @Test fun aTapWithFewDetailsIsStillRecorded() {
        assertEquals("Drive", Teach.pickWord(null, null, "Drive", null))
        assertEquals("Scan", Teach.pickWord(null, null, "", "Scan"))
        assertEquals("Upload", Teach.pickWord("Upload", "x", "y", "z"))                    // the button's own words first
        assertEquals("New file", Teach.pickWord(" ", "New\n file", null, null))
        assertNull(Teach.pickWord(null, null, null, null))
        assertNull(Teach.pickWord(null, null, "a".repeat(51), "  "))                       // a whole paragraph is not a button's name
    }

    // Test phones: every tap is counted, with why it was or was not written down
    @Test fun whyATapWasNotRecorded() {
        Teach.reset("Scan with Drive")
        assertEquals(0, Teach.seen); assertEquals("Test phone: 0 taps seen", Teach.testNote())
        Teach.seen++; assertTrue(Teach.tap("Drive", false)); assertEquals("recorded", Teach.note)
        Teach.seen++; assertFalse(Teach.tap("Drive", false)); assertEquals("the same button again, kept once", Teach.note)
        Teach.seen++; assertFalse(Teach.tap("0971234567", false)); assertTrue(Teach.note.startsWith("not recorded, it looked personal"))
        assertEquals("Test phone: 3 taps seen. Last: " + Teach.note, Teach.testNote())
        assertEquals(1, Teach.steps.size)
        assertEquals("Recording · 1 step", Teach.barText(1)); assertEquals("Recording · 2 steps", Teach.barText(2))
        assertEquals("Recording. Do the task", Teach.barText(0))
        // "Nothing was recorded" says the true reason
        Teach.reset("x")
        assertTrue(Teach.nothing(false).startsWith("Your phone did not tell ScreenGuide about any taps."))
        Teach.seen = 4; Teach.note = Teach.NO_WORDS
        assertTrue(Teach.nothing(false).startsWith("Tap Teach a task again"))
        assertFalse(Teach.nothing(false).contains("Test phone"))
        assertTrue(Teach.nothing(true).endsWith("Test phone: 4 taps seen. Last: not recorded, the phone gave no words for it"))
        Teach.reset("")
    }

    // The bar never covers the box being typed in
    @Test fun theBarKeepsOffTheBox() {
        // (barTop, barH, boxTop, boxBottom, screenH, edge, gap)
        assertEquals(100, Teach.barY(100, 120, 900, 1000, 2400, 48, 16))                   // clear of it: stays
        assertEquals(764, Teach.barY(950, 120, 900, 1000, 2400, 48, 16))                   // on it: above the box (the keyboard is below)
        assertEquals(216, Teach.barY(110, 120, 100, 200, 2400, 48, 16))                    // a box at the very top: below it
        assertEquals(48, Teach.barY(100, 120, 60, 2380, 2400, 48, 16))                     // a box as tall as the screen: the top edge
        assertEquals(1500, Teach.barY(1500, 120, 900, 1000, 2400, 48, 16))
    }

    @Test fun theWiringIsThere() {
        val g = src("GuideService.kt")
        val ev = g.substringAfter("    private fun teachEvent(e: AccessibilityEvent) {").substringBefore("    private fun teachWord(")
        assertFalse(ev.contains("val src = e.source ?: return"))                            // the tap is no longer dropped
        assertTrue(ev.contains("Teach.pickWord(null, null, e.text?.joinToString(\" \"), e.contentDescription?.toString())"))
        assertTrue(ev.contains("if (e.isPassword || src?.isPassword == true) { Teach.note = Teach.SECRET"))   // passwords: never
        assertTrue(ev.indexOf("blockedApps.any") < ev.indexOf("Teach.pickWord("))            // money apps: never, checked first
        assertTrue(ev.contains("Teach.barY(lp.y, v.height, r.top, r.bottom"))
        val bar = g.substringAfter("    private fun showTeachPill() {").substringBefore("    private fun moveTeach(")
        assertFalse(Regex("textSize = \\d").containsMatchIn(bar))                           // sized to the screen, not the word size
        assertTrue(bar.contains("setTextSize(DIP, 15f)") && bar.contains("maxWidth = roomForWords"))
        assertTrue(g.contains("if (Server.tester) View.VISIBLE else View.GONE"))
        assertTrue(src("MainActivity.kt").contains(".setMessage(Teach.nothing(Server.tester))"))
    }
}
