package zm.screenguide

// v0.90 (the owner's list, 7 Nov, "breadcrumbs"): where the person has been in this Smart guide, oldest first: the apps
// they were in and the buttons they tapped that the guide pointed at ("Settings", "Hotspot & Connections"). It goes to the
// helper with each step, so it knows where they are going. The server keeps only common button names (never a name or
// a number), and only the last few.
object Breadcrumbs {
    const val MAX = 8

    fun add(path: MutableList<String>, name: String?) {
        val n = name?.replace(Regex("\\s+"), " ")?.trim()?.take(40) ?: return
        if (n.isEmpty() || path.lastOrNull().equals(n, true)) return
        path.add(n)
        while (path.size > MAX) path.removeAt(0)
    }
}
