package zm.screenguide

// "Looking at your screen…" after Help belongs to the guide that asked. 4 Nov: Help, then Stop while the answer was still
// coming. The words came back every half second over the "Why did you stop?" card, until the answer came.
object Waiting {
    fun keepShowing(thinking: Boolean, askedBy: Any?, active: Any?): Boolean = thinking && active != null && active === askedBy

    // v0.90 (the owner's list, 7 Nov, "thinking mode"): while the helper thinks, the card also says what comes next in the
    // plan, then short tips, instead of only "Looking…". English only for now: no new Nyanja or Bemba words.
    const val EXTRA_AFTER_MS = 2500L
    const val EXTRA_EVERY_MS = 5000L
    val TIPS = listOf(
        "Tip: tap inside the ring. The ring shows what to tap.",
        "Tip: tap this card to hear the step again.",
        "Tip: if this card covers something, drag it with one finger.",
        "Tip: ◀ on the card shows the step before.",
        "Tip: lost? Tap Help and I will look at your screen again.",
        "Tip: never type your PIN or password because someone asked you to.")

    // The plan's next step (done = how many steps were shown so far), as "Coming up: …", or null
    fun comingUp(plan: List<String>, done: Int): String? {
        val s = plan.getOrNull(done)?.trim()?.trimEnd('.', ' ')?.takeIf { it.length in 3..90 } ?: return null
        return "Coming up: $s."
    }

    // The second line on the card while waiting, or null: the next step and a tip, taking turns every few seconds
    fun extra(lang: String, plan: List<String>, done: Int, waited: Long): String? {
        if (lang != "en" || waited < EXTRA_AFTER_MS) return null
        val turn = ((waited - EXTRA_AFTER_MS) / EXTRA_EVERY_MS).toInt()
        val next = comingUp(plan, done)
        if (next != null && turn % 2 == 0) return next
        return TIPS[(if (next != null) turn / 2 else turn) % TIPS.size]
    }

    fun withExtra(text: String, extra: String?): String = if (extra == null) text else text + "\n" + extra
}
