package zm.screenguide

// v0.103 (the owner, 10 Nov), "task prediction": "as the user is typing, the AI uses the key words and quickly figures out
// how to complete the task before the user clicks send, for quicker responses". Done on the phone, with the same key-word
// rules that already pick a guide or an app after Send (Match): no internet, no cost, and nothing typed leaves the phone
// until the person sends it. A "Start" button shows above the box as soon as the words fit a task ScreenGuide can show
// at once. (Which AI answers a sent question, fast or stronger, is the server's part: its "hard_first" rule.)
object Predict {
    class Task(val kind: String, val label: String, val id: String, val name: String = "")   // kind: "guide" or "open"

    const val HINT = "No internet needed"
    private val yesWords = setOf("yes", "ok", "okay", "showme", "doit", "go", "start", "letsgo", "yesplease", "guideme")

    // text: what is in the box now. guides: the built-in tasks. apps: (name under the icon, package).
    fun of(text: String, guides: List<Guide>, apps: List<Pair<String, String>>, lang: String = "en"): Task? {
        val t = text.trim()
        val letters = t.lowercase().filter { it.isLetterOrDigit() }
        if (letters.length < 4 || t.length > 120 || letters in yesWords) return null
        // Never for money, never for a problem (the helper's work), never for a part of an app or an app to install:
        // those keep the path they have after Send.
        if (Match.isMoney(t) || Match.isProblem(t) || Match.feature(t) != null || Match.installTarget(t) != null) return null
        val best = guides.maxByOrNull { Match.score(it.keywords, t) }
        if (best != null && Match.score(best.keywords, t) > 0)
            return Task("guide", "Start: " + (best.title[lang] ?: best.title["en"] ?: ""), best.id)
        val named = Match.findTarget(t, apps.map { it.first }) ?: Match.keyApp(t, apps)?.first ?: return null
        val pkg = apps.firstOrNull { it.first == named }?.second ?: return null
        return Task("open", "Open $named", pkg, named)
    }
}
