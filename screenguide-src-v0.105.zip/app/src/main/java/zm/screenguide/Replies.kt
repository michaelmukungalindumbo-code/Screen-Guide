package zm.screenguide

// v0.94 (the owner, 8 Nov: the "Sorry, the helper is busy" line at the top of the chat): when the helper does not answer,
// ScreenGuide replies the way it always does, in a bubble, in calm and true words ("busy" was not true: it could not be
// reached), then what still works. Limits and "no internet" keep their own words, which say what to do.
object Replies {
    const val CANT_REACH = "I can’t reach the helper right now."
    const val NOT_AVAILABLE = "The helper isn’t available at the moment. Please try later."
    private val generic = Regex("busy|internal server error", RegexOption.IGNORE_CASE)

    // code: what the server answered (0: no answer at all, the phone's own words). inRow: failed answers in a row, this one too.
    fun fail(code: Int, text: String, inRow: Int): String =
        if (code >= 500 && (text.isBlank() || generic.containsMatchIn(text))) (if (inRow >= 2) NOT_AVAILABLE else CANT_REACH) else text

    // What still works, said under it: the Open or Find button above, or a guide that needs no helper
    fun withWayOn(words: String, hasOffer: Boolean, hasGuide: Boolean): String = when {
        hasOffer -> "$words The button above works without it."
        hasGuide -> "$words\n\nThis guide works without the helper:"
        else -> words
    }
}
