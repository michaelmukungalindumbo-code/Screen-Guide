package zm.screenguide

// v0.100 (the owner, 9 Nov: "Long press, and among the options, Reply to a specific message, like WhatsApp"). Hold a message,
// tap Reply: it shows above the box; the question is sent with it, so the helper knows which message it is about.
// Plain functions (no Android), so a unit test can check them.
object Quoted {
    const val KEEP = 400   // kept with the reply, enough to find the message again and to show two lines of it

    fun of(m: Msg): String = m.text.take(KEEP)

    // The name over the quote, as WhatsApp shows it. English only, like the other words of the chat screen.
    fun who(mine: Boolean) = if (mine) "You" else "ScreenGuide"

    // The message replied to, found again in the chat (to scroll to it when the quote is tapped). -1: no longer there
    // (a message edited since, or a chat started afresh).
    fun original(msgs: List<Msg>, at: Int, quote: String, mine: Boolean): Int =
        (minOf(at, msgs.size) - 1 downTo 0).firstOrNull { msgs[it].mine == mine && quote.isNotEmpty() && msgs[it].text.startsWith(quote) } ?: -1

    // What the helper is told, as the last line of the conversation it already gets (the server keeps 300 letters a line)
    fun context(quote: String, mine: Boolean): String =
        (if (mine) "The user is replying to their own earlier message: “" else "The user is replying to this earlier Helper message: “") +
            quote.replace(Regex("\\s+"), " ").trim().take(220) + "”"

    fun history(base: List<String>, asked: Msg?): List<String> {
        val q = asked?.takeIf { it.mine }?.quote ?: return base
        return base + context(q, asked.quoteMine)
    }

    // "Show me", "yes" or "ok" as a reply to an answer that can be shown on screen: that answer, even an older one
    fun showable(replyTo: Msg?, said: String, showWords: Set<String>): Msg? {
        val r = replyTo?.takeIf { !it.mine && (it.goal != null || it.guideId != null) } ?: return null
        val t = said.lowercase().filter { it.isLetterOrDigit() }
        return if (t in showWords || t.startsWith("showme") || t in setOf("guideme", "doit", "pointtoit")) r else null
    }

    // "It" in a guide's goal: the message replied to says what "it" is, before the question asked before it
    fun about(asked: Msg?): String? = asked?.quote?.removePrefix("📎 ")?.replace(Regex("\\s+"), " ")?.trim()?.take(120)?.ifEmpty { null }
}
