package zm.screenguide

// v0.97 (the owner's tablet, 8 Nov, Samsung Galaxy Tab A): "Take a screenshot" with the quick panel fully open (Wi-Fi,
// Sound, Bluetooth ... Samsung Kids, 15 buttons) kept saying "Swipe down once more to see all the buttons". Samsung's
// panel has no Screenshot button at all. Now: when all the buttons show and the task's is not one of them, say what works.
object Shade {
    private val tileWords = listOf("wifi", "bluetooth", "flightmode", "airplanemode", "aeroplanemode", "mobiledata", "location",
        "donotdisturb", "sound", "vibrate", "mute", "autorotate", "portrait", "landscape", "powermode", "powersaving", "batterysaver",
        "sync", "mobilehotspot", "hotspot", "bluelight", "eyecomfort", "nfc", "screenrecord", "quickshare", "nearbyshare", "dolby",
        "flashlight", "torch", "darkmode", "cast", "smartview", "samsungkids", "datasaver")

    fun tiles(labels: List<String>): Int = labels.count { l -> val w = l.lowercase().filter { it.isLetterOrDigit() }; tileWords.any { w.startsWith(it) } }
    // All the buttons show (not the first row only): 8 or more of them
    fun fullyOpen(labels: List<String>) = tiles(labels) >= 8

    // English only: no new Nyanja or Bemba words
    val KEYS = mapOf("en" to "There is no Screenshot button here. Swipe up to close this, then press the Power button and the Volume down button at the same time.")
    val MORE = mapOf("en" to "Swipe left on the buttons to see more of them.")
    fun missing(id: String): Map<String, String> = if (id == "screenshot") KEYS else MORE

    // A screenshot was taken with the buttons on the side: the phone's own screenshot bar or message
    private val saved = Regex("screenshot (saved|captured|taken)", RegexOption.IGNORE_CASE)
    fun screenshotTaken(pkg: String, texts: List<String>): Boolean =
        pkg.contains("smartcapture", true) || pkg.contains("screenshot", true) || texts.any { saved.containsMatchIn(it) }
}
