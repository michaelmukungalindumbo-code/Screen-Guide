package zm.screenguide

import android.app.Activity
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.RequestConfiguration
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.google.android.gms.ads.rewarded.ServerSideVerificationOptions

// v0.90: one rewarded ad, shown over ScreenGuide's own screen only after the person tapped "Watch ad" (AdsGate has the
// rules). Google's library starts only then, not when the app opens, so phones that never watch an ad stay as fast.
// Google tells our server itself when the ad was watched (server-side verification), with this phone's anonymous id.
object Ads {
    var unit = AdsGate.TEST_UNIT
    @Volatile private var started = false

    // done(result, nonce) comes once, on the main thread. The nonce marks this one ad, so it never counts twice.
    fun watch(a: Activity, installId: String, done: (AdsGate.Result, String) -> Unit) {
        val nonce = java.util.UUID.randomUUID().toString()
        var told = false; var shown = false
        fun finish(r: AdsGate.Result) { if (!told) { told = true; done(r, nonce) } }
        // A weak network: no ad after 30 seconds is "no ad", and one that comes later is not shown
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({ if (!shown) finish(AdsGate.Result.NONE) }, 30_000L)
        fun load() {
            if (a.isFinishing || a.isDestroyed) { finish(AdsGate.Result.NONE); return }
            try {
                RewardedAd.load(a, unit, AdRequest.Builder().build(), object : RewardedAdLoadCallback() {
                    override fun onAdLoaded(ad: RewardedAd) {
                        if (told) return
                        if (a.isFinishing || a.isDestroyed) { finish(AdsGate.Result.NONE); return }
                        ad.setServerSideVerificationOptions(ServerSideVerificationOptions.Builder().setUserId(installId).setCustomData(nonce).build())
                        var earned = false
                        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                            override fun onAdDismissedFullScreenContent() { finish(if (earned) AdsGate.Result.WATCHED else AdsGate.Result.CLOSED) }
                            override fun onAdFailedToShowFullScreenContent(e: AdError) { finish(AdsGate.Result.NONE) }
                        }
                        shown = true
                        ad.show(a) { earned = true }
                    }
                    override fun onAdFailedToLoad(e: LoadAdError) { finish(AdsGate.Result.NONE) }
                })
            } catch (e: Throwable) { finish(AdsGate.Result.NONE) }
        }
        if (started) { load(); return }
        try {
            // Family-friendly ads only (no dating, gambling or alcohol-style ads): ScreenGuide's users are new to phones
            MobileAds.setRequestConfiguration(RequestConfiguration.Builder()
                .setMaxAdContentRating(RequestConfiguration.MAX_AD_CONTENT_RATING_PG).build())
            val app = a.applicationContext
            Thread {
                try { MobileAds.initialize(app) { a.runOnUiThread { started = true; load() } } }
                catch (e: Throwable) { a.runOnUiThread { finish(AdsGate.Result.NONE) } }
            }.start()
        } catch (e: Throwable) { finish(AdsGate.Result.NONE) }
    }
}
