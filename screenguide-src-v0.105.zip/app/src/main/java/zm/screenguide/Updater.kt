package zm.screenguide

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.os.Build
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONObject

// v0.102 (the owner, 8 Nov: "It has been happening every time I update it... it is time consuming, and a new user can get
// irritated easily"). An update installed from a downloaded file is treated by Android 13 and newer as coming from an
// unknown place: ScreenGuide is switched off and locked behind "restricted settings". Here ScreenGuide updates itself the
// way an app store does (Android's session installer), so it stays switched on.
// - It only looks for a new version (a small page from GitHub, once a day, or when asked). It never downloads by itself:
//   the person sees the size first and taps Update (data costs money).
// - The file comes only from ScreenGuide's own releases page, and Android itself refuses a file not signed like the
//   ScreenGuide already on the phone.
// - On Google Play this file must go: the Play Store updates apps there, and Play does not allow an app to update itself.
object Updater {
    const val REPO = "michaelmukungalindumbo-code/Screen-Guide"
    const val LATEST = "https://api.github.com/repos/$REPO/releases/latest"
    const val FROM = "https://github.com/$REPO/releases/download/"
    const val ACTION = "zm.screenguide.UPDATE_STATUS"
    const val EVERY_MS = 20 * 3600 * 1000L

    class Found(val version: String, val url: String, val bytes: Long)

    private fun parts(v: String) = v.trim().removePrefix("v").split(".").map { it.takeWhile { c -> c.isDigit() }.toIntOrNull() ?: 0 }
    // 0.102 is newer than 0.99 (numbers, not letters: "0.102" < "0.99" as words)
    fun newer(found: String, mine: String): Boolean {
        val a = parts(found); val b = parts(mine)
        for (i in 0 until maxOf(a.size, b.size)) { val x = a.getOrElse(i) { 0 }; val y = b.getOrElse(i) { 0 }; if (x != y) return x > y }
        return false
    }

    // GitHub's "latest release" page: a finished release, newer than this one, with an .apk from our own releases
    fun parse(json: String, mine: String): Found? = try {
        val o = JSONObject(json)
        val v = o.optString("tag_name").removePrefix("v")
        if (v.isEmpty() || o.optBoolean("draft") || o.optBoolean("prerelease") || !newer(v, mine)) null
        else {
            val assets = o.optJSONArray("assets")
            (0 until (assets?.length() ?: 0)).map { assets!!.getJSONObject(it) }
                .firstOrNull { it.optString("name").endsWith(".apk") && it.optString("browser_download_url").startsWith(FROM) }
                ?.let { Found(v, it.getString("browser_download_url"), it.optLong("size")) }
        }
    } catch (e: Exception) { null }

    fun due(last: Long, now: Long) = now - last >= EVERY_MS || now < last
    fun size(bytes: Long) = if (bytes <= 0) "" else "${maxOf(1L, Math.round(bytes / 1048576.0))} MB"
    // English only, like the other new words: no checked Nyanja or Bemba words for these
    fun offer(f: Found) = "ScreenGuide ${f.version} is ready" + (if (f.bytes > 0) " (${size(f.bytes)} to download)" else "") +
        ". Update now? ScreenGuide stays switched on."
    const val UP_TO_DATE = "You have the newest ScreenGuide."
    const val NO_CHECK = "I could not check for a new version. Check your internet and try again."
    const val NO_DOWNLOAD = "The download did not finish. Check your internet and try again."
    const val ALLOW = "To update itself, ScreenGuide needs your permission once. On the next screen, switch on “Allow from this source”, then come back."
    // What Android answered when the update did not go in, in plain words
    fun failed(status: Int): String = when (status) {
        PackageInstaller.STATUS_FAILURE_ABORTED -> "The update was stopped. Nothing changed."
        PackageInstaller.STATUS_FAILURE_STORAGE -> "The phone is too full for the update. Free some space and try again."
        PackageInstaller.STATUS_FAILURE_BLOCKED -> "The phone blocked the update. Nothing changed."
        PackageInstaller.STATUS_FAILURE_CONFLICT, PackageInstaller.STATUS_FAILURE_INCOMPATIBLE, PackageInstaller.STATUS_FAILURE_INVALID ->
            "This update does not fit the ScreenGuide on this phone. Nothing changed."
        else -> "The update did not go in. Nothing changed."
    }

    // ---- on the phone (not on the main thread) ----
    fun check(mine: String): Pair<Boolean, Found?> = try {
        val c = URL(LATEST).openConnection() as HttpURLConnection
        c.connectTimeout = 10000; c.readTimeout = 10000
        c.setRequestProperty("Accept", "application/vnd.github+json"); c.setRequestProperty("User-Agent", "ScreenGuide-app")
        val code = c.responseCode
        if (code == 404) true to null   // no release yet
        else if (code != 200) false to null
        else true to parse(c.inputStream.bufferedReader().use { it.readText() }, mine)
    } catch (e: Exception) { false to null }

    fun download(c: Context, f: Found, progress: (Int) -> Unit): File? {
        val out = File(c.cacheDir, "update.apk")
        return try {
            if (!f.url.startsWith(FROM)) return null
            val h = URL(f.url).openConnection() as HttpURLConnection
            h.connectTimeout = 15000; h.readTimeout = 30000; h.instanceFollowRedirects = true
            h.setRequestProperty("User-Agent", "ScreenGuide-app")
            if (h.responseCode != 200) return null
            val total = if (f.bytes > 0) f.bytes else h.contentLength.toLong()
            var done = 0L; var shown = -1
            h.inputStream.use { ins -> out.outputStream().use { os ->
                val buf = ByteArray(32 * 1024)
                while (true) {
                    val n = ins.read(buf); if (n < 0) break
                    os.write(buf, 0, n); done += n
                    val pct = if (total > 0) (done * 100 / total).toInt().coerceIn(0, 100) else 0
                    if (pct != shown) { shown = pct; progress(pct) }
                }
            } }
            if (done < 500_000 || (f.bytes > 0 && done != f.bytes)) { out.delete(); null } else out   // cut short: never installed
        } catch (e: Exception) { out.delete(); null }
    }

    // The same way an app store installs: a session. Android checks the file is signed like the ScreenGuide on the phone.
    fun install(c: Context, apk: File): Boolean = try {
        val pi = c.packageManager.packageInstaller
        val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL)
        params.setAppPackageName(c.packageName)
        if (Build.VERSION.SDK_INT >= 26) params.setInstallReason(android.content.pm.PackageManager.INSTALL_REASON_USER)
        if (Build.VERSION.SDK_INT >= 31) params.setRequireUserAction(PackageInstaller.SessionParams.USER_ACTION_NOT_REQUIRED)
        if (Build.VERSION.SDK_INT >= 33) params.setPackageSource(PackageInstaller.PACKAGE_SOURCE_OTHER)   // the truth: not a store, not a loose file
        val id = pi.createSession(params)
        pi.openSession(id).use { s ->
            s.openWrite("screenguide", 0, apk.length()).use { os -> apk.inputStream().use { it.copyTo(os) }; s.fsync(os) }
            val back = Intent(c, UpdateReceiver::class.java).setAction(ACTION)
            val flags = PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
            s.commit(PendingIntent.getBroadcast(c, id, back, flags).intentSender)
        }
        true
    } catch (e: Exception) { false }
}

// Android's answer to the update: "ask the person" (the phone's own Update box), done, or why not
class UpdateReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action != Updater.ACTION) return
        val status = i.getIntExtra(PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE)
        val sp = c.getSharedPreferences("sg", Context.MODE_PRIVATE)
        when (status) {
            PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                @Suppress("DEPRECATION")
                val ask = if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra(Intent.EXTRA_INTENT, Intent::class.java) else i.getParcelableExtra(Intent.EXTRA_INTENT)
                try { ask?.let { c.startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } } catch (e: Exception) {}
            }
            PackageInstaller.STATUS_SUCCESS -> sp.edit().remove("update_failed").apply()
            else -> sp.edit().putString("update_failed", Updater.failed(status)).apply()
        }
        if (status != PackageInstaller.STATUS_PENDING_USER_ACTION) try { java.io.File(c.cacheDir, "update.apk").delete() } catch (e: Exception) {}
    }
}
