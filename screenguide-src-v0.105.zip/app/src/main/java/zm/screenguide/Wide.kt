package zm.screenguide

// tests first: not built yet
object Wide {
    fun card(widthPx: Int, density: Float, share: Float = 0.9f) = widthPx
    fun side(widthPx: Int, density: Float, usualDp: Int) = 0
    fun bubble(widthPx: Int, density: Float) = widthPx
}
