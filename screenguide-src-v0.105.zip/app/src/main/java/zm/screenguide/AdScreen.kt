package zm.screenguide

// v0.93 (the owner, 7 Nov: "What happens when you are using YouTube, and then an ad pops up?"): another app's ad that
// covers the screen (a YouTube video ad, a game's full-screen ad). Before, a built-in guide said "Not on this screen?
// Scroll down, or go back" ("go back" can close the video), and a Smart guide asked the helper, which could point at the
// ad's "Install" or "Visit advertiser". Now: wait, and ring only "Skip ad" or "Close ad". Never anything else on an ad.
// A "Sponsored" post in a feed does not cover the screen: the guide goes on as usual there.
object AdScreen {
    private val skipRx = Regex("^(skip ads?|skip ad(s)? in \\d+.*|skip in \\d+.*|close ad|close advertisement|close the ad)$", RegexOption.IGNORE_CASE)
    private val coverRx = Regex("^(visit advertiser|ad\\s*[·•‧:]\\s*\\d.*|ad\\s+\\d+\\s+of\\s+\\d+.*|.*will play after (the )?ads?|" +
        "your video will (play|begin) after (the )?ads?|advertisement|why this ad\\??|adchoices|ad choices)$", RegexOption.IGNORE_CASE)
    private fun clean(l: String) = l.replace(Regex("\\s*\\[(tap|text|switch|selected|typing)\\]\\s*$"), "").trim()

    // An ad covers the screen: its own buttons and words say so
    fun covers(labels: List<String>): Boolean = labels.any { val c = clean(it); skipRx.matches(c) || coverRx.matches(c) }

    // The one button that is safe to ring on an ad: its own "Skip ad" or "Close ad", once it can be tapped (not "Skip in 5")
    // YouTube's button may say only "Skip": taken only when the screen is already known to be an ad.
    fun skipButton(labels: List<String>): String? {
        val words = labels.map { clean(it) }
        return words.firstOrNull { skipRx.matches(it) && !Regex("\\bin \\d+", RegexOption.IGNORE_CASE).containsMatchIn(it) }
            ?: if (covers(labels)) words.firstOrNull { it.equals("skip", true) } else null
    }

    const val SAY_SKIP = "This is an ad. Tap “Skip ad” to go on."
    const val SAY_CLOSE = "This is an ad. Tap “Close ad” to go on."
    const val SAY_WAIT = "This is an ad. Wait a few seconds for “Skip ad”, or for the ad to end. Do not tap anything else on it."
    fun say(skip: String?): String = when {
        skip == null -> SAY_WAIT
        skip.startsWith("close", true) -> SAY_CLOSE
        else -> SAY_SKIP
    }
}
