package zm.screenguide

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat

// v0.94 (the owner, 8 Nov: "How do I receive the response from ScreenGuide even when I'm not on the app's screen, like I do
// when I am using you?"): when an answer arrives and ScreenGuide is not on the screen, a notification says it is ready. A
// tap opens that chat. It never shows the answer's words: nothing private on the lock screen. ScreenGuide keeps running
// while its guide service is on, so the phone itself can tell: no server needed.
object Notify {
    const val CHANNEL = "answers"
    const val PERMISSION = "android.permission.POST_NOTIFICATIONS"   // Android 13 and newer: the person allows it once
    const val EXTRA_CHAT = "open_chat"
    private const val ID = 4100
    const val READY = "Your answer is ready. Tap to see it."
    const val FAILED = "I could not answer just now. Tap to try again."
    fun text(ok: Boolean) = if (ok) READY else FAILED

    // Asked once, when the person sends a question for the first time (Android 13 and newer only)
    fun needsAsking(sdk: Int, granted: Boolean, askedBefore: Boolean) = sdk >= 33 && !granted && !askedBefore

    fun answerReady(c: Context, chatId: Long, ok: Boolean) {
        try {
            if (Build.VERSION.SDK_INT >= 33 && c.checkSelfPermission(PERMISSION) != PackageManager.PERMISSION_GRANTED) return
            val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= 26 && nm.getNotificationChannel(CHANNEL) == null)
                nm.createNotificationChannel(NotificationChannel(CHANNEL, "Answers", NotificationManager.IMPORTANCE_DEFAULT)
                    .apply { description = "When the answer to your question is ready" })
            val open = Intent(c, MainActivity::class.java).putExtra(EXTRA_CHAT, chatId)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            val pi = PendingIntent.getActivity(c, ID, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val n = NotificationCompat.Builder(c, CHANNEL).setSmallIcon(R.drawable.ic_notify).setContentTitle("ScreenGuide")
                .setContentText(text(ok)).setContentIntent(pi).setAutoCancel(true)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC).setPriority(NotificationCompat.PRIORITY_DEFAULT).build()
            nm.notify(ID, n)
        } catch (e: Exception) {}
    }

    fun clear(c: Context) {
        try { (c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(ID) } catch (e: Exception) {}
    }
}
