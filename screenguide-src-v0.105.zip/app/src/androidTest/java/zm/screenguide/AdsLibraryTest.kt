package zm.screenguide

import android.content.pm.PackageManager
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

// v0.90: Google's rewarded ads. Learned from #26 (a library part missing from the app closed it): check on a real
// Android that the parts are inside ScreenGuide itself, and that the app carries Google's TEST app id (without an app id,
// Google's library closes the app as it opens).
@RunWith(AndroidJUnit4::class)
class AdsLibraryTest {
    private val ctx = InstrumentationRegistry.getInstrumentation().targetContext

    @Test fun adPartsAreInTheApp() {
        @Suppress("DEPRECATION")
        val names = dalvik.system.DexFile(ctx.applicationInfo.sourceDir).entries().toList().toHashSet()
        val need = listOf("com.google.android.gms.ads.MobileAds", "com.google.android.gms.ads.rewarded.RewardedAd",
            "com.google.android.gms.ads.AdActivity", "zm.screenguide.Ads")
        val missing = need.filter { it !in names }
        assertTrue("Missing from the app: $missing", missing.isEmpty())
    }

    @Test fun testAppIdIsSet() {
        @Suppress("DEPRECATION")
        val meta = ctx.packageManager.getApplicationInfo(ctx.packageName, PackageManager.GET_META_DATA).metaData
        assertEquals(AdsGate.TEST_APP_ID, meta?.getString("com.google.android.gms.ads.APPLICATION_ID"))
    }
}
