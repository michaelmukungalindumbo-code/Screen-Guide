plugins {
    id("com.android.application") version "8.12.0" apply false
    // v0.90: Google's ad library 25.5.0 is built with Kotlin 2.3; Kotlin 2.1 could not read it ("incompatible version of Kotlin")
    id("org.jetbrains.kotlin.android") version "2.3.20" apply false
}
