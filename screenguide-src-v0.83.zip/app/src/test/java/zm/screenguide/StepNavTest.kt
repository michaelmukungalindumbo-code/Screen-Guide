package zm.screenguide

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test

class StepNavTest {
    private fun step(word: String) = Step(listOf(word), mapOf("en" to "Tap “$word”."), null)

    // 6 Nov, the owner's idea: ◀ goes back a step, ▶ skips one. In a 5-step guide:
    @Test fun numberedGuidesGoBackAndOn() {
        assertEquals(1, StepNav.back(2, 5)); assertEquals(3, StepNav.skip(2, 5))
        assertNull(StepNav.back(0, 5))            // nothing before the first step
        assertNull(StepNav.skip(4, 5))            // nothing after the last
        assertEquals(3, StepNav.back(9, 5))       // an index past the end counts as the last step
        assertNull(StepNav.back(0, 0)); assertNull(StepNav.skip(0, 0))
        assertNull(StepNav.back(0, 1)); assertNull(StepNav.skip(0, 1))
    }

    @Test fun smartGuidesGoBackThroughWhatWasShown() {
        val shown = ArrayList<Step>()
        val a = step("Create"); val b = step("Upload"); val c = step("Next")
        for (s in listOf(a, b, c)) StepNav.remember(shown, s)
        assertEquals(3, shown.size)
        assertEquals(1, StepNav.before(2))        // on "Next": back to "Upload"
        assertEquals(0, StepNav.before(1))        // then "Create"
        assertNull(StepNav.before(0))             // nothing before the first
        assertEquals(2, StepNav.before(3))        // an error on the card (not in the list): back to the last one shown
    }

    @Test fun theSameInstructionTwiceIsKeptOnceTheNewestCopy() {
        val shown = ArrayList<Step>()
        val a = step("Create"); val again = step("Create")
        StepNav.remember(shown, a); StepNav.remember(shown, again)
        assertEquals(1, shown.size)
        assertSame(again, shown[0])               // the one on the card is the one found in the list
    }

    @Test fun onlyTheLastFewAreKept() {
        val shown = ArrayList<Step>()
        for (i in 1..20) StepNav.remember(shown, step("Row $i"))
        assertEquals(12, shown.size)
        assertEquals(listOf("Row 9"), shown[0].match)
    }

    @Test fun theAiIsToldWhatWasSkipped() {
        val n = StepNav.skipNote("Tap “Upload”.")
        assertTrue(n.contains("Skip") && n.contains("Upload") && n.contains("another way"))
        assertTrue(StepNav.skipNote("x".repeat(300)).length < 250)
    }

    // The card has the two arrows, each with words for TalkBack, and they do what is above. ScreenGuide never taps.
    @Test fun theCardHasTheArrows() {
        val src = listOf("src/main/java/zm/screenguide/GuideService.kt", "app/src/main/java/zm/screenguide/GuideService.kt")
            .map { File(it) }.first { it.exists() }.readText()
        assertTrue(src.contains("arrow(\"back\", \"Back a step\") { navBack() }"))
        assertTrue(src.contains("arrow(\"next\", \"Skip this step\") { navNext() }"))
        assertTrue(src.contains("if (showPeek(nodes, pkg)) return"))
        assertTrue(src.contains("StepNav.remember(Guides.aiShown, step)"))
        assertTrue(src.contains("nextNote = StepNav.skipNote("))
        val nav = src.substringAfter("private fun navBack()").substringBefore("// Asks the AI for a different way")
        assertTrue(!nav.contains("performAction") && !nav.contains("dispatchGesture"))
    }
}
