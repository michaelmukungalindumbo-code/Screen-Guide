package zm.screenguide

// Test first: no Back or Skip yet (v0.82), so the new tests fail on GitHub before the feature.
object StepNav {
    const val PEEK_MS = 8000L
    fun back(index: Int, size: Int): Int? = null
    fun skip(index: Int, size: Int): Int? = null
    fun before(at: Int): Int? = null
    fun remember(shown: MutableList<Step>, s: Step, max: Int = 12) {}
    fun skipNote(say: String): String = ""
}
