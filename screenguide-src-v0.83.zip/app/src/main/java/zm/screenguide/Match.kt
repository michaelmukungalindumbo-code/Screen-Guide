package zm.screenguide

// Every rule that turns a person's words into an action lives here: start an offline task, open an app first, open an
// app at once, treat a question as a problem or as money. No Android code, so MatchTest runs hundreds of real questions
// through it on every build. Lessons that made this file: "Take a screenshot on your phone" opened the Phone app;
// "number" matched "mb"; "ready" matched "read". Words are not commands: match whole words, and plain words carefully.
object Match {
    // " take a screenshot on your phone " : lower case, whole words, single spaces, a space at each end.
    fun words(s: String) = " " + s.lowercase().replace(Regex("[^\\p{L}\\p{N}]+"), " ").trim() + " "
    private fun has(w: String, phrase: String): Boolean { val p = words(phrase); return p.isNotBlank() && w.contains(p) }
    private fun norm(s: String) = s.lowercase().filter { it.isLetterOrDigit() }

    // How well an offline task's keywords fit the text. Whole words only; a longer phrase counts more.
    fun score(keywords: List<String>, text: String): Int {
        val w = words(text)
        return keywords.sumOf { k -> if (has(w, k)) words(k).trim().split(" ").size else 0 }
    }

    // A problem needs the helper, not a "turn it on" task or an app opening by itself.
    private val problemWords = listOf("not working", "doesn't", "does not", "doesnt", "won't", "wont", "can't", "cant", "cannot",
        "problem", "keeps", "stopped", "error", "failed", "fails", "slow", "not opening", "not showing", "disconnect", "disconnects",
        "disconnecting", "broken", "fix", "hacked", "stuck")
    fun isProblem(text: String): Boolean {
        val w = words(text)
        return w.startsWith(" why ") || w.startsWith(" what ") || problemWords.any { has(w, it) }   // " whatsapp " is not " what "
    }

    // Money tasks are never guided on screen (money apps are off limits).
    private val money = Regex("\\b(mobile money|momo|airtel money|zamtel kwacha|kwacha|send(ing)? money|withdraw\\w*|cash ?out|" +
        "transfer\\w* (money|funds|cash)|pay(ing)? (a |my |the |for )?(\\w+ )?bills?|bank transfer|deposit|banking|bank account|bank app)\\b",
        RegexOption.IGNORE_CASE)
    fun isMoney(text: String) = money.containsMatchIn(text)

    // A question about doing something ("How do I scan a document?", "Which app can edit videos?"). The installed app
    // names go with it, so the helper picks an app the person already has, or names one to install from the Play Store.
    // Never for money, and never for questions about the phone itself ("Why is my phone slow?", "What is WhatsApp?").
    fun wantsApps(text: String): Boolean {
        if (isMoney(text)) return false
        val w = words(text)
        if (listOf("app", "apps", "application", "applications").any { has(w, it) }) return true
        return listOf("how", "which", "can i", "i want", "i need", "i would like", "help me", "is there", "teach me", "show me how")
            .any { w.startsWith(" $it ") }
    }

    // App names that are also ordinary words. They count only when used like an app ("open Settings", "the Camera app").
    val plainNames = setOf("phone", "files", "file manager", "messages", "messaging", "camera", "clock", "gallery", "music", "notes",
        "notepad", "contacts", "calendar", "settings", "weather", "photos", "mail", "email", "maps", "calculator", "recorder", "browser",
        "videos", "video", "radio", "compass", "health", "store", "security", "themes", "theme", "translate", "assistant", "search", "sheets")
    private val callWords = Regex("\\b(call|calls|calling|dial|dialer|dialler|keypad|phone app|call log|missed call|ring)\\b")
    private val stores = listOf("play store", "palm store", "app store", "galaxy store", "appgallery", "app gallery")
    private val installWords = Regex("\\b(install|reinstall|update)\\b")

    // The installed app a guide should open first, as (name, package), or null. apps: (label, package) of launcher apps.
    fun pickApp(goal: String, apps: List<Pair<String, String>>): Pair<String, String>? {
        val low = goal.lowercase()
        // Installing or updating happens in the store, even when the goal names the app ("Install WhatsApp").
        apps.firstOrNull { (n, _) -> n.lowercase() in stores && Regex("(?<![\\w])" + Regex.escape(n.lowercase()) + "(?![\\w])").containsMatchIn(low) }?.let { return it }
        if (installWords.containsMatchIn(low)) apps.firstOrNull { it.first.equals("Play Store", true) }?.let { return it }
        // Google's apps are named without "Google" on the phone: "Google Drive" is the app "Drive" (seen: it opened
        // the Google search app). The longer phrase wins over "Google" at the same place.
        fun find(t: String) = (if (t != "google") Regex("(?<![\\w])google\\s+" + Regex.escape(t) + "(?![\\w])").find(low) else null) ?: run {
            val rx = if (t !in plainNames) "(?<![\\w])" + Regex.escape(t) + "(?![\\w])"
                else "(?:\\b(?:open|in|the|use|using|launch|from|to|tap|start|into|with)\\s+)" + Regex.escape(t) + "(?![\\w])|(?<![\\w])" + Regex.escape(t) + "\\s+app\\b"
            Regex(rx).find(low)
        }
        var best: Pair<String, String>? = null; var at = Int.MAX_VALUE; var len = 0
        for ((n, p) in apps) {
            val ln = n.lowercase()
            if (ln == "phone" && !callWords.containsMatchIn(low)) continue   // "on your phone" is the device
            // Its own name, another name it is known by, or its name without "Go"/"Lite" (a little weaker, so the full
            // app wins when both are on the phone)
            val base = ln.replace(lighter, "")
            val tries = listOfNotNull(ln to 0, aliases[ln]?.let { it to 0 }, if (base != ln && base.length >= 3) base to 1 else null)
            for ((t, weaker) in tries) {
                val m = find(t) ?: continue
                val next = otherApp.find(low.substring(m.range.last + 1))
                if (next != null && !t.endsWith(next.groupValues[1])) continue   // "WhatsApp" in "WhatsApp Business": another app
                val l = m.value.length - weaker
                if (m.range.first < at || (m.range.first == at && l > len)) { best = n to p; at = m.range.first; len = l }
            }
        }
        if (best == null && callWords.containsMatchIn(low)) best = apps.firstOrNull { it.first.equals("phone", true) }   // "Make a call to Mum"
        return best
    }

    // Another app with a longer name: 5 Nov, "Open the WhatsApp Business app" rang plain WhatsApp, on a phone without
    // WhatsApp Business. "WhatsApp" there is not that app; nor is YouTube in "YouTube Kids", "YouTube Music" or "YouTube Studio".
    private val otherApp = Regex("^\\s+(business|kids|music|studio)(?![\\w])")
    // Go and Lite versions do the same job, and cheaper phones (itel, Tecno, Infinix) often have them: Gmail Go, Maps Go,
    // Facebook Lite. Asked for Gmail, the phone's Gmail Go is right.
    private val lighter = Regex("\\s+(go|lite)$")
    // Names under the icon that differ from the app's own name: WhatsApp Business is "WA Business".
    private val aliases = mapOf("wa business" to "whatsapp business")
    // Never offered for installing, whatever the goal says (the same words keep these apps out of guides)
    val moneyApps = listOf("momo", "airtel", "mtn", "bank", "zanaco", "fnb", "stanbic", "absa", "finance", "wallet", "pay", "money",
        "binance", "paypal", "credit", "loan", "cash", "kwacha", "natsave", "investrust", "lupiya", "mukuru", "worldremit", "remit")
    // "the TikTok app": a name in capitals just before "app"
    private val namedApp = Regex("(?:^|\\b(?i:open|the|use|using|in|on|with|from|launch|start)\\s+)((?:[A-Z][\\w!+.'-]*\\s+){0,2}[A-Z][\\w!+.'-]*)\\s+(?i:app)\\b")

    // The app a goal asks for that is not on this phone, or null. Only a name it is sure of: another version of an
    // installed app ("WhatsApp Business" next to "WhatsApp"), or a name in capitals before "app" ("the TikTok app") that
    // is not an ordinary word. Never banking or money apps, never a store, never ScreenGuide. installed: the app names.
    fun missingApp(goal: String, installed: List<String>): String? {
        val low = goal.lowercase()
        if (isMoney(goal) || installWords.containsMatchIn(low) || pickApp(goal, installed.map { it to it }) != null) return null
        val name = installed.firstNotNullOfOrNull { n ->
            Regex("(?<![\\w])" + Regex.escape(n.lowercase()) + "\\s+(business|kids|music|studio)(?![\\w])").find(low)?.let { goal.substring(it.range) }
        } ?: namedApp.find(goal)?.groupValues?.get(1) ?: return null
        val ln = name.lowercase()
        if (ln in plainNames || ln in stores || ln.replace(" ", "") == "screenguide" || moneyApps.any { ln.contains(it) }) return null
        return name
    }

    // ---- ScreenGuide's own settings (6 Nov, the owner chose: Show me works inside ScreenGuide too). Its menus never
    // change, so the way there is known: no AI, and nothing from the chat leaves the phone. First match wins, so the more
    // particular words come first ("chat colour" is the chat background, not Colours).
    private val ownSettings = listOf(
        listOf("smart guide") to "Smart guide (AI)",
        listOf("screen pictures", "screen picture") to "Screen pictures when words are not enough",
        listOf("scam guard") to "Scam guard",
        listOf("read button") to "Read button: reads any screen to you",
        listOf("error messages", "error message") to "Explain error messages")
    private val ownCustomize = listOf(
        listOf("chat background", "background", "wallpaper", "chat theme", "chat colour", "chat color", "skin") to "Chat background",
        listOf("language") to "Language",
        listOf("record", "real voice", "own voice") to "Record a real voice for the steps",
        listOf("speaking speed", "speed", "slower", "faster") to "Speaking speed",
        listOf("speak the steps", "voice", "sound", "mute", "speak") to "Speak the steps",
        listOf("step card", "card size", "card bigger", "bigger card") to "Size of the step card",
        listOf("how i explain", "explain", "simpler words") to "How I explain",
        listOf("dark mode", "light mode", "colours", "colors", "theme", "dark", "light") to "Colours",
        listOf("vibrate", "vibration") to "Vibrate on each step",
        listOf("my name", "your name", "name") to "Your name")
    private val ownMenu = listOf(
        listOf("account", "sign in", "sign out", "log in", "log out", "login") to "Your account",
        listOf("incognito") to "Incognito",
        listOf("plan", "plus", "subscription") to "Your plan",
        listOf("chat history", "old chats", "chats") to "Chats",
        listOf("stay safe", "scams") to "Stay safe from scams",
        listOf("teach a task", "teach") to "Teach a task",
        listOf("shared guide", "share code") to "Open a shared guide",
        listOf("help from someone", "someone to help") to "Get help from someone",
        listOf("learn your phone") to "Learn your phone",
        listOf("about", "version") to "About ScreenGuide",
        listOf("settings", "permissions") to "Settings and permissions")

    fun aboutScreenGuide(goal: String): Boolean { val w = words(goal); return has(w, "screenguide") || has(w, "screen guide") }

    // The way to one of ScreenGuide's own settings, inside ScreenGuide, or null when the goal is not about ScreenGuide
    fun selfPath(goal: String): List<String>? {
        if (!aboutScreenGuide(goal)) return null
        val w = words(goal.replace(Regex("(?i)screen\\s*guide('?s)?"), " "))
        fun pick(list: List<Pair<List<String>, String>>) = list.firstOrNull { (ks, _) -> ks.any { has(w, it) } }?.second
        pick(ownSettings)?.let { return listOf("Menu", "Settings and permissions", it) }
        pick(ownCustomize)?.let { return listOf("Menu", "Customize ScreenGuide", it) }
        pick(ownMenu)?.let { return listOf("Menu", it) }
        return listOf("Menu")   // not sure what: open the menu, they choose
    }
    // What to say when the last row is tapped, or null for the usual "Well done!"
    fun selfDone(row: String): String? = when (row) {
        "Chat background" -> "Now tap a colour, or Your photo for a picture from your gallery."
        "Your account" -> "Now tap Sign out, or Sign in with Google."
        "Language" -> "Now tap your language."
        "Menu" -> "Now tap what you want to change."
        else -> null
    }
    // Did the person just tap the last row? (MainActivity's menus say which row was tapped: Guides.ownTap)
    fun selfFinished(lastRow: String, tapped: String?): Boolean =
        tapped != null && norm(tapped).isNotEmpty() && norm(tapped) == norm(lastRow)
    // Every row name a path can use (SelfGuideTest checks they are all in MainActivity's menus)
    fun selfRows(): List<String> = (listOf("Menu", "Settings and permissions", "Customize ScreenGuide") +
        (ownSettings + ownCustomize + ownMenu).map { it.second }).distinct()

    // Very short requests open an app at once ("weather", "set an alarm"). Never when another app is named or something
    // is being sent ("send a photo from my gallery on WhatsApp"), never for how/why/what questions or problems.
    private val quick = listOf(
        listOf("weather", "forecast", "will it rain") to listOf("weather"),
        listOf("alarm", "timer", "stopwatch") to listOf("clock"),
        listOf("calculator", "calculate") to listOf("calculator"),
        listOf("take a photo", "take a picture", "take a selfie", "camera") to listOf("camera"),
        listOf("gallery", "my pictures", "my photos") to listOf("gallery", "photos"),
        listOf("calendar") to listOf("calendar"),
        listOf("directions", "maps") to listOf("maps"))
    fun quickTarget(text: String, appLabels: List<String>): List<String>? {
        val w = words(text)
        if (w.trim().split(" ").size > 7 || isProblem(text) || isMoney(text)) return null
        if (listOf("how", "why", "what", "where", "can", "could").any { w.startsWith(" $it ") }) return null
        if (Regex("\\b(send|share|upload|post|attach|forward|delete|edit)\\b").containsMatchIn(w)) return null
        if (appLabels.any { a -> a.length >= 3 && a.lowercase() !in plainNames && has(w, a) }) return null   // another app is named
        return quick.firstOrNull { (terms, _) -> terms.any { has(w, it) } }?.second
    }

    // "open X", "find X", "where is X": the launcher app it names, or null. "find my phone" is the device, not an app.
    fun findTarget(text: String, appLabels: List<String>): String? {
        val t = text.trim().lowercase().trimEnd('?', '.', '!')
        for (p in listOf("open ", "find ", "where is ", "where's ", "launch ", "go to ", "start ")) {
            if (!t.startsWith(p)) continue
            val rest = t.removePrefix(p).trim()
            if (rest.split(Regex("\\s+")).size > 3) return null
            val bare = rest.removePrefix("the ").removePrefix("my ").removeSuffix(" app").trim()
            if (bare == "phone" && !rest.endsWith(" app") && !(p == "open " && !rest.startsWith("my "))) return null
            val n = norm(bare)
            if (n.length < 3) return null
            return appLabels.firstOrNull { norm(it) == n } ?: appLabels.firstOrNull { norm(it).startsWith(n) }
        }
        return null
    }
}
