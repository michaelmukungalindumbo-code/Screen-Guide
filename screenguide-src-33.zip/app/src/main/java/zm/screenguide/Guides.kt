package zm.screenguide

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class Step(val match: List<String>, val say: Map<String, String>, val audio: String?, val toggle: Boolean = false, val skipIn: String? = null, val titles: List<String>? = null)
class Guide(val id: String, val title: Map<String, String>, val done: Map<String, String>, val steps: List<Step>, val keywords: List<String>, val doneWhen: String? = null, val hint: Map<String, String>? = null, val by: String? = null)

object Guides {
    var all: List<Guide> = emptyList()
    var active: Guide? = null
    var index = 0
    var lang = "en"
    fun setLang(c: Context, l: String) { lang = l; c.getSharedPreferences("sg", Context.MODE_PRIVATE).edit().putString("lang", l).apply() }
    var lastSeen = ""
    // Smart guide: the AI picks the next button from the words on screen.
    var aiGoal = ""
    var aiStep: Step? = null
    var aiAsked = 0
    var aiFp = 0
    var aiStuck = false
    var aiNeedsApps = false
    var aiPlan: List<String> = emptyList()
    var aiThinking = false
    // What the "Tell me why" chat needs to know about the screen the person is stuck on.
    var chatLabels: List<String> = emptyList()
    var chatGoal = ""
    var chatHistory: List<String> = emptyList()
    var chatPkg = ""
    var chatSet: Set<String> = emptySet()
    var aiPkg = ""
    var aiLabels: Set<String> = emptySet()
    var aiLast = 0L
    var aiBusy = false
    val aiHistory = ArrayList<String>()
    fun aiReset(goal: String) { aiGoal = goal; aiStep = null; aiAsked = 0; aiFp = 0; aiStuck = false; aiThinking = false; aiPlan = emptyList(); aiPkg = ""; aiLabels = emptySet(); aiLast = 0L; aiBusy = false; aiHistory.clear() }
    // The chat found a next step: continue the guide from it (built-in guides become Smart guides).
    fun adopt(label: String?, say: String, lang: String) {
        val g = active ?: return
        if (g.id != "ai") { aiReset(chatGoal); active = Guide("ai", g.title, g.done, emptyList(), emptyList()) }
        aiStep = Step(if (label != null) listOf(label) else emptyList(), mapOf(lang to say), null)
        aiPkg = chatPkg; aiLabels = chatSet; aiLast = System.currentTimeMillis(); aiBusy = false; aiThinking = false
    }
    val seen = LinkedHashMap<String, String>()   // last screen text per app, for the debug copy

    fun step(): Step? = active?.steps?.getOrNull(index)

    private fun map(o: JSONObject) = o.keys().asSequence().associateWith { o.getString(it) }
    private fun strings(a: JSONArray?) = if (a == null) emptyList() else (0 until a.length()).map { a.getString(it) }

    private var builtIn: List<Guide> = emptyList()

    // A broken guide is skipped, never allowed to crash the app.
    private fun parse(arr: JSONArray): List<Guide> = (0 until arr.length()).mapNotNull { i ->
        try {
            val g = arr.getJSONObject(i)
            val st = g.getJSONArray("steps")
            val steps = (0 until st.length()).map { j ->
                val o = st.getJSONObject(j)
                Step(strings(o.getJSONArray("match")), map(o.getJSONObject("say")), o.optString("audio").ifEmpty { null }, o.optBoolean("toggle"), o.optString("skipIn").ifEmpty { null }, o.optJSONArray("titles")?.let { strings(it) })
            }
            if (steps.isEmpty()) null
            else Guide(g.getString("id"), map(g.getJSONObject("title")), map(g.getJSONObject("done")), steps, strings(g.optJSONArray("keywords")),
                g.optString("doneWhen").ifEmpty { null }, null, g.optString("by").ifEmpty { null })
        } catch (e: Exception) { null }
    }

    fun load(c: Context) {
        lang = c.getSharedPreferences("sg", Context.MODE_PRIVATE).getString("lang", lang) ?: lang   // remembered between visits
        if (all.isNotEmpty()) return
        builtIn = parse(JSONArray(c.assets.open("guides.json").bufferedReader().readText()))
        all = builtIn
        c.getSharedPreferences("sg", Context.MODE_PRIVATE).getString("remote_guides", null)?.let { merge(it) }
    }

    // Guides from the server replace built-in ones with the same id, or are added after them.
    private fun merge(text: String): Boolean = try {
        val t = text.trim()
        val arr = if (t.startsWith("[")) JSONArray(t) else JSONObject(t).optJSONArray("guides") ?: JSONArray()
        val remote = parse(arr)
        if (remote.isEmpty()) false
        else {
            val byId = LinkedHashMap<String, Guide>()
            builtIn.forEach { byId[it.id] = it }
            remote.forEach { byId[it.id] = it }
            all = byId.values.toList()
            true
        }
    } catch (e: Exception) { false }

    fun applyRemote(c: Context, text: String): Boolean {
        val prefs = c.getSharedPreferences("sg", Context.MODE_PRIVATE)
        if (prefs.getString("remote_guides", null) == text) return false
        if (!merge(text)) return false
        prefs.edit().putString("remote_guides", text).apply()
        return true
    }
}

// Counters kept on the phone only, for the pilot. No screen words, no names.
object Stats {
    private fun prefs(c: android.content.Context) = c.getSharedPreferences("stats", android.content.Context.MODE_PRIVATE)
    fun inc(c: android.content.Context, key: String) { val p = prefs(c); p.edit().putInt(key, p.getInt(key, 0) + 1).apply() }
    // The last few questions that got a thumbs-down, on this phone only, so the pilot can show what to fix.
    fun remember(c: android.content.Context, key: String, text: String) {
        val p = prefs(c)
        val arr = try { JSONArray(p.getString("r_$key", "[]")) } catch (e: Exception) { JSONArray() }
        arr.put(text.take(80))
        val keep = JSONArray()
        for (i in maxOf(0, arr.length() - 8) until arr.length()) keep.put(arr.getString(i))
        p.edit().putString("r_$key", keep.toString()).apply()
    }
    fun dump(c: android.content.Context): String {
        val p = prefs(c)
        val counts = listOf("questions", "started", "finished", "stopped", "stuck", "ai_steps", "screen_pictures", "thumbs_up", "thumbs_down")
            .joinToString("\n") { "$it: ${p.getInt(it, 0)}" }
        val bad = try { JSONArray(p.getString("r_bad", "[]")) } catch (e: Exception) { JSONArray() }
        if (bad.length() == 0) return counts
        return counts + "\nRecent thumbs-down questions:\n" + (0 until bad.length()).joinToString("\n") { "- " + bad.getString(it) }
    }
}
