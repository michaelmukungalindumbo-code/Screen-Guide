package zm.screenguide

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.ScreenshotResult
import android.accessibilityservice.AccessibilityService.TakeScreenshotCallback
import android.os.Build
import android.view.Display
import android.animation.ValueAnimator
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.widget.TextView
import android.media.MediaPlayer
import android.net.wifi.WifiManager
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityWindowInfo
import android.widget.LinearLayout
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.Locale

class RingView(c: Context) : View(c) {
    var arrowBelow = true
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 8f; color = 0xFFF0A935.toInt() }
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = 0xE6FFFFFF.toInt() }
    private val edgeP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 5f; color = 0xFFFFA45B.toInt() }
    private val glowP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 14f; color = 0xCCFFA45B.toInt(); maskFilter = BlurMaskFilter(18f, BlurMaskFilter.Blur.NORMAL) }
    private val areaP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = 0x26FFA45B }
    init { setLayerType(LAYER_TYPE_SOFTWARE, null) }   // needed for the soft glow
    private val still = Settings.Global.getFloat(c.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f
    private var t = 0f
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1200; repeatCount = ValueAnimator.INFINITE
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); if (!still) anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }
    override fun onDraw(c: Canvas) {
        val a = 118f
        val top = if (arrowBelow) 0f else a
        val bottom = height - (if (arrowBelow) a else 0f)
        p.alpha = 255
        val box = RectF(26f, top + 26f, width - 26f, bottom - 26f)
        c.drawRoundRect(box, 30f, 30f, areaP)
        c.drawRoundRect(box, 30f, 30f, glowP)
        c.drawRoundRect(box, 30f, 30f, p)
        if (!still) {
            val g = 26f - 22f * t
            p.alpha = (255 * (1 - t)).toInt()
            c.drawRoundRect(RectF(g, top + g, width - g, bottom - g), 34f, 34f, p)
        }
        // A pointing arrow that bobs toward the target.
        val bob = if (still) 0f else 14f * kotlin.math.sin(t * 6.2831855f)
        val cx = width / 2f
        val s = if (arrowBelow) 1f else -1f
        val tip = if (arrowBelow) bottom - 26f + 12f - bob else top + 26f - 12f + bob
        val path = Path()
        path.moveTo(cx, tip)
        path.lineTo(cx - 34f, tip + s * 44f); path.lineTo(cx - 14f, tip + s * 44f)
        path.lineTo(cx - 14f, tip + s * 84f); path.lineTo(cx + 14f, tip + s * 84f)
        path.lineTo(cx + 14f, tip + s * 44f); path.lineTo(cx + 34f, tip + s * 44f); path.close()
        c.drawPath(path, fillP); c.drawPath(path, edgeP)
    }
}

class GuideService : AccessibilityService(), TextToSpeech.OnInitListener {
    private var wm: WindowManager? = null
    private var ring: RingView? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var spokenFor = -1
    private var mp: MediaPlayer? = null
    private var label: TextView? = null
    private var holdUntil = 0L
    private var findPkg: String? = null
    private var lastGuide: Guide? = null
    private val handler = Handler(Looper.getMainLooper())

    override fun onServiceConnected() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        tts = TextToSpeech(this, this)
        Guides.load(this)
    }
    override fun onInit(s: Int) { ttsReady = s == TextToSpeech.SUCCESS }
    override fun onInterrupt() {}
    override fun onDestroy() { hide(); hideLabel(); hideControls(); tts?.shutdown(); mp?.release(); super.onDestroy() }

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        val guide = Guides.active ?: run { hide(); hideControls(); return }
        val clicked = e.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED && e.packageName?.toString() != packageName
        if (clicked) bumpProgress()
        if (guide.id == "ai") {
            if (clicked) Guides.aiStep = null   // any tap is progress: ask for the next step
            schedule(e); return
        }
        // Final step: the person tapped the switch, so we are done.
        val last = guide.steps.last()
        if (e.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED && last.toggle && Guides.index == guide.steps.size - 1 && !stateKnown(guide)) {
            val src = e.source
            if (src != null) {
                val r = Rect(); src.getBoundsInScreen(r)
                val belowTitle = r.top > resources.displayMetrics.heightPixels * 0.12
                if (belowTitle && (matches(src, last.match) || matches(src.parent, last.match))) { finish(guide); return }
            }
        }
        schedule(e)
    }

    private fun schedule(e: AccessibilityEvent) {
        val own = e.packageName?.toString() == packageName
        val changed = e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && !own
        if (changed) { hide(); bumpProgress(); lostSince = 0L }   // drop the old ring at once, show the new one when the screen settles
        handler.removeCallbacks(refreshRun)
        handler.postDelayed(refreshRun, if (changed) 300L else 150L)
        if (changed) { handler.removeCallbacks(lateRun); handler.postDelayed(lateRun, 800) }
    }

    private val refreshRun = Runnable { refresh() }
    private val lateRun = Runnable { refresh() }

    private fun refresh() {
        val guide = Guides.active ?: run { hide(); return }
        val root = rootInActiveWindow ?: run { if (classify() == "shade") { hide(); hideControls() }; return }
        val pkg = root.packageName?.toString() ?: ""
        if (pkg == packageName) { hide(); hideControls(); return }
        surface = classify()
        if (surface == "shade") { hide(); hideControls(); return }   // notification shade or quick settings is open
        showControls()
        if (guide !== lastGuide) { lastGuide = guide; findPkg = null }
        // "Find an app" guide: finished once the person has left the screen where the icon was.
        if (guide.id == "find" && findPkg != null && pkg != findPkg && pkg.isNotEmpty() && !pkg.contains("systemui", true)) { findPkg = null; finish(guide); return }
        val nodes = candidates(root)
        val dm0 = resources.displayMetrics
        val dump = nodes.filter { !it.isPassword }.mapNotNull { n ->
            val t = (n.text ?: n.contentDescription)?.toString()?.takeIf { it.isNotBlank() } ?: return@mapNotNull null
            val r = Rect(); n.getBoundsInScreen(r)
            "$t@${r.top * 100 / dm0.heightPixels}%" + (n.className?.toString() ?: "").substringAfterLast('.')
        }.take(70).joinToString(" | ")
        Guides.seen.remove(pkg); Guides.seen[pkg] = "$pkg (h=${dm0.heightPixels}): $dump"
        while (Guides.seen.size > 3) Guides.seen.remove(Guides.seen.keys.first())
        if (guide.id == "ai") { aiRefresh(guide, nodes, pkg); return }
        // Show the LATEST step whose target is on screen. This skips steps a phone brand doesn't have.
        for (i in guide.steps.size - 1 downTo 0) {
            val skip = guide.steps[i].skipIn
            if (skip != null && pkg.contains(skip, true)) continue
            syntheticRect = null
            val node = find(nodes, guide.steps[i]) ?: continue
            if (guide.id == "find") findPkg = pkg
            if (guide.steps[i].toggle && (node.isChecked || isDone(guide))) { finish(guide); return }
            Guides.index = i; lostSince = 0L
            val r = Rect(); node.getBoundsInScreen(r)
            syntheticRect?.let { r.set(it) }
            show(r)
            track(if (syntheticRect == null) node else null)
            val st = guide.steps[i]
            showLabel(st.say[Guides.lang] ?: st.say["en"] ?: "", r.centerY() > resources.displayMetrics.heightPixels / 2, false,
                "Step ${i + 1} of ${guide.steps.size}")
            if (spokenFor != i) { spokenFor = i; speak(guide.steps[i]); buzz(false) }
            // On the last step, keep checking the real phone state until the task is done.
            if (guide.doneWhen != null && i == guide.steps.size - 1) { handler.removeCallbacks(refreshRun); handler.postDelayed(refreshRun, 700) }
            return
        }
        hide()
        if (guide.id == "find") { guide.hint?.let { showLabel(it[Guides.lang] ?: it["en"] ?: "", false) }; return }
        // Nothing to point at on this screen: never leave the person with nothing. Say what to look for, and how.
        val st = guide.steps.getOrNull(Guides.index) ?: guide.steps.firstOrNull() ?: return
        val now = System.currentTimeMillis()
        if (lostSince == 0L) lostSince = now
        if (now - lostSince < 1200) { handler.removeCallbacks(refreshRun); handler.postDelayed(refreshRun, 1300); return }   // the screen may still be loading
        val where = if (isHome(pkg)) "Not on this screen? Swipe up to see all your apps." else "Not on this screen? Go back, or press Home."
        showLabel(st.say[Guides.lang] ?: st.say["en"] ?: "", false, false, where)
    }

    private var lostSince = 0L
    private var homePkg: String? = null
    private fun isHome(pkg: String): Boolean {
        if (homePkg == null) homePkg = try {
            packageManager.resolveActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0)?.activityInfo?.packageName ?: ""
        } catch (e: Exception) { "" }
        return pkg.isNotEmpty() && (pkg == homePkg || pkg.contains("launcher", true))
    }

    // ---- Smart guide: the AI picks the next button from the words on screen ----
    private val blockedApps = listOf("momo", "airtel", "mtn", "bank", "zanaco", "fnb", "stanbic", "absa", "finance", "wallet", "pay", "money", "binance", "paypal", "credit", "loan", "cash")
    private fun sensitive(pkg: String, nodes: List<AccessibilityNodeInfo>) = blockedApps.any { pkg.contains(it, true) } || nodes.any { it.isPassword }

    // Names of apps on the phone (names only), minus banking, money and wallet apps. Sent once, only for "which app" questions.
    private fun installedApps(): List<String> = try {
        val launch = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        packageManager.queryIntentActivities(launch, 0)
            .filter { ri ->
                val label = ri.loadLabel(packageManager).toString()
                blockedApps.none { ri.activityInfo.packageName.contains(it, true) || label.contains(it, true) }
            }
            .map { it.loadLabel(packageManager).toString().trim() }
            .filter { it.isNotEmpty() && it.length <= 40 }
            .distinct().sorted().take(120)
    } catch (e: Exception) { emptyList() }

    // The on/off switch that belongs to this word's row, if there is one (switches have no words of their own).
    private fun switchNear(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        fun walk(x: AccessibilityNodeInfo?, d: Int): AccessibilityNodeInfo? {
            if (x == null || d > 2) return null
            if (isSwitchLike(x) && x.isVisibleToUser) return x
            for (i in 0 until x.childCount) walk(x.getChild(i), d + 1)?.let { return it }
            return null
        }
        return walk(n, 0) ?: walk(n.parent, 1)
    }

    private fun tappable(n: AccessibilityNodeInfo): Boolean {
        var c: AccessibilityNodeInfo? = n
        repeat(4) { if (c?.isClickable == true) return true; c = c?.parent }
        return false
    }

    // Words on screen, each tagged so the AI can tell switches and buttons from plain text.
    private fun taggedLabels(nodes: List<AccessibilityNodeInfo>): List<String> {
        val out = LinkedHashSet<String>()
        for (n in nodes) {
            if (n.isPassword) continue
            val t = (n.text ?: n.contentDescription)?.toString()?.trim() ?: continue
            if (t.isEmpty() || t.length > 50 || Regex("\\d{5,}").containsMatchIn(t) || t.contains("@")) continue
            val tag = if (switchNear(n) != null) "[switch]" else if (tappable(n)) "[tap]" else "[text]"
            out.add("$t $tag")
            if (out.size >= 70) break
        }
        return out.toList()
    }

    private fun hideRing() {
        ringAnim?.cancel(); ringLp = null; trackNode = null; handler.removeCallbacks(trackRun)
        ring?.let { try { wm?.removeView(it) } catch (_: Exception) {} }; ring = null
    }

    private fun aiRefresh(guide: Guide, nodes: List<AccessibilityNodeInfo>, pkg: String) {
        if (askCard != null || capturing) { hideRing(); return }   // waiting for the person's answer, or taking the picture
        if (sensitive(pkg, nodes)) {   // nothing is sent from these screens
            hideRing(); showLabel("For your safety I cannot guide you on this screen. Please do it yourself, or ask someone you trust.", false); return
        }
        val now = nodes.mapNotNull { (it.text ?: it.contentDescription)?.toString() }.take(60).toSet()
        // Still the same screen as when we last asked? (same app, and most words unchanged)
        val same = pkg == Guides.aiPkg && (Guides.aiLabels.isEmpty() || now.intersect(Guides.aiLabels).size >= 0.5 * minOf(now.size, Guides.aiLabels.size))
        val st = Guides.aiStep
        if (st != null && same) {
            val pr = pointRect
            if (st === pointFor && pr != null) {   // a button with no words, found in the screen picture
                show(Rect(pr))
                showLabel(st.say[Guides.lang] ?: st.say["en"] ?: "", pr.centerY() > resources.displayMetrics.heightPixels / 2, false, aiProgress())
                return
            }
            val node = if (st.match.isNotEmpty()) find(nodes, st) else null
            if (node != null) {
                val rn = switchNear(node) ?: node   // point at the real switch, not just its word
                val r = Rect(); rn.getBoundsInScreen(r); show(r); track(rn)
                showLabel(st.say[Guides.lang] ?: st.say["en"] ?: "", r.centerY() > resources.displayMetrics.heightPixels / 2, false, aiProgress())
            } else { hideRing(); showLabel(st.say[Guides.lang] ?: st.say["en"] ?: "", false, false, aiProgress()) }
            return
        }
        // A new screen, or no step yet: ask again, but not more often than every 2 seconds.
        hideRing(); if (!Guides.aiThinking) showLabel(st?.say?.get(Guides.lang) ?: st?.say?.get("en") ?: "Looking\u2026", false, st != null)
        if (!Guides.aiBusy) {
            if (System.currentTimeMillis() - Guides.aiLast > 2000) askNext(guide, nodes, pkg)
            else { handler.removeCallbacks(refreshRun); handler.postDelayed(refreshRun, 2100) }
        }
    }

    private fun askNext(guide: Guide, nodes: List<AccessibilityNodeInfo>, pkg: String) {
        if (Guides.aiAsked >= 20) {
            Guides.active = null; hideRing(); holdUntil = System.currentTimeMillis() + 4000
            showLabel("Let’s stop here. Ask me again if you still need help.", false); handler.postDelayed({ hideLabel() }, 4000); return
        }
        val labels = taggedLabels(nodes)
        val stuck = Guides.aiStuck
        // After "?", a picture of the screen helps find buttons that have no words (icons, switches).
        val wantShot = stuck && Build.VERSION.SDK_INT >= 30 && getSharedPreferences("sg", MODE_PRIVATE).getBoolean("shot_ok", false)
        if (labels.isEmpty() && !wantShot) return
        Stats.inc(this, "ai_steps"); Guides.aiBusy = true; Guides.aiAsked++; Guides.aiPkg = pkg; Guides.aiLast = System.currentTimeMillis()
        Guides.aiLabels = nodes.mapNotNull { (it.text ?: it.contentDescription)?.toString() }.take(60).toSet()
        Guides.aiStuck = false
        val goal = Guides.aiGoal; val lang = Guides.lang; val hist = ArrayList(Guides.aiHistory); val plan = Guides.aiPlan
        val apps = if (Guides.aiNeedsApps) { Guides.aiNeedsApps = false; installedApps() } else emptyList()
        val id = Server.installId(this)
        fun send(image: String) {
            if (image.isNotEmpty()) Stats.inc(this, "screen_pictures")
            Thread {
                val r = Server.next(goal, lang, id, labels, hist, stuck, apps, "", plan, image, level())
                handler.post {
                    Guides.aiBusy = false; Guides.aiThinking = false; handler.removeCallbacks(thinkRun)
                    if (Guides.active !== guide) return@post
                    if (!r.ok) {
                        val err = Step(emptyList(), mapOf(lang to r.say.trimEnd('.') + ". Tap Help to try again."), null)
                        Guides.aiStep = err; pointFor = null; pointRect = null
                        speak(err); refresh(); return@post
                    }
                    if (r.done) {
                        finish(Guide(guide.id, guide.title, mapOf(lang to r.say), emptyList(), emptyList()))
                        return@post
                    }
                    val say = tighten(r.say, r.label != null)
                    Guides.aiHistory.add(say)
                    val step = Step(if (r.label != null) listOf(r.label) else emptyList(), mapOf(lang to say), null)
                    Guides.aiStep = step
                    val rx = r.x; val ry = r.y
                    if (r.label == null && rx != null && ry != null && image.isNotEmpty() && shotW > 0) {
                        val cx = (rx * shotW).toInt(); val cy = (ry * shotH).toInt(); val half = dp(30)
                        pointFor = step; pointRect = Rect(cx - half, cy - half, cx + half, cy + half)
                    } else { pointFor = null; pointRect = null }
                    speak(step); buzz(false)
                    refresh()
                }
            }.start()
        }
        if (wantShot) captureScreen { send(it) } else send("")
    }

    // "Step 2 of 4": from the AI's plan when there is one.
    private fun aiProgress(): String? {
        val k = Guides.aiHistory.size
        val m = Guides.aiPlan.size
        return if (k <= 0) null else if (m in k..12) "Step $k of $m" else "Step $k"
    }

    // New users get the simplest words; confident users get very short ones. Worked out on the phone from counts only.
    private fun level(): String {
        val p = getSharedPreferences("stats", MODE_PRIVATE)
        val done = p.getInt("finished", 0); val stuck = p.getInt("stuck", 0)
        return if (done < 3 || stuck > done) "new" else if (done >= 10 && stuck * 3 < done) "confident" else "some"
    }

    // A light tick for each new step, a stronger one when the task is done. Follows the phone's touch-feedback setting.
    private fun buzz(done: Boolean) {
        val v: View = label ?: ring ?: return
        val kind = if (!done) android.view.HapticFeedbackConstants.CLOCK_TICK
            else if (Build.VERSION.SDK_INT >= 30) android.view.HapticFeedbackConstants.CONFIRM
            else android.view.HapticFeedbackConstants.LONG_PRESS
        try { v.performHapticFeedback(kind) } catch (e: Exception) {}
    }

    // ---- A picture of the screen: only after "?", only if the person agreed, never on bank, money or password screens ----
    private var capturing = false
    private var shotW = 0
    private var shotH = 0
    private var pointFor: Step? = null
    private var pointRect: Rect? = null
    private var askCard: LinearLayout? = null

    private fun captureScreen(done: (String) -> Unit) {
        if (Build.VERSION.SDK_INT < 30) { done(""); return }
        capturing = true
        hideRing(); hideLabel(); controls?.visibility = View.INVISIBLE   // keep our own drawings out of the picture
        fun finishShot(out: String) {
            capturing = false; controls?.visibility = View.VISIBLE
            done(out)
        }
        handler.postDelayed({
            try {
                takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
                    override fun onSuccess(result: ScreenshotResult) {
                        var out = ""
                        try {
                            val hb = result.hardwareBuffer
                            val sw = Bitmap.wrapHardwareBuffer(hb, result.colorSpace)?.copy(Bitmap.Config.ARGB_8888, false)
                            hb.close()
                            if (sw != null) { shotW = sw.width; shotH = sw.height; out = encodeShot(sw) }
                        } catch (e: Exception) {}
                        finishShot(out)
                    }
                    override fun onFailure(errorCode: Int) { finishShot("") }
                })
            } catch (e: Exception) { finishShot("") }
        }, 180)
    }

    private fun encodeShot(b: Bitmap): String {
        val m = maxOf(b.width, b.height)
        val s = if (m > 1024) Bitmap.createScaledBitmap(b, b.width * 1024 / m, b.height * 1024 / m, true) else b
        val o = java.io.ByteArrayOutputStream()
        s.compress(Bitmap.CompressFormat.JPEG, 70, o)
        return android.util.Base64.encodeToString(o.toByteArray(), android.util.Base64.NO_WRAP)
    }

    // Asked once, the first time the person taps "?". The answer can be changed later in the app's menu.
    private fun askShotConsent() {
        val w = wm ?: return
        if (askCard != null) return
        Guides.aiThinking = false; handler.removeCallbacks(thinkRun); hideLabel(); hideRing()
        val prefs = getSharedPreferences("sg", MODE_PRIVATE)
        fun answer(ok: Boolean) {
            prefs.edit().putBoolean("shot_ok", ok).apply()
            askCard?.let { try { w.removeView(it) } catch (_: Exception) {} }; askCard = null
            Guides.aiThinking = true; thinkDots = 0; thinkStart = System.currentTimeMillis()
            handler.removeCallbacks(thinkRun); handler.post(thinkRun)
            handler.removeCallbacks(refreshRun); handler.post(refreshRun)
        }
        fun button(t: String, fill: Int, fg: Int, ok: Boolean) = TextView(this).apply {
            text = t; textSize = 16f; setTextColor(fg); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            background = GradientDrawable().apply { setColor(fill); cornerRadius = dp(22).toFloat() }
            setPadding(dp(18), dp(12), dp(18), dp(12))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { leftMargin = dp(8) }
            setOnClickListener { answer(ok) }
        }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(16), dp(16), dp(14))
            background = GradientDrawable().apply { setColor(0xF5F2F2F2.toInt()); cornerRadius = dp(24).toFloat() }
            addView(TextView(context).apply {
                text = "Can I look at a picture of your screen?"; textSize = 18f; setTextColor(0xFF1A1A1A.toInt()); typeface = Typeface.DEFAULT_BOLD
            })
            addView(TextView(context).apply {
                text = "It helps me find buttons that have no words. I only look when you tap ?, and never on bank, money or password screens."
                textSize = 15f; setTextColor(0xFF333333.toInt()); setPadding(0, dp(6), 0, dp(12))
            })
            addView(LinearLayout(context).apply {
                gravity = Gravity.END
                addView(button("No", 0x00000000, 0xFF333333.toInt(), false))
                addView(button("Yes, look", 0xFF145A3D.toInt(), Color.WHITE, true))
            })
        }
        val d = resources.displayMetrics
        val lp = WindowManager.LayoutParams((d.widthPixels * 0.92).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,   // touchable
            PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; lp.y = dp(96)
        try { w.addView(card, lp); askCard = card } catch (e: Exception) { prefs.edit().putBoolean("shot_ok", false).apply() }
    }

    // ---- Window awareness, tracking and on-screen controls ----
    private var surface = "app"
    private var imeTop: Int? = null

    // What is on top: the app, a permission pop-up, a file or photo picker, or the notification shade.
    private fun classify(): String {
        imeTop = null
        var activePkg = ""
        try {
            for (w in windows) {
                val b = Rect(); w.getBoundsInScreen(b)
                if (w.type == AccessibilityWindowInfo.TYPE_INPUT_METHOD) imeTop = b.top
                if (w.isActive) activePkg = w.root?.packageName?.toString() ?: activePkg
            }
        } catch (_: Exception) {}
        return when {
            activePkg.contains("permissioncontroller") -> "permission"
            activePkg.contains("providers.media") || activePkg.contains("photopicker") || activePkg.contains("documentsui") -> "picker"
            activePkg == "com.android.systemui" -> "shade"
            else -> "app"
        }
    }

    // Keep measuring the target so the ring follows scrolling and animations.
    private var trackNode: AccessibilityNodeInfo? = null
    private val trackRun = object : Runnable {
        override fun run() {
            val n = trackNode ?: return
            if (ring == null) return
            if (n.refresh() && n.isVisibleToUser) {
                val r = Rect(); n.getBoundsInScreen(r)
                if (!r.isEmpty && r != lastTarget) show(r)
                handler.postDelayed(this, 100)
            } else { trackNode = null; handler.removeCallbacks(refreshRun); handler.post(refreshRun) }
        }
    }
    private fun track(n: AccessibilityNodeInfo?) {
        trackNode = n; handler.removeCallbacks(trackRun)
        if (n != null) handler.postDelayed(trackRun, 100)
    }

    // Keep each instruction short. With a ring, one action is enough (the ring shows where). With nothing to
    // point at, the words must carry everything, so keep up to three sentences (for example the safety message).
    private fun tighten(say: String, pointing: Boolean): String {
        val t = say.trim()
        if (pointing) return t.substringBefore(". ").trim().split(" ").take(12).joinToString(" ")
        return t.split(Regex("(?<=[.!?])\\s+")).take(3).joinToString(" ").split(" ").take(40).joinToString(" ")
    }

    private var controls: LinearLayout? = null
    private var stuckChip: View? = null
    private val stuckRun = Runnable { stuckChip?.let { it.background = pillBg(0xFFF0A935.toInt()) } }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun pillBg(c: Int) = GradientDrawable().apply { setColor(c); cornerRadius = dp(24).toFloat() }

    // Any progress (a tap, a new screen) resets the quiet timer; after 9 seconds the "I'm stuck" button lights up.
    private fun bumpProgress() {
        stuckChip?.let { it.background = null }
        handler.removeCallbacks(stuckRun); handler.postDelayed(stuckRun, 9000)
    }

    private fun speakCurrent() {
        val g = Guides.active ?: return
        val st = if (g.id == "ai") Guides.aiStep else g.steps.getOrNull(Guides.index)
        if (st != null) speak(st)
    }

    // Asks the AI for a different way. Built-in guides switch to the Smart guide for the same goal.
    private fun onStuck() {
        val g = Guides.active ?: return
        Stats.inc(this, "stuck")
        val ok = getSharedPreferences("sg", MODE_PRIVATE).getBoolean("smart_ok", false)
        if (!Server.configured || !ok) { showLabel("Open ScreenGuide and agree to Smart guide to get help here.", false); return }
        if (g.id != "ai") {
            val goal = if (g.id == "find") "Open " + (g.title["en"] ?: "") else (g.title["en"] ?: g.id)
            Guides.aiReset(goal)
            Guides.active = Guide("ai", g.title, g.done, emptyList(), emptyList())
        }
        Guides.aiStep = null; Guides.aiLast = 0L; Guides.aiStuck = true
        // Show that the AI is thinking, and offer a chat for the person's own words.
        Guides.aiThinking = true; thinkDots = 0; thinkStart = System.currentTimeMillis()
        handler.removeCallbacks(thinkRun); handler.post(thinkRun)
        chatChip?.visibility = View.VISIBLE
        handler.removeCallbacks(hideChatRun); handler.postDelayed(hideChatRun, 25000)
        bumpProgress()
        if (Build.VERSION.SDK_INT >= 30 && !getSharedPreferences("sg", MODE_PRIVATE).contains("shot_ok")) { askShotConsent(); return }
        handler.removeCallbacks(refreshRun); handler.post(refreshRun)
    }

    private var chatChip: View? = null
    private val hideChatRun = Runnable { chatChip?.visibility = View.GONE }
    private var thinkDots = 0
    private var thinkStart = 0L
    private val thinkRun = object : Runnable {
        override fun run() {
            if (!Guides.aiThinking) return
            val waited = System.currentTimeMillis() - thinkStart
            if (rootInActiveWindow?.packageName?.toString() == packageName) { hideLabel(); handler.postDelayed(this, 450); return }   // our chat is open: it shows its own
            if (waited > 25000) {
                Guides.aiThinking = false
                showLabel("This is taking long. Check your internet, then tap Help to try again.", false)
                return
            }
            if (capturing || askCard != null) { handler.postDelayed(this, 450); return }
            thinkDots = (thinkDots + 1) % 4
            val slow = waited > 10000
            showLabel((if (slow) "Still looking. The connection is slow" else "Looking at your screen") + ".".repeat(thinkDots), false, true)
            handler.postDelayed(this, 450)
        }
    }

    // The person wants to explain in their own words: open a small chat over the current app.
    private fun openChat() {
        val g = Guides.active ?: return
        val ok = getSharedPreferences("sg", MODE_PRIVATE).getBoolean("smart_ok", false)
        if (!Server.configured || !ok) { showLabel("Open ScreenGuide and agree to Smart guide to chat here.", false); return }
        val root = rootInActiveWindow
        val pkg = root?.packageName?.toString() ?: ""
        val nodes = if (root != null) candidates(root) else emptyList()
        if (sensitive(pkg, nodes)) { showLabel("For your safety I cannot help on this screen. Please ask someone you trust.", false); return }
        Guides.chatLabels = taggedLabels(nodes)
        Guides.chatSet = nodes.mapNotNull { (it.text ?: it.contentDescription)?.toString() }.take(60).toSet()
        Guides.chatPkg = pkg
        Guides.chatGoal = if (g.id == "ai") Guides.aiGoal else if (g.id == "find") "Open " + (g.title["en"] ?: "") else (g.title["en"] ?: g.id)
        Guides.chatHistory = ArrayList(Guides.aiHistory)
        hideLabel(); hideRing()
        try { startActivity(Intent(this, HelpActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (e: Exception) { showLabel("Open ScreenGuide to chat.", false) }
    }

    private fun showControls() {
        if (controls != null) return
        val w = wm ?: return
        // Each button has a picture and a short word under it, so nobody has to guess what it does.
        fun icon(kind: String, word: String, desc: String, onTap: () -> Unit) = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; contentDescription = desc
            layoutParams = LinearLayout.LayoutParams(dp(64), dp(62))
            addView(IconView(context, kind, 0xFF1A1A1A.toInt()).apply { layoutParams = LinearLayout.LayoutParams(dp(24), dp(24)) })
            addView(TextView(context).apply {
                text = word; textSize = 11.5f; setTextColor(0xFF1A1A1A.toInt()); gravity = Gravity.CENTER; setPadding(0, dp(3), 0, 0)
                importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            })
            setOnClickListener { v -> v.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY); onTap() }
        }
        val repeat = icon("refresh", "Repeat", "Repeat the instruction") { speakCurrent() }
        val stuck = icon("help", "Help", "I am stuck, help me") { onStuck() }
        val stop = icon("close", "Stop", "Stop the guide") {
            Stats.inc(this, "stopped"); Server.event(this, "stop", Guides.active?.id ?: "unknown")
            Guides.active = null; Guides.aiStep = null; hide(); hideControls(); hideLabel()
        }
        val chat = icon("chat", "Tell me", "Tell me why I am stuck") { openChat() }
        chat.visibility = View.GONE; chatChip = chat
        stuckChip = stuck
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(4), dp(6), dp(4), dp(6))
            background = GradientDrawable().apply { setColor(0xF0F7F5F0.toInt()); cornerRadius = dp(32).toFloat(); setStroke(maxOf(1, dp(1)), 0x33000000) }
            elevation = dp(6).toFloat()
            addView(repeat); addView(stuck); addView(chat); addView(stop)
        }
        val lp = WindowManager.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,   // touchable, unlike the ring
            PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.END or Gravity.TOP; lp.x = dp(6); lp.y = dp(150)
        w.addView(col, lp); controls = col
        handler.removeCallbacks(stuckRun); handler.postDelayed(stuckRun, 9000)
    }

    // Keep the buttons on the side of the screen away from the target.
    private fun moveControls(r: Rect) {
        val c = controls ?: return
        val lp = c.layoutParams as? WindowManager.LayoutParams ?: return
        val g = (if (r.centerX() > resources.displayMetrics.widthPixels / 2) Gravity.START else Gravity.END) or Gravity.TOP
        if (lp.gravity != g) { lp.gravity = g; try { wm?.updateViewLayout(c, lp) } catch (_: Exception) {} }
    }
    private fun hideControls() {
        controls?.let { try { wm?.removeView(it) } catch (_: Exception) {} }
        controls = null; stuckChip = null; chatChip = null; handler.removeCallbacks(stuckRun)
        askCard?.let { try { wm?.removeView(it) } catch (_: Exception) {} }; askCard = null
    }

    // Phones draw switches differently; accept anything that looks like one.
    private fun isSwitchLike(n: AccessibilityNodeInfo?): Boolean {
        if (n == null) return false
        val c = n.className?.toString() ?: ""
        return n.isCheckable || c.contains("Switch") || c.contains("Toggle") || c.contains("CheckBox")
    }

    // Some phones will not tell us (hotspot is a hidden setting). Then a tap on the switch finishes the guide instead.
    private fun hotspotOn(): Boolean? = try {
        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val method = wm.javaClass.getDeclaredMethod("isWifiApEnabled"); method.isAccessible = true
        method.invoke(wm) as Boolean
    } catch (e: Throwable) { null }
    private fun stateKnown(g: Guide) = when (g.doneWhen) { null -> false; "hotspot_on" -> hotspotOn() != null; else -> true }

    // Ask Android itself whether the task is done, instead of guessing from the screen.
    private fun isDone(g: Guide): Boolean = when (g.doneWhen) {
        "wifi_on" -> try { (applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).isWifiEnabled } catch (e: Exception) { false }
        "hotspot_on" -> hotspotOn() ?: false
        "bluetooth_on" -> try { Settings.Global.getInt(contentResolver, "bluetooth_on", 0) == 1 } catch (e: Exception) { false }
        "airplane_on" -> try { Settings.Global.getInt(contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) == 1 } catch (e: Exception) { false }
        else -> false
    }

    private fun finish(g: Guide) {
        Stats.inc(this, "finished"); Server.event(this, "done", g.id)
        hide(); hideControls(); Guides.active = null; spokenFor = -1; say(g.done)
        holdUntil = System.currentTimeMillis() + 4000
        showLabel("\u2714 " + (g.done[Guides.lang] ?: g.done["en"] ?: ""), false)
        buzz(true)
        handler.postDelayed({ hideLabel() }, 4000)
    }

    private fun norm(s: String?) = (s ?: "").lowercase().filter { it.isLetterOrDigit() }

    // Every visible node on screen, as a flat list.
    private fun candidates(root: AccessibilityNodeInfo): List<AccessibilityNodeInfo> {
        val out = ArrayList<AccessibilityNodeInfo>()
        val q = ArrayDeque<AccessibilityNodeInfo>(); q.add(root)
        var seen = 0
        while (q.isNotEmpty() && seen < 800) {
            val n = q.removeFirst(); seen++
            if (n.isVisibleToUser) out.add(n)
            for (i in 0 until n.childCount) n.getChild(i)?.let { q.add(it) }
        }
        return out
    }

    // Some phones never report certain rows (e.g. Airplane mode on Infinix). If the screen's title matches
    // but the row is missing, point at the empty band between the title bar and the next heading.
    private var syntheticRect: Rect? = null
    private fun gapRow(nodes: List<AccessibilityNodeInfo>, s: Step, h: Int): AccessibilityNodeInfo? {
        val tk = (s.titles ?: s.match).map { norm(it) }
        val title = nodes.firstOrNull { n ->
            val r = Rect(); n.getBoundsInScreen(r)
            r.top <= h * 0.12 && norm(n.text?.toString()) in tk
        } ?: return null
        val tr = Rect(); title.getBoundsInScreen(tr)
        val next = nodes.mapNotNull { n ->
            if (n.text.isNullOrBlank()) return@mapNotNull null
            val r = Rect(); n.getBoundsInScreen(r)
            if (r.top > tr.bottom + h * 0.02) r.top else null
        }.minOrNull() ?: return null
        val top = tr.bottom + (h * 0.01).toInt()
        val bottom = next - (h * 0.01).toInt()
        if (bottom - top < h * 0.04) return null
        val mid = (top + bottom) / 2
        val half = minOf((bottom - top) / 2, (h * 0.045).toInt())
        val w = resources.displayMetrics.widthPixels
        syntheticRect = Rect((w * 0.03).toInt(), mid - half, (w * 0.97).toInt(), mid + half)
        return title
    }

    private fun area(n: AccessibilityNodeInfo): Long { val r = Rect(); n.getBoundsInScreen(r); return r.width().toLong() * r.height() }

    private fun find(nodes: List<AccessibilityNodeInfo>, s: Step): AccessibilityNodeInfo? {
        if (s.toggle) {
            nodes.firstOrNull { n ->
                val row = n.parent
                isSwitchLike(n) && row != null && blob(row).length < 120 && matches(row, s.match)
            }?.let { return it }
            // Fallback: the labelled row below the title bar (some phones hide the switch itself).
            val h = resources.displayMetrics.heightPixels
            val keys = s.match.map { norm(it) }
            // Only on the screen that is itself named "Wi-Fi" (label in the title bar), not on the Settings list.
            // Not on the main Settings list (its "Wi-Fi" row is a menu entry, not the switch).
            val onSettingsList = nodes.any { n ->
                val r = Rect(); n.getBoundsInScreen(r)
                r.top <= h * 0.12 && norm(n.text?.toString()) == "settings"
            }
            if (onSettingsList) return null
            val ts = s.titles
            if (ts != null) {   // only on the screen whose own title matches, not on the menu that leads to it
                val tk0 = ts.map { norm(it) }
                val okTitle = nodes.any { n -> val r = Rect(); n.getBoundsInScreen(r); r.top <= h * 0.12 && norm(n.text?.toString()) in tk0 }
                if (!okTitle) return null
            }
            val below = nodes.filter { n -> val r = Rect(); n.getBoundsInScreen(r); r.top > h * 0.12 }
            val cands = below.filter { n -> norm(n.text?.toString()) in keys || norm(n.contentDescription?.toString()) in keys }
            val row = cands.firstOrNull { switchNear(it) != null } ?: cands.minByOrNull { area(it) }
                ?: below.filter { n -> keys.any { k -> norm(n.text?.toString()).startsWith(k) } }.minByOrNull { area(it) }
                ?: return gapRow(nodes, s, h)
            return switchNear(row) ?: target(row)
        }
        val dm = resources.displayMetrics
        val maxArea = dm.widthPixels.toLong() * dm.heightPixels / 6   // ignore huge containers
        for (k in s.match) {
            val nk = norm(k)
            // Same words, ignoring odd hyphens and spacing. The smallest box is the most specific one.
            val best = nodes.filter { norm(it.text?.toString()) == nk || norm(it.contentDescription?.toString()) == nk }
                .filter { area(it) in 1L..maxArea }.minByOrNull { area(it) } ?: continue
            return target(best)
        }
        return null
    }

    // The tappable thing around the label, but never a huge container like a whole screen.
    private fun target(n: AccessibilityNodeInfo): AccessibilityNodeInfo {
        val nr = Rect(); n.getBoundsInScreen(nr)
        val d = resources.displayMetrics
        val limit = minOf(maxOf(1, nr.width() * nr.height()) * 4L, d.widthPixels.toLong() * d.heightPixels / 5)
        var c: AccessibilityNodeInfo = n
        repeat(3) {
            val p = c.parent ?: return n
            val pr = Rect(); p.getBoundsInScreen(pr)
            if (pr.width().toLong() * pr.height() > limit) return n
            if (p.isClickable) return p
            c = p
        }
        return n
    }

    private fun blob(n: AccessibilityNodeInfo?, d: Int = 0): String {
        if (n == null || d > 3) return ""
        var s = "${n.text} ${n.contentDescription} "
        for (i in 0 until n.childCount) s += blob(n.getChild(i), d + 1)
        return s
    }
    private fun matches(n: AccessibilityNodeInfo?, keys: List<String>): Boolean {
        val t = blob(n).lowercase()
        return keys.any { t.contains(it.lowercase()) }
    }

    private val ARROW = 118
    private var ringLp: WindowManager.LayoutParams? = null
    private var ringAnim: ValueAnimator? = null
    private val lastTarget = Rect()

    private fun show(r: Rect) {
        val w = wm ?: return
        moveControls(r)
        val h = resources.displayMetrics.heightPixels
        val below = r.bottom + 26 + ARROW <= h   // arrow goes under the target, or above it near the bottom edge
        val lp = WindowManager.LayoutParams(r.width() + 52, r.height() + 52 + ARROW,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = r.left - 26
        lp.y = if (below) r.top - 26 else r.top - 26 - ARROW
        lastTarget.set(r)
        val v = ring
        if (v == null) {
            ring = RingView(this).also { it.arrowBelow = below; w.addView(it, lp) }
            ringLp = lp
            return
        }
        v.arrowBelow = below; v.invalidate()
        val from = ringLp
        ringAnim?.cancel()
        val still = Settings.Global.getFloat(contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f
        if (from == null || still) { try { w.updateViewLayout(v, lp) } catch (_: Exception) {}; ringLp = lp; return }
        val fx = from.x; val fy = from.y; val tx = lp.x; val ty = lp.y
        ringLp = lp
        ringAnim = ValueAnimator.ofFloat(0f, 1f).apply {   // glide to the new spot instead of jumping
            duration = 120
            addUpdateListener { a ->
                val f = a.animatedFraction
                lp.x = (fx + (tx - fx) * f).toInt(); lp.y = (fy + (ty - fy) * f).toInt()
                try { w.updateViewLayout(v, lp) } catch (_: Exception) {}
            }
            start()
        }
    }

    private fun hide() {
        hideRing()
        if (System.currentTimeMillis() >= holdUntil) hideLabel()
    }

    // Instruction text on screen too, because many phones have no Chinyanja or Icibemba voice.
    private fun showLabel(text: String, top: Boolean, dim: Boolean = false, step: String? = null) {
        val w = wm ?: return
        val shown: CharSequence = if (step == null) text else android.text.SpannableString(step + "\n" + text).apply {
            setSpan(android.text.style.RelativeSizeSpan(0.7f), 0, step.length, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            setSpan(android.text.style.ForegroundColorSpan(0xFF145A3D.toInt()), 0, step.length, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        val d = resources.displayMetrics
        val lp = WindowManager.LayoutParams((d.widthPixels * 0.9).toInt(), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT)
        val atTop = top || surface == "permission"
        lp.gravity = (if (atTop) Gravity.TOP else Gravity.BOTTOM) or Gravity.CENTER_HORIZONTAL
        val kb = imeTop?.let { d.heightPixels - it } ?: 0   // keep the card above the keyboard
        lp.y = if (atTop) (96 * d.density).toInt() else kb + (88 * d.density).toInt()
        val v = label
        if (v == null) {
            val t = TextView(this)
            t.textSize = if (surface == "permission") 16f else 20f; t.setTextColor(0xFF1A1A1A.toInt()); t.typeface = Typeface.DEFAULT_BOLD; t.gravity = Gravity.CENTER
            val p = (14 * d.density).toInt(); t.setPadding(p, p, p, p)
            val g = GradientDrawable(); g.setColor(0xFFF7F5F0.toInt()); g.cornerRadius = 24 * d.density; g.setStroke(maxOf(1, d.density.toInt()), 0x33000000); t.background = g
            t.elevation = 6 * d.density; t.setLineSpacing(0f, 1.15f)
            t.text = shown; t.alpha = if (dim) 0.55f else 1f; label = t; w.addView(t, lp); announce(t, text)
        } else {
            if (v.text.toString() != shown.toString()) { v.text = shown; announce(v, text) }
            v.textSize = if (surface == "permission") 16f else 20f
            v.alpha = if (dim) 0.55f else 1f
            w.updateViewLayout(v, lp)
        }
    }
    private fun touchExploring(): Boolean =
        (getSystemService(ACCESSIBILITY_SERVICE) as android.view.accessibility.AccessibilityManager).isTouchExplorationEnabled
    private fun announce(v: View, text: String) { if (touchExploring()) v.announceForAccessibility(text) }

    private fun hideLabel() { label?.let { try { wm?.removeView(it) } catch (_: Exception) {} }; label = null }

    private fun speak(s: Step) {
        if (touchExploring()) return   // TalkBack already reads the card; do not talk over it
        val l = Guides.lang
        val res = s.audio?.let { resources.getIdentifier("${it}_$l", "raw", packageName) } ?: 0
        if (res != 0) { mp?.release(); mp = MediaPlayer.create(this, res); mp?.start(); return }
        say(s.say)
    }
    // Uses a voice for the chosen language if the phone has one; otherwise falls back to English.
    private fun say(texts: Map<String, String>) {
        if (!ttsReady) return
        val l = Guides.lang
        val loc = Locale(l)
        val ok = (tts?.isLanguageAvailable(loc) ?: TextToSpeech.LANG_NOT_SUPPORTED) >= TextToSpeech.LANG_AVAILABLE
        val msg = if (ok) texts[l] ?: texts["en"] else texts["en"] ?: texts[l]
        tts?.language = if (ok) loc else Locale.ENGLISH
        if (msg != null) tts?.speak(msg, TextToSpeech.QUEUE_FLUSH, null, "sg")
    }
}
