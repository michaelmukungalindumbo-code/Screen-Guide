package zm.screenguide

// tests first: not built yet
object PhoneCheck {
    class Run(val id: String, val steps: Int)
    val runs = LinkedHashMap<String, Run>()
    fun start(id: String, steps: Int) { runs[id] = Run(id, steps) }
    fun found(id: String, step: Int) {}
    fun lost(id: String, step: Int, word: String) {}
    fun help(id: String) {}
    fun end(id: String, how: String) {}
    fun ok(r: Run) = false
    fun line(r: Run, title: String) = ""
    fun report(titles: Map<String, String>, device: String, version: String) = ""
    fun summary(total: Int) = ""
    fun save() = ""
    fun load(json: String?) {}
}
