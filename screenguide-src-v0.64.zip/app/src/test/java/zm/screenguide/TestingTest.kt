package zm.screenguide

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TestingTest {
    private fun part(text: String, click: Boolean = true, w: Int = 48, h: Int = 48, labelled: Boolean = text.isNotBlank(),
                     edit: Boolean = false, progress: Boolean = false) = Testing.Part(text, click, edit, progress, w, h, labelled)

    @Test fun errorMessagesAreFoundButNotArticles() {
        assertEquals("Something went wrong. Try again.", Testing.errorText(listOf("Home", "Something went wrong. Try again.")))
        assertEquals("Error 404", Testing.errorText(listOf("Error 404")))
        assertNull(Testing.errorText(listOf("Download", "Past papers", "Terror")))          // "Terror" is not "error"
        assertNull(Testing.errorText(listOf("How to fix a failed download: " + "x".repeat(150))))   // long text is an article
    }

    @Test fun aTryAgainButtonIsNotAnErrorMessage() {
        // 2 Nov: the ↻ button under ScreenGuide's answer is named "Try again"; it was reported as an error message
        assertTrue(Testing.look(listOf(part("Try again"), part("Copy"), part("Speak"))).none { it.kind == "error_text" })
        val found = Testing.look(listOf(part("Could not load the papers.", click = false), part("Try again")))
        assertEquals("Could not load the papers.", found.first { it.kind == "error_text" }.detail)
    }

    @Test fun buttonsWithNoNameAndSmallButtons() {
        val found = Testing.look(listOf(part("Download"), part("", labelled = false), part("", labelled = false, w = 24, h = 24),
            part("Row with words inside", labelled = true), part("Search", edit = true, labelled = false), part("Title", click = false)))
        val kinds = found.associate { it.kind to it.detail }
        assertEquals("2", kinds["unlabeled"])          // the two icon buttons; the row has words inside, the search box is a box
        assertEquals("1", kinds["small_target"])       // the 24 dp one
        assertTrue(Testing.look(listOf(part("Download"), part("Share"))).isEmpty())
    }

    @Test fun androidsCrashAndFreezeMessages() {
        assertEquals("crash", Testing.systemMessage(listOf("Zexam keeps stopping", "App info", "Close app"), "Zexam")?.kind)
        assertEquals("freeze", Testing.systemMessage(listOf("Zexam isn't responding", "Wait"), "Zexam")?.kind)
        assertNull(Testing.systemMessage(listOf("WhatsApp keeps stopping"), "Zexam"))   // another app
    }

    @Test fun threeTapsThatChangeNothing() {
        val t = Testing.TapWatch()
        assertTrue(!t.tap("Download", "s1", 0) && !t.tap("Download", "s1", 1000))
        assertTrue(t.tap("Download", "s1", 2000))
        assertTrue(!t.tap("Share", "s1", 2100) && !t.tap("Share", "s2", 2200) && !t.tap("Share", "s2", 2300))   // the screen changed
        assertTrue(!t.tap("Next", "s2", 10000) && !t.tap("Next", "s2", 15000) && !t.tap("Next", "s2", 20000))   // too slow to count
    }

    @Test fun loadingThatStays() {
        val l = Testing.Loading()
        assertNull(l.seen(true, 0)); assertNull(l.seen(true, 5000))
        assertEquals(9, l.seen(true, 9000))
        assertNull(l.seen(false, 9500)); assertNull(l.seen(true, 10000)); assertNull(l.seen(true, 12000))
    }
}
