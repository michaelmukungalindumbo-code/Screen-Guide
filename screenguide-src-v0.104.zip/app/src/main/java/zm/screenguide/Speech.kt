package zm.screenguide

// tests first: not built yet
object Speech {
    const val PAUSE_MS = 0L
    const val NOTE_NATURAL = "n"; const val NOTE_UNKNOWN = "u"
    class V(val name: String, val lang: String, val country: String, val quality: Int, val needsNet: Boolean, val missing: Boolean)
    fun best(voices: List<V>, lang: String, homeCountry: String = ""): V? = voices.firstOrNull()
    fun natural(quality: Int) = false
    fun pace(chosen: Float) = chosen
    fun sentences(text: String): List<String> = listOf(text)
    fun label(quality: Int) = ""
    fun note(quality: Int) = ""
}
