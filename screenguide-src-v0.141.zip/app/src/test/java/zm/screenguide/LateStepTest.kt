package zm.screenguide

import java.io.File
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

// v0.141 (the owner's Infinix, 28 Nov, "How do I upload content on YouTube?", #116):
// 1. After "Upload Short", the helper was asked on YouTube's home page (10 words). By the time "Tap You to check" came,
//    his channel page was open (40 words, "Uploading"). Its bottom bar (Home, Shorts, Create, You) was half of the 10 words,
//    so it counted as the same screen: the late step stayed, and Help was needed. A screen with many more words than the
//    one asked about is a new screen: the helper looks again.
// 2. In the middle of the guide, yesterday's report ("ScreenGuide noticed 5 problems… From the guide you just finished",
//    the backup guide's) popped up over YouTube's editor. A "just finished" report never shows during a guide, or long
//    after its guide ended: it stays in Past results.
class LateStepTest {
    private fun words(n: Int, p: String) = (1..n).map { "$p$it" }.toSet()

    @Test fun sameScreenOrNot() {
        val bar = setOf("Home", "Shorts", "Create", "You", "Navigate up")
        val home = bar + words(5, "h")
        val channel = bar + words(35, "c")
        assertFalse(StepNav.sameWords(home, channel))               // the report: a new page, much bigger
        assertTrue(StepNav.sameWords(home, home + words(3, "x")))   // a few more words: the same screen, as before
        assertTrue(StepNav.sameWords(channel, channel - words(8, "c") + words(8, "y")))   // scrolled a little: as before
        assertFalse(StepNav.sameWords(words(20, "a"), words(20, "b")))   // nothing the same: new
        assertTrue(StepNav.sameWords(emptySet(), words(10, "a")))   // asked with no words (a picture): as before
    }

    @Test fun reportsNeverMidGuide() {
        val now = 100_000_000L
        assertTrue(Watch.showReport(true, now - 20_000, now, false))     // just after the guide: shown
        assertFalse(Watch.showReport(true, now - 20_000, now, true))     // a guide is running: kept for later
        assertFalse(Watch.showReport(true, now - 30 * 60_000, now, false))   // long after its guide: kept for later
        assertTrue(Watch.showReport(false, now - 30 * 60_000, now, true))    // opened from Past results: always
    }

    @Test fun theWiring() {
        fun src(n: String) = listOf("src/main/java/zm/screenguide/$n", "app/src/main/java/zm/screenguide/$n").map { File(it) }.first { it.exists() }.readText()
        assertTrue(src("GuideService.kt").contains("StepNav.sameWords(Guides.aiLabels, now))"))
        assertTrue(src("GuideService.kt").contains(".putExtra(\"at\", System.currentTimeMillis())"))
        val w = src("WatchActivity.kt")
        assertTrue(w.contains("if (!Watch.showReport(intent.getBooleanExtra(\"fresh\", false), intent.getLongExtra(\"at\", 0L), System.currentTimeMillis(), Guides.active != null)) {"))
    }
}
