package zm.screenguide

import android.app.Activity
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject

private const val FILL = ViewGroup.LayoutParams.MATCH_PARENT
private const val FIT = ViewGroup.LayoutParams.WRAP_CONTENT

// Developer phones: the step pictures of the guide in progress, kept in memory on the phone until the next guide.
object WatchShots {
    private val list = ArrayList<Pair<Int, String>>()
    @Synchronized fun clear() { list.clear() }
    @Synchronized fun add(n: Int, jpg: String) { if (list.size < 30 && list.none { it.first == n }) list.add(n to jpg) }
    @Synchronized fun all(): List<Pair<Int, String>> = ArrayList(list)
}

// Developer phones only. After a guide, the problems the watcher saw: what went wrong and how to fix it.
// "Allow" sends them to the AI fixer (one GitHub issue each, fixed and waiting for the developer's merge).
// "Don't allow" sends nothing.
class WatchActivity : Activity() {
    private val dark: Boolean get() = when (Profile.str(this, "theme", "auto")) {
        "light" -> false; "dark" -> true
        else -> (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    }
    private val bgc: Int get() = if (dark) 0xFF14181B.toInt() else Color.WHITE
    private val ink: Int get() = if (dark) 0xFFF2F4F5.toInt() else 0xFF1F1A14.toInt()
    private val muted: Int get() = if (dark) 0xFFADB5BA.toInt() else 0xFF534C45.toInt()
    private val red: Int get() = if (dark) 0xFFFF6B6B.toInt() else 0xFFC62828.toInt()
    private val accent: Int get() = if (dark) 0xFF18C3DA.toInt() else 0xFF145A3D.toInt()
    private val onAccent: Int get() = if (dark) 0xFF06262C.toInt() else Color.WHITE
    private val soft: Int get() = if (dark) 0xFF1E2428.toInt() else 0xFFF1EADD.toInt()
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun box(c: Int, r: Int) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat() }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Server.initTester(this)
        val arr = try { JSONArray(intent.getStringExtra("problems") ?: "[]") } catch (e: Exception) { JSONArray() }
        val ps: List<JSONObject> = (0 until arr.length()).mapNotNull { arr.optJSONObject(it) }
        if (ps.isEmpty()) { finish(); return }
        val shots = WatchShots.all()   // this guide's step pictures, taken now so a new guide cannot change them
        window.setGravity(Gravity.BOTTOM)
        window.setLayout(FILL, FIT)
        window.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
        setFinishOnTouchOutside(false)   // a choice is needed: Allow or Don't allow

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(16), dp(18), dp(16))
            background = GradientDrawable().apply { setColor(bgc); val r = dp(24).toFloat(); cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f) }
        }
        root.addView(TextView(this).apply {
            text = if (ps.size == 1) "ScreenGuide noticed 1 problem" else "ScreenGuide noticed ${ps.size} problems"
            textSize = 20f; typeface = Typeface.DEFAULT_BOLD; setTextColor(red)
        })
        root.addView(TextView(this).apply {
            text = "In the guide you just finished. Send them to the AI fixer? It fixes them and asks you to merge." +
                (if (shots.isNotEmpty()) " ${shots.size} pictures of your screen go with them: kept private for the fixer, never published." else "")
            textSize = 14.5f; setTextColor(muted); setPadding(0, dp(4), 0, dp(10))
        })

        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        ps.forEachIndexed { i, p ->
            list.addView(LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; background = box(soft, 16); setPadding(dp(14), dp(12), dp(14), dp(12))
                layoutParams = LinearLayout.LayoutParams(FILL, FIT).apply { bottomMargin = dp(8) }
                addView(TextView(context).apply {
                    text = "${i + 1}. ${p.optString("title")}"; textSize = 16f; typeface = Typeface.DEFAULT_BOLD; setTextColor(ink)
                })
                addView(TextView(context).apply {
                    text = "What happened: " + p.optString("what"); textSize = 14.5f; setTextColor(ink); setPadding(0, dp(6), 0, 0)
                })
                addView(TextView(context).apply {
                    text = "How to fix it: " + p.optString("fix"); textSize = 14.5f; setTextColor(muted); setPadding(0, dp(4), 0, 0)
                })
            })
        }
        root.addView(ScrollView(this).apply {
            addView(list)
            val tall = minOf(dp(380), (resources.displayMetrics.heightPixels * 0.55).toInt())
            layoutParams = LinearLayout.LayoutParams(FILL, if (ps.size <= 2) FIT else tall)
        })

        val status = TextView(this).apply { textSize = 14.5f; setTextColor(ink); setPadding(0, dp(8), 0, 0); visibility = View.GONE }
        root.addView(status)
        val no = TextView(this).apply {
            text = "Don’t allow"; textSize = 16f; setTextColor(ink); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            background = box(soft, 24); minHeight = dp(48); setPadding(dp(12), dp(12), dp(12), dp(12))
            layoutParams = LinearLayout.LayoutParams(0, FIT, 1f).apply { rightMargin = dp(8) }
            setOnClickListener { finish() }
        }
        val yes = TextView(this).apply {
            text = "Allow"; textSize = 16f; setTextColor(onAccent); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            background = box(accent, 24); minHeight = dp(48); setPadding(dp(12), dp(12), dp(12), dp(12))
            layoutParams = LinearLayout.LayoutParams(0, FIT, 1f)
        }
        yes.setOnClickListener {
            yes.isEnabled = false; no.isEnabled = false; yes.text = "Sending…"
            val id = Server.installId(this)
            val ids = ps.map { it.optString("id") }
            Thread {
                val msg = Server.watchSend(id, ids, shots)
                runOnUiThread {
                    status.text = msg; status.visibility = View.VISIBLE
                    no.visibility = View.GONE
                    yes.text = "Close"; yes.isEnabled = true; yes.setOnClickListener { finish() }
                }
            }.start()
        }
        root.addView(LinearLayout(this).apply { setPadding(0, dp(12), 0, 0); addView(no); addView(yes) })
        setContentView(root)
    }
}
