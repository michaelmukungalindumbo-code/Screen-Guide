package zm.screenguide

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.ScreenshotResult
import android.accessibilityservice.AccessibilityService.TakeScreenshotCallback
import android.os.Build
import android.view.Display
import android.animation.ValueAnimator
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.widget.TextView
import android.media.MediaPlayer
import android.net.wifi.WifiManager
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityWindowInfo
import android.widget.LinearLayout
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.Locale

class RingView(c: Context) : View(c) {
    var arrowBelow = true
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 8f; color = 0xFFF0A935.toInt() }
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = 0xE6FFFFFF.toInt() }
    private val edgeP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 5f; color = 0xFFFFA45B.toInt() }
    private val glowP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 14f; color = 0xCCFFA45B.toInt(); maskFilter = BlurMaskFilter(18f, BlurMaskFilter.Blur.NORMAL) }
    private val areaP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = 0x26FFA45B }
    init { setLayerType(LAYER_TYPE_SOFTWARE, null) }   // needed for the soft glow
    private val still = Settings.Global.getFloat(c.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f
    private var t = 0f
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1200; repeatCount = ValueAnimator.INFINITE
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); if (!still) anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }
    override fun onDraw(c: Canvas) {
        val a = 118f
        val top = if (arrowBelow) 0f else a
        val bottom = height - (if (arrowBelow) a else 0f)
        p.alpha = 255
        val box = RectF(26f, top + 26f, width - 26f, bottom - 26f)
        c.drawRoundRect(box, 30f, 30f, areaP)
        c.drawRoundRect(box, 30f, 30f, glowP)
        c.drawRoundRect(box, 30f, 30f, p)
        if (!still) {
            val g = 26f - 22f * t
            p.alpha = (255 * (1 - t)).toInt()
            c.drawRoundRect(RectF(g, top + g, width - g, bottom - g), 34f, 34f, p)
        }
        // A pointing arrow that bobs toward the target.
        val bob = if (still) 0f else 14f * kotlin.math.sin(t * 6.2831855f)
        val cx = width / 2f
        val s = if (arrowBelow) 1f else -1f
        val tip = if (arrowBelow) bottom - 26f + 12f - bob else top + 26f - 12f + bob
        val path = Path()
        path.moveTo(cx, tip)
        path.lineTo(cx - 34f, tip + s * 44f); path.lineTo(cx - 14f, tip + s * 44f)
        path.lineTo(cx - 14f, tip + s * 84f); path.lineTo(cx + 14f, tip + s * 84f)
        path.lineTo(cx + 14f, tip + s * 44f); path.lineTo(cx + 34f, tip + s * 44f); path.close()
        c.drawPath(path, fillP); c.drawPath(path, edgeP)
    }
}

// A finger that slides upward, showing the swipe the person has to make (on the home screen and the app list).
class SwipeView(c: Context) : View(c) {
    private val still = Settings.Global.getFloat(c.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = Color.WHITE }
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 5f; color = 0xFFFFA45B.toInt(); strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    private val trail = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; color = 0xFFFFA45B.toInt() }
    private var t = 0f
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1500; repeatCount = ValueAnimator.INFINITE
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); if (!still) anim.start() else t = 0.6f }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }
    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val bottom = height - 40f; val top = 100f
        val move = minOf(1f, t / 0.75f)
        val y = bottom - (bottom - top) * (1f - (1f - move) * (1f - move))   // starts quick, slows at the top
        val a = if (t < 0.85f) 1f else (1f - t) / 0.15f                      // fully visible, then a short fade
        // a short dotted trail behind the finger
        trail.style = Paint.Style.FILL
        for (k in 1..3) {
            val ty = y + 30f + k * 34f
            if (ty < bottom + 10f) { trail.alpha = ((200 - k * 55) * a).toInt(); c.drawCircle(cx, ty, 9f - k * 2f, trail) }
        }
        fill.alpha = (255 * a).toInt(); edge.alpha = (255 * a).toInt()
        c.drawCircle(cx, y, 30f, fill); c.drawCircle(cx, y, 30f, edge)
        // the arrow head above the finger
        val p = Path().apply { moveTo(cx, y - 86f); lineTo(cx - 36f, y - 46f); lineTo(cx + 36f, y - 46f); close() }
        c.drawPath(p, fill); c.drawPath(p, edge)
    }
}

class GuideService : AccessibilityService(), TextToSpeech.OnInitListener {
    private var wm: WindowManager? = null
    private var ring: RingView? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var spokenFor = -1
    private var mp: MediaPlayer? = null
    private var label: TextView? = null
    private var holdUntil = 0L
    private var findPkg: String? = null
    private var lastGuide: Guide? = null
    private val handler = Handler(Looper.getMainLooper())

    override fun onServiceConnected() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        tts = TextToSpeech(this, this)
        Guides.load(this)
    }
    override fun onInit(s: Int) { ttsReady = s == TextToSpeech.SUCCESS }
    override fun onInterrupt() {}
    override fun onDestroy() { hide(); hideSwipe(); hideLabel(); hideControls(); tts?.shutdown(); mp?.release(); super.onDestroy() }

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        val guide = Guides.active ?: run { hide(); hideControls(); return }
        val clicked = e.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED && e.packageName?.toString() != packageName
        if (clicked) {
            bumpProgress()
            // The person tapped: the old ring must not linger on whatever moves into that spot (it landed on "Private DNS").
            hideRing()
            if (guide.id != "ai") quietUntil = System.currentTimeMillis() + 450
        }
        if (guide.id == "ai") {
            val other = e.packageName?.toString() != packageName
            if (other && e.eventType == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED) {
                typingAt = System.currentTimeMillis(); bumpProgress()
                val src = e.source
                val hint = listOf(if (Build.VERSION.SDK_INT >= 26) src?.hintText else null, src?.contentDescription, src?.viewIdResourceName, src?.text).joinToString(" ")
                typedSearch = hint.contains("search", true)
                typedText = if (e.isPassword || src?.isPassword == true) "" else (e.text?.joinToString(" ") ?: "").trim().take(40)
            }
            if (other && e.eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED && System.currentTimeMillis() - screenAt > 1000) {
                val box = e.source?.let { val r = Rect(); it.getBoundsInScreen(r); r }
                // A page scroll moves a big list. Sliding banners and shelves (YouTube's Shorts row) do not count.
                if (box != null && box.height() >= resources.displayMetrics.heightPixels * 0.35) {
                    scrolledAt = System.currentTimeMillis(); scrollPending = true; scrollBox = box; bumpProgress()
                }
            }
            if (clicked) {
                // Keep the step if the tap landed on what we pointed at: that is the path to remember.
                val st = Guides.aiStep; val src = e.source
                if (st != null && st.match.isNotEmpty() && src != null && tappedSwitch(src, st.match) &&
                    Guides.aiTrail.lastOrNull()?.match != st.match) Guides.aiTrail.add(st)
                Guides.aiStep = null   // any tap is progress: ask for the next step
            }
            schedule(e); return
        }
        if (clicked && guide.doneWhen == "last_tap" && Guides.index == guide.steps.size - 1 && !guide.steps.last().toggle) {
            val src = e.source
            if (src != null && tappedSwitch(src, guide.steps.last().match)) { finish(guide); return }
        }
        // Final step: the person tapped the switch, so we are done.
        val last = guide.steps.last()
        if (e.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED && last.toggle && Guides.index == guide.steps.size - 1 && !stateKnown(guide)) {
            val src = e.source
            if (src != null) {
                val r = Rect(); src.getBoundsInScreen(r)
                val belowTitle = r.top > resources.displayMetrics.heightPixels * 0.12
                if (belowTitle && tappedSwitch(src, last.match)) { finish(guide); return }
            }
        }
        schedule(e)
    }

    private fun schedule(e: AccessibilityEvent) {
        val own = e.packageName?.toString() == packageName
        val changed = e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && !own
        // A new screen: drop the old ring at once. The card stays until the new screen replaces it, so it never blinks.
        if (changed) { hideRing(); bumpProgress(); screenAt = System.currentTimeMillis() }
        handler.removeCallbacks(refreshRun)
        handler.postDelayed(refreshRun, if (changed) 300L else 150L)
        if (changed) { handler.removeCallbacks(lateRun); handler.postDelayed(lateRun, 800) }
    }

    private val refreshRun = Runnable { refresh() }
    private val lateRun = Runnable { refresh() }

    private fun refresh() {
        if (Guides.chatOpen) { hide(); hideLabel(); hideControls(); return }   // the Tell me panel is open: keep the screen clear
        val guide = Guides.active ?: run { hide(); return }
        val root = rootInActiveWindow ?: run { if (classify() == "shade") { hide(); hideControls() }; return }
        val pkg = root.packageName?.toString() ?: ""
        if (pkg == packageName) { hide(); hideControls(); return }
        surface = classify()
        if (surface == "shade") { hide(); hideControls(); return }   // notification shade or quick settings is open
        showControls()
        if (guide !== lastGuide) {
            lastGuide = guide; findPkg = null
            typingAt = 0L; scrollPending = false; scrollAsked = null; ringStep = null; aheadStep = null; reask = false; nextNote = ""
        }
        // "Find an app" guide: finished once the person has left the screen where the icon was.
        if (guide.id == "find" && findPkg != null && pkg != findPkg && pkg.isNotEmpty() && !pkg.contains("systemui", true)) { findPkg = null; finish(guide); return }
        val nodes = candidates(root)
        val dm0 = resources.displayMetrics
        val dump = nodes.filter { !it.isPassword }.mapNotNull { n ->
            val t = (n.text ?: n.contentDescription)?.toString()?.takeIf { it.isNotBlank() } ?: return@mapNotNull null
            val r = Rect(); n.getBoundsInScreen(r)
            "$t@${r.top * 100 / dm0.heightPixels}%" + (n.className?.toString() ?: "").substringAfterLast('.')
        }.take(70).joinToString(" | ")
        Guides.seen.remove(pkg); Guides.seen[pkg] = "$pkg (h=${dm0.heightPixels}): $dump"
        while (Guides.seen.size > 3) Guides.seen.remove(Guides.seen.keys.first())
        if (guide.id == "ai") { aiRefresh(guide, nodes, pkg); return }
        val wait = quietUntil - System.currentTimeMillis()
        if (wait > 0) { handler.removeCallbacks(refreshRun); handler.postDelayed(refreshRun, wait + 30); return }   // let the screen change first
        // Show the LATEST step whose target is on screen. This skips steps a phone brand doesn't have.
        for (i in guide.steps.size - 1 downTo 0) {
            val skip = guide.steps[i].skipIn
            if (skip != null && pkg.contains(skip, true)) continue
            syntheticRect = null
            val node = find(nodes, guide.steps[i]) ?: continue
            if (guide.id == "find") findPkg = pkg
            if (guide.steps[i].toggle && (node.isChecked || isDone(guide))) { finish(guide); return }
            Guides.index = i; lostSince = 0L; hideSwipe()
            val r = Rect(); node.getBoundsInScreen(r)
            syntheticRect?.let { r.set(it) }
            val on = (node.text ?: node.contentDescription)?.toString()?.takeIf { it.isNotBlank() }
                ?: matchedText ?: (if (isSwitchLike(node)) "the switch" else "a button")
            note("Step ${i + 1} of ${guide.steps.size}", "Ring on \u201C$on\u201D, found by $foundHow.", nodes, pkg, Rect(r))
            show(r)
            track(if (syntheticRect == null) node else null)
            val st = named(guide.steps[i])
            showLabel(st.say[Guides.lang] ?: st.say["en"] ?: "", r.centerY() > resources.displayMetrics.heightPixels / 2, false,
                "Step ${i + 1} of ${guide.steps.size}")
            if (spokenFor != i) { spokenFor = i; speak(st); buzz(false) }
            // On the last step, keep checking the real phone state until the task is done.
            if (guide.doneWhen != null && i == guide.steps.size - 1) { handler.removeCallbacks(refreshRun); handler.postDelayed(refreshRun, 700) }
            return
        }
        hideRing()
        val home = isHome(pkg)
        if (guide.id == "find") {
            guide.hint?.let { showLabel(it[Guides.lang] ?: it["en"] ?: "", true) }
            if (home) showSwipe() else hideSwipe()
            return
        }
        // Nothing to point at on this screen: never leave the person with nothing. Say what to look for, and show how.
        val st = guide.steps.getOrNull(Guides.index) ?: guide.steps.firstOrNull() ?: return
        val now = System.currentTimeMillis()
        if (pkg != lostPkg) { lostPkg = pkg; lostSince = now }   // only a different app restarts the wait, not every small change
        if (now - lostSince < 1200) { handler.removeCallbacks(refreshRun); handler.postDelayed(refreshRun, 1300); return }   // the screen may still be loading
        note("Step ${Guides.index + 1} of ${guide.steps.size}", "Looking for \u201C${st.match.firstOrNull() ?: ""}\u201D. It is not on this screen" +
            (if (home) ", so the swipe arrow is showing." else "."), nodes, pkg)
        val where = if (home) "Not on this screen? Swipe up to find it." else "Not on this screen? Scroll down, or go back."
        showLabel(st.say[Guides.lang] ?: st.say["en"] ?: "", true, false, where)
        if (home) showSwipe() else hideSwipe()
    }

    private var quietUntil = 0L
    private var screenAt = 0L
    // Typing and scrolling during a Smart guide (see aiRefresh)
    private var typingAt = 0L
    private var typedText = ""
    private var typedSearch = false
    private var scrolledAt = 0L
    private var scrollPending = false
    private var scrollBox: Rect? = null
    private var scrollAsked: Step? = null    // re-asked once already for this step after a scroll
    private var ringStep: Step? = null
    private val firstRect = Rect()           // where the ring first sat for ringStep
    private var nextNote = ""                // what the person just did, for the next AI question
    private var aheadStep: Step? = null      // "Scroll down to find Storage": Storage gets a ring as soon as it shows
    private var askStart = 0L
    private var reask = false                // the screen is "new" for the AI even if most words stayed (scrolled, typed)
    private var waitTop = false
    private var errStep: Step? = null
    private val swipeWords = Regex("swipe up|scroll down|see all your apps", RegexOption.IGNORE_CASE)
    private var lostPkg = ""
    private var matchedText: String? = null

    // "Tap the glowing row" names the row instead, using the words on this phone's own screen.
    private fun named(st: Step): Step {
        val w = matchedText?.trim()?.takeIf { it.isNotEmpty() && it.length <= 40 } ?: return st
        if (!(st.say["en"] ?: "").contains("glowing row")) return st
        val q = "\u201C$w\u201D"
        return Step(st.match, mapOf("en" to "Tap $q.", "ny" to "Dinani $q.", "bem" to "Kandeni $q."), st.audio, st.toggle, st.skipIn, st.titles)
    }

    private var lostSince = 0L
    private var homePkg: String? = null
    private fun isHome(pkg: String): Boolean {
        if (homePkg == null) homePkg = try {
            packageManager.resolveActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0)?.activityInfo?.packageName ?: ""
        } catch (e: Exception) { "" }
        return pkg.isNotEmpty() && (pkg == homePkg || pkg.contains("launcher", true))
    }

    // ---- Smart guide: the AI picks the next button from the words on screen ----
    private val blockedApps get() = Guides.blockedApps
    private fun sensitive(pkg: String, nodes: List<AccessibilityNodeInfo>) = blockedApps.any { pkg.contains(it, true) } || nodes.any { it.isPassword }

    // Names of apps on the phone (names only), minus banking, money and wallet apps. Sent once, only for "which app" questions.
    private fun installedApps(): List<String> = try {
        val launch = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        packageManager.queryIntentActivities(launch, 0)
            .filter { ri ->
                val label = ri.loadLabel(packageManager).toString()
                blockedApps.none { ri.activityInfo.packageName.contains(it, true) || label.contains(it, true) }
            }
            .map { it.loadLabel(packageManager).toString().trim() }
            .filter { it.isNotEmpty() && it.length <= 40 }
            .distinct().sorted().take(120)
    } catch (e: Exception) { emptyList() }

    // The on/off switch that belongs to this word's row, if there is one (switches have no words of their own).
    private fun switchNear(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        fun walk(x: AccessibilityNodeInfo?, d: Int): AccessibilityNodeInfo? {
            if (x == null || d > 2) return null
            if (isSwitchLike(x) && x.isVisibleToUser) return x
            for (i in 0 until x.childCount) walk(x.getChild(i), d + 1)?.let { return it }
            return null
        }
        return walk(n, 0) ?: walk(n.parent, 1)
    }

    private fun tappable(n: AccessibilityNodeInfo): Boolean {
        var c: AccessibilityNodeInfo? = n
        repeat(4) { if (c?.isClickable == true) return true; c = c?.parent }
        return false
    }

    // Words on screen, each tagged so the AI can tell switches and buttons from plain text.
    private fun taggedLabels(nodes: List<AccessibilityNodeInfo>): List<String> {
        val out = LinkedHashSet<String>()
        for (n in nodes) {
            if (n.isPassword) continue
            val t = (n.text ?: n.contentDescription)?.toString()?.trim() ?: continue
            if (t.isEmpty() || t.length > 50 || Regex("\\d{5,}").containsMatchIn(t) || t.contains("@")) continue
            // [selected]: a tab already chosen ("Video" in Video | Short | Live), so the AI does not ask for it again.
            // Short words only: long titles can be "selected" just to scroll their text.
            val tag = if (switchNear(n) != null) "[switch]" else if (n.isSelected && t.length <= 20 && tappable(n)) "[selected]" else if (tappable(n)) "[tap]" else "[text]"
            out.add("$t $tag")
            if (out.size >= 70) break
        }
        return out.toList()
    }

    // ---- Tester view: a thin strip at the top saying what ScreenGuide sees and why it chose that spot, so a screen
    // recording explains itself. On by default in test builds (the ones GitHub makes), off in a Play Store build.
    private var dbg: LinearLayout? = null
    private var dbgTitle: TextView? = null
    private var dbgStatus: TextView? = null
    private var dbgAi: TextView? = null
    private var dbgSees: TextView? = null
    private var aiNote = ""
    private fun tester(): Boolean {
        val debuggable = (applicationInfo.flags and android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE) != 0
        return getSharedPreferences("sg", MODE_PRIVATE).getBoolean("tester", debuggable)
    }
    private val version: String by lazy { try { packageManager.getPackageInfo(packageName, 0).versionName ?: "" } catch (e: Exception) { "" } }

    // The app's own name for a screen ("Settings", "YouTube"), or "Home screen".
    private val appNames = HashMap<String, String>()
    private fun screenName(pkg: String): String {
        if (isHome(pkg)) return "Home screen"
        return appNames.getOrPut(pkg) {
            try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString() } catch (e: Exception) { pkg.substringAfterLast('.') }
        }
    }

    // What can be tapped on this screen, without clutter (times, dates, page dots, plain text).
    private val noise = Regex("^(\\d{1,2}:\\d{2}|am|pm|\\d{1,2}|.{1}|home screen \\d+ of \\d+|(mon|tue|wed|thu|fri|sat|sun)\\w* .*\\d.*)$", RegexOption.IGNORE_CASE)
    private fun words(nodes: List<AccessibilityNodeInfo>): String =
        taggedLabels(nodes).filter { !it.endsWith("[text]") }
            .map { it.replace(" [switch]", " (switch)").replace(" [selected]", " (selected)").replace(" [tap]", "").trim() }
            .filter { !noise.matches(it) }.distinct().take(9).joinToString("  \u00B7  ")

    private var testerTop = true   // which edge the tester card is on; the instruction card makes room for it
    private fun testerHeight(): Int = dbg?.let { if (it.height > 0) it.height else dp(100) } ?: 0

    private fun note(step: String, status: String, nodes: List<AccessibilityNodeInfo>?, pkg: String, ring: Rect? = null) {
        if (!tester()) { hideDbg(); return }
        val w = wm ?: return
        val g = Guides.active
        val name = if (g?.id == "ai") "Smart guide" else (g?.title?.get("en") ?: g?.id ?: "")
        val box = dbg ?: run {
            fun line(sz: Float, c: Int, bold: Boolean = false, lines: Int = 2) = TextView(this).apply {
                textSize = sz; setTextColor(c); if (bold) typeface = Typeface.DEFAULT_BOLD
                maxLines = lines; ellipsize = android.text.TextUtils.TruncateAt.END; setLineSpacing(0f, 1.1f)
            }
            val title = line(12f, Color.WHITE, true, 1)
            val status = line(12.5f, 0xFFF2F4F5.toInt(), false, 2).apply { setPadding(0, dp(3), 0, 0) }
            val ai = line(11f, 0xFFF0C27A.toInt(), false, 1).apply { setPadding(0, dp(2), 0, 0) }
            val sees = line(11f, 0xFFADB5BA.toInt(), false, 2).apply { setPadding(0, dp(3), 0, 0) }
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(8), dp(12), dp(9))
                background = GradientDrawable().apply { setColor(0xEB15191C.toInt()); cornerRadius = dp(14).toFloat(); setStroke(maxOf(1, dp(1)), 0x33FFFFFF) }
                elevation = dp(4).toFloat(); importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS
                addView(LinearLayout(context).apply {
                    gravity = Gravity.CENTER_VERTICAL
                    addView(TextView(context).apply {
                        text = "TEST"; textSize = 9.5f; setTextColor(0xFF1A1A1A.toInt()); typeface = Typeface.DEFAULT_BOLD; letterSpacing = 0.08f
                        background = GradientDrawable().apply { setColor(0xFFF0A935.toInt()); cornerRadius = dp(6).toFloat() }
                        setPadding(dp(6), dp(1), dp(6), dp(1))
                        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { rightMargin = dp(8) }
                    })
                    addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                })
                addView(status); addView(ai); addView(sees)
            }
            val lp = WindowManager.LayoutParams(resources.displayMetrics.widthPixels - dp(20), ViewGroup.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT)
            lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; lp.y = dp(28)
            try { w.addView(card, lp) } catch (_: Exception) { return }
            dbg = card; dbgTitle = title; dbgStatus = status; dbgAi = ai; dbgSees = sees
            card
        }
        fun set(t: TextView?, v: String) { if (t != null && t.text.toString() != v) t.text = v; t?.visibility = if (v.isEmpty()) View.GONE else View.VISIBLE }
        set(dbgTitle, listOf("v$version", name, step, screenName(pkg)).filter { it.isNotEmpty() }.joinToString("  \u00B7  "))
        set(dbgStatus, status)
        val kb = imeTop?.let { resources.displayMetrics.heightPixels - it }?.coerceAtLeast(0) ?: 0
        set(dbgAi, if (g?.id == "ai" && kb == 0) aiNote else "")   // keyboard open: keep the card small
        set(dbgSees, if (nodes != null && kb == 0) words(nodes).let { if (it.isEmpty()) "" else "Sees:  $it" } else "")
        // Three things share the screen: the ring, the instruction card and this card. The instruction card sits away
        // from the ring; this card takes an edge the ring does not reach (never the bottom while the swipe arrow shows),
        // and if it must share an edge with the instruction card, the instruction card moves aside (see showLabel).
        val h = resources.displayMetrics.heightPixels
        val th = testerHeight()
        val labelTop = ring == null || ring.centerY() > h / 2
        val swipeShowing = swipe != null || (ring == null && isHome(pkg) && g?.id != "ai")
        testerTop = when {
            swipeShowing -> true
            labelTop -> ring != null && ring.bottom > h - kb - (dp(10) + th + dp(8))   // bottom, unless the ring is down there
            else -> !(ring != null && ring.top < dp(28) + th + dp(8))                // top, unless the ring is up there
        }
        val lp = box.layoutParams as? WindowManager.LayoutParams ?: return
        val side = (if (testerTop) Gravity.TOP else Gravity.BOTTOM) or Gravity.CENTER_HORIZONTAL
        val y = if (testerTop) dp(28) else kb + dp(10)   // never on top of the keyboard
        if (lp.gravity != side || lp.y != y) { lp.gravity = side; lp.y = y; try { w.updateViewLayout(box, lp) } catch (_: Exception) {} }
    }
    private fun hideDbg() {
        dbg?.let { try { wm?.removeView(it) } catch (_: Exception) {} }
        dbg = null; dbgTitle = null; dbgStatus = null; dbgAi = null; dbgSees = null
    }

    private var swipe: SwipeView? = null
    private fun showSwipe() {
        if (swipe != null || Guides.chatOpen) return
        val w = wm ?: return
        val d = resources.displayMetrics
        val lp = WindowManager.LayoutParams(dp(120), (d.heightPixels * 0.34).toInt(),
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; lp.y = dp(70)
        try { swipe = SwipeView(this).also { w.addView(it, lp) } } catch (_: Exception) {}
    }
    private fun hideSwipe() { swipe?.let { try { wm?.removeView(it) } catch (_: Exception) {} }; swipe = null }

    private fun hideRing() {
        ringAnim?.cancel(); ringLp = null; trackNode = null; handler.removeCallbacks(trackRun)
        ring?.let { try { wm?.removeView(it) } catch (_: Exception) {} }; ring = null
    }

    private fun aiRefresh(guide: Guide, nodes: List<AccessibilityNodeInfo>, pkg: String) {
        if (askCard != null || capturing) { hideRing(); return }   // waiting for the person's answer, or taking the picture
        if (openApp(guide, nodes, pkg)) return
        if (sensitive(pkg, nodes)) {   // nothing is sent from these screens
            hideRing(); showLabel("For your safety I cannot guide you on this screen. Please do it yourself, or ask someone you trust.", false); return
        }
        val now = nodes.mapNotNull { (it.text ?: it.contentDescription)?.toString() }.take(60).toSet()
        val t = System.currentTimeMillis()
        // Typing changes the screen with every key. Never ask the AI in the middle of a word ("st" gave "you are in the
        // wrong part of Settings"). A result that matches the word they were told to type gets a ring at once, on the phone.
        if (typingAt > 0 && pkg == Guides.aiPkg) {
            val want = typeWord()
            val hit = if (want != null) nodes.firstOrNull { n -> !n.isEditable && n.isVisibleToUser && area(n) > 0 && norm(txt(n)) == norm(want) } else null
            if (hit != null) {
                typingAt = 0L
                if (norm(Guides.aiStep?.match?.firstOrNull()) != norm(txt(hit))) { pointLocal(hit, pkg, now); return }
                Guides.aiLabels = now   // already pointing at it
            } else if (t - typingAt < 1500) {
                hideRing(); handler.removeCallbacks(refreshRun); handler.postDelayed(refreshRun, 1550)
                note(aiProgress() ?: "", "Typing" + (if (want != null) ", watching for \u201C$want\u201D in the results" else "") +
                    ". The AI is asked when they pause.", nodes, pkg)
                return
            } else {
                // They paused. Ask again only for a search or a word we told them to type, never while they write a message.
                if (typedText.isNotEmpty() && (typedSearch || want != null)) {
                    nextNote = if (typedSearch) "They typed \u201C$typedText\u201D in the search box." else "They typed in a box."
                    reask = true
                }
                typingAt = 0L
            }
        }
        // Scrolling: once it stops, check the step still fits. If what we pointed at slid out of sight (or sits outside the
        // list, like a search box under the title bar), ask again once, so the AI can point at what shows now.
        if (scrollPending && pkg == Guides.aiPkg && !Guides.aiBusy) {
            if (t - scrolledAt < 700) { handler.removeCallbacks(refreshRun); handler.postDelayed(refreshRun, 720) }
            else {
                scrollPending = false
                val stp = Guides.aiStep
                val fresh = now.count { it !in Guides.aiLabels }
                if (stp != null && stp !== errStep && stp !== aheadStep && scrollAsked !== stp && fresh >= 3) {
                    val n = if (stp.match.isNotEmpty()) find(nodes, stp) else null
                    val r = n?.let { val rr = Rect(); it.getBoundsInScreen(rr); rr }
                    val box = scrollBox
                    val stillGood = n != null && r != null && n.isVisibleToUser && box != null && box.contains(r) &&
                        (ringStep !== stp || r.height() >= firstRect.height() * 0.8)
                    if (!stillGood) { scrollAsked = stp; reask = true; nextNote = "They scrolled the list." }
                }
            }
        }
        // Still the same screen as when we last asked? (same app, and most words unchanged). While they scroll to find what
        // we are looking for, the words change a lot but it is still the same step.
        val st = Guides.aiStep
        val same = !reask && pkg == Guides.aiPkg && (Guides.aiLabels.isEmpty() || (st != null && st === aheadStep) ||
            now.intersect(Guides.aiLabels).size >= 0.5 * minOf(now.size, Guides.aiLabels.size))
        if (st != null && same) {
            val pr = pointRect
            if (st === pointFor && pr != null) {   // a button with no words, found in the screen picture
                show(Rect(pr))
                showLabel(st.say[Guides.lang] ?: st.say["en"] ?: "", pr.centerY() > resources.displayMetrics.heightPixels / 2, false, aiProgress())
                return
            }
            val node = if (st.match.isNotEmpty()) find(nodes, st) else null
            val nodeRect = node?.let { val rr = Rect(); it.getBoundsInScreen(rr); rr }
            note(aiProgress() ?: "", when {
                st.match.isEmpty() -> "The AI gave words only, nothing to point at."
                node != null -> "The AI chose \u201C${st.match[0]}\u201D. Ring on it, found by $foundHow."
                else -> "The AI chose \u201C${st.match[0]}\u201D, but it is not on this screen."
            }, nodes, pkg, nodeRect)
            if (node != null) {
                hideSwipe()
                val wantsSwitch = st.say.values.any { it.contains("switch", true) }
                // point at the real switch, not just its word (only when the step is about a switch)
                val rn = (if (wantsSwitch) switchFor(nodes, st.match) else null) ?: switchNear(node) ?: tileOf(node)
                val r = Rect(); rn.getBoundsInScreen(r)
                if (ringStep !== st) { ringStep = st; firstRect.set(r) }
                show(r); track(rn)
                val words = if (st === aheadStep) tapWords(txt(node)) else st.say   // "Scroll down to find Storage" became "Tap Storage"
                showLabel(words[Guides.lang] ?: words["en"] ?: "", r.centerY() > resources.displayMetrics.heightPixels / 2, false, aiProgress())
            } else {
                hideRing(); showLabel(st.say[Guides.lang] ?: st.say["en"] ?: "", isHome(pkg), false, aiProgress())
                // Show the swipe only when the step says to swipe up or scroll down; never for an error or anything else.
                val wantsSwipe = st !== errStep && st.say.values.any { swipeWords.containsMatchIn(it) }
                if (wantsSwipe) showSwipe() else hideSwipe()
            }
            return
        }
        note(aiProgress() ?: "", if (Guides.aiBusy) "Waiting for the AI\u2026 ${(t - askStart) / 1000} s" + (if (t - askStart > 6000) " (the server was asleep?)" else "")
            else if (reask) "They scrolled or typed. Asking the AI again." else "New screen. Asking the AI what to tap.", nodes, pkg)
        // A new screen, or no step yet: ask again, but not more often than every 2 seconds.
        hideRing(); hideSwipe(); waitTop = isHome(pkg)
        if (!Guides.aiThinking) {
            val slow = Guides.aiBusy && t - askStart >= 6000
            showLabel(if (slow) waitText() else st?.say?.get(Guides.lang) ?: st?.say?.get("en") ?: "Looking\u2026", waitTop, st != null && !slow)
        }
        if (!Guides.aiBusy) {
            if (System.currentTimeMillis() - Guides.aiLast > 1200) askNext(guide, nodes, pkg)
            else { handler.removeCallbacks(refreshRun); handler.postDelayed(refreshRun, 1300) }
        }
    }

    private fun askNext(guide: Guide, nodes: List<AccessibilityNodeInfo>, pkg: String) {
        if (Guides.aiAsked >= 20) {
            Guides.active = null; hideRing(); holdUntil = System.currentTimeMillis() + 4000
            showLabel("Let’s stop here. Ask me again if you still need help.", false); handler.postDelayed({ hideLabel() }, 4000); return
        }
        val labels = taggedLabels(nodes)
        val stuck = Guides.aiStuck
        // After "?", a picture of the screen helps find buttons that have no words (icons, switches).
        val wantShot = stuck && Build.VERSION.SDK_INT >= 30 && getSharedPreferences("sg", MODE_PRIVATE).getBoolean("shot_ok", false)
        if (labels.isEmpty() && !wantShot) return
        Stats.inc(this, "ai_steps"); Guides.aiBusy = true; Guides.aiAsked++; Guides.aiPkg = pkg; Guides.aiLast = System.currentTimeMillis()
        askStart = Guides.aiLast; handler.removeCallbacks(waitRun); handler.postDelayed(waitRun, 6000); reask = false
        val told = nextNote; nextNote = ""
        Guides.aiLabels = nodes.mapNotNull { (it.text ?: it.contentDescription)?.toString() }.take(60).toSet()
        Guides.aiStuck = false
        val goal = Guides.aiGoal; val lang = Guides.lang; val hist = ArrayList(Guides.aiHistory); val plan = Guides.aiPlan
        val apps = if (Guides.aiNeedsApps) { Guides.aiNeedsApps = false; installedApps() } else emptyList()
        val id = Server.installId(this)
        fun send(image: String) {
            if (image.isNotEmpty()) Stats.inc(this, "screen_pictures")
            Thread {
                val t0 = System.currentTimeMillis()
                val r = Server.next(goal, lang, id, labels, hist, stuck, apps, told, plan, image, level())
                val ms = System.currentTimeMillis() - t0
                handler.post {
                    aiNote = (if (!r.ok) "Problem after ${ms / 100 / 10.0} s: ${Server.lastProblem.ifEmpty { r.say }.take(70)}" else "Last AI answer: ${ms / 100 / 10.0} s" +
                        (if (image.isNotEmpty()) ", with a screen picture" else "")) + "  \u00B7  Goal: " + goal.substringBefore(" (about:").take(50)
                    Guides.aiBusy = false; Guides.aiThinking = false; handler.removeCallbacks(thinkRun); handler.removeCallbacks(waitRun)
                    if (Guides.active !== guide) return@post
                    if (!r.ok) {
                        val err = Step(emptyList(), mapOf(lang to r.say.trimEnd('.') + ". Tap Help to try again."), null)
                        Guides.aiStep = err; errStep = err; pointFor = null; pointRect = null
                        speak(err); refresh(); return@post
                    }
                    if (r.done) {
                        val trail = ArrayList(Guides.aiTrail)
                        if (trail.size >= 2 || (trail.size == 1 && !Guides.aiJustOpen && trail[0].match.firstOrNull() != Guides.aiApp)) {
                            val sw = trail.last().say.values.any { it.contains("switch", true) }
                            Recipes.save(this, Guides.aiGoal, trail, sw)
                            Stats.inc(this, "tasks_learned")
                        }
                        finish(Guide(guide.id, guide.title, mapOf(lang to r.say), emptyList(), emptyList()))
                        return@post
                    }
                    val say = tighten(r.say, r.label != null)
                    val prev = Guides.aiStep
                    if (prev != null && prev !== errStep && r.label != null && norm(prev.match.firstOrNull()) == norm(r.label)) {
                        refresh(); return@post   // a re-check gave the same answer: keep the step, its number and its ring
                    }
                    if (Guides.aiHistory.lastOrNull() != say) Guides.aiHistory.add(say)
                    val ahead = r.label == null && r.lookFor != null && r.x == null
                    val step = Step(if (r.label != null) listOf(r.label) else if (ahead) listOf(r.lookFor!!) else emptyList(), mapOf(lang to say), null)
                    Guides.aiStep = step; aheadStep = if (ahead) step else null
                    val rx = r.x; val ry = r.y
                    if (r.label == null && rx != null && ry != null && image.isNotEmpty() && shotW > 0) {
                        val cx = (rx * shotW).toInt(); val cy = (ry * shotH).toInt(); val half = dp(30)
                        pointFor = step; pointRect = Rect(cx - half, cy - half, cx + half, cy + half)
                    } else { pointFor = null; pointRect = null }
                    speak(step); buzz(false)
                    refresh()
                }
            }.start()
        }
        if (wantShot) captureScreen { send(it) } else send("")
    }

    // Stage one of a Smart guide: get into the app. Done on the phone, like the built-in guides: the icon gets a
    // ring at once, the swipe arrow shows when it is not on screen, and no AI is asked. True while still in this stage.
    private var appSaid = ""
    private fun openApp(guide: Guide, nodes: List<AccessibilityNodeInfo>, pkg: String): Boolean {
        val app = Guides.aiApp ?: return false
        val appPkg = Guides.aiAppPkg ?: return false
        if (Guides.aiInApp) return false
        val lang = Guides.lang
        val q = "\u201C$app\u201D"
        val tap = Step(listOf(app), mapOf("en" to "Tap $q.", "ny" to "Dinani $q.", "bem" to "Kandeni $q."), null)
        if (pkg == appPkg) {
            Guides.aiInApp = true
            Guides.aiTrail.add(tap); Guides.aiHistory.add("Tap $q.")
            if (Guides.aiJustOpen) {
                finish(Guide(guide.id, guide.title, mapOf("en" to "Well done! $app is open.", "ny" to "Zabwino! $app yatseguka.",
                    "bem" to "Nawamya! $app yaisuka."), emptyList(), emptyList()))
                return true
            }
            Guides.aiStep = null; Guides.aiLast = 0L   // now the AI helps inside the app
            return false
        }
        val icon = nodes.filter { norm((it.text ?: it.contentDescription)?.toString()) == norm(app) }.filter { area(it) > 0 }.minByOrNull { area(it) }
        val iconRect = icon?.let { val rr = Rect(); it.getBoundsInScreen(rr); rr }
        note("Step 1", "Opening \u201C$app\u201D without the AI. " + (if (icon != null) "Ring on its icon" else "Icon not on this screen, swipe arrow showing") +
            (if (Guides.aiJustOpen) ". Done when it opens." else ". The AI takes over inside it."), nodes, pkg, iconRect)
        val key: String
        if (icon != null) {
            hideSwipe()
            val t = target(icon); val r = Rect(); t.getBoundsInScreen(r)
            show(r); track(t)
            showLabel(tap.say[lang] ?: tap.say["en"] ?: "", r.centerY() > resources.displayMetrics.heightPixels / 2, false, "Step 1")
            key = "tap"
        } else {
            hideRing()
            val home = isHome(pkg)
            val how = if (home) "Swipe up to see all your apps." else "Press Home, then swipe up to see all your apps."
            showLabel(how, true, false, "Step 1: find $q")
            if (home) showSwipe() else hideSwipe()
            key = "find"
        }
        if (appSaid != key + app) {
            appSaid = key + app
            speak(if (key == "tap") tap else Step(emptyList(), mapOf("en" to "Find $app. Swipe up to see all your apps."), null))
            buzz(false)
        }
        return true
    }

    // A video length ("0:14") sits on its thumbnail: ring the whole picture, not the small number.
    private val durRx = Regex("^\\d{1,2}:\\d{2}(:\\d{2})?$")
    private fun tileOf(n: AccessibilityNodeInfo): AccessibilityNodeInfo {
        if (!durRx.matches(txt(n))) return n
        val d = resources.displayMetrics
        val cap = d.widthPixels.toLong() * d.heightPixels / 4
        var c = n
        repeat(4) {
            val p = c.parent ?: return n
            val r = Rect(); p.getBoundsInScreen(r)
            if (r.width().toLong() * r.height() > cap) return n
            if (p.isClickable) return p
            c = p
        }
        return n
    }

    private fun txt(n: AccessibilityNodeInfo) = (n.text ?: n.contentDescription)?.toString()?.trim() ?: ""
    private fun tapWords(w: String): Map<String, String> { val q = "\u201C$w\u201D"; return mapOf("en" to "Tap $q.", "ny" to "Dinani $q.", "bem" to "Kandeni $q.") }

    // "Type the word storage." -> "storage". From this step, or the last two (the AI may already have moved on).
    private val typeRx = Regex("\\btype\\s+(?:the\\s+word\\s+|in\\s+)?[\"\u201C']?(\\p{L}[\\p{L}\\- ]{1,25}?)[\"\u201D']?\\s*(?:[.,!]|$|\\s(?:in|into|on)\\b)", RegexOption.IGNORE_CASE)
    private fun typeWord(): String? {
        val texts = listOfNotNull(Guides.aiStep?.say?.values?.joinToString(" ")) + Guides.aiHistory.takeLast(2).reversed()
        for (x in texts) typeRx.find(x)?.let { m -> m.groupValues[1].trim().takeIf { it.length >= 3 }?.let { return it } }
        return null
    }

    // Point at something without asking the AI: a search result that matches the word they typed.
    private fun pointLocal(n: AccessibilityNodeInfo, pkg: String, now: Set<String>) {
        val step = Step(listOf(txt(n)), tapWords(txt(n)), null)
        Guides.aiStep = step; Guides.aiPkg = pkg; Guides.aiLabels = now
        Guides.aiHistory.add(step.say["en"] ?: "")
        aheadStep = null; pointFor = null; pointRect = null
        speak(step); buzz(false)
        handler.removeCallbacks(refreshRun); handler.post(refreshRun)
    }

    // A free server sleeps when nobody has used it for a while; its first answer then takes up to a minute. Say so,
    // instead of "Looking…" with no end.
    private fun waitText(): String {
        val s = (System.currentTimeMillis() - askStart) / 1000
        return if (s < 50) "Waking up the helper. The first answer can take up to a minute." else "Still waiting. Please check your internet."
    }
    private val waitRun = object : Runnable {
        override fun run() {
            if (!Guides.aiBusy || Guides.active?.id != "ai") return
            if (!Guides.aiThinking && askCard == null && !capturing && !Guides.chatOpen) showLabel(waitText(), waitTop)
            handler.postDelayed(this, 1000)
        }
    }

    // "Step 2 of 4": from the AI's plan when there is one.
    private fun aiProgress(): String? {
        val k = Guides.aiHistory.size
        val m = Guides.aiPlan.size
        return if (k <= 0) null else if (m in k..12) "Step $k of $m" else if (m in 1 until k) "Almost there" else "Step $k"
    }

    // New users get the simplest words; confident users get very short ones. Worked out on the phone from counts only.
    private fun level(): String {
        when (Profile.str(this, "words", "auto")) { "simple" -> return "new"; "short" -> return "confident"; "normal" -> return "some" }
        val p = getSharedPreferences("stats", MODE_PRIVATE)
        val done = p.getInt("finished", 0); val stuck = p.getInt("stuck", 0)
        return if (done < 3 || stuck > done) "new" else if (done >= 10 && stuck * 3 < done) "confident" else "some"
    }

    // A light tick for each new step, a stronger one when the task is done. Follows the phone's touch-feedback setting.
    private fun buzz(done: Boolean) {
        if (!Profile.buzzOn(this)) return
        val v: View = label ?: ring ?: return
        val kind = if (!done) android.view.HapticFeedbackConstants.CLOCK_TICK
            else if (Build.VERSION.SDK_INT >= 30) android.view.HapticFeedbackConstants.CONFIRM
            else android.view.HapticFeedbackConstants.LONG_PRESS
        try { v.performHapticFeedback(kind) } catch (e: Exception) {}
    }

    // ---- A picture of the screen: only after "?", only if the person agreed, never on bank, money or password screens ----
    private var capturing = false
    private var shotW = 0
    private var shotH = 0
    private var pointFor: Step? = null
    private var pointRect: Rect? = null
    private var askCard: LinearLayout? = null

    private fun captureScreen(done: (String) -> Unit) {
        if (Build.VERSION.SDK_INT < 30) { done(""); return }
        capturing = true
        hideRing(); hideLabel(); controls?.visibility = View.INVISIBLE; dbg?.visibility = View.INVISIBLE   // keep our own drawings out of the picture
        fun finishShot(out: String) {
            capturing = false; controls?.visibility = View.VISIBLE; dbg?.visibility = View.VISIBLE
            done(out)
        }
        handler.postDelayed({
            try {
                takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
                    override fun onSuccess(result: ScreenshotResult) {
                        var out = ""
                        try {
                            val hb = result.hardwareBuffer
                            val sw = Bitmap.wrapHardwareBuffer(hb, result.colorSpace)?.copy(Bitmap.Config.ARGB_8888, false)
                            hb.close()
                            if (sw != null) { shotW = sw.width; shotH = sw.height; out = encodeShot(sw) }
                        } catch (e: Exception) {}
                        finishShot(out)
                    }
                    override fun onFailure(errorCode: Int) { finishShot("") }
                })
            } catch (e: Exception) { finishShot("") }
        }, 180)
    }

    private fun encodeShot(b: Bitmap): String {
        val m = maxOf(b.width, b.height)
        val s = if (m > 1024) Bitmap.createScaledBitmap(b, b.width * 1024 / m, b.height * 1024 / m, true) else b
        val o = java.io.ByteArrayOutputStream()
        s.compress(Bitmap.CompressFormat.JPEG, 70, o)
        return android.util.Base64.encodeToString(o.toByteArray(), android.util.Base64.NO_WRAP)
    }

    // Asked once, the first time the person taps "?". The answer can be changed later in the app's menu.
    private fun askShotConsent() {
        val w = wm ?: return
        if (askCard != null) return
        Guides.aiThinking = false; handler.removeCallbacks(thinkRun); hideLabel(); hideRing()
        val prefs = getSharedPreferences("sg", MODE_PRIVATE)
        fun answer(ok: Boolean) {
            prefs.edit().putBoolean("shot_ok", ok).apply()
            askCard?.let { try { w.removeView(it) } catch (_: Exception) {} }; askCard = null
            Guides.aiThinking = true; thinkDots = 0; thinkStart = System.currentTimeMillis()
            handler.removeCallbacks(thinkRun); handler.post(thinkRun)
            handler.removeCallbacks(refreshRun); handler.post(refreshRun)
        }
        fun button(t: String, fill: Int, fg: Int, ok: Boolean) = TextView(this).apply {
            text = t; textSize = 16f; setTextColor(fg); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            background = GradientDrawable().apply { setColor(fill); cornerRadius = dp(22).toFloat() }
            setPadding(dp(18), dp(12), dp(18), dp(12))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { leftMargin = dp(8) }
            setOnClickListener { answer(ok) }
        }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(16), dp(16), dp(14))
            background = GradientDrawable().apply { setColor(0xF5F2F2F2.toInt()); cornerRadius = dp(24).toFloat() }
            addView(TextView(context).apply {
                text = "Can I look at a picture of your screen?"; textSize = 18f; setTextColor(0xFF1A1A1A.toInt()); typeface = Typeface.DEFAULT_BOLD
            })
            addView(TextView(context).apply {
                text = "It helps me find buttons that have no words. I only look when you tap ?, and never on bank, money or password screens."
                textSize = 15f; setTextColor(0xFF333333.toInt()); setPadding(0, dp(6), 0, dp(12))
            })
            addView(LinearLayout(context).apply {
                gravity = Gravity.END
                addView(button("No", 0x00000000, 0xFF333333.toInt(), false))
                addView(button("Yes, look", 0xFF145A3D.toInt(), Color.WHITE, true))
            })
        }
        val d = resources.displayMetrics
        val lp = WindowManager.LayoutParams((d.widthPixels * 0.92).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,   // touchable
            PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; lp.y = dp(96)
        try { w.addView(card, lp); askCard = card } catch (e: Exception) { prefs.edit().putBoolean("shot_ok", false).apply() }
    }

    // ---- Window awareness, tracking and on-screen controls ----
    private var surface = "app"
    private var imeTop: Int? = null

    // What is on top: the app, a permission pop-up, a file or photo picker, or the notification shade.
    private fun classify(): String {
        imeTop = null
        var activePkg = ""
        try {
            for (w in windows) {
                val b = Rect(); w.getBoundsInScreen(b)
                if (w.type == AccessibilityWindowInfo.TYPE_INPUT_METHOD) imeTop = b.top
                if (w.isActive) activePkg = w.root?.packageName?.toString() ?: activePkg
            }
        } catch (_: Exception) {}
        return when {
            activePkg.contains("permissioncontroller") -> "permission"
            activePkg.contains("providers.media") || activePkg.contains("photopicker") || activePkg.contains("documentsui") -> "picker"
            activePkg == "com.android.systemui" -> "shade"
            else -> "app"
        }
    }

    // Keep measuring the target so the ring follows scrolling and animations.
    private var trackNode: AccessibilityNodeInfo? = null
    private val trackRun = object : Runnable {
        override fun run() {
            val n = trackNode ?: return
            if (ring == null) return
            if (n.refresh() && n.isVisibleToUser) {
                val r = Rect(); n.getBoundsInScreen(r)
                if (!r.isEmpty && r != lastTarget) show(r)
                handler.postDelayed(this, 100)
            } else { trackNode = null; handler.removeCallbacks(refreshRun); handler.post(refreshRun) }
        }
    }
    private fun track(n: AccessibilityNodeInfo?) {
        trackNode = n; handler.removeCallbacks(trackRun)
        if (n != null) handler.postDelayed(trackRun, 100)
    }

    // Keep each instruction short. With a ring, one action is enough (the ring shows where). With nothing to
    // point at, the words must carry everything, so keep up to three sentences (for example the safety message).
    private fun tighten(say: String, pointing: Boolean): String {
        val t = say.trim()
        if (pointing) return t.substringBefore(". ").trim().split(" ").take(12).joinToString(" ")
        return t.split(Regex("(?<=[.!?])\\s+")).take(3).joinToString(" ").split(" ").take(40).joinToString(" ")
    }

    private var controls: LinearLayout? = null
    private var stuckChip: View? = null
    private val stuckRun = object : Runnable {
        override fun run() {
            if (Guides.aiBusy) { handler.postDelayed(this, 3000); return }   // waiting for the AI is not being stuck
            stuckChip?.let { it.background = pillBg(0xFFF0A935.toInt()) }
        }
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun pillBg(c: Int) = GradientDrawable().apply { setColor(c); cornerRadius = dp(24).toFloat() }

    // Any progress (a tap, a new screen) resets the quiet timer; after 9 seconds the "I'm stuck" button lights up.
    private fun bumpProgress() {
        stuckChip?.let { it.background = null }
        handler.removeCallbacks(stuckRun); handler.postDelayed(stuckRun, 9000)
        handler.removeCallbacks(idleRun); handler.postDelayed(idleRun, IDLE_MS)
    }

    // A guide left untouched (no taps, no new screens) for 4 minutes stops by itself, so an old guide never
    // talks over the next task.
    private val IDLE_MS = 4 * 60_000L
    private val idleRun = Runnable {
        val g = Guides.active
        if (g != null) {
            Server.event(this, "stop", "idle_" + g.id)
            Guides.active = null; Guides.aiStep = null; hide(); hideControls()
            holdUntil = System.currentTimeMillis() + 5000
            showLabel("I stopped the guide because nothing happened for a while. Open ScreenGuide when you need help.", true)
            handler.postDelayed({ hideLabel() }, 5000)
        }
    }

    private fun speakCurrent() {
        val g = Guides.active ?: return
        val st = if (g.id == "ai") Guides.aiStep else g.steps.getOrNull(Guides.index)
        if (st != null) speak(st, asked = true)
    }

    // Asks the AI for a different way. Built-in guides switch to the Smart guide for the same goal.
    private fun onStuck() {
        val g = Guides.active ?: return
        Stats.inc(this, "stuck")
        val ok = getSharedPreferences("sg", MODE_PRIVATE).getBoolean("smart_ok", false)
        if (!Server.configured || !ok) { showLabel("Open ScreenGuide and agree to Smart guide to get help here.", false); return }
        if (g.id != "ai") {
            val goal = if (g.id == "find") "Open " + (g.title["en"] ?: "") else (g.title["en"] ?: g.id)
            Guides.aiReset(goal)
            Guides.active = Guide("ai", g.title, g.done, emptyList(), emptyList())
        }
        Guides.aiStep = null; Guides.aiLast = 0L; Guides.aiStuck = true
        if (!Guides.aiInApp) Guides.aiApp = null   // could not find the app icon alone: let the AI help from here
        // Show that the AI is thinking, and offer a chat for the person's own words.
        Guides.aiThinking = true; thinkDots = 0; thinkStart = System.currentTimeMillis()
        handler.removeCallbacks(thinkRun); handler.post(thinkRun)
        chatChip?.visibility = View.VISIBLE
        handler.removeCallbacks(hideChatRun); handler.postDelayed(hideChatRun, 25000)
        bumpProgress()
        if (Build.VERSION.SDK_INT >= 30 && !getSharedPreferences("sg", MODE_PRIVATE).contains("shot_ok")) { askShotConsent(); return }
        handler.removeCallbacks(refreshRun); handler.post(refreshRun)
    }

    private var chatChip: View? = null
    private val hideChatRun = Runnable { chatChip?.visibility = View.GONE }
    private var thinkDots = 0
    private var thinkStart = 0L
    private val thinkRun = object : Runnable {
        override fun run() {
            if (!Guides.aiThinking) return
            if (Guides.chatOpen) { hideLabel(); handler.postDelayed(this, 450); return }
            val waited = System.currentTimeMillis() - thinkStart
            if (rootInActiveWindow?.packageName?.toString() == packageName) { hideLabel(); handler.postDelayed(this, 450); return }   // our chat is open: it shows its own
            if (waited > 65000) {
                Guides.aiThinking = false
                showLabel("This is taking long. Check your internet, then tap Help to try again.", false)
                return
            }
            if (capturing || askCard != null) { handler.postDelayed(this, 450); return }
            thinkDots = (thinkDots + 1) % 4
            val slow = waited > 7000
            showLabel((if (slow) "Waking up the helper. The first answer can take up to a minute" else "Looking at your screen") + ".".repeat(thinkDots), false, true)
            handler.postDelayed(this, 450)
        }
    }

    // The person wants to explain in their own words: open a small chat over the current app.
    private fun openChat() {
        val g = Guides.active ?: return
        val ok = getSharedPreferences("sg", MODE_PRIVATE).getBoolean("smart_ok", false)
        if (!Server.configured || !ok) { showLabel("Open ScreenGuide and agree to Smart guide to chat here.", false); return }
        val root = rootInActiveWindow
        val pkg = root?.packageName?.toString() ?: ""
        val nodes = if (root != null) candidates(root) else emptyList()
        if (sensitive(pkg, nodes)) { showLabel("For your safety I cannot help on this screen. Please ask someone you trust.", false); return }
        Guides.chatLabels = taggedLabels(nodes)
        Guides.chatSet = nodes.mapNotNull { (it.text ?: it.contentDescription)?.toString() }.take(60).toSet()
        Guides.chatPkg = pkg
        Guides.chatGoal = if (g.id == "ai") Guides.aiGoal else if (g.id == "find") "Open " + (g.title["en"] ?: "") else (g.title["en"] ?: g.id)
        Guides.chatHistory = ArrayList(Guides.aiHistory)
        hideLabel(); hideRing()
        try { startActivity(Intent(this, HelpActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (e: Exception) { showLabel("Open ScreenGuide to chat.", false) }
    }

    private fun showControls() {
        if (controls != null) return
        val w = wm ?: return
        // Each button has a picture and a short word under it, so nobody has to guess what it does.
        fun icon(kind: String, word: String, desc: String, onTap: () -> Unit) = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; contentDescription = desc
            layoutParams = LinearLayout.LayoutParams(dp(64), dp(62))
            addView(IconView(context, kind, 0xFF1A1A1A.toInt()).apply { layoutParams = LinearLayout.LayoutParams(dp(24), dp(24)) })
            addView(TextView(context).apply {
                text = word; textSize = 11.5f; setTextColor(0xFF1A1A1A.toInt()); gravity = Gravity.CENTER; setPadding(0, dp(3), 0, 0)
                importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            })
            setOnClickListener { v -> v.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY); onTap() }
        }
        val repeat = icon("refresh", "Repeat", "Repeat the instruction") { speakCurrent() }
        val stuck = icon("help", "Help", "I am stuck, help me") { onStuck() }
        val stop = icon("close", "Stop", "Stop the guide") {
            Stats.inc(this, "stopped"); Server.event(this, "stop", Guides.active?.id ?: "unknown")
            Guides.active = null; Guides.aiStep = null; hide(); hideControls(); hideLabel()
        }
        val chat = icon("chat", "Tell me", "Tell me why I am stuck") { openChat() }
        chat.visibility = View.GONE; chatChip = chat
        stuckChip = stuck
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(4), dp(6), dp(4), dp(6))
            background = GradientDrawable().apply { setColor(0xF0F7F5F0.toInt()); cornerRadius = dp(32).toFloat(); setStroke(maxOf(1, dp(1)), 0x33000000) }
            elevation = dp(6).toFloat()
            addView(repeat); addView(stuck); addView(chat); addView(stop)
        }
        val lp = WindowManager.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,   // touchable, unlike the ring
            PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.END or Gravity.TOP; lp.x = dp(6); lp.y = dp(150)
        w.addView(col, lp); controls = col
        handler.removeCallbacks(stuckRun); handler.postDelayed(stuckRun, 9000)
        handler.removeCallbacks(idleRun); handler.postDelayed(idleRun, IDLE_MS)
    }

    // Keep the buttons on the side of the screen away from the target.
    private fun moveControls(r: Rect) {
        val c = controls ?: return
        val lp = c.layoutParams as? WindowManager.LayoutParams ?: return
        val g = (if (r.centerX() > resources.displayMetrics.widthPixels / 2) Gravity.START else Gravity.END) or Gravity.TOP
        if (lp.gravity != g) { lp.gravity = g; try { wm?.updateViewLayout(c, lp) } catch (_: Exception) {} }
    }
    private fun hideControls() {
        controls?.let { try { wm?.removeView(it) } catch (_: Exception) {} }
        controls = null; stuckChip = null; chatChip = null; handler.removeCallbacks(stuckRun); handler.removeCallbacks(idleRun)
        hideDbg(); aiNote = ""
        askCard?.let { try { wm?.removeView(it) } catch (_: Exception) {} }; askCard = null
    }

    // Phones draw switches differently; accept anything that looks like one.
    private fun isSwitchLike(n: AccessibilityNodeInfo?): Boolean {
        if (n == null) return false
        val c = n.className?.toString() ?: ""
        return n.isCheckable || c.contains("Switch") || c.contains("Toggle") || c.contains("CheckBox")
    }

    // Some phones will not tell us (hotspot is a hidden setting). Then a tap on the switch finishes the guide instead.
    private fun hotspotOn(): Boolean? = try {
        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val method = wm.javaClass.getDeclaredMethod("isWifiApEnabled"); method.isAccessible = true
        method.invoke(wm) as Boolean
    } catch (e: Throwable) { null }
    private fun stateKnown(g: Guide) = when (g.doneWhen) { null -> false; "hotspot_on" -> hotspotOn() != null; else -> true }

    // Ask Android itself whether the task is done, instead of guessing from the screen.
    private fun isDone(g: Guide): Boolean = when (g.doneWhen) {
        "wifi_on" -> try { (applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).isWifiEnabled } catch (e: Exception) { false }
        "hotspot_on" -> hotspotOn() ?: false
        "bluetooth_on" -> try { Settings.Global.getInt(contentResolver, "bluetooth_on", 0) == 1 } catch (e: Exception) { false }
        "airplane_on" -> try { Settings.Global.getInt(contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) == 1 } catch (e: Exception) { false }
        else -> false
    }

    private fun finish(g: Guide) {
        appSaid = ""
        Stats.inc(this, "finished"); Server.event(this, "done", g.id)
        hide(); hideControls(); Guides.active = null; spokenFor = -1; say(g.done)
        holdUntil = System.currentTimeMillis() + 4000
        showLabel("\u2714 " + (g.done[Guides.lang] ?: g.done["en"] ?: ""), false)
        buzz(true)
        handler.postDelayed({ hideLabel() }, 4000)
    }

    private fun norm(s: String?) = (s ?: "").lowercase().filter { it.isLetterOrDigit() }

    // Every visible node on screen, as a flat list.
    private fun candidates(root: AccessibilityNodeInfo): List<AccessibilityNodeInfo> {
        val out = ArrayList<AccessibilityNodeInfo>()
        val q = ArrayDeque<AccessibilityNodeInfo>(); q.add(root)
        var seen = 0
        while (q.isNotEmpty() && seen < 800) {
            val n = q.removeFirst(); seen++
            if (n.isVisibleToUser) out.add(n)
            for (i in 0 until n.childCount) n.getChild(i)?.let { q.add(it) }
        }
        return out
    }

    // Some phones never report certain rows (e.g. Airplane mode on Infinix). If the screen's title matches
    // but the row is missing, point at the empty band between the title bar and the next heading.
    private var syntheticRect: Rect? = null
    private fun gapRow(nodes: List<AccessibilityNodeInfo>, s: Step, h: Int): AccessibilityNodeInfo? {
        val tk = (s.titles ?: s.match).map { norm(it) }
        val title = nodes.firstOrNull { n ->
            val r = Rect(); n.getBoundsInScreen(r)
            r.top <= h * 0.12 && norm(n.text?.toString()) in tk
        } ?: return null
        val tr = Rect(); title.getBoundsInScreen(tr)
        val next = nodes.mapNotNull { n ->
            if (n.text.isNullOrBlank()) return@mapNotNull null
            val r = Rect(); n.getBoundsInScreen(r)
            if (r.top > tr.bottom + h * 0.02) r.top else null
        }.minOrNull() ?: return null
        val top = tr.bottom + (h * 0.01).toInt()
        val bottom = next - (h * 0.01).toInt()
        if (bottom - top < h * 0.04) return null
        val mid = (top + bottom) / 2
        val half = minOf((bottom - top) / 2, (h * 0.045).toInt())
        val w = resources.displayMetrics.widthPixels
        syntheticRect = Rect((w * 0.03).toInt(), mid - half, (w * 0.97).toInt(), mid + half)
        return title
    }

    private fun area(n: AccessibilityNodeInfo): Long { val r = Rect(); n.getBoundsInScreen(r); return r.width().toLong() * r.height() }

    private var foundHow = ""
    private fun find(nodes: List<AccessibilityNodeInfo>, s: Step): AccessibilityNodeInfo? {
        foundHow = ""
        if (s.toggle) {
            matchedText = null
            switchFor(nodes, s.match)?.let { return it }
            // Fallback: the labelled row below the title bar (some phones hide the switch itself).
            val h = resources.displayMetrics.heightPixels
            val keys = s.match.map { norm(it) }
            // Only on the screen that is itself named "Wi-Fi" (label in the title bar), not on the Settings list.
            // Not on the main Settings list (its "Wi-Fi" row is a menu entry, not the switch).
            val onSettingsList = nodes.any { n ->
                val r = Rect(); n.getBoundsInScreen(r)
                r.top <= h * 0.12 && norm(n.text?.toString()) == "settings"
            }
            if (onSettingsList) return null
            val ts = s.titles
            if (ts != null) {   // only on the screen whose own title matches, not on the menu that leads to it
                val tk0 = ts.map { norm(it) }
                val okTitle = nodes.any { n -> val r = Rect(); n.getBoundsInScreen(r); r.top <= h * 0.12 && norm(n.text?.toString()) in tk0 }
                if (!okTitle) return null
            }
            val below = nodes.filter { n -> val r = Rect(); n.getBoundsInScreen(r); r.top > h * 0.12 }
            val cands = below.filter { n -> norm(n.text?.toString()) in keys || norm(n.contentDescription?.toString()) in keys }
            // Prefer a row that can be tapped over a plain heading (the ring once sat on the "Portable hotspot" heading).
            val row = cands.firstOrNull { switchNear(it) != null } ?: cands.filter { tappable(it) }.minByOrNull { area(it) } ?: cands.minByOrNull { area(it) }
                ?: below.filter { n -> keys.any { k -> norm(n.text?.toString()).startsWith(k) } }.minByOrNull { area(it) }
                ?: return gapRow(nodes, s, h).also { if (it != null) foundHow = "empty band under the title" }
            foundHow = if (switchNear(row) != null) "switch next to its words" else "row words (no switch seen)"
            return switchNear(row) ?: target(row)
        }
        val dm = resources.displayMetrics
        val maxArea = dm.widthPixels.toLong() * dm.heightPixels / 6   // ignore huge containers
        for (k in s.match) {
            val nk = norm(k)
            // Same words, ignoring odd hyphens and spacing. The smallest box is the most specific one.
            val best = nodes.filter { norm(it.text?.toString()) == nk || norm(it.contentDescription?.toString()) == nk }
                .filter { area(it) in 1L..maxArea }.minByOrNull { area(it) } ?: continue
            matchedText = (best.text ?: best.contentDescription)?.toString()
            foundHow = "same words"
            return target(best)
        }
        return null
    }

    // The on/off switch for a setting. Phones lay rows out differently: on Infinix the switch sits in its own box,
    // next to (not inside) the box with the setting's name. So: first a switch whose row (up to three levels up)
    // names the setting, then a switch on the same line as the name.
    private fun switchFor(nodes: List<AccessibilityNodeInfo>, keys: List<String>): AccessibilityNodeInfo? {
        val switches = nodes.filter { isSwitchLike(it) }
        if (switches.isEmpty()) return null
        var best: AccessibilityNodeInfo? = null
        var bestArea = Long.MAX_VALUE
        for (sw in switches) {
            var p: AccessibilityNodeInfo? = sw.parent
            var level = 0
            while (p != null && level < 3) {
                if (blob(p).length < 160 && matches(p, keys)) {
                    val a = area(p)
                    if (a < bestArea) { bestArea = a; best = sw }
                    break
                }
                p = p.parent; level++
            }
        }
        if (best != null) { foundHow = "switch in the same row"; return best }
        val nk = keys.map { norm(it) }
        val words = nodes.filter { n -> norm(n.text?.toString()).let { it.isNotEmpty() && it in nk } }.sortedBy { area(it) }
        for (wd in words) {
            val wr = Rect(); wd.getBoundsInScreen(wr)
            switches.firstOrNull { sw ->
                val r = Rect(); sw.getBoundsInScreen(r)
                kotlin.math.abs(r.centerY() - wr.centerY()) < dp(24) && r.left >= wr.left
            }?.let { foundHow = "switch on the same line"; return it }
        }
        return null
    }

    // Did this tap land on the switch for these words? (The switch itself has no words; its row does.)
    private fun tappedSwitch(src: AccessibilityNodeInfo, keys: List<String>): Boolean {
        var p: AccessibilityNodeInfo? = src; var level = 0
        while (p != null && level < 4) {
            if (blob(p).length < 160 && matches(p, keys)) return true
            p = p.parent; level++
        }
        val r = Rect(); src.getBoundsInScreen(r)
        return isSwitchLike(src) && !lastTarget.isEmpty && Rect.intersects(r, lastTarget)
    }

    // The tappable thing around the label, but never a huge container like a whole screen.
    private fun target(n: AccessibilityNodeInfo): AccessibilityNodeInfo {
        val nr = Rect(); n.getBoundsInScreen(nr)
        val d = resources.displayMetrics
        val limit = minOf(maxOf(1, nr.width() * nr.height()) * 4L, d.widthPixels.toLong() * d.heightPixels / 5)
        var c: AccessibilityNodeInfo = n
        repeat(3) {
            val p = c.parent ?: return n
            val pr = Rect(); p.getBoundsInScreen(pr)
            if (pr.width().toLong() * pr.height() > limit) return n
            if (p.isClickable) return p
            c = p
        }
        return n
    }

    private fun blob(n: AccessibilityNodeInfo?, d: Int = 0): String {
        if (n == null || d > 3) return ""
        var s = "${n.text} ${n.contentDescription} "
        for (i in 0 until n.childCount) s += blob(n.getChild(i), d + 1)
        return s
    }
    private fun matches(n: AccessibilityNodeInfo?, keys: List<String>): Boolean {
        val t = blob(n).lowercase()
        return keys.any { t.contains(it.lowercase()) }
    }

    private val ARROW = 118
    private var ringLp: WindowManager.LayoutParams? = null
    private var ringAnim: ValueAnimator? = null
    private val lastTarget = Rect()

    private fun show(r: Rect) {
        val w = wm ?: return
        moveControls(r)
        val h = resources.displayMetrics.heightPixels
        val below = r.bottom + 26 + ARROW <= h   // arrow goes under the target, or above it near the bottom edge
        val lp = WindowManager.LayoutParams(r.width() + 52, r.height() + 52 + ARROW,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = r.left - 26
        lp.y = if (below) r.top - 26 else r.top - 26 - ARROW
        lastTarget.set(r)
        val v = ring
        if (v == null) {
            ring = RingView(this).also { it.arrowBelow = below; w.addView(it, lp) }
            ringLp = lp
            return
        }
        v.arrowBelow = below; v.invalidate()
        val from = ringLp
        ringAnim?.cancel()
        val still = Settings.Global.getFloat(contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f
        if (from == null || still) { try { w.updateViewLayout(v, lp) } catch (_: Exception) {}; ringLp = lp; return }
        val fx = from.x; val fy = from.y; val tx = lp.x; val ty = lp.y
        ringLp = lp
        ringAnim = ValueAnimator.ofFloat(0f, 1f).apply {   // glide to the new spot instead of jumping
            duration = 120
            addUpdateListener { a ->
                val f = a.animatedFraction
                lp.x = (fx + (tx - fx) * f).toInt(); lp.y = (fy + (ty - fy) * f).toInt()
                try { w.updateViewLayout(v, lp) } catch (_: Exception) {}
            }
            start()
        }
    }

    private fun hide() {
        hideRing(); hideSwipe()
        if (System.currentTimeMillis() >= holdUntil) hideLabel()
    }

    // Instruction text on screen too, because many phones have no Chinyanja or Icibemba voice.
    private fun showLabel(text: String, top: Boolean, dim: Boolean = false, step: String? = null) {
        if (Guides.chatOpen) return
        val w = wm ?: return
        val shown: CharSequence = if (step == null) text else android.text.SpannableString(step + "\n" + text).apply {
            setSpan(android.text.style.RelativeSizeSpan(0.7f), 0, step.length, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            setSpan(android.text.style.ForegroundColorSpan(0xFF145A3D.toInt()), 0, step.length, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        val d = resources.displayMetrics
        val lp = WindowManager.LayoutParams((d.widthPixels * 0.9).toInt(), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT)
        val atTop = top || surface == "permission"
        lp.gravity = (if (atTop) Gravity.TOP else Gravity.BOTTOM) or Gravity.CENTER_HORIZONTAL
        val kb = imeTop?.let { d.heightPixels - it } ?: 0   // keep the card above the keyboard
        lp.y = if (atTop) (96 * d.density).toInt() else kb + (88 * d.density).toInt()
        val th = testerHeight()
        if (th > 0 && atTop == testerTop) lp.y = maxOf(lp.y, (if (atTop) dp(28) else kb + dp(10)) + th + dp(8))   // below or above the tester card
        val v = label
        if (v == null) {
            val t = TextView(this)
            t.textSize = if (surface == "permission") Profile.cardSize(this) - 4f else Profile.cardSize(this); t.setTextColor(0xFF1A1A1A.toInt()); t.typeface = Typeface.DEFAULT_BOLD; t.gravity = Gravity.CENTER
            val p = (14 * d.density).toInt(); t.setPadding(p, p, p, p)
            val g = GradientDrawable(); g.setColor(0xFFF7F5F0.toInt()); g.cornerRadius = 24 * d.density; g.setStroke(maxOf(1, d.density.toInt()), 0x33000000); t.background = g
            t.elevation = 6 * d.density; t.setLineSpacing(0f, 1.15f)
            t.text = shown; t.alpha = if (dim) 0.55f else 1f; label = t; w.addView(t, lp); announce(t, text)
        } else {
            if (v.text.toString() != shown.toString()) { v.text = shown; announce(v, text) }
            v.textSize = if (surface == "permission") Profile.cardSize(this) - 4f else Profile.cardSize(this)
            v.alpha = if (dim) 0.55f else 1f
            w.updateViewLayout(v, lp)
        }
    }
    private fun touchExploring(): Boolean =
        (getSystemService(ACCESSIBILITY_SERVICE) as android.view.accessibility.AccessibilityManager).isTouchExplorationEnabled
    private fun announce(v: View, text: String) { if (touchExploring()) v.announceForAccessibility(text) }

    private fun hideLabel() { label?.let { try { wm?.removeView(it) } catch (_: Exception) {} }; label = null }

    private fun speak(s: Step, asked: Boolean = false) {
        if (touchExploring()) return   // TalkBack already reads the card; do not talk over it
        if (!asked && !Profile.voiceOn(this)) return   // the person turned spoken steps off (Repeat still speaks)
        val l = Guides.lang
        val res = s.audio?.let { resources.getIdentifier("${it}_$l", "raw", packageName) } ?: 0
        if (res != 0) { mp?.release(); mp = MediaPlayer.create(this, res); mp?.start(); return }
        say(s.say)
    }
    // Uses a voice for the chosen language if the phone has one; otherwise falls back to English.
    private fun say(texts: Map<String, String>) {
        if (!ttsReady) return
        val l = Guides.lang
        val loc = Locale(l)
        val ok = (tts?.isLanguageAvailable(loc) ?: TextToSpeech.LANG_NOT_SUPPORTED) >= TextToSpeech.LANG_AVAILABLE
        val msg = if (ok) texts[l] ?: texts["en"] else texts["en"] ?: texts[l]
        tts?.language = if (ok) loc else Locale.ENGLISH
        tts?.setSpeechRate(Profile.speechRate(this))
        if (msg != null) tts?.speak(msg, TextToSpeech.QUEUE_FLUSH, null, "sg")
    }
}
