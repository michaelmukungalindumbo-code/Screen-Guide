package zm.screenguide

// Every rule that turns a person's words into an action lives here: start an offline task, open an app first, open an
// app at once, treat a question as a problem or as money. No Android code, so MatchTest runs hundreds of real questions
// through it on every build. Lessons that made this file: "Take a screenshot on your phone" opened the Phone app;
// "number" matched "mb"; "ready" matched "read". Words are not commands: match whole words, and plain words carefully.
object Match {
    // " take a screenshot on your phone " : lower case, whole words, single spaces, a space at each end.
    fun words(s: String) = " " + s.lowercase().replace(Regex("[^\\p{L}\\p{N}]+"), " ").trim() + " "
    private fun has(w: String, phrase: String): Boolean { val p = words(phrase); return p.isNotBlank() && w.contains(p) }
    private fun norm(s: String) = s.lowercase().filter { it.isLetterOrDigit() }

    // How well an offline task's keywords fit the text. Whole words only; a longer phrase counts more.
    fun score(keywords: List<String>, text: String): Int {
        val w = words(text)
        return keywords.sumOf { k -> if (has(w, k)) words(k).trim().split(" ").size else 0 }
    }

    // A problem needs the helper, not a "turn it on" task or an app opening by itself.
    private val problemWords = listOf("not working", "doesn't", "does not", "doesnt", "won't", "wont", "can't", "cant", "cannot",
        "problem", "keeps", "stopped", "error", "failed", "fails", "slow", "not opening", "not showing", "disconnect", "disconnects",
        "disconnecting", "broken", "fix", "hacked", "stuck")
    fun isProblem(text: String): Boolean {
        val w = words(text)
        return w.startsWith(" why ") || w.startsWith(" what ") || problemWords.any { has(w, it) }   // " whatsapp " is not " what "
    }

    // Money tasks are never guided on screen (money apps are off limits).
    private val money = Regex("\\b(mobile money|momo|airtel money|zamtel kwacha|kwacha|send(ing)? money|withdraw\\w*|cash ?out|" +
        "transfer\\w* (money|funds|cash)|pay(ing)? (a |my |the |for )?(\\w+ )?bills?|bank transfer|deposit|banking|bank account|bank app)\\b",
        RegexOption.IGNORE_CASE)
    fun isMoney(text: String) = money.containsMatchIn(text)

    // A question about doing something ("How do I scan a document?", "Which app can edit videos?"). The installed app
    // names go with it, so the helper picks an app the person already has, or names one to install from the Play Store.
    // Never for money, and never for questions about the phone itself ("Why is my phone slow?", "What is WhatsApp?").
    fun wantsApps(text: String): Boolean {
        if (isMoney(text)) return false
        val w = words(text)
        if (listOf("app", "apps", "application", "applications").any { has(w, it) }) return true
        return listOf("how", "which", "can i", "i want", "i need", "i would like", "help me", "is there", "teach me", "show me how")
            .any { w.startsWith(" $it ") }
    }

    // App names that are also ordinary words. They count only when used like an app ("open Settings", "the Camera app").
    val plainNames = setOf("phone", "files", "file manager", "messages", "messaging", "camera", "clock", "gallery", "music", "notes",
        "notepad", "contacts", "calendar", "settings", "weather", "photos", "mail", "email", "maps", "calculator", "recorder", "browser",
        "videos", "video", "radio", "compass", "health", "store", "security", "themes", "theme", "translate", "assistant", "search", "sheets")
    private val callWords = Regex("\\b(call|calls|calling|dial|dialer|dialler|keypad|phone app|call log|missed call|ring)\\b")
    private val stores = listOf("play store", "palm store", "app store", "galaxy store", "appgallery", "app gallery")
    private val installWords = Regex("\\b(install|reinstall|update)\\b")

    // The installed app a guide should open first, as (name, package), or null. apps: (label, package) of launcher apps.
    fun pickApp(goal: String, apps: List<Pair<String, String>>): Pair<String, String>? {
        val low = goal.lowercase()
        // Installing or updating happens in the store, even when the goal names the app ("Install WhatsApp").
        apps.firstOrNull { (n, _) -> n.lowercase() in stores && Regex("(?<![\\w])" + Regex.escape(n.lowercase()) + "(?![\\w])").containsMatchIn(low) }?.let { return it }
        if (installWords.containsMatchIn(low)) apps.firstOrNull { it.first.equals("Play Store", true) }?.let { return it }
        // Google's apps are named without "Google" on the phone: "Google Drive" is the app "Drive" (seen: it opened
        // the Google search app). The longer phrase wins over "Google" at the same place.
        fun find(t: String) = (if (t != "google") Regex("(?<![\\w])google\\s+" + Regex.escape(t) + "(?![\\w])").find(low) else null) ?: run {
            val rx = if (t !in plainNames) "(?<![\\w])" + Regex.escape(t) + "(?![\\w])"
                else "(?:\\b(?:open|in|the|use|using|launch|from|to|tap|start|into|with)\\s+)" + Regex.escape(t) + "(?![\\w])|(?<![\\w])" + Regex.escape(t) + "\\s+app\\b"
            Regex(rx).find(low)
        }
        var best: Pair<String, String>? = null; var at = Int.MAX_VALUE; var len = 0
        for ((n, p) in apps) {
            val ln = n.lowercase()
            if (ln == "phone" && !callWords.containsMatchIn(low)) continue   // "on your phone" is the device
            // Its own name, another name it is known by, or its name without "Go"/"Lite" (a little weaker, so the full
            // app wins when both are on the phone)
            val base = ln.replace(lighter, "")
            val tries = listOfNotNull(ln to 0, aliases[ln]?.let { it to 0 }, if (base != ln && base.length >= 3) base to 1 else null)
            for ((t, weaker) in tries) {
                val m = find(t) ?: continue
                val next = otherApp.find(low.substring(m.range.last + 1))
                if (next != null && !t.endsWith(next.groupValues[1])) continue   // "WhatsApp" in "WhatsApp Business": another app
                val l = m.value.length - weaker
                if (m.range.first < at || (m.range.first == at && l > len)) { best = n to p; at = m.range.first; len = l }
            }
        }
        if (best == null) best = nearApp(goal, apps)   // "Cap Cut", "you tube", "Watsap": the name written another way
        if (best == null && callWords.containsMatchIn(low)) best = apps.firstOrNull { it.first.equals("phone", true) }   // "Make a call to Mum"
        return best
    }

    // ---- 7 Nov: a name written or heard another way: "Cap Cut", "you tube", "Whats App" (split), "Watsap", "Youtub" (a
    // slip), "what's up" (voice typing). Used only when no name matched as written, and never for plain words (Photos,
    // Notes, Drive, Phone), which one slip turns into an ordinary word. Otherwise the app was not opened, or was called
    // "not on this phone" and offered for install.
    private val heard = mapOf("whatsup" to "whatsapp", "watsup" to "whatsapp", "ticktock" to "tiktok", "tictoc" to "tiktok",
        "tiktoc" to "tiktok", "insta" to "instagram", "fb" to "facebook")
    private val wordRx = Regex("[\\p{L}\\p{N}']+")

    // Letters added, left out or changed to get from one word to the other
    private fun slips(a: String, b: String): Int {
        var prev = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            val cur = IntArray(b.length + 1); cur[0] = i
            for (j in 1..b.length) cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1)
            prev = cur
        }
        return prev[b.length]
    }

    // How far the words are from an app's name: 0 when they are the same without spaces and marks ("Cap Cut"), or a known
    // way of hearing it ("what's up"); 1 or 2 slips for a longer name with the same first letter; null when not that app.
    private fun near(said: String, name: String): Int? {
        if (name.lowercase() in plainNames) return null
        val s = norm(said); val n = norm(name)
        if (s.isEmpty() || n.length < 3) return null
        if (s == n || heard[s] == n) return 0
        if (n.length < 5 || s.length < 4 || s[0] != n[0]) return null
        return slips(s, n).takeIf { it <= (if (n.length >= 8) 2 else 1) }
    }

    // The installed app these words name another way, as (name, package), or null. Up to three words joined, exactly ("you
    // tube", "Whats App"), or one word with a slip ("Watsap"); fewest slips first, then the first one named. "Whats App
    // Business" is still another app.
    fun nearApp(text: String, apps: List<Pair<String, String>>): Pair<String, String>? {
        val words = wordRx.findAll(text).toList()
        var best: Pair<String, String>? = null; var bestD = Int.MAX_VALUE; var bestAt = Int.MAX_VALUE
        for (i in words.indices) for (k in 1..3) {
            if (i + k > words.size) break
            val said = words.subList(i, i + k).joinToString("") { it.value }
            val next = otherApp.find(text.substring(words[i + k - 1].range.last + 1).lowercase())
            for ((n, p) in apps) {
                val ln = n.lowercase()
                if (next != null && !ln.endsWith(next.groupValues[1])) continue
                for (t in listOfNotNull(ln, ln.replace(lighter, "").takeIf { it != ln && it.length >= 3 })) {
                    val d = near(said, t) ?: continue
                    if (k > 1 && d > 0) continue   // joined words must be the name exactly ("phone faster" is not Phone Master)
                    val at = words[i].range.first
                    if (d < bestD || (d == bestD && at < bestAt)) { best = n to p; bestD = d; bestAt = at }
                }
            }
        }
        return best
    }

    // Another app with a longer name: 5 Nov, "Open the WhatsApp Business app" rang plain WhatsApp, on a phone without
    // WhatsApp Business. "WhatsApp" there is not that app; nor is YouTube in "YouTube Kids", "YouTube Music" or "YouTube Studio".
    private val otherApp = Regex("^\\s+(business|kids|music|studio)(?![\\w])")
    // Go and Lite versions do the same job, and cheaper phones (itel, Tecno, Infinix) often have them: Gmail Go, Maps Go,
    // Facebook Lite. Asked for Gmail, the phone's Gmail Go is right.
    private val lighter = Regex("\\s+(go|lite)$")
    // Names under the icon that differ from the app's own name: WhatsApp Business is "WA Business".
    private val aliases = mapOf("wa business" to "whatsapp business")
    // Never offered for installing, whatever the goal says (the same words keep these apps out of guides)
    val moneyApps = listOf("momo", "airtel", "mtn", "bank", "zanaco", "fnb", "stanbic", "absa", "finance", "wallet", "pay", "money",
        "binance", "paypal", "credit", "loan", "cash", "kwacha", "natsave", "investrust", "lupiya", "mukuru", "worldremit", "remit")
    // "the TikTok app": a name in capitals just before "app"
    private val namedApp = Regex("(?:^|\\b(?i:open|the|use|using|in|on|with|from|launch|start)\\s+)((?:[A-Z][\\w!+.'-]*\\s+){0,2}[A-Z][\\w!+.'-]*)\\s+(?i:app)\\b")

    // The app a goal asks for that is not on this phone, or null. Only a name it is sure of: another version of an
    // installed app ("WhatsApp Business" next to "WhatsApp"), or a name in capitals before "app" ("the TikTok app") that
    // is not an ordinary word. Never banking or money apps, never a store, never ScreenGuide. installed: the app names.
    fun missingApp(goal: String, installed: List<String>): String? {
        val low = goal.lowercase()
        if (isMoney(goal) || installWords.containsMatchIn(low) || pickApp(goal, installed.map { it to it }) != null) return null
        val name = installed.firstNotNullOfOrNull { n ->
            Regex("(?<![\\w])" + Regex.escape(n.lowercase()) + "\\s+(business|kids|music|studio)(?![\\w])").find(low)?.let { goal.substring(it.range) }
        } ?: namedApp.find(goal)?.groupValues?.get(1) ?: return null
        val ln = name.lowercase()
        if (ln in plainNames || ln in stores || ln.replace(" ", "") == "screenguide" || moneyApps.any { ln.contains(it) }) return null
        if (feature(ln) != null) return null   // v0.91: a part of an app ("the Safe Folder app") is never offered for installing
        return name
    }

    // ---- v0.91 (the owner's tests, 7 Nov) ----
    // Parts of apps that people call apps ("a new user can consider it to be an app"). Never offered for installing: a
    // stranger's app with that name could be installed. Said plainly, with the app they are part of.
    private val features = listOf("safe folder" to ("Safe folder" to "Files"), "app twin" to ("App twin" to "Settings"),
        "dual apps" to ("Dual apps" to "Settings"), "dual app" to ("Dual apps" to "Settings"), "app clone" to ("App clone" to "Settings"))
    fun feature(text: String): Pair<String, String>? { val w = words(text); return features.firstOrNull { has(w, it.first) }?.second }
    fun featureLine(f: String, app: String) = "$f is not an app. It is part of the $app app."

    // Key terms: the app on this phone that a message names anywhere, however it is asked ("How do I use XTheme?", "xtheme",
    // "I can't find xtheme"), with the tested rules of pickApp (plain words like Phone or Camera only when clearly the app).
    // Never for money. ScreenGuide then offers to open it at once, with no helper (the owner: "use KEY TERMS").
    fun keyApp(text: String, apps: List<Pair<String, String>>): Pair<String, String>? {
        if (isMoney(text) || feature(text) != null) return null
        // An app named after a language ("English" on the owner's phone) only when clearly the app: "learn English words" is not
        val low = text.lowercase()
        return pickApp(text, apps.filter { (n, _) -> val ln = n.lowercase()
            ln !in languages || Regex("\\b(?:open|use|using|launch|start)\\s+(?:the\\s+)?" + Regex.escape(ln) + "(?![\\w])|(?<![\\w])" + Regex.escape(ln) + "\\s+app\\b").containsMatchIn(low) })
    }
    private val languages = setOf("english", "french", "spanish", "portuguese", "arabic", "chinese", "swahili", "bemba", "nyanja", "chinyanja",
        "icibemba", "tonga", "lozi", "kaonde", "lunda", "luvale")

    // "Install TikTok", "download Boomplay from the Play Store", "download the CapCut app": the app to install, or null.
    // "Download a video" or "install it" are not apps. Not money apps, not plain words, not parts of apps.
    private val installAsk = Regex("^(?:please\\s+)?install\\s+(?:the\\s+)?(.+?)(?:\\s+app)?(?:\\s+(?:from|on)\\s+(?:the\\s+)?(?:play\\s*store|store))?$")
    private val downloadAsk = Regex("^(?:please\\s+)?download\\s+(?:the\\s+)?(.+?)(?:\\s+app(?:\\s+(?:from|on)\\s+(?:the\\s+)?(?:play\\s*store|store))?|\\s+(?:from|on)\\s+(?:the\\s+)?(?:play\\s*store|store))$")
    private val notAnApp = Regex("^(?:a|an|my|this|that|these|some|it|them|apps?|updates?|games?)(?:\\s|$)")
    fun installTarget(text: String): String? {
        val t = text.trim().trimEnd('?', '.', '!').replace(Regex("\\s+"), " ")
        val low = t.lowercase()
        val m = installAsk.find(low) ?: downloadAsk.find(low) ?: return null
        val name = t.substring(m.groups[1]!!.range).trim()
        val ln = name.lowercase()
        if (name.length < 2 || name.split(" ").size > 3 || notAnApp.containsMatchIn(ln) || ln in plainNames || ln in stores) return null
        if (isMoney(name) || moneyApps.any { ln.contains(it) } || feature(ln) != null) return null
        return name.split(" ").joinToString(" ") { it.replaceFirstChar { c -> c.uppercaseChar() } }
    }

    // The name after "open", "find", "where is" ("Open xtheme" -> "xtheme"), or null: for the test phone's note when no app
    // has that name, with the closest names this phone has (so the next report shows why).
    fun openWord(text: String): String? {
        val t = text.trim().lowercase().trimEnd('?', '.', '!')
        val p = listOf("open ", "find ", "where is ", "where's ", "launch ", "go to ", "start ").firstOrNull { t.startsWith(it) } ?: return null
        return t.removePrefix(p).trim().removePrefix("the ").removePrefix("my ").removeSuffix(" app").trim().ifEmpty { null }
    }
    fun closest(word: String, names: List<String>, n: Int = 3): List<String> =
        names.distinct().sortedBy { slips(norm(word), norm(it)) }.take(n)

    // ---- ScreenGuide's own settings (6 Nov, the owner chose: Show me works inside ScreenGuide too). Its menus never
    // change, so the way there is known: no AI, and nothing from the chat leaves the phone. First match wins, so the more
    // particular words come first ("chat colour" is the chat background, not Colours).
    private val ownSettings = listOf(
        listOf("smart guide") to "Smart guide (AI)",
        listOf("screen pictures", "screen picture") to "Screen pictures when words are not enough",
        listOf("scam guard") to "Scam guard",
        listOf("read button") to "Read button: reads any screen to you",
        listOf("error messages", "error message") to "Explain error messages")
    private val ownCustomize = listOf(
        listOf("chat background", "background", "wallpaper", "chat theme", "chat colour", "chat color", "skin") to "Chat background",
        listOf("language") to "Language",
        listOf("record", "real voice", "own voice") to "Record a real voice for the steps",
        listOf("speaking speed", "speed", "slower", "faster") to "Speaking speed",
        listOf("speak the steps", "voice", "sound", "mute", "speak") to "Speak the steps",
        listOf("step card", "card size", "card bigger", "bigger card") to "Size of the step card",
        listOf("how i explain", "explain", "simpler words") to "How I explain",
        listOf("dark mode", "light mode", "colours", "colors", "theme", "dark", "light") to "Colours",
        listOf("vibrate", "vibration") to "Vibrate on each step",
        listOf("my name", "your name", "name") to "Your name")
    private val ownMenu = listOf(
        listOf("account", "sign in", "sign out", "log in", "log out", "login") to "Your account",
        listOf("incognito") to "Incognito",
        listOf("plan", "plus", "subscription") to "Your plan",
        listOf("chat history", "old chats", "chats") to "Chats",
        listOf("stay safe", "scams") to "Stay safe from scams",
        listOf("teach a task", "teach") to "Teach a task",
        listOf("shared guide", "share code") to "Open a shared guide",
        listOf("help from someone", "someone to help") to "Get help from someone",
        listOf("learn your phone") to "Learn your phone",
        listOf("about", "version") to "About ScreenGuide",
        listOf("settings", "permissions") to "Settings and permissions")

    fun aboutScreenGuide(goal: String): Boolean { val w = words(goal); return has(w, "screenguide") || has(w, "screen guide") }

    // The way to one of ScreenGuide's own settings, inside ScreenGuide, or null when the goal is not about ScreenGuide
    fun selfPath(goal: String): List<String>? {
        if (!aboutScreenGuide(goal)) return null
        val w = words(goal.replace(Regex("(?i)screen\\s*guide('?s)?"), " "))
        fun pick(list: List<Pair<List<String>, String>>) = list.firstOrNull { (ks, _) -> ks.any { has(w, it) } }?.second
        pick(ownSettings)?.let { return listOf("Menu", "Settings and permissions", it) }
        pick(ownCustomize)?.let { return listOf("Menu", "Customize ScreenGuide", it) }
        pick(ownMenu)?.let { return listOf("Menu", it) }
        return listOf("Menu")   // not sure what: open the menu, they choose
    }
    // What to say when the last row is tapped, or null for the usual "Well done!"
    fun selfDone(row: String): String? = when (row) {
        "Chat background" -> "Now tap a colour, or Your photo for a picture from your gallery."
        "Your account" -> "Now tap Sign out, or Sign in with Google."
        "Language" -> "Now tap your language."
        "Menu" -> "Now tap what you want to change."
        else -> null
    }
    // Did the person just tap the last row? (MainActivity's menus say which row was tapped: Guides.ownTap)
    fun selfFinished(lastRow: String, tapped: String?): Boolean =
        tapped != null && norm(tapped).isNotEmpty() && norm(tapped) == norm(lastRow)
    // Every row name a path can use (SelfGuideTest checks they are all in MainActivity's menus)
    fun selfRows(): List<String> = (listOf("Menu", "Settings and permissions", "Customize ScreenGuide") +
        (ownSettings + ownCustomize + ownMenu).map { it.second }).distinct()

    // Very short requests open an app at once ("weather", "set an alarm"). Never when another app is named or something
    // is being sent ("send a photo from my gallery on WhatsApp"), never for how/why/what questions or problems.
    private val quick = listOf(
        listOf("weather", "forecast", "will it rain") to listOf("weather"),
        listOf("alarm", "timer", "stopwatch") to listOf("clock"),
        listOf("calculator", "calculate") to listOf("calculator"),
        listOf("take a photo", "take a picture", "take a selfie", "camera") to listOf("camera"),
        listOf("gallery", "my pictures", "my photos") to listOf("gallery", "photos"),
        listOf("calendar") to listOf("calendar"),
        listOf("directions", "maps") to listOf("maps"))
    fun quickTarget(text: String, appLabels: List<String>): List<String>? {
        val w = words(text)
        if (w.trim().split(" ").size > 7 || isProblem(text) || isMoney(text)) return null
        if (listOf("how", "why", "what", "where", "can", "could").any { w.startsWith(" $it ") }) return null
        if (Regex("\\b(send|share|upload|post|attach|forward|delete|edit)\\b").containsMatchIn(w)) return null
        if (appLabels.any { a -> a.length >= 3 && a.lowercase() !in plainNames && has(w, a) }) return null   // another app is named
        return quick.firstOrNull { (terms, _) -> terms.any { has(w, it) } }?.second
    }

    // "open X", "find X", "where is X": the launcher app it names, or null. "find my phone" is the device, not an app.
    fun findTarget(text: String, appLabels: List<String>): String? {
        val t = text.trim().lowercase().trimEnd('?', '.', '!')
        for (p in listOf("open ", "find ", "where is ", "where's ", "launch ", "go to ", "start ")) {
            if (!t.startsWith(p)) continue
            val rest = t.removePrefix(p).trim()
            if (rest.split(Regex("\\s+")).size > 3) return null
            val bare = rest.removePrefix("the ").removePrefix("my ").removeSuffix(" app").trim()
            if (bare == "phone" && !rest.endsWith(" app") && !(p == "open " && !rest.startsWith("my "))) return null
            val n = norm(bare)
            if (n.length < 3) return null
            return appLabels.firstOrNull { norm(it) == n } ?: appLabels.firstOrNull { norm(it).startsWith(n) }
                ?: nearApp(bare, appLabels.map { it to it })?.first   // "open watsap", "open insta"
        }
        return null
    }

    // v0.94 tests first: not built yet
    fun findableName(w: String): Boolean = false
    fun titleCase(w: String) = w
}
