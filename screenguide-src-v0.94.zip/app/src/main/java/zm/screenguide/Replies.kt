package zm.screenguide

// v0.94 tests first: not built yet
object Replies {
    const val CANT_REACH = ""
    const val NOT_AVAILABLE = ""
    fun fail(code: Int, text: String, inRow: Int): String = text
    fun withWayOn(words: String, hasOffer: Boolean, hasGuide: Boolean): String = words
}
