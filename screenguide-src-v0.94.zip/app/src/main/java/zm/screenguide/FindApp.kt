package zm.screenguide

// Getting into the app a guide needs when its icon is not on the screen. 6 Nov (issues 39 and 40, Infinix): the list of
// all apps was already open, scrolled past Drive, with a Search box; the guide said "Swipe up to see all your apps", and
// the owner asked "why didn't you just tell me to search?". He chose: point at Search, then say what to type.
object FindApp {
    enum class Way { TYPE, SEARCH, SCROLL, SWIPE, HOME }

    // The phone's own app search ("Search", "Search apps"), never a search inside an app ("Search in Drive").
    private val searchBox = Regex("^search(\\s+(apps|your apps|phone|your phone|apps (and|&) more))?\\W*$", RegexOption.IGNORE_CASE)
    fun isSearchBox(word: String) = searchBox.matches(word.trim())

    private fun norm(s: String) = s.lowercase().filter { it.isLetterOrDigit() }
    private val listWords = setOf("allapps", "searchapps", "applibrary", "searchyourapps")
    private val letter = Regex("^[A-Z#]$")

    // The list of all apps: its own words ("All apps", "Search apps"), the A-Z index down its side, or the app names in
    // A to Z order, which is all Infinix's list has. shown: the screen's words, top to bottom; installed: app names.
    fun isAppList(shown: List<String>, installed: Collection<String>): Boolean {
        if (shown.any { norm(it) in listWords }) return true
        if (shown.count { letter.matches(it.trim()) } >= 8) return true
        val known = installed.map { it.trim().lowercase() }.toSet()
        val names = shown.map { it.trim().lowercase() }.filter { it in known }
        if (names.size < 6) return false
        return names.zipWithNext().count { (a, b) -> a <= b } >= (names.size - 1) * 0.8
    }

    // home: the phone's home or app list is showing. search: its Search box is on the screen. typing: a text box is open.
    // searched: they were already told to tap Search (so an open box is that search, waiting for the name).
    fun way(home: Boolean, appList: Boolean, search: Boolean, typing: Boolean, searched: Boolean): Way = when {
        typing && searched -> Way.TYPE
        home && appList && search -> Way.SEARCH
        home && appList -> Way.SCROLL
        home -> Way.SWIPE
        else -> Way.HOME
    }

    // ---- v0.86: two copies of an app (App twin, Dual apps, Clone apps), and an app whose icon is hidden ----
    private val twinMark = Regex("^\\(?\\s*(2|ii|clone|twin|dual|copy)\\s*\\)?$")
    private val twinWord = setOf("dual", "twin", "clone", "second", "2nd")

    // The app's own name, or a second copy's ("WhatsApp (2)", "Dual WhatsApp", "WhatsApp Twin"), not another app
    // ("WhatsApp Business").
    fun isCopyOf(word: String, app: String): Boolean {
        val w = word.trim().lowercase(); val a = app.trim().lowercase()
        if (a.isEmpty() || w.isEmpty()) return false
        if (norm(w) == norm(a)) return true
        if (w.startsWith(a)) return twinMark.matches(w.removePrefix(a).trim())
        if (w.endsWith(a)) return w.removeSuffix(a).trim().let { it in twinWord || twinMark.matches(it) }
        return false
    }

    // A second copy's name: marked as one. Two plain "WhatsApp" can be the same app twice on one screen (the row of
    // recent apps above the list of all apps), so only a marked name counts as a second copy.
    fun isTwin(word: String, app: String) = isCopyOf(word, app) && norm(word) != norm(app)

    // A name cut short under its icon ("Past Papers …" for Past Papers ZM)
    fun isCut(word: String, app: String): Boolean {
        val w = word.trim()
        if (!(w.endsWith("...") || w.endsWith("\u2026"))) return false
        val stem = norm(w)
        return stem.length >= 4 && norm(app).startsWith(stem) && stem != norm(app)
    }

    // How many separate places these boxes are in (left, top, right, bottom): an icon and its name overlap, two copies
    // of an app do not.
    fun places(boxes: List<IntArray>): Int {
        val groups = ArrayList<IntArray>()
        for (b in boxes) {
            val g = groups.firstOrNull { it[0] < b[2] && b[0] < it[2] && it[1] < b[3] && b[1] < it[3] }
            if (g == null) groups.add(b.copyOf())
            else { g[0] = minOf(g[0], b[0]); g[1] = minOf(g[1], b[1]); g[2] = maxOf(g[2], b[2]); g[3] = maxOf(g[3], b[3]) }
        }
        return groups.size
    }

    // In the list of all apps (A to Z), the app is not where its name belongs: two names next to each other in the list
    // go round it ("Docs", then "Files", but no "Drive"). Only inside a run of at least five names in A-Z order, so the
    // row of recent apps above the list does not count. shown: the screen's words, top to bottom; installed: app names.
    fun hiddenHere(app: String, shown: List<String>, installed: Collection<String>): Boolean {
        val a = app.trim().lowercase()
        val known = installed.map { it.trim().lowercase() }.toSet()
        val names = shown.map { it.trim().lowercase() }.filter { it in known }
        if (a in names || names.size < 5 || shown.any { isCut(it, app) }) return false
        for (i in 0 until names.size - 1) {
            if (!(names[i] < a && a < names[i + 1])) continue
            var lo = i; while (lo > 0 && names[lo - 1] <= names[lo]) lo--
            var hi = i + 1; while (hi < names.size - 1 && names[hi] <= names[hi + 1]) hi++
            if (hi - lo + 1 >= 5) return true
        }
        return false
    }

    // They typed the whole name in the phone's search, and nothing came up
    fun typedName(typed: String, app: String) = norm(typed).let { it.isNotEmpty() && it == norm(app) }

    // English only, like the other words of this step: there are no checked Nyanja or Bemba words for these yet.
    fun twoCopies(app: String) = "You have two $app. Tap the one you want."
    fun hidden(app: String) = "$app is on this phone, but its icon is hidden. I can open it for you."

    // English only, like the other words of this step: there are no checked Nyanja or Bemba words for "type" yet.
    fun say(way: Way, app: String, box: String = "Search"): String = when (way) {
        Way.TYPE -> "Type $app."
        Way.SEARCH -> "Tap “$box”, then type $app."
        Way.SCROLL -> "Scroll down to find “$app”."
        Way.SWIPE -> "Swipe up to see all your apps."
        Way.HOME -> "Press Home, then swipe up to see all your apps."
    }

    // v0.94 tests first: not built yet
    fun sameName(said: String, app: String): Boolean = false
}
