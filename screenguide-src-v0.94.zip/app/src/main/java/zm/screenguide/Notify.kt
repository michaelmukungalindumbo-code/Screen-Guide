package zm.screenguide

// v0.94 tests first: not built yet
object Notify {
    fun text(ok: Boolean) = ""
    fun needsAsking(sdk: Int, granted: Boolean, askedBefore: Boolean) = false
}
