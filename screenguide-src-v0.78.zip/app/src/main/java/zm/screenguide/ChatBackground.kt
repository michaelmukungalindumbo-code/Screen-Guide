package zm.screenguide

// The chat's background colour, like WhatsApp's chat themes (the owner asked, 6 Nov). Each colour has a pale shade for
// light mode and a deep one for dark mode, so the words on it stay easy to read (ChatBackgroundTest checks it).
object ChatBackground {
    class Choice(val key: String, val name: String, val light: Int, val dark: Int)

    val choices = listOf(Choice("default", "Default", 0xFFFAF6EF.toInt(), 0xFF0B0D0F.toInt()))

    fun of(key: String): Choice = choices.firstOrNull { it.key == key } ?: choices[0]
    fun color(key: String, dark: Boolean): Int = of(key).let { if (dark) it.dark else it.light }

    // How readable one colour is on another (WCAG contrast: 1 to 21; 7 and more is easy to read)
    fun contrast(a: Int, b: Int): Double {
        fun lum(c: Int): Double {
            fun ch(v: Int): Double { val x = v / 255.0; return if (x <= 0.03928) x / 12.92 else Math.pow((x + 0.055) / 1.055, 2.4) }
            return 0.2126 * ch(c shr 16 and 0xFF) + 0.7152 * ch(c shr 8 and 0xFF) + 0.0722 * ch(c and 0xFF)
        }
        val la = lum(a); val lb = lum(b)
        return (maxOf(la, lb) + 0.05) / (minOf(la, lb) + 0.05)
    }
}
