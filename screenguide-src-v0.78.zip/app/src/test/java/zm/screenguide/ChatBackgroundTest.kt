package zm.screenguide

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ChatBackgroundTest {
    // The app's own text colours (MainActivity): ink, mute and the accent, in light and in dark mode
    private val light = Triple(0xFF1F1A14.toInt(), 0xFF534C45.toInt(), 0xFF145A3D.toInt())
    private val dark = Triple(0xFFF2F4F5.toInt(), 0xFFADB5BA.toInt(), 0xFF18C3DA.toInt())

    // v0.78, 6 Nov: the owner asked for a choice of chat background colours, like WhatsApp's chat themes
    @Test fun thereIsAChoice() {
        assertTrue(ChatBackground.choices.size >= 6)
        assertEquals(ChatBackground.choices.size, ChatBackground.choices.map { it.key }.toSet().size)
        assertEquals(ChatBackground.choices.size, ChatBackground.choices.map { it.light }.toSet().size)
        assertEquals("Default", ChatBackground.of("default").name)
        assertEquals("Default", ChatBackground.of("something old").name)                  // an unknown choice: the usual colour
        assertEquals(0xFFFAF6EF.toInt(), ChatBackground.color("default", false))          // the same as before in both modes
        assertEquals(0xFF0B0D0F.toInt(), ChatBackground.color("default", true))
        assertEquals(ChatBackground.of("green").dark, ChatBackground.color("green", true))
    }

    // Every colour keeps the words easy to read, for people with weak eyes and in sunlight
    @Test fun everyColourIsEasyToRead() {
        for (c in ChatBackground.choices) {
            for ((bg, t) in listOf(c.light to light, c.dark to dark)) {
                assertTrue("${c.name}: text", ChatBackground.contrast(t.first, bg) >= 7.0)
                assertTrue("${c.name}: grey text", ChatBackground.contrast(t.second, bg) >= 4.5)
                assertTrue("${c.name}: buttons", ChatBackground.contrast(t.third, bg) >= 4.5)
            }
        }
        assertEquals(21.0, ChatBackground.contrast(0xFF000000.toInt(), 0xFFFFFFFF.toInt()), 0.01)
    }
}
