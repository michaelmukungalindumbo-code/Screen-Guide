package zm.screenguide

// tests first: not built yet
object Updater {
    class Found(val version: String, val url: String, val bytes: Long)
    fun newer(found: String, mine: String): Boolean = false
    fun parse(json: String, mine: String): Found? = null
    fun due(last: Long, now: Long) = false
    fun size(bytes: Long) = "?"
    fun offer(f: Found) = ""
    fun failed(status: Int): String = ""
}
