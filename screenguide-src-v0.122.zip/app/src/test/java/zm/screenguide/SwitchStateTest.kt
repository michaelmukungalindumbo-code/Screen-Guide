package zm.screenguide

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

// v0.122, the owner's phone (13 Nov, Infinix, 0.120): he asked about an app's error, then "Show me". On the Wi-Fi page the
// guide said "Tap the switch next to Wi-Fi to turn it on." on step after step, with Wi-Fi already on (the helper was
// never told whether a switch is on), and the ring stayed on the word "Wi-Fi", not on its switch.
class SwitchStateTest {
    private fun src(n: String) = listOf("src/main/java/zm/screenguide/$n", "app/src/main/java/zm/screenguide/$n").map { File(it) }.first { it.exists() }.readText()

    @Test fun theHelperIsToldWhetherASwitchIsOn() {
        assertEquals("[switch on]", ScreenWords.tag(true, false, true, true, false, false, on = true))
        assertEquals("[switch off]", ScreenWords.tag(true, false, true, true, false, false, on = false))
        assertEquals("[switch]", ScreenWords.tag(true, false, true, true, false, false, on = null))   // the phone does not say
        assertEquals("[switch]", ScreenWords.tag(true, false, true, true, false, false))
        assertEquals("[tap]", ScreenWords.tag(false, false, true, true, false, false, on = true))    // not a switch: as before
        assertTrue(ScreenWords.isSwitch("Wi-Fi [switch on]") && ScreenWords.isSwitch("Wi-Fi [switch off]") && ScreenWords.isSwitch("Wi-Fi [switch]"))
        assertFalse(ScreenWords.isSwitch("Wi-Fi [tap]"))
        // A screen whose only buttons are switches has words enough (no picture needed)
        assertFalse(ScreenWords.wordsShort(listOf("Wi-Fi [switch on]", "Network Assistant [text]", "More Settings [text]")))
        assertFalse(ScreenWords.wordsShort(listOf("Bluetooth [switch off]", "Paired devices [text]", "Device name [text]")))
    }

    @Test fun theSwitchBesideItsWord() {
        // His Wi-Fi page (1080 wide): the word "Wi-Fi" at the left of the first line, its switch at the right
        val wifi = ScreenWords.Box(40, 180, 160, 230)
        val sw = ScreenWords.Box(930, 175, 1030, 235)
        val lower = ScreenWords.Box(930, 420, 1030, 480)                     // another row's switch
        assertEquals(0, ScreenWords.rowSwitch(wifi, listOf(sw, lower)))
        assertEquals(1, ScreenWords.rowSwitch(wifi, listOf(lower, sw)))
        assertEquals(-1, ScreenWords.rowSwitch(wifi, listOf(lower)))        // nothing on its line
        assertEquals(-1, ScreenWords.rowSwitch(wifi, emptyList()))
        // A word in a two-line row (name, and a line under it): its switch sits between the two
        assertEquals(0, ScreenWords.rowSwitch(ScreenWords.Box(40, 300, 300, 345), listOf(ScreenWords.Box(930, 320, 1030, 380))))
        assertEquals(-1, ScreenWords.rowSwitch(ScreenWords.Box(500, 180, 700, 230), listOf(ScreenWords.Box(100, 175, 200, 235))))   // a switch to its left: not its own
        assertEquals(-1, ScreenWords.rowSwitch(ScreenWords.Box(0, 100, 1080, 1800), listOf(sw)))   // a whole page: not a word on a line
        assertEquals(-1, ScreenWords.rowSwitch(ScreenWords.Box(40, 180, 160, 180), listOf(sw)))    // nothing to measure
    }

    @Test fun theWiringIsThere() {
        val g = src("GuideService.kt")
        assertTrue(g.contains("val sw = switchNear(n) ?: rowSwitchOf(n, sws)"))
        assertTrue(g.contains("ScreenWords.tag(sw != null, n.isSelected, t.length <= 20, tappable(n), n.isEditable, n.isFocused, switchOn(sw))"))
        assertTrue(g.contains("sw?.takeIf { it.isCheckable }?.isChecked"))
        assertTrue(g.contains("!c.contains(\"CheckBox\") && !c.contains(\"Radio\")"))            // never ticks in a list
        val ring = g.substringAfter("val wantsSwitch = st.say.values.any { it.contains(\"switch\", true) }").substringBefore("show(r); track(rn)")
        assertTrue(ring.indexOf("rowSwitchOf(node, rowSwitches(nodes))") in ring.indexOf("switchNear(node)") until ring.indexOf("tileOf(node)"))
        assertTrue(ring.contains("if (wantsSwitch) rowSwitchOf("))                                 // only for a step about a switch
        assertTrue(ring.contains("no switch was found beside"))                                  // test phones see it
    }
}
