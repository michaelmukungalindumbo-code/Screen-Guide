package zm.screenguide

// v0.97 tests first: not built yet
object Shade {
    fun tiles(labels: List<String>): Int = 0
    fun fullyOpen(labels: List<String>) = false
    val KEYS = mapOf("en" to "")
    val MORE = mapOf("en" to "")
    fun missing(id: String): Map<String, String> = emptyMap()
    fun screenshotTaken(pkg: String, texts: List<String>): Boolean = false
}
