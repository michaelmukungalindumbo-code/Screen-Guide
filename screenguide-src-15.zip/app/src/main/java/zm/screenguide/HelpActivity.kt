package zm.screenguide

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.speech.RecognizerIntent
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.*

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

// A small chat that opens over the app the person is stuck in. They tap a reason or explain in their own words.
class HelpActivity : Activity() {
    private lateinit var log: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var showBtn: TextView
    private var lastLabel: String? = null
    private var lastSay = ""

    private val dark: Boolean get() = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    private val bgc: Int get() = if (dark) 0xFF14181B.toInt() else Color.WHITE
    private val ink: Int get() = if (dark) 0xFFF2F4F5.toInt() else 0xFF1F1A14.toInt()
    private val accent: Int get() = if (dark) 0xFF18C3DA.toInt() else 0xFF145A3D.toInt()
    private val onAccent: Int get() = if (dark) 0xFF06262C.toInt() else Color.WHITE
    private val soft: Int get() = if (dark) 0xFF1E2428.toInt() else 0xFFF1EADD.toInt()
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun box(c: Int, r: Int) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat() }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.setGravity(Gravity.BOTTOM)
        window.setLayout(MATCH, WRAP)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = box(bgc, 24); setPadding(dp(16), dp(14), dp(16), dp(14)) }
        root.addView(TextView(this).apply { text = "Tell me what is wrong"; textSize = 20f; typeface = Typeface.DEFAULT_BOLD; setTextColor(ink); setPadding(0, 0, 0, dp(8)) })

        val chips = LinearLayout(this)
        listOf("I can\u2019t find it", "Nothing happened", "It looks different", "I don\u2019t understand").forEach { r ->
            chips.addView(TextView(this).apply {
                text = r; textSize = 14f; setTextColor(accent); typeface = Typeface.DEFAULT_BOLD
                background = box(soft, 20); setPadding(dp(14), dp(10), dp(14), dp(10)); minHeight = dp(48); gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(WRAP, WRAP).apply { rightMargin = dp(8) }
                setOnClickListener { send(r) }
            })
        }
        root.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(chips) })

        log = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(6), 0, dp(6)) }
        scroll = ScrollView(this).apply { addView(log); layoutParams = LinearLayout.LayoutParams(MATCH, dp(200)) }
        root.addView(scroll)
        bubble("I am looking at your screen. Tap a reason, or tell me in your own words.", false)

        showBtn = TextView(this).apply {
            text = "Show me"; textSize = 17f; setTextColor(onAccent); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            background = box(accent, 26); setPadding(dp(20), dp(14), dp(20), dp(14)); visibility = View.GONE
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(8) }
            setOnClickListener { Guides.adopt(lastLabel, lastSay, Guides.lang); finish() }
        }
        root.addView(showBtn)

        input = EditText(this).apply {
            hint = "Type what is wrong"; setSingleLine(true); imeOptions = EditorInfo.IME_ACTION_SEND
            setTextColor(ink); setHintTextColor(if (dark) 0xFFADB5BA.toInt() else 0xFF534C45.toInt())
            layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
            setOnEditorActionListener { v, _, _ -> send(v.text.toString()); true }
        }
        val mic = ImageButton(this).apply {
            setImageResource(android.R.drawable.ic_btn_speak_now); setColorFilter(ink); background = box(soft, 24)
            layoutParams = LinearLayout.LayoutParams(dp(48), dp(48)).apply { leftMargin = dp(6) }
            contentDescription = "Speak"; setOnClickListener { listen() }
        }
        val sendBtn = TextView(this).apply {
            text = "Send"; textSize = 16f; setTextColor(onAccent); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            background = box(accent, 24); setPadding(dp(18), 0, dp(18), 0)
            layoutParams = LinearLayout.LayoutParams(WRAP, dp(48)).apply { leftMargin = dp(6) }
            setOnClickListener { send(input.text.toString()) }
        }
        root.addView(LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; addView(input); addView(mic); addView(sendBtn) })
        setContentView(root)
    }

    private fun bubble(text: String, mine: Boolean): TextView {
        val t = TextView(this).apply {
            this.text = text; textSize = 16f; setTextColor(if (mine) onAccent else ink)
            background = box(if (mine) accent else soft, 18); setPadding(dp(14), dp(10), dp(14), dp(10))
            layoutParams = LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(8); gravity = if (mine) Gravity.END else Gravity.START }
        }
        log.addView(t)
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        return t
    }

    private fun send(note: String) {
        val n = note.trim()
        if (n.isEmpty()) return
        bubble(n, true); input.setText(""); showBtn.visibility = View.GONE
        val thinking = bubble("Thinking\u2026 looking carefully at your screen", false)
        val id = Server.installId(this)
        Thread {
            val r = Server.next(Guides.chatGoal, Guides.lang, id, Guides.chatLabels, Guides.chatHistory, true, emptyList(), n)
            runOnUiThread {
                thinking.text = r.say.ifBlank { "I am not sure. Tell me more." }
                lastLabel = r.label; lastSay = r.say
                Guides.chatHistory = Guides.chatHistory + ("User said: " + n) + ("Told: " + r.say)
                showBtn.visibility = if (r.label != null) View.VISIBLE else View.GONE
                scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
            }
        }.start()
    }

    private fun listen() {
        try {
            startActivityForResult(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM), 11)
        } catch (e: ActivityNotFoundException) { Toast.makeText(this, "Voice input is not available on this phone", Toast.LENGTH_LONG).show() }
    }

    override fun onActivityResult(rc: Int, res: Int, data: Intent?) {
        super.onActivityResult(rc, res, data)
        if (rc == 11 && res == RESULT_OK) data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let { send(it) }
    }
}
