package zm.screenguide

import java.io.File
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

// v0.118, the owner's phone (12 Nov, 0.116): his taught task "How to use the past papers app" (4 steps). On the list of
// all apps, at step 1 ("Type Pap, then tap Past Papers ZM"), the guide jumped to step 3, "Type English, then tap
// English": a button inside Past Papers ZM. It rang the "English" dictionary app's icon, and he ended up in the wrong app.
class TaughtAppsTest {
    private val papers = "zm.pastpapers"; private val dictionary = "com.dictionary.english"

    @Test fun aTaughtStepIsOnlyLookedForWhereItWasTaught() {
        // His guide, as it would be taught now: step 1 on the app list, steps 2 to 4 inside Past Papers ZM
        assertTrue(StepNav.mayLook(0, 0, Teach.HOME, "com.transsion.launcher", home = true, builtIn = false))
        assertFalse(StepNav.mayLook(2, 0, papers, "com.transsion.launcher", home = true, builtIn = false))   // "English" on the app list: not this step
        assertFalse(StepNav.mayLook(2, 1, papers, dictionary, home = false, builtIn = false))               // inside the dictionary: not this step
        assertTrue(StepNav.mayLook(2, 1, papers, papers, home = false, builtIn = false))
        assertFalse(StepNav.mayLook(0, 0, Teach.HOME, papers, home = false, builtIn = false))
        // His recording as it is (made before this version, so its steps do not know their app): never further ahead than the next step
        assertTrue(StepNav.mayLook(0, 0, null, "launcher", true, builtIn = false)); assertTrue(StepNav.mayLook(1, 0, null, "launcher", true, builtIn = false))
        assertFalse(StepNav.mayLook(2, 0, null, "launcher", true, builtIn = false))                         // the jump to step 3
        assertTrue(StepNav.mayLook(3, 2, null, papers, false, builtIn = false))
        // Built-in guides: as before (they skip steps a phone maker does not have)
        assertTrue(StepNav.mayLook(3, 0, null, "com.android.settings", false, builtIn = true))
    }

    @Test fun eachStepRemembersItsApp() {
        Teach.reset("How to use the past papers app")
        Teach.at = Teach.HOME; Teach.typedIn("Pap"); assertTrue(Teach.tap("Past Papers ZM", false))
        Teach.at = papers; assertTrue(Teach.tap("Grade 12", false)); Teach.unknown(listOf("English", "Maths"))
        assertEquals(listOf(Teach.HOME, papers, papers), Teach.steps.map { it.app })
        assertTrue(Teach.answer(2, "English")); assertEquals(papers, Teach.steps[2].app)             // answered: still in its app
        // Kept on the phone, and back again
        val saved = Teach.pending(); Teach.reset(""); assertTrue(Teach.restore(saved))
        assertEquals(listOf(Teach.HOME, papers, papers), Teach.steps.map { it.app })
        assertEquals(listOf(Teach.HOME, papers, papers), Teach.guide()!!.steps.map { it.app })
        Teach.reset("")
        // A saved task from before this version: no app, as before
        val old = JSONArray().put(JSONObject().put("k", "x").put("t", "x").put("sw", false)
            .put("st", JSONArray().put(JSONObject().put("m", JSONArray().put("Drive")).put("s", JSONObject().put("en", "Tap Drive.")))))
        assertNull(Recipes.parse(old)[0].guide.steps[0].app)
    }

    @Test fun theWiringIsThere() {
        val g = listOf("src/main/java/zm/screenguide/GuideService.kt", "app/src/main/java/zm/screenguide/GuideService.kt").map { File(it) }.first { it.exists() }.readText()
        val loop = g.substringAfter("for (i in guide.steps.size - 1 downTo 0) {").substringBefore("val node = find(nodes, guide.steps[i])")
        assertTrue(loop.contains("if (!StepNav.mayLook(i, Guides.index, guide.steps[i].app, pkg, isHome(pkg), Guides.all.any { it.id == guide.id })) continue"))
        assertTrue(g.contains("Teach.at = if (isHome(pkg)) Teach.HOME else pkg   // v0.118: where this step is"))
        assertTrue(g.contains("Teach.at = if (isHome(was)) Teach.HOME else was"))
    }
}
