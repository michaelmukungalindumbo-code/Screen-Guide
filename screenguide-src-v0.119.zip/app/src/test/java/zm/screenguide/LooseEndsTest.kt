package zm.screenguide

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test

// v0.115, the owner (11 Nov): "Kindly work on other issues you can identify, take your time, go through the code."
class LooseEndsTest {
    private fun src(n: String) = listOf("src/main/java/zm/screenguide/$n", "app/src/main/java/zm/screenguide/$n").map { File(it) }.first { it.exists() }.readText()

    // #73 (his phone, "Install … from the Play Store"): the search box was open, the keyboard up, and the guide said "Tap
    // the search bar" again. The screen as the report gives it: nothing marked as the box being typed in.
    @Test fun anOpenBoxIsKnownByItsKeyboard() {
        val play = listOf("… [text]", "More options [tap]", "Search apps & games [tap]", "Navigate up [tap]")
        assertEquals(listOf("… [text]", "More options [tap]", "Search apps & games [typing]", "Navigate up [tap]"),
            ScreenWords.withKeyboard(play, listOf(2), keyboardUp = true))
        assertSame(play, ScreenWords.withKeyboard(play, listOf(2), keyboardUp = false))               // no keyboard: as before
        val marked = listOf("Search [typing]", "Cancel [tap]")
        assertSame(marked, ScreenWords.withKeyboard(marked, listOf(0), keyboardUp = true))             // already marked: as before
        assertEquals(play + "Text box [typing]", ScreenWords.withKeyboard(play, emptyList(), keyboardUp = true))   // the screen names no box
        assertEquals(play + "Text box [typing]", ScreenWords.withKeyboard(play, listOf(9), keyboardUp = true))
        assertTrue(src("GuideService.kt").contains("return ScreenWords.withKeyboard(out.toList(), if (boxAt >= 0) listOf(boxAt) else emptyList(), imeTop != null)"))
    }

    // A taught task ends with a tap the phone may never report: done when its last button was rung and the page moved on
    @Test fun aTaughtTaskFinishesWithoutTheTapBeingReported() {
        assertTrue(StepNav.lastTapDone("last_tap", false, false, lastWasRung = true, pageOpenedSince = true, nowHome = false))
        assertFalse(StepNav.lastTapDone("last_tap", false, false, lastWasRung = true, pageOpenedSince = false, nowHome = false))   // still on that page
        assertFalse(StepNav.lastTapDone("last_tap", false, false, lastWasRung = false, pageOpenedSince = true, nowHome = false))   // never got to the last step
        assertFalse(StepNav.lastTapDone("last_tap", false, false, lastWasRung = true, pageOpenedSince = true, nowHome = true))     // they went Home: not done
        assertFalse(StepNav.lastTapDone("last_tap", true, false, true, true, false))                  // the pull-down panel: as before
        assertFalse(StepNav.lastTapDone("last_tap", false, true, true, true, false))                  // a switch: as before
        assertFalse(StepNav.lastTapDone("wifi_on", false, false, true, true, false)); assertFalse(StepNav.lastTapDone(null, false, false, true, true, false))
        val g = src("GuideService.kt")
        assertTrue(g.contains("if (i == guide.steps.size - 1) lastRungAt = System.currentTimeMillis()"))
        assertTrue(g.contains("WatchShots.clear(); lastRungAt = 0L"))                                 // a new guide starts afresh
    }

    // The voice is chosen once, not looked up among all the phone's voices before every sentence
    @Test fun theVoiceIsChosenOnce() {
        val s = src("Speech.kt")
        val tune = s.substringAfter("    fun tune(c: Context, t: TextToSpeech, lang: String): Boolean {").substringBefore("    fun say(")
        assertTrue(tune.indexOf("if (picked[use.language] != null && t.voice?.name == picked[use.language])") in 1 until tune.indexOf("val all = t.voices"))
        assertTrue(tune.contains("t.setSpeechRate(pace(Profile.speechRate(c))); return ok"))          // their speed still counts each time
    }
}
