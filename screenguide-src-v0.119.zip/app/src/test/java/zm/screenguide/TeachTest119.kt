package zm.screenguide

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

// v0.119, the owner's phone (12 Nov, 0.118): Teach a task through the Drive scan again. The bar counted better, but:
// opening Drive from the home screen's Search became a question; only one question was kept for +, Scan, the camera
// and Next; and "Try it yourself", with two questions unanswered, began in the middle and searched the apps for "Upload".
class TeachTest119 {
    private fun src(n: String) = listOf("src/main/java/zm/screenguide/$n", "app/src/main/java/zm/screenguide/$n").map { File(it) }.first { it.exists() }.readText()

    @Test fun anAppOpenedFromTheHomeScreensSearch() {
        assertTrue(Teach.openedFrom("com.transsion.XOSLauncher", wasHome = true))
        assertTrue(Teach.openedFrom("com.transsion.search", wasHome = false))                  // Infinix's Search is a screen of its own
        assertTrue(Teach.openedFrom("com.sec.android.app.launcher", wasHome = false))
        assertFalse(Teach.openedFrom("com.google.android.apps.docs", wasHome = false))         // Drive opening Google's scanner: not a tap on an icon
        val g = src("GuideService.kt")
        assertTrue(g.contains("was != pkg && Teach.openedFrom(was, isHome(was)) && packageManager.getLaunchIntentForPackage(pkg) != null -> Teach.opened(screenName(pkg))"))
    }

    @Test fun everyNewScreenGetsItsQuestion() {
        Teach.reset("Scan")
        Teach.at = "drive"; assertTrue(Teach.unknown(listOf("Google Docs", "Scan", "Upload")))
        Teach.at = "gms"; assertTrue(Teach.unknown(emptyList()))                               // the camera: no words
        assertFalse(Teach.unknown(emptyList()))                                                 // the same screen again: once
        Teach.at = "gms"; assertTrue(Teach.unknown(listOf("Discard scan", "Next")))             // the page after the photo
        assertEquals(3, Teach.open())
        Teach.reset("")
    }

    @Test fun onlyAppsAreSearchedForAmongTheApps() {
        val apps = listOf("Drive", "Past Papers ZM", "WhatsApp", "Settings")
        assertTrue(FindApp.isAppName("Drive", apps)); assertTrue(FindApp.isAppName("past papers zm", apps))
        assertFalse(FindApp.isAppName("Upload", apps)); assertFalse(FindApp.isAppName("", apps))
        assertTrue(src("GuideService.kt").contains("if (word != null && (home || searchSaid == word) && FindApp.isAppName(word, launcherNames())) {"))
    }

    @Test fun questionsBeforeTryingOrSharing() {
        val m = src("MainActivity.kt")
        assertTrue(m.contains("Row(\"play\", \"Try it yourself first\") { answerFirst { Teach.guide()?.let { start(it) } } }"))
        assertTrue(m.contains("Row(\"share\", \"Share it (WhatsApp and more)\") { answerFirst { shareTaught() } }"))
        assertTrue(m.contains("Row(\"check\", \"Save it on this phone\") { answerFirst {"))
        assertTrue(m.contains(".setPositiveButton(\"Answer now\") { _, _ -> askTaught(first) }"))
        assertTrue(Teach.UNANSWERED.contains("left out"))
    }
}
