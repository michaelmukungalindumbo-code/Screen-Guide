package zm.screenguide

import java.io.File
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

// v0.116, the owner (12 Nov): "Where can I find teach a task recordings in ScreenGuide, where are they stored?"; then,
// with two recordings of the menu and Learn your phone: "I haven't seen anything like that. I need to save or delete or
// share." His recording waited under "Share what you taught" (lost when ScreenGuide closed), and Learn your phone
// showed only the newest four kept tasks, with nothing saying which ones he had taught.
class TaughtTasksTest {
    private fun src(n: String) = listOf("src/main/java/zm/screenguide/$n", "app/src/main/java/zm/screenguide/$n").map { File(it) }.first { it.exists() }.readText()
    private fun kept(t: String, by: String?) = JSONObject().put("k", t.lowercase()).put("t", t).put("sw", false)
        .put("st", JSONArray().put(JSONObject().put("m", JSONArray().put("Drive")).put("s", JSONObject().put("en", "Tap “Drive”."))))
        .apply { if (by != null) put("by", by) }

    @Test fun everyKeptTaskSaysWhoMadeIt() {
        val a = JSONArray().put(kept("Old Smart guide task", null)).put(kept("Shared by a friend", "shared"))
        (1..6).forEach { a.put(kept("Taught $it", "me")) }
        val all = Recipes.parse(a)
        assertEquals(8, all.size)                                                       // all of them, not the newest four
        assertEquals("Taught 6", all.first().title)                                     // newest first
        assertEquals(listOf("Taught by you", "Shared with you", "Learned by ScreenGuide"), listOf("me", "shared", "").map { Recipes.label(it) })
        assertEquals(6, all.count { it.by == Recipes.ME }); assertEquals("", all.last().by)
        assertEquals(1, all.first().steps); assertEquals(listOf("Drive"), all.first().guide.steps[0].match)
    }

    // The recording waits on the phone until it is saved, shared or thrown away (it was lost when ScreenGuide closed)
    @Test fun aRecordingSurvivesClosing() {
        Teach.reset("How to scan a document")
        Teach.opened("Drive"); Teach.unknown(listOf("Scan", "Upload", "Folder")); Teach.typedIn("Scanned document.pdf"); Teach.tap("Upload", false)
        val saved = Teach.pending()
        Teach.reset("")                                                                 // ScreenGuide closed
        assertTrue(Teach.restore(saved))
        assertEquals("How to scan a document", Teach.title)
        assertEquals(listOf("Tap “Drive”.", "What did you tap here?", "Type “Scanned document.pdf”, then tap “Upload”."), Teach.steps.map { it.say["en"] })
        assertEquals(listOf("Scan", "Upload", "Folder"), Teach.choices(1))              // the question still has its choices
        assertTrue(Teach.answer(1, "Scan"))
        assertFalse(Teach.restore(saved))                                               // never over a recording already there
        Teach.reset(""); assertFalse(Teach.restore("not json")); assertTrue(Teach.steps.isEmpty()); assertFalse(Teach.restore(null))
    }

    @Test fun theWiringIsThere() {
        val m = src("MainActivity.kt")
        assertTrue(m.contains("if (taught > 0) rows.add(Row(\"share\", \"Your taught tasks\", taught.toString()) { showTaught() })"))
        val one = m.substringAfter("    private fun taughtOne(k: Recipes.Kept) {").substringBefore("    private fun shareKept(")
        assertTrue(one.contains("\"Start it\"") && one.contains("\"Share it (WhatsApp and more)\"") && one.contains("\"Delete it\""))   // save, share, delete
        assertTrue(m.contains("Recipes.save(this, Teach.title, g.steps, g.steps.last().toggle, Recipes.ME)"))
        assertTrue(m.contains("Recipes.save(this, title, g.steps, j.optBoolean(\"sw\"), Recipes.SHARED)"))
        assertTrue(m.contains("Teach.restore(getSharedPreferences(\"sg\", MODE_PRIVATE).getString(\"teach_pending\", null))"))
        assertTrue(src("GuideService.kt").contains("putString(\"teach_pending\", Teach.pending())"))
        assertFalse(m.contains("Recipes.recent(this, 4)"))
        assertTrue(m.contains("private fun taughtDone() { Teach.reset(\"\"); getSharedPreferences(\"sg\", MODE_PRIVATE).edit().remove(\"teach_pending\").apply() }"))
    }
}
