package zm.screenguide

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

// v0.113, the owner's phone (11 Nov, twice): "Scan a document with Drive". On Drive's camera and scan pages the guide
// stopped: "I cannot read the words in this app. Turn on Screen pictures…". "This issue keeps appearing."
class BlindStepTest {
    @Test fun askedOnceForEachScreen() {
        val camera = ScreenWords.blindKey("com.google.android.gms", 1000L)
        assertTrue(ScreenWords.askBlind(camera, "", 0L))                                     // a screen with no words: the helper is asked
        assertFalse(ScreenWords.askBlind(camera, camera, 1500L))                             // the same screen a moment later: not again
        assertFalse(ScreenWords.askBlind(camera, camera, 19_000L))
        assertTrue(ScreenWords.askBlind(camera, camera, 21_000L))                            // still there much later: once more
        val preview = ScreenWords.blindKey("com.google.android.gms", 9000L)                  // the next page of the same app
        assertNotEquals(camera, preview); assertTrue(ScreenWords.askBlind(preview, camera, 500L))
        assertEquals(camera, ScreenWords.blindKey("com.google.android.gms", 1000L))          // the camera's moving picture: the same screen
    }

    @Test fun theWiringIsThere() {
        val g = listOf("src/main/java/zm/screenguide/GuideService.kt", "app/src/main/java/zm/screenguide/GuideService.kt").map { File(it) }.first { it.exists() }.readText()
        val blind = g.substringAfter("        if (labels.isEmpty() && !wantShot) {").substringBefore("        Stats.inc(this, \"ai_steps\")")
        assertTrue(blind.contains("val ask = ScreenWords.askBlind(key, blindKey, nowMs - blindAt)"))
        assertTrue(blind.contains("val key = ScreenWords.blindKey(pkg, screenAt)"))
        assertTrue(blind.contains("            if (!ask) return\n        }"))                // asked: the step goes to the helper, as any other
        assertTrue(blind.contains("else showLabel(ScreenWords.blindCard(blindSay, when {"))   // v0.114: the helper's words stay on the card (BlindCardTest)
        assertTrue(blind.contains("I cannot read the words in this app"))                    // the old words, when it cannot be asked
        // Money apps and password screens never get this far: they are stopped before any step is asked for
        assertTrue(g.contains("private fun sensitive(pkg: String, nodes: List<AccessibilityNodeInfo>) = blockedApps.any { pkg.contains(it, true) } || nodes.any { it.isPassword }"))
    }
}
