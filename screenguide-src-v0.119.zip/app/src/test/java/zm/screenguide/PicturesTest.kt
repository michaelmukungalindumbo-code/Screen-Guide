package zm.screenguide

import java.io.File
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

// v0.117, the owner (12 Nov): "'See your screen'… when allowed, don't you think it would help with the accuracy of
// ScreenGuide?" Yes: a picture only where the screen's words are not enough, for people who said yes, offered at setup.
class PicturesTest {
    private fun src(n: String) = listOf("src/main/java/zm/screenguide/$n", "app/src/main/java/zm/screenguide/$n").map { File(it) }.first { it.exists() }.readText()

    @Test fun whenWordsAreNotEnough() {
        assertTrue(ScreenWords.wordsShort(emptyList()))                                              // Drive's scan pages
        assertTrue(ScreenWords.wordsShort(listOf("Upload [tap]", "Cancel [tap]")))                   // almost no words, as before
        // Icons only: the screen has words, but nothing that can be tapped has a name
        assertTrue(ScreenWords.wordsShort(listOf("Position document in frame [text]", "Google Drive [text]", "Auto capture [text]", "Manual [text]")))
        assertFalse(ScreenWords.wordsShort(listOf("Enhance [tap]", "Filters [tap]", "Discard scan [tap]", "Next [tap]")))   // named buttons: words are enough
        assertFalse(ScreenWords.wordsShort(listOf("Wi-Fi [switch]", "Network & internet [text]", "Saved networks [text]")))
        assertFalse(ScreenWords.wordsShort(listOf("Search apps & games [typing]", "Apps [text]", "Games [text]")))
    }

    // Offered at setup with the other extra help; a "no" from before is asked about once more, never again after that
    @Test fun askedAtSetupAndOnceMore() {
        assertTrue(ScreenWords.offerPicturesAgain(34, decided = true, saidYes = false, askedAgain = false))
        assertFalse(ScreenWords.offerPicturesAgain(34, decided = true, saidYes = false, askedAgain = true))   // never a second time
        assertFalse(ScreenWords.offerPicturesAgain(34, decided = true, saidYes = true, askedAgain = false))
        assertFalse(ScreenWords.offerPicturesAgain(34, decided = false, saidYes = false, askedAgain = false))  // never asked: asked when it helps, as before
        assertFalse(ScreenWords.offerPicturesAgain(29, decided = true, saidYes = false, askedAgain = false))  // Android 10 and older cannot take them
        assertTrue(ScreenWords.PICTURES.contains("Never on bank, money or password screens"))
        val m = src("MainActivity.kt")
        assertTrue(m.contains("(if (pics) arrayOf(ScreenWords.PICTURES) else emptyArray())") && m.contains("(if (pics) arrayOf(\"shot_ok\") else emptyArray())"))
        assertTrue(m.contains("if (k == \"shot_ok\") e.putBoolean(\"shot_auto\", pick[i])"))
    }

    @Test fun theWiringIsThere() {
        val g = src("GuideService.kt")
        assertTrue(g.contains("val wordsShort = ScreenWords.wordsShort(labels) || wantPicture"))
        assertTrue(g.contains("try { w.addView(card, lp); askCard = card } catch (e: Exception) {}"))   // a card that failed is not a "no"
        assertFalse(g.contains("catch (e: Exception) { prefs.edit().putBoolean(\"shot_ok\", false).apply() }"))
        // Still never from money apps or password screens: nothing is sent from them at all
        assertTrue(g.contains("if (sensitive(pkg, nodes)) {   // nothing is sent from these screens"))
    }
}
