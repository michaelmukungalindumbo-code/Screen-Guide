package zm.screenguide

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

// v0.114, the owner's phone (11 Nov, 0.113, the first test of the words-only step, on Drive's page after the photo):
// the helper's words came, were replaced a moment later by "Looking at your screen…", then by the old "I cannot read
// the words in this app", again and again. And its instruction was the camera page's, on the page after it.
class BlindCardTest {
    private val old = "I cannot read the words in this app. Turn on Screen pictures in ScreenGuide’s settings, or ask someone you trust."

    @Test fun theHelpersWordsStay() {
        assertEquals("I can’t see this screen. Tap “Next” at the bottom right.",
            ScreenWords.blindCard("I can’t see this screen. Tap “Next” at the bottom right.", old, false, "x"))
        assertEquals(old, ScreenWords.blindCard("", old, false, "x"))                        // the helper has not answered (yet): the old words
        assertEquals(old, ScreenWords.blindCard("  ", old, false, "x"))
        // Test phones: what was found is on the card itself
        assertEquals("Tap Next.\n[Test: No words found: 12 things with no name, in 3 windows.]",
            ScreenWords.blindCard("Tap Next.", old, true, ScreenWords.noWordsNote(12, 3)))
    }

    // The camera page is the first unseen screen, the page after the photo the second: the helper is told which
    @Test fun unseenScreensInARow() {
        var row = 0
        row = ScreenWords.blindRow(row, newScreen = true, hasWords = false); assertEquals(1, row)     // the camera
        row = ScreenWords.blindRow(row, newScreen = false, hasWords = false); assertEquals(1, row)    // still the camera
        row = ScreenWords.blindRow(row, newScreen = true, hasWords = false); assertEquals(2, row)     // the page after the photo
        row = ScreenWords.blindRow(row, newScreen = false, hasWords = true); assertEquals(0, row)     // a screen it can read: starts afresh
    }

    @Test fun theWiringIsThere() {
        fun src(n: String) = listOf("src/main/java/zm/screenguide/$n", "app/src/main/java/zm/screenguide/$n").map { File(it) }.first { it.exists() }.readText()
        val g = src("GuideService.kt")
        val blind = g.substringAfter("        if (labels.isEmpty() && !wantShot) {").substringBefore("        Stats.inc(this, \"ai_steps\")")
        assertTrue(blind.contains("else showLabel(ScreenWords.blindCard(blindSay, when {"))
        assertTrue(blind.contains("if (ask) { if (key != blindKey) blindSay = \"\"; blindKey = key; blindAt = nowMs }"))   // a new screen: its own words
        assertTrue(g.contains("if (labels.isEmpty() && image.isEmpty() && !r.done) blindSay = r.say"))
        assertTrue(g.contains("val row = if (labels.isEmpty()) blindRow else 0") && g.contains("val r = Server.unseen(row) { Server.next("))
        assertTrue(src("Server.kt").contains("(unseenRow.get() ?: 0).let { if (it > 0) body.put(\"blind\", it) }"))
    }
}
