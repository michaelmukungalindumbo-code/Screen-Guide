package zm.screenguide

// The tag after each screen word that goes to the server, so the AI knows what the word is. The phone reads the screen;
// the deciding is here, so it can be tested.
// [switch] its row has an on/off switch; [selected] a tab already chosen; [tap] can be tapped; [text] plain text;
// [typing] a text box that is open, with the keyboard up. 5 Nov: in the Play Store the search box read the same before
// and after it was tapped ("Search apps & games [tap]"), so the guide said "tap the search box" again and again.
object ScreenWords {
    // v0.107 (the owner's phone, 11 Nov, Drive's scan page): "I cannot read the words in this app" on a page with Enhance,
    // Filters, Crop, Discard scan and Next on it. The window Android calls "active" had no words; the page's buttons
    // were in another of the app's windows, which was only read when it lay on top. With no words at all in the usual
    // place, every other window of an ordinary app is read too (never ScreenGuide's own, the keyboard, the phone's bars,
    // or a money app).
    fun readOtherWindows(words: Int) = words == 0
    fun otherWindowOk(pkg: String?, own: String, blocked: List<String>): Boolean =
        !pkg.isNullOrEmpty() && pkg != own && !pkg.contains("systemui", true) && !pkg.contains("inputmethod", true) && blocked.none { pkg.contains(it, true) }
    // v0.113 (the owner's phone, 11 Nov, "This issue keeps appearing"): Drive's camera and scan pages share no words at
    // all, in any window. That used to be the end of the guide. Now the helper is asked anyway, once for each such
    // screen: it says it cannot see the screen and what people usually tap there (the server's "blind step"; it never
    // points). The old words stay for when that cannot be asked again so soon.
    // One screen: the app, and when it last opened a new page (a camera picture moving does not make it a new screen)
    fun blindKey(pkg: String, pageOpenedAt: Long) = "$pkg/$pageOpenedAt"
    fun askBlind(key: String, lastKey: String, sinceMs: Long) = key != lastKey || sinceMs > 20_000L

    // v0.114 (the owner's test of 0.113, 11 Nov): the helper's words for a screen it cannot see were replaced a moment
    // later by "Looking at your screen…" and then by the old "I cannot read the words" card, over and over. They now stay
    // for as long as that screen does. Test phones also see, on the card itself, what was found there (the test strip's
    // own line did not show in his recordings).
    fun blindCard(helperSaid: String, oldWords: String, tester: Boolean, found: String): String =
        helperSaid.ifBlank { oldWords } + (if (tester) "\n[Test: $found]" else "")
    // How many screens with no words have come in a row (the helper is told: the second is the page AFTER the first)
    fun blindRow(row: Int, newScreen: Boolean, hasWords: Boolean) = if (hasWords) 0 else if (newScreen) row + 1 else row

    // v0.115 (#73, the owner's phone, 11 Nov, "Install … from the Play Store"): Play Store's search box was open with the
    // keyboard up, and the guide said "Tap the search bar" again. An open box is marked [typing] so the helper says what
    // to type, but this box did not say it was the one being typed in. With the keyboard up and no box marked, the
    // screen's text box is marked; if the screen names no box at all, one line says a box is open.
    const val OPEN_BOX = "Text box [typing]"
    fun withKeyboard(labels: List<String>, boxes: List<Int>, keyboardUp: Boolean): List<String> {
        if (!keyboardUp || labels.any { it.endsWith("[typing]") }) return labels
        val i = boxes.firstOrNull { it in labels.indices } ?: return labels + OPEN_BOX
        return labels.mapIndexed { k, l -> if (k == i) l.substringBeforeLast(" [") + " [typing]" else l }
    }

    // v0.117 (the owner, 12 Nov: screen pictures "when allowed… would help with the accuracy"): words are not enough not
    // only when there are almost none, but when nothing on the screen that can be tapped has a name (icons only: a tick,
    // an arrow, a camera button). Then, for people who said yes, a picture of the screen goes with the step.
    fun wordsShort(labels: List<String>): Boolean =
        labels.size < 3 || labels.none { l -> listOf("[tap]", "[switch]", "[typing]", "[selected]").any { l.endsWith(it) } }
    // Screen pictures, offered at setup with the other extra help (ticked, the person chooses). Someone who said no before
    // is asked once more, at the next start, with the clearer words: never again after that.
    const val PICTURES = "Screen pictures: when a screen's words are not enough (buttons with only an icon, or a screen with no words), " +
        "ScreenGuide sends a picture of that screen to find the button. Never on bank, money or password screens."
    fun offerPicturesAgain(sdk: Int, decided: Boolean, saidYes: Boolean, askedAgain: Boolean) = sdk >= 30 && decided && !saidYes && !askedAgain

    // Test phones: what was there when no words were found, so the next recording shows the cause
    fun noWordsNote(things: Int, windows: Int) = "No words found: $things thing" + (if (things == 1) "" else "s") + " with no name, in $windows window" + (if (windows == 1) "" else "s") + "."

    fun tag(switch: Boolean, selected: Boolean, short: Boolean, tappable: Boolean, editable: Boolean, focused: Boolean): String = when {
        switch -> "[switch]"
        editable && focused -> "[typing]"
        selected && short && tappable -> "[selected]"
        tappable -> "[tap]"
        else -> "[text]"
    }
}
