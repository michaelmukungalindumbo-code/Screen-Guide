package zm.screenguide

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

// v0.104 (the owner, 10 Nov: "Work on the voice, I want it to sound natural"). ScreenGuide used whatever voice the phone
// gave first, at full speed, in one breath. Now:
// - Google's speech engine when the phone has it (its newer voices are the natural ones);
// - of that engine's voices for the language, the best one already on the phone (never one that needs the internet for
//   every sentence: weak networks, and data costs money);
// - a calmer pace, and a short pause between sentences.
// No paid online voice: nothing spoken leaves the phone. Plain functions first, so a unit test can check them.
object Speech {
    const val GOOGLE = "com.google.android.tts"
    const val NATURAL = 400          // Android's own mark for a high-quality voice (Voice.QUALITY_HIGH)
    const val PAUSE_MS = 280L        // between sentences
    class V(val name: String, val lang: String, val country: String, val quality: Int, val needsNet: Boolean, val missing: Boolean)

    // The best voice for the language that works with no internet: the highest quality; among equals the phone's own
    // country, then British, then American English (what Zambian schools and radio sound closest to).
    fun best(voices: List<V>, lang: String, homeCountry: String = ""): V? {
        val order = listOf(homeCountry.uppercase(), "GB", "US").filter { it.isNotEmpty() }
        return voices.filter { it.lang.equals(lang, true) && !it.needsNet && !it.missing }
            .sortedWith(compareBy<V>({ -it.quality }, { v -> order.indexOf(v.country.uppercase()).let { if (it < 0) 99 else it } }, { it.name }))
            .firstOrNull()
    }
    fun natural(quality: Int) = quality >= NATURAL
    fun pace(chosen: Float) = chosen * 0.92f                                   // calmer than the phone's own speed
    // One sentence at a time, so there is a breath between them. "e.g." and "0:14" are not sentence ends.
    fun sentences(text: String): List<String> =
        text.replace(Regex("\\s+"), " ").trim().split(Regex("(?<=[.!?…])\\s+(?=[\\p{Lu}\\p{N}“\"(])")).map { it.trim() }.filter { it.isNotEmpty() }

    fun label(quality: Int) = when { quality < 0 -> "Not checked yet"; natural(quality) -> "Natural"; else -> "Basic" }
    // English only, like the other new words
    const val NOTE_BASIC = "This phone's voice is a basic one, so it can sound like a robot. For a more natural voice: open the phone's voice settings " +
        "below, choose “Speech Services by Google” as the engine, tap its settings, then “Install voice data”, choose English and download a voice. " +
        "It is free, but the download uses data (about 20 MB), so Wi-Fi is best. ScreenGuide then uses it by itself."
    const val NOTE_NATURAL = "ScreenGuide is using the most natural voice on this phone. You can choose another in the phone's voice settings below."
    const val NOTE_UNKNOWN = "ScreenGuide uses the most natural voice on this phone. Start a guide once so the voice can be checked, then look here again."
    fun note(quality: Int) = when { quality < 0 -> NOTE_UNKNOWN; natural(quality) -> NOTE_NATURAL; else -> NOTE_BASIC }

    // ---- on the phone ----
    // Google's engine only when it is on the phone AND switched on (v0.106, health check: a phone where it is turned off
    // would have had no voice at all)
    fun pickEngine(installed: Boolean, enabled: Boolean): String? = if (installed && enabled) GOOGLE else null
    fun engine(c: Context): String? = try { pickEngine(true, c.packageManager.getApplicationInfo(GOOGLE, 0).enabled) } catch (e: Exception) { null }
    // usedGoogle: Google's engine was asked for. If it does not start, the caller starts the phone's own (fallback()).
    fun create(c: Context, onReady: (ok: Boolean, usedGoogle: Boolean) -> Unit): TextToSpeech {
        val e = engine(c)
        val l = TextToSpeech.OnInitListener { s -> onReady(s == TextToSpeech.SUCCESS, e != null) }
        return if (e != null) TextToSpeech(c, l, e) else TextToSpeech(c, l)
    }
    fun fallback(c: Context, onReady: (Boolean) -> Unit): TextToSpeech = TextToSpeech(c) { s -> onReady(s == TextToSpeech.SUCCESS) }

    private val picked = HashMap<String, String>()   // language -> the voice chosen for it (looked up once)
    // The language (English when the phone has no voice for it), the best voice, the calmer pace. True: the language is spoken.
    fun tune(c: Context, t: TextToSpeech, lang: String): Boolean {
        val loc = Locale.forLanguageTag(lang)
        val ok = try { t.isLanguageAvailable(loc) >= TextToSpeech.LANG_AVAILABLE } catch (e: Exception) { false }
        val use = if (ok) loc else Locale.ENGLISH
        try {
            // v0.115: the voice was looked up among all the phone's voices before every sentence. Once chosen, it is kept.
            if (picked[use.language] != null && t.voice?.name == picked[use.language]) { t.setSpeechRate(pace(Profile.speechRate(c))); return ok }
            t.language = use
            val all = t.voices
            if (all != null) {
                val name = picked[use.language] ?: best(all.filterNotNull().map { v ->
                    V(v.name, v.locale.language, v.locale.country, v.quality, v.isNetworkConnectionRequired,
                        v.features?.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED) == true)
                }, use.language, t.defaultVoice?.locale?.country ?: "")?.name
                val voice = all.firstOrNull { it != null && it.name == name }
                if (voice != null) {
                    picked[use.language] = voice.name; t.voice = voice
                    if (use.language == "en") c.getSharedPreferences("sg", Context.MODE_PRIVATE).edit().putInt("voice_quality", voice.quality).apply()
                }
            }
        } catch (e: Exception) {}
        try { t.setSpeechRate(pace(Profile.speechRate(c))); t.setPitch(1.0f) } catch (e: Exception) {}
        return ok
    }
    fun say(t: TextToSpeech, text: String, id: String) {
        val parts = sentences(text)
        parts.forEachIndexed { i, p ->
            t.speak(p, if (i == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, if (i == parts.size - 1) id else "$id.$i")
            if (i < parts.size - 1) t.playSilentUtterance(PAUSE_MS, TextToSpeech.QUEUE_ADD, "$id.p$i")
        }
    }
    fun forget() = picked.clear()   // the person may have installed a better voice
}
